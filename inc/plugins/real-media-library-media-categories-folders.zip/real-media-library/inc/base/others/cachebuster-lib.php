<?php
// Cachebusters generated on 2025-12-02 07:02:13
return [
	'antd' => '3.8.4',
	'classnames' => '2.5.1',
	'i18n-react' => '0.7.0',
	'jquery' => '3.7.1',
	'lil-uri' => '0.3.1',
	'mobx' => '4.15.7',
	'mobx-react' => '6.3.1',
	'mobx-state-tree' => '3.17.3',
	'react' => '18.3.1',
	'react-dom' => '18.3.1'
];
