<?php

namespace MatthiasWeb\RealMediaLibrary\overrides\interfce\comp;

// @codeCoverageIgnoreStart
\defined('ABSPATH') or die('No script kiddies please!');
// Avoid direct file request
// @codeCoverageIgnoreEnd
/** @internal */
interface IOverrideWPML
{
    // Most methods Defined in IFolder interface.
}
