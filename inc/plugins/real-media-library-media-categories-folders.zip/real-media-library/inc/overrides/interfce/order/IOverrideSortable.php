<?php

namespace MatthiasWeb\RealMediaLibrary\overrides\interfce\order;

// @codeCoverageIgnoreStart
\defined('ABSPATH') or die('No script kiddies please!');
// Avoid direct file request
// @codeCoverageIgnoreEnd
/** @internal */
interface IOverrideSortable
{
    // Most methods Defined in IFolder interface.
}
