<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<div class="info-banner-content-wrapper" >
	<div class="info-front-content">
		<?php echo $list_img.$list_title.$list_sub_title.$description.$loop_button; ?>
	</div>
</div>
