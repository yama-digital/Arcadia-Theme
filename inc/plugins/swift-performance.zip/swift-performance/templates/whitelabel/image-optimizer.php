<?php defined('ABSPATH') or die("KEEP CALM AND CARRY ON");?>
<?php
      $GLOBALS['swift_performance']->modules['image-optimizer']->dashboard();
?>
