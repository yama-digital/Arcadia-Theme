<div class="swift-clear-cache-notice"><?php echo sprintf(__('Please enter and activate your purchase key for %s to <strong>enable API features and automatic updates.</strong>', 'swift-performance'), SWIFT_PERFORMANCE_PLUGIN_NAME);?></div>
<div class="swift-notice-buttonset">
      <a href="#" class="swift-btn swift-btn-gray" data-swift-dismiss-notice><?php esc_html_e('Dismiss', 'swift-performance');?></a>
</div>