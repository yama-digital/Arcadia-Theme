<p><?php echo $action;?></p>
<div class="swift-notice-buttonset">
      <a href="#" class="swift-btn swift-btn-blue" data-swift-clear-cache><?php esc_html_e('Clear all cache', 'swift-performance');?></a>
      <a href="#" class="swift-btn swift-btn-gray" data-swift-dismiss-notice><?php esc_html_e('Dismiss', 'swift-performance');?></a>
</div>