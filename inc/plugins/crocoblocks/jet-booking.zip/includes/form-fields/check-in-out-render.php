<?php

namespace JET_ABAF\Form_Fields;

use JET_ABAF\Vendor\Fields_Core\Smart_Field_Trait;

class Check_In_Out_Render {
	use Smart_Field_Trait;
	use Check_In_Out_Render_Trait;
}