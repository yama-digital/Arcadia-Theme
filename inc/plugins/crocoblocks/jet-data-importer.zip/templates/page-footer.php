<?php
/**
 * Page footer template
 */
?>
	</div>
</div>
