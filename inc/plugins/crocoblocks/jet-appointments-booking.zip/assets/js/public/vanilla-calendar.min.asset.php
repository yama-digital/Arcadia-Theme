<?php return array('dependencies' => array(), 'version' => 'a5140366d514531ae0d3');
