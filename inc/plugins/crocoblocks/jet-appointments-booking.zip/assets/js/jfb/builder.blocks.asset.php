<?php return array('dependencies' => array('react', 'wp-hooks'), 'version' => '499ea386a2f21bb7d056');
