<?php return array('dependencies' => array('react'), 'version' => 'e7085d4e18c068f3d64c');
