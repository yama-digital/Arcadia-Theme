<?php
namespace JET_APB\Rest_API;

use JET_APB\Plugin;

class Endpoint_External_Meta extends Endpoint_Appointment_Meta {

	/**
	 * Returns route name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'external-meta';
	}

	/**
	 * API callback
	 *
	 * @return void
	 */
	public function callback( $request ) {

		$params       = $request->get_params();
		$item_id      = ! empty( $params['id'] ) ? absint( $params['id'] ) : 0;
		$allowed_meta = $this->get_allowed_meta_fields();

		return rest_ensure_response( array(
			'success' => true,
			'fields'  => $this->get_meta( 'external_id', $item_id, $allowed_meta ),
		) );

	}

	/**
	 * Returns table name
	 *
	 * @return string
	 */
	public function get_table() {
		return Plugin::instance()->db->external_meta->table();
	}

	/**
	 * Returns array of allowed meta fields to display
	 *
	 * @return array
	 */
	public function get_allowed_meta_fields() {
		return apply_filters( 'jet-apb/display-external-meta-fields', [
			'event_title' => [
				'label' => __( 'Event Title', 'jet-appointments-booking' ),
				'cb'    => false,
			],
			'event_link' => [
				'label' => __( 'Event Link', 'jet-appointments-booking' ),
				'cb'    => false,
			],
		] );
	}

	/**
	 * Check user access to current end-popint
	 *
	 * @return bool
	 */
	public function permission_callback( $request ) {
		return Plugin::instance()->current_user_can( $this->get_name() );
	}

	/**
	 * Returns endpoint request method - GET/POST/PUT/DELTE
	 *
	 * @return string
	 */
	public function get_method() {
		return 'GET';
	}

	/**
	 * Get query param. Regex with query parameters
	 *
	 * @return string
	 */
	public function get_query_params() {
		return '(?P<id>[\d]+)';
	}

}