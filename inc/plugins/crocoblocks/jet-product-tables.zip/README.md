# JetProductTables

## 1.2.3
- ADD: Clear labels/titles in the Presets Manager and UI so saved presets are easier to identify and apply;
- FIX: Updated behaviour so that Variation Swatches no longer affects JetProductTables and variable products work without errors;
- FIX: Presets now apply correctly on Shop/Category/Product Taxonomy pages when using block themes;

## 1.2.2
- FIX: Prevented duplicated quantity inputs for variable products by disabling quantity picker rendering on variable product types;
- FIX: Corrected `Product Image` column behavior to ensure images remain unlinked after filtering;

## 1.2.1
- FIX: Corrected pagination calculation logic in `get_pages_count()` to ensure compatibility with offset and limit parameters;
- FIX: Ensured proper query page count when offset is greater than zero;
- FIX: Minor fixes.

## 1.2.0.1
- FIX: Minor fixes.

## 1.2.0
- ADD: Bricks compatibility;
- ADD: Ability to use dynamic data via `jet_wc_product_table/macros_filter` filter hook;
- ADD: Search by SKU and custom fields;
- FIX: Update mini-cart after adding a variation product to the cart;
- FIX: Issue with Quantity for variation;
- FIX: Search filter is case-sensitive.

## 1.1.2
- UPD: Make table scrollable on desktop;
- FIX: Sticky header behaviour;
- FIX: Minor fixes.

## 1.1.1
- FIX: Horizontal scroll issue with some WP themes;
- FIX: Sticky header issue.

## 1.1.0
- ADD: Elementor integration;
- ADD: Cross-sell product integration;
- FIX: Minor bug fixes.

## 1.0.0
- Initial release.
