<?php
/**
 * Silence is golden
 */

