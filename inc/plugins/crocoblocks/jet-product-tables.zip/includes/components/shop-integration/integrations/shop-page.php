<?php

namespace Jet_WC_Product_Table\Components\Shop_Integration\Integrations;

use Jet_WC_Product_Table\Plugin;
use Jet_WC_Product_Table\Table;

/**
 * An abstract class that defines the essential structure and functionality of a column type in the product table.
 * All specific column types must extend this class and implement its abstract methods.
 */
class Shop_Page extends Base_Integration {

	/**
	 * Retrieves the unique identifier of the column.
	 * Must be implemented by the subclass to return a string that uniquely identifies the column type.
	 *
	 * @return string The unique identifier of the column.
	 */
	public function get_id() {
		return 'shop_page';
	}

	/**
	 * Retrieves the display name of the column.
	 * Must be implemented by the subclass to return the name that will be shown in the UI for the column.
	 *
	 * @return string The display name of the column.
	 */
	public function get_name() {
		return __( 'Shop Page', 'jet-wc-product-table' );
	}

	/**
	 * Description of current integration type for settings page
	 *
	 * @return [type] [description]
	 */
	public function get_description() {
		return __( 'Show a table instead of the default products grid on the Shop Page. It`s your website page that meets the conditional function is_shop() from the WooCommerce core.', 'jet-wc-product-table' );
	}

	/**
	 * Renders the content of the column for a given product.
	 * Must be implemented by the subclass to generate the HTML output specific to this column.
	 *
	 * @return void
	 */
	public function apply() {
		if ( $this->is_block_theme_active() ) {

			add_filter( 'pre_render_block', function ( $pre_render, $block ) {

				if ( ! $this->is_integration_page_now() ) {
					return $pre_render;
				}

				$bn = $block['blockName'] ?? '';

				if ( in_array( $bn, [ 'woocommerce/product-collection', 'woocommerce/all-products' ], true ) ) {
					return $this->get_integration_table();
				}

				if ( in_array( $bn, [
					'woocommerce/catalog-sorting',
					'woocommerce/product-results-count',
					'woocommerce/legacy-template',
					'woocommerce/active-filters',
					'woocommerce/price-filter',
					'woocommerce/product-template',
					'woocommerce/pagination',
					'core/query-no-results',
				], true ) ) {
					return '';
				}

				return $pre_render;
			}, 10, 2 );

			return;
		}

		add_filter( 'woocommerce_product_loop_start', function () {
			$GLOBALS['woocommerce_loop']['total'] = false;
			return '';
		} );

		add_filter( 'woocommerce_product_loop_end', [ $this, 'get_integration_table' ] );
		remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination' );

		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
	}

	/**
	 * Check if integration page is currently displaying
	 *
	 * @return boolean [description]
	 */
	public function is_integration_page_now() {
		return function_exists( 'is_shop' ) && is_shop();
	}

	protected function is_block_theme_active() {
		return function_exists( 'wp_is_block_theme' ) && wp_is_block_theme();
	}
}
