<?php
namespace Jet_WC_Product_Table\Components\Shop_Integration\Integrations;

use Jet_WC_Product_Table\Plugin;
use Jet_WC_Product_Table\Table;

/**
 * An abstract class that defines the essential structure and functionality of a column type in the product table.
 * All specific column types must extend this class and implement its abstract methods.
 */
class Related_Products extends Base_Integration {

	/**
	 * Retrieves the unique identifier of the column.
	 * Must be implemented by the subclass to return a string that uniquely identifies the column type.
	 *
	 * @return string The unique identifier of the column.
	 */
	public function get_id() {
		return 'related_products';
	}

	/**
	 * Retrieves the display name of the column.
	 * Must be implemented by the subclass to return the name that will be shown in the UI for the column.
	 *
	 * @return string The display name of the column.
	 */
	public function get_name() {
		return __( 'Related Products', 'jet-wc-product-table' );
	}

	/**
	 * Description of current integration type for settings page
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Add related products table insted of related products list on a single product page.', 'jet-wc-product-table' );
	}

	/**
	 * Check if integration page is currently displaying
	 *
	 * @return boolean [description]
	 */
	public function is_integration_page_now() {
		return function_exists( 'is_product' ) && is_product();
	}

	/**
	 * Get type of query for current integration
	 *
	 * @return string
	 */
	public function get_query_type() {
		return 'related_products';
	}

	/**
	 * Heading for related products integration.
	 *
	 * Shown only on single product pages and only when there is at least one
	 * related product. Uses WooCommerce filter so themes still can change
	 * the text.
	 *
	 * @return string
	 */
	public function get_heading() {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return '';
		}

		global $product;

		if ( ! $product instanceof \WC_Product ) {
			$product = wc_get_product( get_the_ID() );
		}

		if ( ! $product instanceof \WC_Product ) {
			return '';
		}

		if ( function_exists( 'wc_get_related_products' ) ) {
			$related_ids = wc_get_related_products( $product->get_id(), 1 );
		} else {
			$related_ids = [];
		}

		if ( empty( $related_ids ) ) {
			return '';
		}

		$heading = apply_filters(
			'woocommerce_product_related_products_heading',
			__( 'Related products', 'jet-wc-product-table' )
		);

		return $heading;
	}

	/**
	 * Apply current integration
	 *
	 * @return void
	 */
	public function apply() {
		add_filter( 'body_class', [ $this, 'add_body_class' ] );

		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
		add_action( 'woocommerce_after_single_product_summary', [ $this, 'render_integration_table' ], 20 );

		add_filter( 'render_block', [ $this, 'filter_related_products_block' ], 20, 2 );
	}

	/**
	 * Add body class when Related Products integration is active.
	 *
	 * @param array $classes Body classes.
	 *
	 * @return array
	 */
	public function add_body_class( $classes ) {
		$classes[] = 'jet-wc-pt-related-integration';

		return $classes;
	}

	/**
	 * Remove default Related Products block on block themes
	 * when our integration is active.
	 *
	 * @param string $block_content Rendered block HTML.
	 * @param array  $block Parsed block data.
	 *
	 * @return string
	 */
	public function filter_related_products_block( $block_content, $block ): string {

		if ( is_admin() || wp_is_json_request() || wp_doing_ajax() ) {
			return $block_content;
		}

		if ( empty( $block['blockName'] ) ) {
			return $block_content;
		}

		$related_blocks = [
			'woocommerce/related-products',              // old classic block
			'woocommerce/product-related-products',      // new block themes
			'woocommerce/product-collection',            // shown with related namespace
		];

		if ( in_array( $block['blockName'], $related_blocks, true ) ) {
			return '';
		}

		if (
			isset( $block['attrs']['namespace'] ) &&
			'woocommerce/related-products' === $block['attrs']['namespace']
		) {
			return '';
		}

		return $block_content;
	}
}
