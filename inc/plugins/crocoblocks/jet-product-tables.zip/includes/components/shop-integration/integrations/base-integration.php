<?php

namespace Jet_WC_Product_Table\Components\Shop_Integration\Integrations;

use Jet_WC_Product_Table\Plugin;
use Jet_WC_Product_Table\Table;

/**
 * An abstract class that defines the essential structure and functionality of a column type in the product table.
 * All specific column types must extend this class and implement its abstract methods.
 */
abstract class Base_Integration {

	protected $preset = null;

	/**
	 * Retrieves the unique identifier of the column.
	 * Must be implemented by the subclass to return a string that uniquely identifies the column type.
	 *
	 * @return string The unique identifier of the column.
	 */
	abstract public function get_id();

	/**
	 * Retrieves the display name of the column.
	 * Must be implemented by the subclass to return the name that will be shown in the UI for the column.
	 *
	 * @return string The display name of the column.
	 */
	abstract public function get_name();

	abstract public function get_description();

	/**
	 * Renders the content of the column for a given product.
	 * Must be implemented by the subclass to generate the HTML output specific to this column.
	 *
	 * @return string The rendered HTML of the column content.
	 */
	abstract public function apply();

	/**
	 * Defines when integration page is rendered.
	 * Any custom integrations must rewrite this method with own logic
	 *
	 * @return boolean [description]
	 */
	public function is_integration_page_now() {
		return false;
	}

	/**
	 * Returns heading text for current integration.
	 *
	 * Child integrations may override this.
	 *
	 * @return string
	 */
	public function get_heading() {
		return '';
	}

	/**
	 * Get type of query for current integration
	 *
	 * @return string
	 */
	public function get_query_type() {
		return 'current_query';
	}

	/**
	 * Add preset to current integration
	 *
	 * @param int $preset Preset ID.
	 */
	public function add_preset( $preset = '' ) {

		$preset = absint( $preset );

		if ( $preset ) {
			$this->preset = $preset;
		}

		return $this;
	}

	/**
	 * Get a table for the current integration
	 *
	 * @return string
	 */
	public function get_integration_table() {

		if ( $this->preset ) {
			$settings = Plugin::instance()->presets->get_preset_data_for_display( $this->preset );
		} else {
			$settings = Plugin::instance()->settings->get();
		}

		// Create a new Table instance with the given attributes.
		$table = new Table( [
			'query'           => [ 'query_type' => $this->get_query_type() ],
			'columns'         => $settings['columns'] ?? null,
			'settings'        => $settings['settings'] ?? [],
			'filters_enabled' => $settings['filters_enabled'] ?? null,
			'filters'         => $settings['filters'] ?? null,
		] );

		$heading = $this->get_heading();

		// Render table HTML into a string.
		ob_start();
		$table->render();
		$table_html = ob_get_clean();

		// If we have a heading, try to inject it inside the main table container.
		if ( $heading ) {

			$heading_tag = apply_filters(
				'jet-wc-product-table/integration-heading-tag',
				'h2',
				$this
			);

			$heading_html = sprintf(
				'<%1$s class="jet-wc-product-table__integration-heading">%2$s</%1$s>',
				tag_escape( $heading_tag ),
				esc_html( $heading )
			);

			// Insert heading right after the opening container div.
			if ( false !== strpos( $table_html, 'jet-wc-product-table-container' ) ) {
				$table_html = preg_replace(
					'/(<div[^>]*class="[^"]*jet-wc-product-table-container[^"]*"[^>]*>)/',
					'$1' . $heading_html,
					$table_html,
					1
				);
			} else {
				$table_html = $heading_html . $table_html;
			}
		}

		$output = '<div class="jet-wc-product-table-integration">';
		$output .= $table_html;
		$output .= '</div>';

		return $output;
	}

	/**
	 * Render a table for current integration
	 *
	 * @return void
	 */
	public function render_integration_table() {
		echo $this->get_integration_table(); //phpcs:ignore
	}
}
