<?php
/**
 * Points layout template
 */
echo $this->__get_stars( $val, $max );
