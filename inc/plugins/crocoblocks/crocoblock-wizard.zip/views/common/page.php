<?php
/**
 * Main wizard page
 */
?>
<div class="wrap">
	<div id="crocoblock_wizard">
		<cbw-main></cbw-main>
	</div>
</div>
