# JetFormBuilder Login Action
Premium Addon for JetFormBuilder

# ChangeLog

## 2.0.7
* FIX: PHP warnings

## 2.0.6
* FIX: Problem with submit button when enabled recaptcha

## 2.0.5
* UPD: make reset & login actions compatible with >= 3.4.0 JetFormBuilder

## 2.0.4
* Tweak: Added placeholder for drop-down fields in action settings

## 2.0.3
* ADD: Custom response messages on error in User Login action
* UPD: Minor improvement in Reset password pattern (for Welcome Block)

## 2.0.2
* ADD: User Login & Reset password patterns for Welcome block (JetFormBuilder version should be >= 3.3.0)
* FIX: Custom success message for Reset Password action

## 2.0.1
* ADD: Custom success message for Reset Password Action
* FIX: Object Cache compatibility
* FIX: Compatibility with JetFormBuilder 3.1

## 2.0.0
* ADD: Reset password logic

## 1.0.2
* Tweak: Removed unnecessary hook

## 1.0.1
* Tweak: add license manager