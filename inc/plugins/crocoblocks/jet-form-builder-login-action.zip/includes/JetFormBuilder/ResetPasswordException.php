<?php


namespace Jet_FB_Login\JetFormBuilder;


use Jet_Form_Builder\Exceptions\Handler_Exception;

class ResetPasswordException extends Handler_Exception {

}