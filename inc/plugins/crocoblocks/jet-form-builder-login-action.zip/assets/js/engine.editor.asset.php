<?php return array('dependencies' => array(), 'version' => '1cc1da251b907b52f94c');
