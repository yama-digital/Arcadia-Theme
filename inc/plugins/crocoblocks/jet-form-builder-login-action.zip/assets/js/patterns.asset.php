<?php return array('dependencies' => array(), 'version' => 'fd55e9b778a716d49869');
