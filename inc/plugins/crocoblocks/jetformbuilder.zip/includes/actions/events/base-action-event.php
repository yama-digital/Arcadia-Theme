<?php


namespace Jet_Form_Builder\Actions\Events;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

abstract class Base_Action_Event extends Base_Event {


}
