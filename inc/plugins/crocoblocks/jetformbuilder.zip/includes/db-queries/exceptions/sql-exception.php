<?php


namespace Jet_Form_Builder\Db_Queries\Exceptions;

use Jet_Form_Builder\Exceptions\Handler_Exception;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Sql_Exception extends Handler_Exception {

}
