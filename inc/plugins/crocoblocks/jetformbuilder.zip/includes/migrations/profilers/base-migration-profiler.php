<?php


namespace Jet_Form_Builder\Migrations\Profilers;

use Jet_Form_Builder\Migrations\Versions\Base_Migration;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Base_Migration_Profiler {

	public function on_up_end( Base_Migration $migration, string $timer_stop ) {
	}

	public function on_down_end( Base_Migration $migration, string $timer_stop ) {
	}

}
