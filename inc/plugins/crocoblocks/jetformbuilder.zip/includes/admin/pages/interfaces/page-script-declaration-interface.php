<?php

namespace Jet_Form_Builder\Admin\Pages\interfaces;

interface Page_Script_Declaration_Interface {

	public function register_scripts();

}
