<?php


namespace Jet_Form_Builder\Admin\Exceptions;

use Jet_Form_Builder\Exceptions\Handler_Exception;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Failed_Box_Update extends Handler_Exception {

}
