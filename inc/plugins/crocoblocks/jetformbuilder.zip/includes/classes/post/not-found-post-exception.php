<?php


namespace Jet_Form_Builder\Classes\Post;

use Jet_Form_Builder\Exceptions\Silence_Exception;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Not_Found_Post_Exception extends Silence_Exception {

}
