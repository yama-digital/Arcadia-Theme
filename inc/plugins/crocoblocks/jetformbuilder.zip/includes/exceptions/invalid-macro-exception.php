<?php


namespace Jet_Form_Builder\Exceptions;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Invalid_Macro_Exception extends \Exception {

}
