<?php


namespace Jet_Form_Builder\Blocks\Types;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

trait Form_Break_Field_Style {

	public function form_break_css_scheme() {
	}

	public function form_break_styles() {
	}

}
