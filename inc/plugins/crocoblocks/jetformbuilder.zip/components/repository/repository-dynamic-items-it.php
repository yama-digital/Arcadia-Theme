<?php


namespace JFB_Components\Repository;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

interface Repository_Dynamic_Items_It {

}
