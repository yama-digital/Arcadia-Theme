<?php


namespace JFB_Components\Repository;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

interface Repository_Static_Item_It {

	public static function rep_item_id();

}
