<?php


namespace JFB_Components\Module;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

trait Base_Module_Handle_Trait {

	public function get_handle( string $unique_string = '' ): string {
		$parts = array(
			Base_Module_Handle_It::HANDLE_PREFIX . $this->rep_item_id(),
			$unique_string,
		);

		return implode( '-', array_filter( $parts ) );
	}

	abstract public function rep_item_id();

}
