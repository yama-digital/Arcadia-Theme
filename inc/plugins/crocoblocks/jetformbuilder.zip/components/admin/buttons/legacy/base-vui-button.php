<?php


namespace Jet_Form_Builder\Admin\Buttons;

use JFB_Components\Admin\Buttons;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Base_Vui_Button extends Buttons\Base_Vui_Button {

}
