<?php return array('dependencies' => array(), 'version' => '29592a4719e8a355b7e2');
