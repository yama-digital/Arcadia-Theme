<?php return array('dependencies' => array('react-jsx-runtime'), 'version' => '3de7d889283fc0e706d8');
