<?php return array('dependencies' => array(), 'version' => 'c85144b6e71e1409c801');
