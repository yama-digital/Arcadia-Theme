# Description
For JetWooBuilder widgets such as Products Grid, Products List, Archive Add to Cart
Button, Single Add to Cart Button and Cart Table add custom quantity selectors controls.