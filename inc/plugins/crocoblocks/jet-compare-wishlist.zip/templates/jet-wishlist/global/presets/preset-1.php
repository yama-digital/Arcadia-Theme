<?php
/**
 * Wishlist preset 1
 */

include $this->get_template( 'remove-button' );
include $this->get_template( 'thumbnail' );
include $this->get_template( 'categories' );
include $this->get_template( 'sku' );
include $this->get_template( 'stock-status' );
include $this->get_template( 'title' );
include $this->get_template( 'price' );
include $this->get_template( 'excerpt' );
include $this->get_template( 'action-button' );
include $this->get_template( 'rating' );
include $this->get_template( 'tags' );
?>