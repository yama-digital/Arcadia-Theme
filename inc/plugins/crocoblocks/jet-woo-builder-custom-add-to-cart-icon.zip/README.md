# How to use

### Products Grid & Products List widgets
1. Activate the plugin;
1. Find plugins folder on your local storage or server and open it;
1. Copy `jet-woo-builder` folder and paste it to your child theme;

### Archive Add to Cart & Single Add to Cart widgets
Just activate plugin.