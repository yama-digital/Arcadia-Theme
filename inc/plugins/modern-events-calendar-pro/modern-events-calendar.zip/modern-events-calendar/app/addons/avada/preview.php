<?php
/**
 * Underscore.js template.
 *
 * @package fusion-builder
 */

?>
<script type="text/template" id="mec-avada-shortcode-element">
    <h4 class="fusion_module_title">MEC Shortcode ({{ params.id }})</h4>
</script>
