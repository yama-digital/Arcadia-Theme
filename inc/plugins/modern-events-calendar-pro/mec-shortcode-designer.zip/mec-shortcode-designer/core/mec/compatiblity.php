<?php

namespace MEC_Shortcodedesigner\Core\MEC_options;

// don't load directly.
if ( ! defined( 'ABSPATH' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit;
}
/**
 * MEC_options.
 *
 * @author     author
 * @package     package
 * @since     1.0.0
 */
class MEC_options {

	/**
	 * Instance of this class.
	 *
	 * @since   1.0.0
	 * @access  public
	 * @var     MEC_ShortcodeDesigner
	 **/
	public static $instance;

	/**
	 * Provides access to a single instance of a module using the singleton pattern.
	 *
	 * @since   1.0.0
	 * @return  object
	 **/
	public static function instance() {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}


	public function __construct() {
		self::setHooks( $this );
    }

	/**
	 * Set Hooks
	 *
	 * @since     1.0.0
	 **/
	public static function setHooks( $This ) {
		add_filter( 'mec_calendar_skins', [$This, 'set_skin'] );
		add_filter( 'mec_skin_options', [$This, 'set_skin_options'] );
        add_filter( 'mec_sf_options', [$This, 'set_search_options'] );
		add_filter( 'mec_skin_query_args', [$This, 'map_end_date_to_maximum_date_range'], 10, 2 );
		add_action( 'mec_before_render_skin', [$This, 'fix_custom_skin_end_date'], 10, 1 );
	}

	/**
	 * set skin.
	 *
	 * @since   1.0.0
	 **/
	public function set_skin( $skins ) {
		$skins['custom'] = __( 'Shortcode Designer', 'mec-shortcode-designer' );
		return $skins;
	}

	/**
	 * set skin options.
	 *
	 * @since   1.0.0
	 **/
	public function set_skin_options( $sk_options ) { 
        include_once('skin_options.php');
	}

	/**
	 * set search options.
	 *
	 * @since   1.0.0
	 **/
	public function set_search_options( $sf_options ) { 
		include_once('search_options.php');
	}

	/**
	 * Map end_date to maximum_date_range for backward compatibility
	 *
	 * @since   1.0.0
	 **/
	public function map_end_date_to_maximum_date_range( $args, $skin ) {
		if ( isset( $skin->skin ) && $skin->skin === 'custom' ) {
			if ( isset( $skin->skin_options['end_date'] ) && ! isset( $skin->skin_options['maximum_date_range'] ) ) {
				$skin->skin_options['maximum_date_range'] = $skin->skin_options['end_date'];
			}
			// Also update maximum_date_range property if end_date exists
			if ( isset( $skin->skin_options['end_date'] ) && empty( $skin->maximum_date_range ) ) {
				$skin->maximum_date_range = $skin->skin_options['end_date'];
			}
		}
		return $args;
	}

	/**
	 * Fix custom skin end_date before rendering
	 *
	 * @since   1.0.0
	 **/
	public function fix_custom_skin_end_date( $skin ) {
		if ( isset( $skin->skin ) && $skin->skin === 'custom' ) {
			// Map end_date to maximum_date_range if it exists
			if ( isset( $skin->skin_options['end_date'] ) && empty( $skin->skin_options['maximum_date_range'] ) ) {
				$skin->skin_options['maximum_date_range'] = $skin->skin_options['end_date'];
			}
			// Update maximum_date_range property
			if ( isset( $skin->skin_options['maximum_date_range'] ) && ! empty( $skin->skin_options['maximum_date_range'] ) ) {
				$skin->maximum_date_range = $skin->skin_options['maximum_date_range'];
			} elseif ( isset( $skin->skin_options['end_date'] ) && ! empty( $skin->skin_options['end_date'] ) ) {
				$skin->maximum_date_range = $skin->skin_options['end_date'];
			}
		}
	}

} //MEC_options

MEC_options::instance();
