<?php

namespace MEC_ShortcodeDesigner\Core;

/**
 * global $MEC_Events_dates
 * @version 1.0.0
 */
class EventsDateTimes{

    private static $instance;

    public static function instance(){

        if(is_null(self::$instance)){
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function get_group_data($group_id){

        global $MEC_Events_dates,$MEC_Events_dates_groups;
		if( !isset($MEC_Events_dates_groups[$group_id]) || empty($MEC_Events_dates_groups[$group_id] ) ){

			$MEC_Events_dates_groups[$group_id] = $MEC_Events_dates;
		}

        return $MEC_Events_dates_groups[$group_id];
    }

    public function remove_event_datetime_data($group_id,$event_id,$key){

        global $MEC_Events_dates_groups;
        unset($MEC_Events_dates_groups[$group_id][$event_id][$key]);
    }

    public function get_datetimes($event_id,$group_id){

        $data = $this->get_group_data($group_id);
        $datetimes = array();

		if( isset($data[$event_id]) && is_array( $data[$event_id] ) ){

			$k = key($data[$event_id]);
			$datetimes = isset($data[$event_id][$k]) ? $data[$event_id][$k] : null;

            $this->remove_event_datetime_data($group_id,$event_id,$k);
		}

        /**
         * array(
         *      'start' => array(
         *          'date' => '2021:01:01',
         *          'time' => '11:00 pm',
         *          'timestamp' => '1234567890',
         *      ),
         *      'end' => array(
         *          'date' => '2021:01:01',
         *          'time' => '11:00 pm',
         *          'timestamp' => '1234567890',
         *      ),
         * )
         */

        return $datetimes;
    }

    /**
     * Get complete date range for multi-day events (for Date widget)
     */
    public function get_datetimes_with_full_range($event_id, $group_id){
        
        global $MEC_Events_dates;
        
        // Get all available dates for this event
        $all_event_dates = isset($MEC_Events_dates[$event_id]) ? $MEC_Events_dates[$event_id] : array();
        
        if(empty($all_event_dates)){
            // Fallback to regular method
            return $this->get_datetimes($event_id, $group_id);
        }
        
        // Find earliest start and latest end date
        $earliest_start = null;
        $latest_end = null;
        $first_datetime = null;
        
        foreach($all_event_dates as $datetime_entry){
            if(!$first_datetime) {
                $first_datetime = $datetime_entry;
            }
            
            $start_date = $datetime_entry['start']['date'];
            $end_date = $datetime_entry['end']['date'];
            
            if($earliest_start === null || $start_date < $earliest_start){
                $earliest_start = $start_date;
            }
            
            if($latest_end === null || $end_date > $latest_end){
                $latest_end = $end_date;
            }
        }
        
        // Create a new datetime array with full range
        if($first_datetime && $earliest_start && $latest_end){
            $first_datetime['start']['date'] = $earliest_start;
            $first_datetime['end']['date'] = $latest_end;
        }
        
        // Still remove one entry to prevent multiple calls
        $this->get_datetimes($event_id, $group_id);
        
        return $first_datetime ? $first_datetime : array();
    }
}