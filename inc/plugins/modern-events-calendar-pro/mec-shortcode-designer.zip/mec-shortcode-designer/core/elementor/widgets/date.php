<?php
use MEC\Base;
use Elementor\Plugin;
use MEC\Events\Event;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use MEC_ShortcodeDesigner\Core\EventsDateTimes;

/** no direct access */
defined( 'MECEXEC' ) or die();

/**
 * Webnus MEC elementor addon shortcode class
 *
 * @author Webnus <info@webnus.net>
 */
class MecShortCodeDesignerDate extends Widget_Base {

	/**
	 * Retrieve MEC widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'mec-date';
	}

	/**
	 * Retrieve MEC widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'MEC Date', 'mec-shortcode-designer' );
	}

	/**
	 * Retrieve MEC widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-date';
	}


	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget category.
	 */
	public function get_categories() {
		return [ 'mec_shortcode_designer' ];
	}

	/**
	 * Register MEC widget controls.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$date_format = $this->get_default_date_format();

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Settings', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'date_format1',
			array(
				'label'		    => __('Date Format', 'mec-shortcode-designer'),
				'type'		    => \Elementor\Controls_Manager::TEXT,
                'default'	    => $date_format,
            )
        );

		$this->end_controls_section();

		// typography
		$this->start_controls_section(
			'styling_section',
			[
				'label' => __( 'Typography', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);



		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'		=> 'title_typography',
				'label'		=> __( 'Typography', 'mec-shortcode-designer' ),
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
				'selector'	=> '{{WRAPPER}} .mec-event-date',
			]
		);
		$this->add_control(
			'title_align',
			[
				'label'		=> __( 'Alignment', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::CHOOSE,
				'options'	=> [
					'left' => [
						'title' => __( 'Left', 'mec-shortcode-designer' ),
						'icon'	=> 'mec-fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'mec-shortcode-designer' ),
						'icon'	=> 'mec-fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'mec-shortcode-designer' ),
						'icon'	=> 'mec-fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .mec-event-date' => 'text-align: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'display',
			[
				'label'		=> __( 'Display', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::SELECT,
				'default' 	=> 'block',
				'options' 	=> [
					'inherit'		=> __( 'inherit', 'mec-shortcode-designer' ),
					'inline'		=> __( 'inline', 'mec-shortcode-designer' ),
					'inline-block'	=> __( 'inline-block', 'mec-shortcode-designer' ),
					'block'			=> __( 'block', 'mec-shortcode-designer' ),
					'none'			=> __( 'none', 'mec-shortcode-designer' ),
				],
				'selectors' => [
					'{{WRAPPER}} .mec-event-date' => 'display: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		// color
		$this->start_controls_section(
			'title_color_style',
			[
				'label' => __( 'Colors', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label'		=> __( 'Color', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY,
                ],
				'default'	=> '#000',
				'selectors' => [
					'{{WRAPPER}} .mec-event-date' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'title_color_hover',
			[
				'label'		=> __( 'Hover', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY,
                ],
				'default'	=> '#000',
				'selectors' => [
					'{{WRAPPER}} .mec-event-date:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		// background
		$this->start_controls_section(
			'title_background_style',
			[
				'label' => __( 'Background', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_background',
			[
				'label'		=> __( 'Background', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY,
                ],
				'default'	=> 'rgba(255,255,255,0)',
				'selectors' => [
					'{{WRAPPER}} .mec-event-date' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'title_background_hover',
			[
				'label'		=> __( 'Hover', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
                'global' => [
                    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY,
                ],
				'default'	=> 'rgba(255,255,255,0)',
				'selectors' => [
					'{{WRAPPER}} .mec-event-date:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		// Spacing
		$this->start_controls_section(
			'title_spacing_style',
			[
				'label' => __( 'Spacing', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_margin',
			[
				'label'			=> __( 'Margin', 'mec-shortcode-designer' ),
				'type'			=> Controls_Manager::DIMENSIONS,
				'size_units'	=> [ 'px', '%', 'em' ],
				'default'		=> [
					'top'		=> '0',
					'right'		=> '0',
					'bottom'	=> '0',
					'left'		=> '0',
					'isLinked' => true,
				],
				'selectors'		=> [
					'{{WRAPPER}} .mec-event-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'title_padding',
			[
				'label'			=> __( 'Padding', 'mec-shortcode-designer' ),
				'type'			=> Controls_Manager::DIMENSIONS,
				'size_units'	=> [ 'px', '%', 'em' ],
				'selectors'		=> [
					'{{WRAPPER}} .mec-event-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'		=> 'border',
				'label'		=> __( 'Border', 'mec-shortcode-designer' ),
				'selector'	=> '{{WRAPPER}} .mec-event-date',
			]
		);
		$this->add_control(
			'date_border_radius', //param_name
			[
				'label' 		=> __( 'Border Radius', 'mec-shortcode-designer' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .mec-event-date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => __( 'Box Shadow', 'mec-shortcode-designer' ),
				'selector' => '{{WRAPPER}} .mec-event-date',
			]
		);
		$this->end_controls_section();

	}

	/**
	 * Return default date format
	 *
	 * @return string
	 */
	public function get_default_date_format(){

		$date_format = \MEC\Settings\Settings::getInstance()->get_settings('single_date_format1');

		return !empty( $date_format ) ? $date_format : get_option( 'date_format' );
	}

	/**
	 * Render MEC widget output on the frontend.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings   = $this->get_settings_for_display();
		$element_id = $this->get_id();

		$date_format = isset( $settings['date_format1'] ) && !empty( $settings['date_format1'] ) ? $settings['date_format1'] : $this->get_default_date_format();

		if ( get_post_type() == 'mec_designer' ) {
			$event_id = get_posts( 'post_type=mec-events&numberposts=1' )[0]->ID;

			$start_date = get_post_meta($event_id, 'mec_start_date', true);
			$end_date = get_post_meta($event_id, 'mec_end_date', true);

			$datetimes = array(
				'start' => array( 'date' => $start_date ),
				'end' => array( 'date' => $end_date ),
			);
		} else {

			$event_id = get_the_ID();

			// Check if event is recurring
			$repeat_status = get_post_meta($event_id, 'mec_repeat_status', true);
			$repeat_type = get_post_meta($event_id, 'mec_repeat_type', true);
			
			if ($repeat_status && $repeat_type) {
				// For recurring events, check if we have a specific occurrence date
				global $mec_current_occurrence_date;
                if (isset($mec_current_occurrence_date) && !empty($mec_current_occurrence_date)) {
                    // Display the specific occurrence date using a safe timestamp resolution
                    $occurrence_ts = false;
                    if(is_numeric($mec_current_occurrence_date)){
                        $occurrence_ts = intval($mec_current_occurrence_date);
                    } elseif(preg_match('/^\d{4}-\d{2}-\d{2}$/', $mec_current_occurrence_date)) {
                        $occurrence_ts = strtotime($mec_current_occurrence_date);
                    }

                    // Fallback: try to get timestamp from MEC event datetimes
                    if(!$occurrence_ts){
                        global $MEC_Shortcode_id;
                        $datetimes_try = EventsDateTimes::instance()->get_datetimes($event_id,'date'.($MEC_Shortcode_id ?? '').$element_id);
                        if(isset($datetimes_try['start']['timestamp']) && !empty($datetimes_try['start']['timestamp'])){
                            $occurrence_ts = intval($datetimes_try['start']['timestamp']);
                        }
                    }

                    // Final fallback: use event meta start date if available
                    if(!$occurrence_ts){
                        $meta_start = get_post_meta($event_id, 'mec_start_date', true);
                        if(!empty($meta_start) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $meta_start)){
                            $occurrence_ts = strtotime($meta_start);
                        }
                    }

                    // If all else fails, use current_time to avoid showing today's date incorrectly from false
                    if(!$occurrence_ts){
                        $occurrence_ts = current_time('timestamp');
                    }

                    $date_label = Base::get_main()->date_i18n($date_format, $occurrence_ts);
                } else {
					// Fallback to getting all occurrences
					$event = new Event( $event_id );
					$event_detail = $event->get_detail();
					
					// Get next occurrences
					$occurrence = date('Y-m-d');
					$occurrences = Base::get_main()->get_event_next_occurrences($event_detail, $occurrence, 10);
					
					// Display each occurrence date separately for recurring events
					if (!empty($occurrences)) {
						$date_labels = array();
						foreach ($occurrences as $occurrence) {
							$date_labels[] = Base::get_main()->date_i18n($date_format, $occurrence['start']['timestamp']);
						}
						$date_label = implode('<br>', $date_labels);
					} else {
						$date_label = '';
					}
				}
			} else {
				// Regular single event
				global $MEC_Shortcode_id;
				$datetimes = EventsDateTimes::instance()->get_datetimes_with_full_range($event_id,'date'.$MEC_Shortcode_id . $element_id);
				
				if( empty( $datetimes ) ){
					return;
				}
				$start_datetime =  isset($datetimes['start']) && !empty($datetimes['start']) ? $datetimes['start'] : array();
				$end_datetime = isset($datetimes['end']) && !empty($datetimes['end']) ? $datetimes['end'] : array();

				$event = new Event( $event_id );
				$event_detail = $event->get_detail();
				$event_detail->date = $datetimes;

				$midnight_event = Base::get_main()->is_midnight_event($event_detail);
				
				// Format the date label
				if($midnight_event){
					$date_label = Base::get_main()->dateify( $event_detail, $date_format );
				} else {
					// Use MEC's date_label function which handles multi-day events correctly
					$date_label = Base::get_main()->date_label( $start_datetime, $end_datetime, $date_format );
				}
			}
		}

		?>
		<div class="mec-shortcode-designer">
			<div class="mec-event-date">
				<?php echo $date_label; ?>
			</div>
		</div>
		<?php
	}
}
