<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following flow
 * of control:
 *
 * - This method should be static
 * - Check if the $_REQUEST content actually is the plugin name
 * - Run an admin referrer check to make sure it goes through authentication
 * - Verify the output of $_GET makes sense
 * - Repeat with other user roles. Best directly by using the links/query string parameters.
 * - Repeat things for multisite. Once for a single site in the network, once sitewide.
 *
 * This file may be updated more in future version of the Boilerplate; however, this is the
 * general skeleton and outline for how the file should work.
 *
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @package    MecUtility
 * @since      1.0.0
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Check if user has permission to uninstall plugins
if (!current_user_can('activate_plugins')) {
    exit;
}

// Note: Do NOT compare __FILE__ to WP_UNINSTALL_PLUGIN here.
// WordPress includes this file directly during uninstall and the comparison
// can be incorrect, causing an early exit and blocking deletion.

/**
 * Only remove data if user has opted to remove all data on uninstall
 */
if (get_option('mec_utility_remove_data_on_uninstall', false)) {
    mec_utility_uninstall_cleanup();
}

/**
 * Perform cleanup when plugin is uninstalled.
 *
 * @since 1.0.0
 */
function mec_utility_uninstall_cleanup()
{
    global $wpdb;

    // Remove database tables
    mec_utility_remove_database_tables();

    // Remove plugin options
    mec_utility_remove_plugin_options();

    // Remove user meta
    mec_utility_remove_user_meta();

    // Remove uploaded files
    mec_utility_remove_uploaded_files();

    // Clear scheduled cron events
    mec_utility_clear_cron_events();

    // Remove capabilities
    mec_utility_remove_capabilities();

    // Clear cache
    mec_utility_clear_cache();

    // Log uninstall
    mec_utility_log_uninstall();
}

/**
 * Remove database tables created by the plugin.
 *
 * @since 1.0.0
 */
function mec_utility_remove_database_tables()
{
    global $wpdb;

    $tables = [
        $wpdb->prefix . 'mec_utility_api_keys',
        $wpdb->prefix . 'mec_utility_qr_sessions',
        $wpdb->prefix . 'mec_utility_activity_logs',
    ];

    foreach ($tables as $table) {
        $wpdb->query("DROP TABLE IF EXISTS {$table}");
    }
}

/**
 * Remove all plugin options.
 *
 * @since 1.0.0
 */
function mec_utility_remove_plugin_options()
{
    global $wpdb;

    // Remove all options that start with our prefix
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
            'mec_utility_%'
        )
    );

    // Remove specific options
    $options_to_remove = [
        'mec_utility_version',
        'mec_utility_activated_at',
        'mec_utility_deactivation_log',
        'mec_utility_activation_log',
        'mec_utility_settings_backup',
    ];

    foreach ($options_to_remove as $option) {
        delete_option($option);
    }
}

/**
 * Remove user meta data created by the plugin.
 *
 * @since 1.0.0
 */
function mec_utility_remove_user_meta()
{
    global $wpdb;

    // Remove user meta that starts with our prefix
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
            'mec_utility_%'
        )
    );
}

/**
 * Remove uploaded files and directories.
 *
 * @since 1.0.0
 */
function mec_utility_remove_uploaded_files()
{
    $upload_dir = wp_upload_dir();
    $mec_utility_dir = $upload_dir['basedir'] . '/mec-utility';

    if (is_dir($mec_utility_dir)) {
        mec_utility_remove_directory($mec_utility_dir);
    }
}

/**
 * Recursively remove a directory and its contents.
 *
 * @since 1.0.0
 * @param string $dir Directory path to remove.
 * @return bool True on success, false on failure.
 */
function mec_utility_remove_directory($dir)
{
    if (!is_dir($dir)) {
        return false;
    }

    $files = array_diff(scandir($dir), ['.', '..']);

    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        if (is_dir($path)) {
            mec_utility_remove_directory($path);
        } else {
            unlink($path);
        }
    }

    return rmdir($dir);
}

/**
 * Clear scheduled cron events.
 *
 * @since 1.0.0
 */
function mec_utility_clear_cron_events()
{
    // Clear all instances of our cron hooks
    wp_clear_scheduled_hook('mec_utility_cleanup_qr_codes');
    wp_clear_scheduled_hook('mec_utility_cleanup_logs');
}

/**
 * Remove custom capabilities added by the plugin.
 *
 * @since 1.0.0
 */
function mec_utility_remove_capabilities()
{
    $capabilities = [
        'mec_utility_manage_api',
        'mec_utility_manage_qr',
        'mec_utility_view_logs',
        'mec_utility_manage_settings',
    ];

    $roles = ['administrator', 'editor'];

    foreach ($roles as $role_name) {
        $role = get_role($role_name);
        if ($role) {
            foreach ($capabilities as $capability) {
                $role->remove_cap($capability);
            }
        }
    }
}

/**
 * Clear all cached data.
 *
 * @since 1.0.0
 */
function mec_utility_clear_cache()
{
    global $wpdb;

    // Clear WordPress object cache
    wp_cache_flush();

    // Remove all transients that start with our prefix
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            '_transient_mec_utility_%',
            '_transient_timeout_mec_utility_%'
        )
    );

    // Clear third-party cache if available
    if (function_exists('rocket_clean_domain')) {
        rocket_clean_domain();
    }

    if (function_exists('w3tc_flush_all')) {
        w3tc_flush_all();
    }

    if (function_exists('wp_cache_clear_cache')) {
        wp_cache_clear_cache();
    }
}

/**
 * Log plugin uninstall for debugging purposes.
 *
 * @since 1.0.0
 */
function mec_utility_log_uninstall()
{
    $log_data = [
        'action' => 'plugin_uninstalled',
        'plugin_version' => defined('MEC_UTILITY_VERSION') ? MEC_UTILITY_VERSION : 'unknown',
        'wordpress_version' => get_bloginfo('version'),
        'php_version' => PHP_VERSION,
        'uninstalled_at' => current_time('mysql'),
        'user_id' => get_current_user_id(),
    ];

    // Log to WordPress debug log if enabled
    if (defined('WP_DEBUG') && WP_DEBUG && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
        error_log('MEC Utility Plugin Uninstalled: ' . wp_json_encode($log_data));
    }

    // Send uninstall feedback if user opted in
    if (get_option('mec_utility_send_feedback', false)) {
        wp_remote_post('https://your-domain.com/api/uninstall-feedback', [
            'body' => wp_json_encode($log_data),
            'headers' => ['Content-Type' => 'application/json'],
            'timeout' => 5,
        ]);
    }
}

/**
 * Get uninstall statistics.
 *
 * @since 1.0.0
 * @return array Uninstall statistics.
 */
function mec_utility_get_uninstall_stats()
{
    global $wpdb;

    $stats = [];

    // Count records in each table before deletion
    $tables = [
        'api_keys' => $wpdb->prefix . 'mec_utility_api_keys',
        'qr_sessions' => $wpdb->prefix . 'mec_utility_qr_sessions',
        'activity_logs' => $wpdb->prefix . 'mec_utility_activity_logs',
    ];

    foreach ($tables as $key => $table) {
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        $stats[$key . '_count'] = $count ? $count : 0;
    }

    // Count plugin options
    $options_count = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
            'mec_utility_%'
        )
    );
    $stats['options_count'] = $options_count ? $options_count : 0;

    // Count user meta
    $user_meta_count = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
            'mec_utility_%'
        )
    );
    $stats['user_meta_count'] = $user_meta_count ? $user_meta_count : 0;

    return $stats;
}

// For multisite installations
if (is_multisite()) {
    // Get all blog IDs
    $blog_ids = get_sites(['fields' => 'ids']);

    foreach ($blog_ids as $blog_id) {
        switch_to_blog($blog_id);

        // Only cleanup if the option is set for this site
        if (get_option('mec_utility_remove_data_on_uninstall', false)) {
            mec_utility_uninstall_cleanup();
        }

        restore_current_blog();
    }
}
