===  ===


== Changelog ==
= 1.2.0 - 15 December 2025 =
- Added: Ability to edit and change app words and strings
- Fixed: Auto update issue
- Fixed: Minor issues

= 1.1.0 - 5 November 2025 =
- Added: Add/Edit events APIs
- Added: RSVP management APIs
- Added: Booking management APIs
- Fixed: Some minor issues

= 1.0.0 - 30 August 2025 =
- Initial Release