import { CapacitorHttp, Capacitor } from '@capacitor/core'

class MECAuthService {
	constructor() {
		this.baseURL = null
		this.apiKey = null
		this.sessionData = null
	}

	// Set Base URL
	setBaseURL(websiteUrl) {
		// Ensure the URL doesn't end with a slash
		const cleanUrl = websiteUrl.replace(/\/$/, '')
		this.baseURL = `${cleanUrl}/wp-json/mec-utility/v1`
	}

	// Test connection
	async testConnection(websiteUrl) {
		this.setBaseURL(websiteUrl)
		const testURL = `${this.baseURL}/status`


		try {
			// Use official Capacitor HTTP plugin for better mobile support
			const response = await CapacitorHttp.request({
				url: testURL,
				method: 'GET',
				headers: {
					Accept: 'application/json',
					'Content-Type': 'application/json',
					'Cache-Control': 'no-cache',
					'User-Agent': 'MEC-Events-App/1.0'
				},
				connectTimeout: 15000,
				readTimeout: 15000
			})


			if (response.status < 200 || response.status >= 300) {
				throw new Error(`HTTP ${response.status}: Request failed`)
			}

			const data = response.data

			if (data.status === 'active') {
				return {
					success: true,
					data: data
				}
			} else {
				throw new Error(
					'MEC Utility plugin not active or not configured properly'
				)
			}
		} catch (error) {
			console.error('💥 [MECAuthService] Connection test error:')
			console.error('   - Error type:', error.constructor.name)
			console.error('   - Error message:', error.message)
			console.error('   - Full error:', error)

			// Provide more specific error messages
			let errorMessage = error.message || 'Network connection failed'

			if (error.message.includes('timeout')) {
				errorMessage =
					'Request timeout. The server is taking too long to respond.'
			} else if (
				error.message.includes('Load failed') ||
				error.name === 'TypeError' ||
				error.message.includes('Network request failed')
			) {
				errorMessage =
					'Network error: Cannot reach the website. Please check your internet connection and ensure the website URL is correct.'
			} else if (error.message.includes('CORS')) {
				errorMessage =
					'CORS error: Website is blocking mobile app requests. Please contact the website administrator.'
			}

			return {
				success: false,
				error: errorMessage
			}
		}
	}

	// Authenticate with API Key
	async authenticateWithApiKey(apiKey, websiteUrl) {
		const authURL = `${this.baseURL}/auth/validate-api-key`
		const payload = {
			api_key: apiKey,
			website_url: websiteUrl
		}

		try {
			// Android-specific configuration
			const requestConfig = {
				url: authURL,
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'User-Agent': 'MEC-Events-App/1.0'
				},
				data: payload,
				connectTimeout: 15000,
				readTimeout: 15000
			}

			// Add Android-specific options
			if (Capacitor.getPlatform() === 'android') {
				requestConfig.webFetchExtra = {
					mode: 'cors'
				}
			}

			const response = await CapacitorHttp.request(requestConfig)

			if (response.status < 200 || response.status >= 300) {
				throw new Error(`HTTP ${response.status}: Request failed`)
			}

			const data = response.data

			if (data.success) {
				this.apiKey = apiKey
				this.sessionData = data

				// Store credentials in localStorage
				localStorage.setItem('mec_api_key', apiKey)
				localStorage.setItem('mec_website_url', websiteUrl)
				localStorage.setItem('mec_session_data', JSON.stringify(data))

				return {
					success: true,
					message: 'API Key authentication successful',
					sessionData: data
				}
			} else {
				console.error('❌ [MECAuthService] Authentication failed:', data.error)
				throw new Error(data.error || 'Authentication failed')
			}
		} catch (error) {
			console.error('💥 [MECAuthService] Authentication error:')
			console.error('Platform:', Capacitor.getPlatform())
			console.error('   - Error type:', error.constructor.name)
			console.error('   - Error message:', error.message)
			console.error('   - Full error:', error)

			// Platform-specific error handling
			if (Capacitor.getPlatform() === 'android') {
				console.error('🤖 [Android] Specific error handling')
				if (error.message && error.message.includes('null')) {
					console.error(
						'🤖 [Android] Null pointer detected - possible HTTP plugin issue'
					)
				}
			}

			// Provide specific error messages
			let errorMessage = error.message || 'Authentication failed'

			if (error.message.includes('timeout')) {
				errorMessage = 'Request timeout. Please try again.'
			} else if (error.message.includes('401')) {
				errorMessage = 'Invalid API key. Please check your credentials.'
			} else if (error.message.includes('403')) {
				errorMessage = 'Access denied. Please check your permissions.'
			} else if (error.message.includes('404')) {
				errorMessage = 'API endpoint not found. Please check the website URL.'
			} else if (error.message.includes('500')) {
				errorMessage = 'Server error. Please try again later.'
			} else if (
				error.message.includes('Load failed') ||
				error.name === 'TypeError' ||
				error.message.includes('Network request failed')
			) {
				errorMessage =
					'Network error: Cannot reach the authentication server. Please check your internet connection.'
			}

			return {
				success: false,
				error: errorMessage
			}
		}
	}


	// Refresh session
	async refreshSession() {
		if (!this.apiKey) {
			return { success: false, error: 'No active session' }
		}

		try {
			const websiteUrl = this.baseURL.replace('/wp-json/mec-utility/v1', '')
			const response = await CapacitorHttp.request({
				url: `${this.baseURL}/auth/refresh-session`,
				method: 'POST',
				headers: {
					'X-API-Key': this.apiKey,
					'X-Website-URL': websiteUrl,
					'Content-Type': 'application/json',
					Accept: 'application/json',
					'Cache-Control': 'no-cache',
					'User-Agent': 'MEC-Events-App/1.0',
					'X-Requested-With': 'XMLHttpRequest'
				},
				connectTimeout: 15000,
				readTimeout: 15000
			})

			if (response.status < 200 || response.status >= 300) {
				throw new Error(`HTTP ${response.status}: Request failed`)
			}

			const data = response.data

			if (data.success) {
				this.sessionData = data
				localStorage.setItem('mec_session_data', JSON.stringify(data))
				return {
					success: true,
					sessionData: data
				}
			} else {
				throw new Error(data.error || 'Session refresh failed')
			}
		} catch (error) {
			console.error('💥 [MECAuthService] Session refresh error:', error)
			return {
				success: false,
				error: error.message || 'Session refresh failed'
			}
		}
	}

	// Check if user is authenticated
	isAuthenticated() {
		return !!(this.apiKey && this.sessionData)
	}

	// Get session data
	getSessionData() {
		return this.sessionData
	}

	// Get API key (for debugging - should not be exposed in production)
	getApiKey() {
		return this.apiKey ? this.apiKey.substring(0, 10) + '...' : null
	}

	// Logout
	logout() {
		this.apiKey = null
		this.sessionData = null
		this.baseURL = null

		// Clear stored credentials
		localStorage.removeItem('mec_api_key')
		localStorage.removeItem('mec_website_url')
		localStorage.removeItem('mec_session_data')

		return { success: true, message: 'Logged out successfully' }
	}

	// Restore session from localStorage
	restoreSession() {

		const storedApiKey = localStorage.getItem('mec_api_key')
		const storedWebsiteUrl = localStorage.getItem('mec_website_url')
		const storedSessionData = localStorage.getItem('mec_session_data')

		if (storedApiKey && storedWebsiteUrl && storedSessionData) {
			try {
				this.apiKey = storedApiKey
				this.setBaseURL(storedWebsiteUrl)
				this.sessionData = JSON.parse(storedSessionData)

				return {
					success: true,
					message: 'Session restored',
					sessionData: this.sessionData
				}
			} catch (error) {
				console.error('❌ [MECAuthService] Failed to restore session:', error)
				this.logout() // Clear invalid data
				return {
					success: false,
					error: 'Failed to restore session'
				}
			}
		}

		return {
			success: false,
			error: 'No stored session found'
		}
	}

	// Generic API request method
	async makeRequest(endpoint, options = {}) {
		if (!this.apiKey) {
			return { success: false, error: 'Not authenticated' }
		}

		const url = `${this.baseURL}${endpoint}`
		const defaultOptions = {
			method: 'GET',
			headers: {
				Authorization: `Bearer ${this.apiKey}`,
				'Content-Type': 'application/json',
				Accept: 'application/json',
				'User-Agent': 'MEC-Events-App/1.0'
			},
			connectTimeout: 15000,
			readTimeout: 15000
		}

		const requestOptions = {
			...defaultOptions,
			...options,
			url: url,
			headers: {
				...defaultOptions.headers,
				...options.headers
			}
		}

		// Handle body data for PUT/POST requests
		if (options.body && (options.method === 'PUT' || options.method === 'POST')) {
			requestOptions.data = options.body
			delete requestOptions.body
		}

		// Add Android-specific options
		if (Capacitor.getPlatform() === 'android') {
			requestOptions.webFetchExtra = {
				mode: 'cors'
			}
		}

		try {

			const response = await CapacitorHttp.request(requestOptions)

			if (response.status < 200 || response.status >= 300) {
				throw new Error(`HTTP ${response.status}: Request failed`)
			}

			return {
				success: true,
				data: response.data
			}
		} catch (error) {
			console.error(`💥 [MECAuthService] Request failed for ${endpoint}:`, error)
			console.error('Platform:', Capacitor.getPlatform())
			console.error('Error type:', error.constructor.name)
			console.error('Error message:', error.message)

			// Platform-specific error handling
			if (Capacitor.getPlatform() === 'android') {
				console.error('🤖 [Android] HTTP request error details:')
				if (error.message && error.message.includes('null')) {
					console.error(
						'🤖 [Android] Null pointer in HTTP request - possible plugin issue'
					)
				}
			}

			return {
				success: false,
				error: error.message || 'Request failed'
			}
		}
	}

	// Public (unauthenticated) API request method - for QR validate/exchange
	async makePublicRequest(endpoint, options = {}) {
		if (!this.baseURL) {
			return { success: false, error: 'Base URL is not set' }
		}

		const url = `${this.baseURL}${endpoint}`
		const defaultOptions = {
			method: 'GET',
			headers: {
				'Content-Type': 'application/json',
				Accept: 'application/json',
				'User-Agent': 'MEC-Events-App/1.0'
			},
			connectTimeout: 15000,
			readTimeout: 15000
		}

		const requestOptions = {
			...defaultOptions,
			...options,
			url: url,
			headers: {
				...defaultOptions.headers,
				...options.headers
			}
		}

		// Add Android-specific options
		if (Capacitor.getPlatform() === 'android') {
			requestOptions.webFetchExtra = {
				mode: 'cors'
			}
		}

		try {
			const response = await CapacitorHttp.request(requestOptions)

			if (response.status < 200 || response.status >= 300) {
				throw new Error(`HTTP ${response.status}: Request failed`)
			}

			return {
				success: true,
				data: response.data
			}
		} catch (error) {
			console.error(`💥 [MECAuthService] Public request failed for ${endpoint}:`, error)
			return {
				success: false,
				error: error.message || 'Request failed'
			}
		}
	}

	// Get user info
	async getUserInfo() {
		const websiteUrl = this.baseURL.replace('/wp-json/mec-utility/v1', '')
		return await this.makeRequest('/user/info', {
			method: 'POST',
			headers: {
				'X-API-Key': this.apiKey,
				'X-Website-URL': websiteUrl
			},
			data: {
				api_key: this.apiKey,
				website_url: websiteUrl
			}
		})
	}

	// Delete event
	async deleteEvent(eventId) {
		if (!this.apiKey) {
			return { success: false, error: 'Not authenticated' }
		}

		try {
			const response = await this.makeRequest(`/events/${eventId}`, {
				method: 'DELETE',
				headers: {
					'X-API-Key': this.apiKey
				}
			})

			return response
		} catch (error) {
			console.error('💥 [MECAuthService] Delete event error:', error)
			return {
				success: false,
				error: error.message || 'Failed to delete event'
			}
		}
	}

	// Test basic network connectivity
	async testBasicConnectivity() {
		try {

			const response = await CapacitorHttp.request({
				url: 'https://httpbin.org/status/200',
				method: 'GET',
				connectTimeout: 10000,
				readTimeout: 10000
			})

			const isConnected = response.status === 200

			return {
				success: isConnected,
				status: response.status
			}
		} catch (error) {
			console.error('💥 [MECAuthService] Basic connectivity test failed:', error)
			return {
				success: false,
				error: error.message || 'Network connectivity test failed'
			}
		}
	}
}

// Export both the class and a singleton instance
export { MECAuthService }

// Export singleton instance as default
const mecAuthService = new MECAuthService()
export default mecAuthService
