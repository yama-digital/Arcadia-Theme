<?php

/**
 * Plugin Name: MEC Utility
 * Plugin URI: http://webnus.net/modern-events-calendar/
 * Description: Utility plugin for Modern Events Calendar with API and mobile app integration. Provides authentication, QR codes, and route management.
 * Version: 1.2.0
 * Author: Webnus
 * Author URI: https://webnus.net
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: mec-utility
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('MEC_UTILITY_VERSION', '1.2.0');
define('MEC_UTILITY_PLUGIN_FILE', __FILE__);
define('MEC_UTILITY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MEC_UTILITY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MEC_UTILITY_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('MEC_UTILITY_TEXT_DOMAIN', 'mec-utility');

// Auto-update constants
define('MEC_UTILITY_MAIN_FILE_PATH', __FILE__);
define('MEC_UTILITY_ABSPATH', dirname(__FILE__));


// MEC plugin slugs (Pro and Lite versions)
define('MEC_UTILITY_MEC_PRO_SLUG', 'modern-events-calendar/mec.php');
define('MEC_UTILITY_MEC_LITE_SLUG', 'modern-events-calendar-lite/modern-events-calendar-lite.php');

/**
 * Check if any version of MEC (Pro or Lite) is installed
 */
function mec_utility_is_mec_installed()
{
    $mec_pro_path = WP_PLUGIN_DIR . '/' . MEC_UTILITY_MEC_PRO_SLUG;
    $mec_lite_path = WP_PLUGIN_DIR . '/' . MEC_UTILITY_MEC_LITE_SLUG;

    return file_exists($mec_pro_path) || file_exists($mec_lite_path);
}

/**
 * Check if any version of MEC (Pro or Lite) is active
 */
function mec_utility_is_mec_active()
{
    // Ensure plugin.php is loaded
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    return is_plugin_active(MEC_UTILITY_MEC_PRO_SLUG) || is_plugin_active(MEC_UTILITY_MEC_LITE_SLUG);
}

/**
 * Get active MEC version info
 */
function mec_utility_get_mec_version()
{
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    if (is_plugin_active(MEC_UTILITY_MEC_PRO_SLUG)) {
        return [
            'version' => 'pro',
            'slug' => MEC_UTILITY_MEC_PRO_SLUG,
            'name' => 'Modern Events Calendar (Pro)'
        ];
    } elseif (is_plugin_active(MEC_UTILITY_MEC_LITE_SLUG)) {
        return [
            'version' => 'lite',
            'slug' => MEC_UTILITY_MEC_LITE_SLUG,
            'name' => 'Modern Events Calendar (Lite)'
        ];
    }

    return null;
}

/**
 * Check if MEC plugin is installed and active
 */
function mec_utility_check_mec_dependency()
{
    // Ensure plugin.php is loaded
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    // Debug: Check what plugins are active
    $active_plugins = get_option('active_plugins', array());

    // Check if any version of MEC is active
    if (!mec_utility_is_mec_active()) {
        // Show admin notice but don't deactivate (for debugging)
        add_action('admin_notices', function() use ($active_plugins) {
            mec_utility_mec_missing_notice();

            // Debug information
            echo '<div class="notice notice-info">';
            echo '<p><strong>Debug Info:</strong></p>';
            echo '<p>Looking for: MEC Pro or MEC Lite</p>';
            echo '<p>MEC Pro: ' . MEC_UTILITY_MEC_PRO_SLUG . ' - ' . (file_exists(WP_PLUGIN_DIR . '/' . MEC_UTILITY_MEC_PRO_SLUG) ? 'Installed' : 'Not installed') . '</p>';
            echo '<p>MEC Lite: ' . MEC_UTILITY_MEC_LITE_SLUG . ' - ' . (file_exists(WP_PLUGIN_DIR . '/' . MEC_UTILITY_MEC_LITE_SLUG) ? 'Installed' : 'Not installed') . '</p>';
            echo '<p>Active plugins: ' . esc_html(implode(', ', $active_plugins)) . '</p>';
            echo '</div>';
        });

        // Continue loading for debugging (comment this return to allow loading)
        // return false;
    }

    return true;
}

/**
 * Admin notice when MEC is not active
 */
function mec_utility_mec_missing_notice()
{
    $plugin_name = __('MEC Utility', MEC_UTILITY_TEXT_DOMAIN);

    echo '<div class="notice notice-error is-dismissible">';
    echo '<p>';
    printf(
        /* translators: %s: Plugin name */
        __('<strong>%s</strong> requires <strong>Modern Events Calendar</strong> plugin (Pro or Lite version) to be installed and activated.', MEC_UTILITY_TEXT_DOMAIN),
        $plugin_name
    );
    echo '</p>';
    echo '<p>';
    _e('You can install one of these versions:', MEC_UTILITY_TEXT_DOMAIN);
    echo '</p>';
    echo '<ul style="list-style: disc; padding-left: 20px;">';
    echo '<li><strong>MEC Pro:</strong> Full featured version with bookings, payments, etc.</li>';
    echo '<li><strong>MEC Lite:</strong> Free version with basic event management (no bookings)</li>';
    echo '</ul>';
    echo '<p>';
    printf(
        /* translators: %s: Plugin installation URL */
        __('<a href="%s" class="button button-primary">Install Modern Events Calendar</a>', MEC_UTILITY_TEXT_DOMAIN),
        admin_url('plugin-install.php?s=modern+events+calendar&tab=search&type=term')
    );
    echo '</p>';
    echo '</div>';
}

/**
 * Admin notice when wp-json is disabled
 */
function mec_utility_wp_json_notice()
{
    // Only show notice if wp-json is disabled
    if (!get_option('mec_utility_wp_json_disabled', false)) {
        return;
    }

    $plugin_name = __('MEC Utility', MEC_UTILITY_TEXT_DOMAIN);
    $wp_json_url = get_rest_url();

    echo '<div class="notice notice-warning is-dismissible">';
    echo '<p>';
    printf(
        /* translators: %s: Plugin name */
        __('<strong>%s</strong>: WordPress REST API (wp-json) is disabled on your site.', MEC_UTILITY_TEXT_DOMAIN),
        $plugin_name
    );
    echo '</p>';
    echo '<p>';
    _e('This will prevent the MEC Utility API from working properly. Mobile apps and external integrations that rely on the REST API will not function.', MEC_UTILITY_TEXT_DOMAIN);
    echo '</p>';
    echo '<p>';
    printf(
        /* translators: %s: wp-json URL */
        __('<strong>Expected URL:</strong> <code>%s</code>', MEC_UTILITY_TEXT_DOMAIN),
        esc_url($wp_json_url)
    );
    echo '</p>';
    echo '<p>';
    _e('<strong>To fix this issue:</strong>', MEC_UTILITY_TEXT_DOMAIN);
    echo '</p>';
    echo '<ul style="list-style-type: disc; margin-left: 20px;">';
    echo '<li>' . __('Check if your theme or another plugin is blocking REST API access', MEC_UTILITY_TEXT_DOMAIN) . '</li>';
    echo '<li>' . __('Verify that your .htaccess file is not blocking wp-json requests', MEC_UTILITY_TEXT_DOMAIN) . '</li>';
    echo '<li>' . __('Ensure your hosting provider allows REST API access', MEC_UTILITY_TEXT_DOMAIN) . '</li>';
    echo '<li>' . __('Check if you have any security plugins that might be blocking the REST API', MEC_UTILITY_TEXT_DOMAIN) . '</li>';
    echo '</ul>';
    echo '<p>';
    printf(
        /* translators: %s: Settings page URL */
        __('<a href="%s" class="button button-primary">Go to MEC Utility Settings</a>', MEC_UTILITY_TEXT_DOMAIN),
        admin_url('admin.php?page=mec-utility-settings')
    );
    echo '</p>';
    echo '</div>';
}

/**
 * Periodically check wp-json accessibility
 */
function mec_utility_check_wp_json_periodic()
{
    // Only check once per day
    $last_check = get_option('mec_utility_wp_json_last_check', 0);
    $current_time = time();

    if ($current_time - $last_check < 86400) { // 24 hours
        return;
    }

    // Update last check time
    update_option('mec_utility_wp_json_last_check', $current_time);

    // Test wp-json endpoint
    $wp_json_url = get_rest_url();
    $response = wp_remote_get($wp_json_url, array(
        'timeout' => 10,
        'user-agent' => 'MEC-Utility-Plugin/1.0.0'
    ));

    // Check if wp-json is accessible
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        // Store flag to show admin notice
        update_option('mec_utility_wp_json_disabled', true);
        update_option('mec_utility_wp_json_disabled_time', current_time('mysql'));
    } else {
        // Clear the flag if wp-json is working
        delete_option('mec_utility_wp_json_disabled');
        delete_option('mec_utility_wp_json_disabled_time');
    }
}

/**
 * Plugin activation hook
 */
function mec_utility_activate()
{
    // Ensure plugin.php is loaded
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    // Check if any version of MEC is installed
    if (!mec_utility_is_mec_installed()) {
        wp_die(
            sprintf(
                /* translators: %s: Required plugin name */
                __('MEC Utility requires %s plugin (Pro or Lite version) to be installed first.', MEC_UTILITY_TEXT_DOMAIN),
                'Modern Events Calendar'
            ),
            __('Plugin Activation Error', MEC_UTILITY_TEXT_DOMAIN),
            ['back_link' => true]
        );
    }

    // Check if any version of MEC is active
    if (!mec_utility_is_mec_active()) {
        $mec_version = mec_utility_is_mec_installed() ? 'installed but not activated' : 'not installed';
        wp_die(
            sprintf(
                /* translators: %1$s: Required plugin name, %2$s: Installation status */
                __('MEC Utility requires %1$s plugin to be activated first. Status: %2$s', MEC_UTILITY_TEXT_DOMAIN),
                'Modern Events Calendar',
                $mec_version
            ),
            __('Plugin Activation Error', MEC_UTILITY_TEXT_DOMAIN),
            ['back_link' => true]
        );
    }

    // Load composer autoloader if available
    if (file_exists(MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php')) {
        require_once MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php';

        // Run activation
        if (class_exists('MecUtility\Core\Activator')) {
            MecUtility\Core\Activator::activate();
        }
    }
}

/**
 * Plugin deactivation hook
 */
function mec_utility_deactivate()
{
    // Load composer autoloader if available
    if (file_exists(MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php')) {
        require_once MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php';

        // Run deactivation
        if (class_exists('MecUtility\Core\Deactivator')) {
            MecUtility\Core\Deactivator::deactivate();
        }
    }
}

/**
 * Ensure database tables exist (manual creation if needed)
 */
function mec_utility_ensure_database_tables() {
    global $wpdb;

    // Check if tables exist
    $api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$api_keys_table'");

    if ($table_exists != $api_keys_table) {
        // Tables don't exist, create them
        if (class_exists('MecUtility\Core\Activator')) {
            MecUtility\Core\Activator::activate();
        } else {
            // Manual table creation if Activator class not available
            mec_utility_create_tables_manual();
        }
    }
}

/**
 * Manual database tables creation
 */
function mec_utility_create_tables_manual() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    // API Keys table
    $api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
    $api_keys_sql = "CREATE TABLE $api_keys_table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        user_id bigint(20) unsigned NOT NULL,
        api_key varchar(64) NOT NULL,
        api_secret varchar(64) NOT NULL,
        name varchar(200) NOT NULL,
        permissions text,
        last_access datetime DEFAULT NULL,
        is_active tinyint(1) DEFAULT 1,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY api_key (api_key),
        KEY user_id (user_id),
        KEY is_active (is_active)
    ) $charset_collate;";

    // QR Sessions table
    $qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
    $qr_sessions_sql = "CREATE TABLE $qr_sessions_table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        user_id bigint(20) unsigned NOT NULL,
        qr_token varchar(64) NOT NULL,
        session_data text,
        expires_at datetime DEFAULT NULL,
        used_at datetime DEFAULT NULL,
        is_used tinyint(1) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY qr_token (qr_token),
        KEY user_id (user_id),
        KEY expires_at (expires_at),
        KEY is_used (is_used)
    ) $charset_collate;";

    // Activity Logs table
    $activity_logs_table = $wpdb->prefix . 'mec_utility_activity_logs';
    $activity_logs_sql = "CREATE TABLE $activity_logs_table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        user_id bigint(20) unsigned DEFAULT NULL,
        api_key_id bigint(20) unsigned DEFAULT NULL,
        action varchar(100) NOT NULL,
        object_type varchar(50) DEFAULT NULL,
        object_id bigint(20) unsigned DEFAULT NULL,
        ip_address varchar(45) DEFAULT NULL,
        user_agent text,
        request_data text,
        response_data text,
        status varchar(20) DEFAULT 'success',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY api_key_id (api_key_id),
        KEY action (action),
        KEY status (status),
        KEY created_at (created_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($api_keys_sql);
    dbDelta($qr_sessions_sql);
    dbDelta($activity_logs_sql);

    // Set default options
    $default_options = array(
        'mec_utility_api_enabled'     => 1,
        'mec_utility_qr_enabled'      => 1,
        'mec_utility_qr_expiry'       => 300,
        'mec_utility_rate_limit'      => 100,
        'mec_utility_log_retention'   => 30,
        'mec_utility_require_ssl'     => 0,
        'mec_utility_allowed_origins' => '',
        'mec_utility_jwt_secret'      => wp_generate_password(64, true, true),
    );

    foreach ($default_options as $option_name => $option_value) {
        if (get_option($option_name) === false) {
            add_option($option_name, $option_value);
        }
    }
}

/**
 * Initialize the plugin
 */
function mec_utility_init()
{
    // Check MEC dependency
    if (!mec_utility_check_mec_dependency()) {
        return;
    }

    // Load text domain
    load_plugin_textdomain(
        MEC_UTILITY_TEXT_DOMAIN,
        false,
        dirname(plugin_basename(__FILE__)) . '/languages/'
    );

    // CORS headers are handled by the anonymous function at the bottom of this file

    // Explicitly load core classes first
    $core_files = [
        'src/MecUtility/Core/Loader.php',
        'src/MecUtility/Core/I18n.php',
        'src/MecUtility/Core/Plugin.php',
        'src/MecUtility/Core/CorsHandler.php',
        'src/MecUtility/Auth/AuthHelper.php',
        'src/MecUtility/Services/QrCodeService.php',
        'src/MecUtility/Admin/AdminController.php',
        'src/MecUtility/PublicArea/PublicController.php',
        // Load API Controllers before ApiController
        'src/MecUtility/Api/Controllers/EventsController.php',
        'src/MecUtility/Api/Controllers/EventBookingController.php',
        'src/MecUtility/Api/Controllers/EventRSVPController.php',
        'src/MecUtility/Api/Controllers/BookingsExportController.php',
        'src/MecUtility/Api/Controllers/InvoiceController.php',
        'src/MecUtility/Api/AttendeesController.php',
        'src/MecUtility/Api/BookingFieldsRoutes.php',
        'src/MecUtility/Api/RSVPRoutes.php',
        'src/MecUtility/Api/WaitingListRoutes.php',
        'src/MecUtility/Api/DirectRoutes.php',
        'src/MecUtility/Controllers/QrScanController.php',
        'src/MecUtility/Controllers/QrGenerateController.php',
        'src/MecUtility/Controllers/TranslateController.php',
        // Load ApiController last
        'src/MecUtility/Api/ApiController.php',
    ];

    foreach ($core_files as $file) {
        $file_path = MEC_UTILITY_PLUGIN_DIR . $file;
        if (file_exists($file_path)) {
            require_once $file_path;
        }
    }

    // Load composer autoloader or manual includes
    if (file_exists(MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php')) {
        require_once MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php';
    } else {
        // Manual loading for additional development files (if any)
        // Core files are already loaded above
    }

    // Initialize CORS handler
    if (class_exists('MecUtility\Core\CorsHandler')) {
        MecUtility\Core\CorsHandler::init();
    }

    // Initialize plugin
    if (class_exists('MecUtility\Core\Plugin')) {
        $plugin_instance = MecUtility\Core\Plugin::get_instance();
        $plugin_instance->run();
    }

    // Ensure database tables exist
    mec_utility_ensure_database_tables();

    // Add backward compatibility for WordPress functions
    if (!function_exists('esc_js_e')) {
        /**
         * Backward compatibility for esc_js_e function (WP 6.2+)
         */
        function esc_js_e($text, $domain = 'default') {
            echo esc_js(__($text, $domain));
        }
    }

    // Admin menu and API registration are now handled by Plugin.php and AdminController
    // No need for fallback registration as proper initialization is in place

    // License
    $license_file = MEC_UTILITY_ABSPATH . '/core/update-activation.php';
    if (file_exists($license_file)) {
        require_once $license_file;
        MecUtility\Core\checkLicense\UtilityAddonUpdateActivation::instance();
    }
}

/**
 * Add admin menu (fallback method - only used if AdminController fails)
 */
function mec_utility_add_admin_menu() {
    // This function is kept as fallback but should not be called normally
    // AdminController handles all menu registration
    if (!class_exists('MecUtility\Admin\AdminController')) {
        // Main menu page
        add_menu_page(
            __('MEC Utility', 'mec-utility'),
            __('MEC Utility', 'mec-utility'),
            'manage_options',
            'mec-utility',
            'mec_utility_dashboard_page',
            plugin_dir_url(__FILE__) . '../../../admin/img/mec-utility.svg',
            30
        );

        // App Access submenu
        add_submenu_page(
            'mec-utility',
            __('App Access', 'mec-utility'),
            __('App Access', 'mec-utility'),
            'manage_options',
            'mec-utility-app-access',
            'mec_utility_app_access_page'
        );

        // Settings submenu
        add_submenu_page(
            'mec-utility',
            __('Settings', 'mec-utility'),
            __('Settings', 'mec-utility'),
            'manage_options',
            'mec-utility-settings',
            'mec_utility_settings_page'
        );
    }
}

/**
 * Dashboard page callback
 */
function mec_utility_dashboard_page() {
    // Debug: Check if AdminController exists
    if (!class_exists('MecUtility\Admin\AdminController')) {
        echo '<div class="wrap">';
        echo '<h1>MEC Utility Dashboard</h1>';
        echo '<div class="notice notice-error"><p><strong>Debug Info:</strong></p>';
        echo '<p>AdminController class not found.</p>';
        echo '<p>Plugin Dir: ' . MEC_UTILITY_PLUGIN_DIR . '</p>';
        echo '<p>AdminController file exists: ' . (file_exists(MEC_UTILITY_PLUGIN_DIR . 'src/MecUtility/Admin/AdminController.php') ? 'Yes' : 'No') . '</p>';
        echo '<p>Autoloader exists: ' . (file_exists(MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php') ? 'Yes' : 'No') . '</p>';
        echo '</div>';
        echo '</div>';
        return;
    }

    $admin_controller = new MecUtility\Admin\AdminController('mec-utility', MEC_UTILITY_VERSION);
    $admin_controller->dashboard_page();
}

/**
 * App Access page callback
 */
function mec_utility_app_access_page() {
    // Debug: Check if AdminController exists
    if (!class_exists('MecUtility\Admin\AdminController')) {
        echo '<div class="wrap">';
        echo '<h1>App Access</h1>';
        echo '<div class="notice notice-error"><p><strong>Debug Info:</strong></p>';
        echo '<p>AdminController class not found.</p>';
        echo '<p>Plugin Dir: ' . MEC_UTILITY_PLUGIN_DIR . '</p>';
        echo '<p>AdminController file exists: ' . (file_exists(MEC_UTILITY_PLUGIN_DIR . 'src/MecUtility/Admin/AdminController.php') ? 'Yes' : 'No') . '</p>';
        echo '<p>Autoloader exists: ' . (file_exists(MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php') ? 'Yes' : 'No') . '</p>';
        echo '</div>';
        echo '</div>';
        return;
    }

    $admin_controller = new MecUtility\Admin\AdminController('mec-utility', MEC_UTILITY_VERSION);
    $admin_controller->app_access_page();
}

/**
 * Settings page callback
 */
function mec_utility_settings_page() {
    // Debug: Check if AdminController exists
    if (!class_exists('MecUtility\Admin\AdminController')) {
        echo '<div class="wrap">';
        echo '<h1>Settings</h1>';
        echo '<div class="notice notice-error"><p><strong>Debug Info:</strong></p>';
        echo '<p>AdminController class not found.</p>';
        echo '<p>Plugin Dir: ' . MEC_UTILITY_PLUGIN_DIR . '</p>';
        echo '<p>AdminController file exists: ' . (file_exists(MEC_UTILITY_PLUGIN_DIR . 'src/MecUtility/Admin/AdminController.php') ? 'Yes' : 'No') . '</p>';
        echo '<p>Autoloader exists: ' . (file_exists(MEC_UTILITY_PLUGIN_DIR . 'vendor/autoload.php') ? 'Yes' : 'No') . '</p>';
        echo '</div>';
        echo '</div>';
        return;
    }

    $admin_controller = new MecUtility\Admin\AdminController('mec-utility', MEC_UTILITY_VERSION);
    $admin_controller->settings_page();
}

/**
 * Admin init callback (fallback - only used if AdminController fails)
 */
function mec_utility_admin_init() {
    // This function is kept as fallback but should not be called normally
    // AdminController handles all admin initialization
    if (!class_exists('MecUtility\Admin\AdminController')) {
        // Register settings
        register_setting('mec_utility_settings', 'mec_utility_api_enabled');
        register_setting('mec_utility_settings', 'mec_utility_qr_enabled');
        register_setting('mec_utility_settings', 'mec_utility_qr_expiry');
        register_setting('mec_utility_settings', 'mec_utility_rate_limit');
        register_setting('mec_utility_settings', 'mec_utility_require_ssl');
        register_setting('mec_utility_settings', 'mec_utility_allowed_origins');
    }
}

/**
 * Enqueue admin scripts and styles (fallback - only used if AdminController fails)
 */
function mec_utility_admin_scripts() {
    // This function is kept as fallback but should not be called normally
    // AdminController handles all script/style enqueuing
    if (!class_exists('MecUtility\Admin\AdminController')) {
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        // Enqueue admin styles if available
        if (file_exists(MEC_UTILITY_PLUGIN_DIR . 'admin/css/admin.css')) {
            wp_enqueue_style(
                'mec-utility-admin',
                MEC_UTILITY_PLUGIN_URL . 'admin/css/admin.css',
                array(),
                MEC_UTILITY_VERSION
            );
        }

        // Enqueue admin scripts if available
        if (file_exists(MEC_UTILITY_PLUGIN_DIR . 'admin/js/admin.js')) {
            wp_enqueue_script(
                'mec-utility-admin',
                MEC_UTILITY_PLUGIN_URL . 'admin/js/admin.js',
                array('jquery', 'wp-color-picker'),
                MEC_UTILITY_VERSION,
                false
            );

            // Localize script for AJAX
            wp_localize_script(
                'mec-utility-admin',
                'mecUtilityAjax',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce'    => wp_create_nonce('mec_utility_ajax_nonce'),
                    'strings'  => array(
                        'confirm_delete'     => __('Are you sure you want to delete this item?', 'mec-utility'),
                        'qr_generation_error' => __('Failed to generate QR code. Please try again.', 'mec-utility'),
                    ),
                )
            );
        }
    }
}

/**
 * Load Direct Routes (Backup Method)
 *
 * All API route functions are now organized in a separate file
 * to keep the main plugin file clean and modular.
 */
require_once plugin_dir_path(__FILE__) . 'src/MecUtility/Api/DirectRoutes.php';

// Register hooks
register_activation_hook(__FILE__, 'mec_utility_activate');
register_deactivation_hook(__FILE__, 'mec_utility_deactivate');

// CORS handling moved to .htaccess for better mobile app compatibility

// Initialize plugin on plugins_loaded
add_action('plugins_loaded', 'mec_utility_init');

// Check dependency on admin_init (for when MEC gets deactivated)
add_action('admin_init', function () {
    if (is_plugin_active(plugin_basename(__FILE__))) {
        mec_utility_check_mec_dependency();
    }
});

// Check wp-json accessibility and show admin notice
add_action('admin_notices', 'mec_utility_wp_json_notice');

// Periodically check wp-json accessibility (every 24 hours)
add_action('wp_loaded', 'mec_utility_check_wp_json_periodic');