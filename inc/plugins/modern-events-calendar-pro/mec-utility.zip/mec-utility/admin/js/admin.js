/**
 * MEC Utility Admin JavaScript
 *
 * @package    MecUtility
 * @subpackage MecUtility/admin/js
 * @author     Your Name <your-email@domain.com>
 */

(function ($) {
  'use strict';

  /**
   * Initialize admin functionality when document is ready
   */
  $(document).ready(function () {
    MecUtilityAdmin.init();
  });

  /**
   * Main admin object
   */
  var MecUtilityAdmin = {
    /**
     * Initialize all admin functionality
     */
    init: function () {
      this.initClipboard();
      this.initForms();
      this.initTables();
      this.initQRCodes();
      this.initSettings();
      this.initNotifications();
    },

    /**
     * Initialize clipboard functionality
     */
    initClipboard: function () {
      // Copy to clipboard functionality
      $(document).on(
        'click',
        '.mec-utility-copy-btn, .mec-utility-copy-key',
        function (e) {
          e.preventDefault();

          var $btn = $(this);
          var textToCopy =
            $btn.data('copy') ||
            $btn.parent().data('copy') ||
            $btn.closest('.mec-utility-copy-text').data('copy');

          if (!textToCopy) {
            console.warn('No text to copy found');
            return;
          }

          // Use modern clipboard API if available
          if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard
              .writeText(textToCopy)
              .then(function () {
                MecUtilityAdmin.showCopySuccess($btn);
              })
              .catch(function (err) {
                console.error('Failed to copy text: ', err);
                MecUtilityAdmin.fallbackCopyText(textToCopy, $btn);
              });
          } else {
            // Fallback for older browsers
            MecUtilityAdmin.fallbackCopyText(textToCopy, $btn);
          }
        }
      );
    },

    /**
     * Fallback copy method for older browsers
     */
    fallbackCopyText: function (text, $btn) {
      var textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      try {
        var successful = document.execCommand('copy');
        if (successful) {
          this.showCopySuccess($btn);
        } else {
          this.showCopyError($btn);
        }
      } catch (err) {
        console.error('Fallback copy failed: ', err);
        this.showCopyError($btn);
      }

      document.body.removeChild(textArea);
    },

    /**
     * Show copy success feedback
     */
    showCopySuccess: function ($btn) {
      var originalText = $btn.text();
      var originalClass = $btn.attr('class');

      $btn.addClass('copied').text(mecUtilityAjax.strings.success || 'Copied!');

      setTimeout(function () {
        $btn.removeClass('copied').text(originalText);
      }, 2000);
    },

    /**
     * Show copy error feedback
     */
    showCopyError: function ($btn) {
      var originalText = $btn.text();

      $btn.addClass('error').text('Failed');

      setTimeout(function () {
        $btn.removeClass('error').text(originalText);
      }, 2000);
    },

    /**
     * Initialize form functionality
     */
    initForms: function () {
      // Show/Hide API Key form (legacy)
      $(document).on(
        'click',
        '#mec-utility-add-api-key, #mec-utility-create-first-key',
        function (e) {
          e.preventDefault();
          $('#mec-utility-api-key-form').slideDown(300);
          $('#api_key_name').focus();
        }
      );

      // Cancel API Key form (legacy)
      $(document).on('click', '#mec-utility-cancel-api-key', function (e) {
        e.preventDefault();
        $('#mec-utility-api-key-form').slideUp(300);
      });

      // Show/Hide App Access form (new unified)
      $(document).on(
        'click',
        '#mec-utility-add-app-access, #mec-utility-create-first-access',
        function (e) {
          e.preventDefault();
          $('#mec-utility-app-access-form').slideDown(300);
          $('#app_name').focus();
        }
      );

      // Cancel App Access form (new unified)
      $(document).on('click', '#mec-utility-cancel-app-access', function (e) {
        e.preventDefault();
        $('#mec-utility-app-access-form').slideUp(300);
      });

      // Show/Hide QR form (legacy)
      $(document).on(
        'click',
        '#mec-utility-generate-qr, #mec-utility-generate-first-qr, #mec-utility-refresh-qr',
        function (e) {
          e.preventDefault();
          $('#mec-utility-qr-form').slideDown(300);
          $('#qr_expiry').focus();
        }
      );

      // Cancel QR form (legacy)
      $(document).on('click', '#mec-utility-cancel-qr', function (e) {
        e.preventDefault();
        $('#mec-utility-qr-form').slideUp(300);
      });

      // Form validation
      $('form').on('submit', function (e) {
        var $form = $(this);
        var isValid = true;

        // Validate required fields
        $form.find('[required]').each(function () {
          var $field = $(this);
          if (!$field.val().trim()) {
            $field.addClass('error');
            isValid = false;
          } else {
            $field.removeClass('error');
          }
        });

        if (!isValid) {
          e.preventDefault();
          MecUtilityAdmin.showNotification(
            'Please fill in all required fields.',
            'error'
          );
        }
      });

      // Remove error class on input
      $(document).on('input', '.error', function () {
        $(this).removeClass('error');
      });
    },

    /**
     * Initialize table functionality
     */
    initTables: function () {
      // Toggle API Key visibility (legacy and new)
      $(document).on('click', '.mec-utility-toggle-key', function (e) {
        e.preventDefault();

        var $btn = $(this);
        var $row = $btn.closest('.mec-utility-credential-row, tr');
        var $preview = $row.find('.mec-utility-key-preview');
        var $full = $row.find('.mec-utility-key-full');
        var $copyBtn = $row.find('.mec-utility-copy-key');

        if ($preview.is(':visible')) {
          $preview.hide();
          $full.show();
          if ($copyBtn.length) $copyBtn.show();
          $btn.text('Hide');
        } else {
          $preview.show();
          $full.hide();
          if ($copyBtn.length) $copyBtn.hide();
          $btn.text('Show');
        }
      });

      // Toggle API Secret visibility (new unified interface)
      $(document).on('click', '.mec-utility-toggle-secret', function (e) {
        e.preventDefault();

        var $btn = $(this);
        var $row = $btn.closest('.mec-utility-credential-row');
        var $preview = $row.find('.mec-utility-secret-preview');
        var $full = $row.find('.mec-utility-secret-full');

        if ($preview.is(':visible')) {
          $preview.hide();
          $full.show();
          $btn.text('Hide');
        } else {
          $preview.show();
          $full.hide();
          $btn.text('Show');
        }
      });

      // Copy to clipboard functionality (new unified interface)
      $(document).on('click', '.mec-utility-copy-btn', function (e) {
        e.preventDefault();

        var $btn = $(this);
        var textToCopy = $btn.closest('.mec-utility-copy-text').data('copy');

        if (navigator.clipboard && textToCopy) {
          navigator.clipboard
            .writeText(textToCopy)
            .then(function () {
              $btn.addClass('copied');
              setTimeout(function () {
                $btn.removeClass('copied');
              }, 2000);
            })
            .catch(function () {
              // Fallback for older browsers
              MecUtilityAdmin.fallbackCopyToClipboard(textToCopy);
            });
        }
      });

      // Confirm delete actions
      $(document).on('submit', 'form[onsubmit*="confirm"]', function (e) {
        var confirmMessage = $(this)
          .attr('onsubmit')
          .match(/'([^']+)'/);
        if (confirmMessage && !confirm(confirmMessage[1])) {
          e.preventDefault();
        }
      });

      // Enhanced delete confirmation
      $(document).on('click', '.button-link-delete', function (e) {
        if (
          !confirm(
            mecUtilityAjax.strings.confirm_delete ||
              'Are you sure you want to delete this item?'
          )
        ) {
          e.preventDefault();
        }
      });
    },

    /**
     * Initialize QR code functionality
     */
    initQRCodes: function () {
      // Generate QR codes for all elements with data-qr attribute
      this.generateAllQRCodes();

      // Download QR code functionality (legacy)
      $(document).on('click', '#mec-utility-download-qr', function (e) {
        e.preventDefault();
        MecUtilityAdmin.downloadQRCode();
      });

      // Download QR code functionality (unified interface)
      $(document).on('click', '.mec-utility-download-qr', function (e) {
        e.preventDefault();
        var qrToken = $(this).data('qr');
        var $btn = $(this);
        MecUtilityAdmin.downloadQRCodeUnified(qrToken, $btn);
      });
    },

    /**
     * Generate QR codes for all elements
     */
    generateAllQRCodes: function () {
      $('[data-qr], .mec-utility-qr-code[data-qr]').each(function () {
        var $element = $(this);
        var qrToken = $element.data('qr');

        if (qrToken) {
          MecUtilityAdmin.generateQRCode($element, qrToken);
        }
      });
    },

    /**
     * Generate QR code for a specific element
     */
    generateQRCode: function ($element, qrToken) {
      var size = 150; // Default size for unified interface

      // Determine size based on element class or context
      if ($element.hasClass('mec-utility-qr-mini')) {
        size = 50;
      } else if ($element.closest('.mec-utility-qr-display-large').length) {
        size = 200;
      } else if ($element.closest('.mec-utility-access-method').length) {
        size = 120; // Smaller size for access cards
      }

      if (!qrToken) {
        console.error('No QR token found for element');
        return;
      }

      // Show loading placeholder
      var placeholder = $('<div>')
        .addClass('mec-utility-qr-loading')
        .css({
          width: size + 'px',
          height: size + 'px',
          lineHeight: size + 'px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#f0f0f1',
          border: '2px dashed #c3c4c7',
          borderRadius: '4px',
          color: '#646970',
        })
        .text('Generating QR...');

      $element.html(placeholder);

      // Generate QR code via AJAX
      $.ajax({
        url: mecUtilityAjax.ajax_url,
        type: 'POST',
        data: {
          action: 'mec_utility_generate_qr',
          qr_token: qrToken,
          size: size,
          nonce: mecUtilityAjax.nonce,
        },
        success: function (response) {
          if (response.success && response.data.qr_code) {
            var qrImage = $('<img>')
              .attr('src', response.data.qr_code)
              .attr('alt', 'QR Code for ' + qrToken)
              .css({
                width: size + 'px',
                height: size + 'px',
                display: 'block',
              });

            $element.html(qrImage);
          } else {
            MecUtilityAdmin.showQRError($element, size);
          }
        },
        error: function () {
          MecUtilityAdmin.showQRError($element, size);
        },
      });
    },

    /**
     * Show QR code generation error
     */
    showQRError: function ($element, size) {
      var errorPlaceholder = $('<div>')
        .addClass('mec-utility-qr-error')
        .css({
          width: size + 'px',
          height: size + 'px',
          lineHeight: size + 'px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#f8d7da',
          border: '2px solid #dc3545',
          borderRadius: '4px',
          color: '#721c24',
          fontSize: '12px',
          textAlign: 'center',
        })
        .html('QR Generation<br>Failed');

      $element.html(errorPlaceholder);

      // Show error message
      if (
        typeof mecUtilityAjax !== 'undefined' &&
        mecUtilityAjax.strings.qr_generation_error
      ) {
        console.error(mecUtilityAjax.strings.qr_generation_error);
      }
    },

    /**
     * Download QR code as image
     */
    downloadQRCode: function () {
      // Get the current QR token from the page
      var qrToken = $('#mec-utility-current-qr').data('qr');

      if (!qrToken) {
        alert('No QR code found to download');
        return;
      }

      // Show loading state
      var $downloadBtn = $('#mec-utility-download-qr');
      var originalText = $downloadBtn.text();
      $downloadBtn.text('Generating...').prop('disabled', true);

      // Request QR code for download
      $.ajax({
        url: mecUtilityAjax.ajax_url,
        type: 'POST',
        data: {
          action: 'mec_utility_download_qr',
          qr_token: qrToken,
          nonce: mecUtilityAjax.nonce,
        },
        success: function (response) {
          if (response.success && response.data.qr_code) {
            // Create download link
            var link = document.createElement('a');
            link.href = response.data.qr_code;
            link.download = response.data.filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          } else {
            alert('Failed to generate QR code for download');
          }
        },
        error: function () {
          alert('Error downloading QR code. Please try again.');
        },
        complete: function () {
          // Restore button state
          $downloadBtn.text(originalText).prop('disabled', false);
        },
      });
    },

    /**
     * Download QR code for unified interface
     */
    downloadQRCodeUnified: function (qrToken, $btn) {
      if (!qrToken) {
        alert('No QR code found to download');
        return;
      }

      var originalText = $btn.text();
      $btn.text('Generating...').prop('disabled', true);

      $.ajax({
        url: mecUtilityAjax.ajax_url,
        type: 'POST',
        data: {
          action: 'mec_utility_download_qr',
          qr_token: qrToken,
          nonce: mecUtilityAjax.nonce,
        },
        success: function (response) {
          if (response.success && response.data.qr_code) {
            var link = document.createElement('a');
            link.href = response.data.qr_code;
            link.download = response.data.filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          } else {
            alert('Failed to generate QR code for download');
          }
        },
        error: function () {
          alert('Error downloading QR code. Please try again.');
        },
        complete: function () {
          $btn.text(originalText).prop('disabled', false);
        },
      });
    },

    /**
     * Fallback copy to clipboard for older browsers
     */
    fallbackCopyToClipboard: function (text) {
      var textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      try {
        document.execCommand('copy');
        console.log('Fallback: Copied to clipboard');
      } catch (err) {
        console.error('Fallback: Unable to copy to clipboard');
      }

      document.body.removeChild(textArea);
    },

    /**
     * Initialize settings functionality
     */
    initSettings: function () {
      // Database cleanup
      $(document).on('click', '#mec-utility-cleanup-db', function (e) {
        e.preventDefault();

        if (
          !confirm(
            'Are you sure you want to clean up expired data? This action cannot be undone.'
          )
        ) {
          return;
        }

        var $btn = $(this);
        var originalText = $btn.text();

        $btn.text('Cleaning...').prop('disabled', true);

        $.ajax({
          url: mecUtilityAjax.ajaxurl,
          type: 'POST',
          data: {
            action: 'mec_utility_cleanup_db',
            nonce: mecUtilityAjax.nonce,
          },
          success: function (response) {
            if (response.success) {
              MecUtilityAdmin.showNotification(
                'Database cleanup completed successfully!',
                'success'
              );
            } else {
              MecUtilityAdmin.showNotification(
                'Cleanup failed. Please try again.',
                'error'
              );
            }
          },
          error: function () {
            MecUtilityAdmin.showNotification(
              'An error occurred. Please try again.',
              'error'
            );
          },
          complete: function () {
            $btn.text(originalText).prop('disabled', false);
          },
        });
      });

      // Settings form enhancements
      $('input[type="checkbox"]').on('change', function () {
        var $checkbox = $(this);
        var $row = $checkbox.closest('tr');

        if ($checkbox.is(':checked')) {
          $row.addClass('enabled');
        } else {
          $row.removeClass('enabled');
        }
      });
    },

    /**
     * Initialize notification system
     */
    initNotifications: function () {
      // Auto-dismiss notices after 5 seconds
      setTimeout(function () {
        $('.notice.is-dismissible').fadeOut();
      }, 5000);

      // Handle manual notice dismissal
      $(document).on('click', '.notice-dismiss', function () {
        $(this).closest('.notice').fadeOut();
      });
    },

    /**
     * Show custom notification
     */
    showNotification: function (message, type) {
      type = type || 'info';

      var $notice = $('<div>')
        .addClass('notice notice-' + type + ' is-dismissible')
        .html(
          '<p>' +
            message +
            '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>'
        );

      $('.wrap').prepend($notice);

      // Auto-dismiss after 5 seconds
      setTimeout(function () {
        $notice.fadeOut(function () {
          $(this).remove();
        });
      }, 5000);
    },

    /**
     * AJAX helper function
     */
    ajaxRequest: function (action, data, callback) {
      data = data || {};
      data.action = action;
      data.nonce = mecUtilityAjax.nonce;

      $.ajax({
        url: mecUtilityAjax.ajaxurl,
        type: 'POST',
        data: data,
        success: function (response) {
          if (typeof callback === 'function') {
            callback(response);
          }
        },
        error: function (xhr, status, error) {
          console.error('AJAX Error:', error);
          MecUtilityAdmin.showNotification(
            'An error occurred. Please try again.',
            'error'
          );
        },
      });
    },

    /**
     * Utility function to format dates
     */
    formatDate: function (date) {
      if (!(date instanceof Date)) {
        date = new Date(date);
      }

      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    },

    /**
     * Utility function to validate URLs
     */
    isValidUrl: function (string) {
      try {
        new URL(string);
        return true;
      } catch (_) {
        return false;
      }
    },

    /**
     * Utility function to debounce function calls
     */
    debounce: function (func, wait, immediate) {
      var timeout;
      return function () {
        var context = this,
          args = arguments;
        var later = function () {
          timeout = null;
          if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
      };
    },
  };

  // Make MecUtilityAdmin globally available
  window.MecUtilityAdmin = MecUtilityAdmin;
})(jQuery);
