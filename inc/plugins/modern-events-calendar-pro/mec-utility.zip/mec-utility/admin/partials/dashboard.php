<?php
/**
 * Admin Dashboard Page
 *
 * @link       https://your-domain.com
 * @since      1.0.0
 *
 * @package    MecUtility
 * @subpackage MecUtility/admin/partials
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="mec-utility-wrap" class="mec-utility-wrap">
	<div class="mec-utility-header">
		<h1>
			<?php esc_html_e( 'MEC Utility Dashboard', 'mec-utility' ); ?>
		</h1>
		<span class="w-theme-version"><?php echo __('Version ', 'mec-utility'); ?><?php echo MEC_UTILITY_VERSION; ?></span>
	</div>

	<!-- Quick Stats -->
	<div class="mec-utility-stats">
		<div class="mec-utility-stat-cards">
			<div class="mec-utility-stat-card">
				<div class="mec-utility-stat-icon">
					<span class="dashicons dashicons-admin-network"></span>
				</div>
				<div class="mec-utility-stat-content">
					<h3><?php echo esc_html( $api_keys_count ); ?></h3>
					<p><?php esc_html_e( 'API Keys', 'mec-utility' ); ?></p>
				</div>
			</div>

			<!-- <div class="mec-utility-stat-card">
				<div class="mec-utility-stat-icon">
					<span class="dashicons dashicons-smartphone"></span>
				</div>
				<div class="mec-utility-stat-content">
					<h3><?php //echo esc_html( $qr_codes_count ); ?></h3>
					<p><?php //esc_html_e( 'QR Codes Generated', 'mec-utility' ); ?></p>
				</div>
			</div> -->

			<div class="mec-utility-stat-card">
				<div class="mec-utility-stat-icon">
					<span class="dashicons dashicons-admin-site-alt3"></span>
				</div>
				<div class="mec-utility-stat-content">
					<h3><?php echo esc_url( home_url() ); ?></h3>
					<p><?php esc_html_e( 'Website URL', 'mec-utility' ); ?></p>
				</div>
			</div>
		</div>
	</div>

	<!-- Quick Setup Section -->
	<div class="mec-utility-dashboard-section">
		<h2><?php esc_html_e( 'Quick Setup for Mobile App', 'mec-utility' ); ?></h2>

		<div class="mec-utility-setup-methods">
			<!-- Method 1: API Key -->
			<div class="mec-utility-setup-method">
				<h3>
					<span class="dashicons dashicons-admin-network"></span>
					<?php esc_html_e( 'Method 1: API Key Authentication', 'mec-utility' ); ?>
				</h3>

				<?php if ( $default_api_key ) : ?>
					<div class="mec-utility-api-info">
						<div class="mec-utility-info-row">
							<label><?php esc_html_e( 'Website URL:', 'mec-utility' ); ?></label>
							<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( home_url() ); ?>">
								<?php echo esc_url( home_url() ); ?>
								<button type="button" class="pure-button pure-button-primary mec-utility-copy-btn"><?php echo esc_html('Copy' , 'mec-utility'); ?></button>
							</code>
						</div>

						<div class="mec-utility-info-row">
							<label><?php esc_html_e( 'API Key:', 'mec-utility' ); ?></label>
							<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( $default_api_key->api_key ); ?>">
								<?php echo esc_html( $default_api_key->api_key ); ?>
								<button type="button" class="pure-button pure-button-primary mec-utility-copy-btn"><?php echo esc_html('Copy' , 'mec-utility'); ?></button>
							</code>
						</div>

						<p class="description">
							<?php esc_html_e( 'Enter these credentials in your mobile app to connect.', 'mec-utility' ); ?>
						</p>
					</div>
				<?php else : ?>
					<div class="">
						<p>
							<?php esc_html_e( 'Default API key not found.', 'mec-utility' ); ?>
						</p>
						<?php if ( ! empty( $latest_api_key ) ) : ?>
							<div class="mec-utility-api-info">
								<div class="mec-utility-info-row">
									<label><?php esc_html_e( 'Website URL', 'mec-utility' ); ?></label>
									<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( home_url() ); ?>">
										<?php echo esc_url( home_url() ); ?>
										<button type="button" class="pure-button pure-button-primary mec-utility-copy-btn"><?php echo esc_html('Copy' , 'mec-event-API'); ?></button>
									</code>
								</div>

								<div class="mec-utility-info-row">
									<label><?php esc_html_e( 'Latest API Key', 'mec-utility' ); ?></label>
									<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( $latest_api_key->api_key ); ?>">
										<?php echo esc_html( substr( $latest_api_key->api_key, 0, 20 ) . '...' ); ?>
										<button type="button" class="pure-button pure-button-primary mec-utility-copy-btn"><?php echo esc_html('Copy' , 'mec-event-API'); ?></button>
									</code>
								</div>

								<p class="description">
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=mec-utility-app-access' ) ); ?>" class="button button-primary">
										<?php esc_html_e( 'Manage App Access', 'mec-utility' ); ?>
									</a>
								</p>
							</div>
						<?php else : ?>
							<p>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=mec-utility-app-access' ) ); ?>" class="button button-primary">
									<?php esc_html_e( 'Create App Access', 'mec-utility' ); ?>
								</a>
							</p>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>

			<!-- Method 2: QR Code -->
			<div class="mec-utility-setup-method">
				<h3>
					<span class="dashicons dashicons-smartphone"></span>
					<?php esc_html_e( 'Method 2: QR Code Authentication', 'mec-utility' ); ?>
				</h3>

				<?php if ( $default_qr = $this->get_default_qr_code() ) : ?>
					<div class="mec-utility-qr-info">
						<div class="mec-utility-qr-display">
							<div id="mec-utility-qr-code" class="mec-utility-qr-code" data-qr="<?php echo esc_attr( $default_qr->qr_token ); ?>"></div>
							<p class="description">
								<?php esc_html_e( 'Scan this QR code with the app to instantly connect your website.', 'mec-utility' ); ?>
							</p>
						</div>

						<div class="mec-utility-qr-details">
							<p><strong><?php esc_html_e( 'Type:', 'mec-utility' ); ?></strong> <?php esc_html_e( 'Permanent (No Expiry)', 'mec-utility' ); ?></p>
							<p><strong><?php esc_html_e( 'Status:', 'mec-utility' ); ?></strong>
								<span class="mec-utility-status <?php echo $default_qr->is_used ? 'used' : 'active'; ?>">
									<?php echo $default_qr->is_used ? esc_html__( 'Used', 'mec-utility' ) : esc_html__( 'Active', 'mec-utility' ); ?>
								</span>
							</p>
						</div>
					</div>
				<?php else : ?>
					<div class="notice notice-info inline">
						<p>
							<?php esc_html_e( 'No active QR code found.', 'mec-utility' ); ?>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=mec-utility-app-access' ) ); ?>" class="button button-primary">
								<?php esc_html_e( 'Create App Access', 'mec-utility' ); ?>
							</a>
						</p>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<!-- Instructions -->
	<div class="mec-utility-dashboard-section">
		<h2><?php esc_html_e( 'Mobile App Setup Instructions', 'mec-utility' ); ?></h2>

		<div class="mec-utility-instructions">
			<div class="mec-utility-instruction-step">
				<div class="mec-utility-step-number">1</div>
				<div class="mec-utility-step-content">
					<h4><?php esc_html_e( 'Download the Mobile App', 'mec-utility' ); ?></h4>
					<p><?php esc_html_e( 'Download and install the app from the relevant app store, search for MEC Events.', 'mec-utility' ); ?></p>
				</div>
			</div>

			<div class="mec-utility-instruction-step">
				<div class="mec-utility-step-number">2</div>
				<div class="mec-utility-step-content">
					<h4><?php esc_html_e( 'Choose Authentication Method', 'mec-utility' ); ?></h4>
					<p><?php esc_html_e( 'Either scan the QR code above or manually enter the Website URL and API Key.', 'mec-utility' ); ?></p>
				</div>
			</div>

			<div class="mec-utility-instruction-step">
				<div class="mec-utility-step-number">3</div>
				<div class="mec-utility-step-content">
					<h4><?php esc_html_e( 'Start Using the App', 'mec-utility' ); ?></h4>
					<p><?php esc_html_e( 'Once connected, you can access all your MEC events and features from the mobile app.', 'mec-utility' ); ?></p>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
jQuery(document).ready(function($) {
	// Copy to clipboard functionality
	$('.mec-utility-copy-btn').on('click', function() {
		var textToCopy = $(this).parent().data('copy');
		navigator.clipboard.writeText(textToCopy).then(function() {
			// Show success message
			$(this).addClass('copied');
			setTimeout(function() {
				$(this).removeClass('copied');
			}.bind(this), 2000);
		}.bind(this));
	});

	// Generate QR code if element exists
	if ($('#mec-utility-qr-code').length) {
		var qrData = {
			website_url: '<?php echo esc_js( home_url() ); ?>',
			qr_token: $('#mec-utility-qr-code').data('qr'),
			timestamp: '<?php echo esc_js( current_time( 'timestamp' ) ); ?>'
		};

		// You can integrate a QR code library here
		$('#mec-utility-qr-code').html('<div class="mec-utility-qr-placeholder">QR Code will be generated here</div>');
	}
});
</script>
