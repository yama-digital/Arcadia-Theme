<?php
/**
 * Admin App Access Management Page
 *
 * @link       https://your-domain.com
 * @since      1.0.0
 *
 * @package    MecUtility
 * @subpackage MecUtility/admin/partials
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$app_access = $this->get_app_access();
$website_url = home_url();

if ( ! function_exists( 'mec_utility_render_permission_checkboxes' ) ) {
	function mec_utility_render_permission_checkboxes( $selected_permissions = array() ) {
		$selected_permissions = is_array( $selected_permissions ) ? $selected_permissions : array();

		$groups = array(
			array(
				'title' => __( 'Event Management', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'read_events',
						'label'       => __( 'Read Events', 'mec-utility' ),
						'description' => __( 'View and list events', 'mec-utility' ),
					),
					array(
						'value'       => 'create_events',
						'label'       => __( 'Create Events', 'mec-utility' ),
						'description' => __( 'Create new events', 'mec-utility' ),
					),
					array(
						'value'       => 'update_events',
						'label'       => __( 'Update Events', 'mec-utility' ),
						'description' => __( 'Edit existing events', 'mec-utility' ),
					),
					array(
						'value'       => 'delete_events',
						'label'       => __( 'Delete Events', 'mec-utility' ),
						'description' => __( 'Delete events', 'mec-utility' ),
					),
					array(
						'value'       => 'publish_events',
						'label'       => __( 'Publish Events', 'mec-utility' ),
						'description' => __( 'Publish and unpublish events', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'Booking Form Management', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'read_booking_fields',
						'label'       => __( 'Read Booking Form Fields', 'mec-utility' ),
						'description' => __( 'View booking form fields', 'mec-utility' ),
					),
					array(
						'value'       => 'create_booking_fields',
						'label'       => __( 'Create Booking Form Fields', 'mec-utility' ),
						'description' => __( 'Create new booking form fields', 'mec-utility' ),
					),
					array(
						'value'       => 'update_booking_fields',
						'label'       => __( 'Update Booking Form Fields', 'mec-utility' ),
						'description' => __( 'Modify existing booking form fields', 'mec-utility' ),
					),
					array(
						'value'       => 'delete_booking_fields',
						'label'       => __( 'Delete Booking Form Fields', 'mec-utility' ),
						'description' => __( 'Remove booking form fields', 'mec-utility' ),
					),
					array(
						'value'       => 'manage_booking_fields',
						'label'       => __( 'Manage Booking Form Fields (All)', 'mec-utility' ),
						'description' => __( 'Full booking form field management', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'Booking Management', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'read_bookings',
						'label'       => __( 'Read Bookings', 'mec-utility' ),
						'description' => __( 'View booking information', 'mec-utility' ),
					),
					array(
						'value'       => 'create_bookings',
						'label'       => __( 'Create Bookings', 'mec-utility' ),
						'description' => __( 'Create new bookings', 'mec-utility' ),
					),
					array(
						'value'       => 'update_bookings',
						'label'       => __( 'Update Bookings', 'mec-utility' ),
						'description' => __( 'Modify existing bookings', 'mec-utility' ),
					),
					array(
						'value'       => 'delete_bookings',
						'label'       => __( 'Delete Bookings', 'mec-utility' ),
						'description' => __( 'Remove bookings', 'mec-utility' ),
					),
					array(
						'value'       => 'confirm_bookings',
						'label'       => __( 'Confirm Bookings', 'mec-utility' ),
						'description' => __( 'Confirm booking status', 'mec-utility' ),
					),
					array(
						'value'       => 'manage_bookings',
						'label'       => __( 'Manage Bookings (All)', 'mec-utility' ),
						'description' => __( 'Full booking management', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'Waiting List Management', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'read_waiting_list',
						'label'       => __( 'Read Waiting List', 'mec-utility' ),
						'description' => __( 'View waiting list information', 'mec-utility' ),
					),
					array(
						'value'       => 'manage_waiting_list',
						'label'       => __( 'Manage Waiting List', 'mec-utility' ),
						'description' => __( 'Full waiting list management', 'mec-utility' ),
					),
					array(
						'value'       => 'create_waiting_list',
						'label'       => __( 'Create Waiting List', 'mec-utility' ),
						'description' => __( 'Create new waiting list entries', 'mec-utility' ),
					),
					array(
						'value'       => 'update_waiting_list',
						'label'       => __( 'Update Waiting List', 'mec-utility' ),
						'description' => __( 'Modify waiting list details', 'mec-utility' ),
					),
					array(
						'value'       => 'delete_waiting_list',
						'label'       => __( 'Delete Waiting List', 'mec-utility' ),
						'description' => __( 'Remove waiting list entries', 'mec-utility' ),
					),
					array(
						'value'       => 'confirm_waiting_list',
						'label'       => __( 'Confirm Waiting List', 'mec-utility' ),
						'description' => __( 'Confirm waiting list status', 'mec-utility' ),
					),
					array(
						'value'       => 'verify_waiting_list',
						'label'       => __( 'Verify Waiting List', 'mec-utility' ),
						'description' => __( 'Verify waiting list entries', 'mec-utility' ),
					),
					array(
						'value'       => 'export_waiting_list',
						'label'       => __( 'Export Waiting List', 'mec-utility' ),
						'description' => __( 'Export waiting list data', 'mec-utility' ),
					),
					array(
						'value'       => 'bulk_waiting_list',
						'label'       => __( 'Bulk Waiting List Operations', 'mec-utility' ),
						'description' => __( 'Perform bulk waiting list operations', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'Invoice Management', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'read_invoices',
						'label'       => __( 'Read Invoices', 'mec-utility' ),
						'description' => __( 'View invoice information and lists', 'mec-utility' ),
					),
					array(
						'value'       => 'manage_invoices',
						'label'       => __( 'Manage Invoices', 'mec-utility' ),
						'description' => __( 'Full invoice management including updates', 'mec-utility' ),
					),
					array(
						'value'       => 'view_invoice_pdf',
						'label'       => __( 'View Invoice PDF', 'mec-utility' ),
						'description' => __( 'Generate and view invoice PDFs', 'mec-utility' ),
					),
					array(
						'value'       => 'invoice_qr_codes',
						'label'       => __( 'Invoice QR Codes', 'mec-utility' ),
						'description' => __( 'Generate QR codes for invoices', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'Attendee Management', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'read_attendees',
						'label'       => __( 'Read Attendees', 'mec-utility' ),
						'description' => __( 'View attendee information', 'mec-utility' ),
					),
					array(
						'value'       => 'manage_attendees',
						'label'       => __( 'Manage Attendees', 'mec-utility' ),
						'description' => __( 'Full attendee management', 'mec-utility' ),
					),
					array(
						'value'       => 'checkin_attendees',
						'label'       => __( 'Check-in Attendees', 'mec-utility' ),
						'description' => __( 'Check-in and check-out attendees', 'mec-utility' ),
					),
					array(
						'value'       => 'export_attendees',
						'label'       => __( 'Export Attendees', 'mec-utility' ),
						'description' => __( 'Export attendee data', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'QR Code & Check-in', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'generate_qr',
						'label'       => __( 'Generate QR Codes', 'mec-utility' ),
						'description' => __( 'Generate QR codes for attendees', 'mec-utility' ),
					),
					array(
						'value'       => 'scan_qr',
						'label'       => __( 'Scan QR Codes', 'mec-utility' ),
						'description' => __( 'Scan QR codes for check-in', 'mec-utility' ),
					),
					array(
						'value'       => 'bulk_checkin',
						'label'       => __( 'Bulk Check-in', 'mec-utility' ),
						'description' => __( 'Bulk check-in operations', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'RSVP Management', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'read_rsvp',
						'label'       => __( 'Read RSVP', 'mec-utility' ),
						'description' => __( 'View RSVP information', 'mec-utility' ),
					),
					array(
						'value'       => 'manage_rsvp',
						'label'       => __( 'Manage RSVP', 'mec-utility' ),
						'description' => __( 'Full RSVP management', 'mec-utility' ),
					),
					array(
						'value'       => 'create_rsvp',
						'label'       => __( 'Create RSVP', 'mec-utility' ),
						'description' => __( 'Create new RSVP entries', 'mec-utility' ),
					),
					array(
						'value'       => 'update_rsvp',
						'label'       => __( 'Update RSVP', 'mec-utility' ),
						'description' => __( 'Modify RSVP details', 'mec-utility' ),
					),
					array(
						'value'       => 'delete_rsvp',
						'label'       => __( 'Delete RSVP', 'mec-utility' ),
						'description' => __( 'Remove RSVP entries', 'mec-utility' ),
					),
					array(
						'value'       => 'confirm_rsvp',
						'label'       => __( 'Confirm RSVP', 'mec-utility' ),
						'description' => __( 'Confirm RSVP status', 'mec-utility' ),
					),
					array(
						'value'       => 'verify_rsvp',
						'label'       => __( 'Verify RSVP', 'mec-utility' ),
						'description' => __( 'Verify RSVP entries', 'mec-utility' ),
					),
					array(
						'value'       => 'export_rsvp',
						'label'       => __( 'Export RSVP', 'mec-utility' ),
						'description' => __( 'Export RSVP data', 'mec-utility' ),
					),
					array(
						'value'       => 'bulk_rsvp',
						'label'       => __( 'Bulk RSVP Operations', 'mec-utility' ),
						'description' => __( 'Perform bulk RSVP operations', 'mec-utility' ),
					),
				),
			),
			array(
				'title' => __( 'System & Configuration', 'mec-utility' ),
				'items' => array(
					array(
						'value'       => 'manage_settings',
						'label'       => __( 'Manage Settings', 'mec-utility' ),
						'description' => __( 'Access system settings', 'mec-utility' ),
					),
					array(
						'value'       => 'manage_translations',
						'label'       => __( 'Manage Translations', 'mec-utility' ),
						'description' => __( 'Update translations', 'mec-utility' ),
					),
					array(
						'value'       => 'view_logs',
						'label'       => __( 'View Logs', 'mec-utility' ),
						'description' => __( 'Access system logs', 'mec-utility' ),
					),
				),
			),
		);

		ob_start();
		?>
		<div class="mec-utility-permissions-grid">
			<?php foreach ( $groups as $group ) : ?>
				<div class="mec-utility-permission-group">
					<h4><?php echo esc_html( $group['title'] ); ?></h4>
					<?php foreach ( $group['items'] as $item ) : ?>
						<label>
							<input type="checkbox"
								name="permissions[]"
								value="<?php echo esc_attr( $item['value'] ); ?>"
								<?php checked( in_array( $item['value'], $selected_permissions, true ) ); ?>
							>
							<?php echo esc_html( $item['label'] ); ?>
							<?php if ( ! empty( $item['description'] ) ) : ?>
								<span class="description"><?php echo esc_html( $item['description'] ); ?></span>
							<?php endif; ?>
						</label><br>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
		return ob_get_clean();
	}
}
?>

<div id="mec-utility-wrap" class="mec-utility-wrap">
	<div class="mec-utility-header">
		<h1>
			<?php esc_html_e( 'App Access Management', 'mec-utility' ); ?>
		</h1>
		<span class="w-theme-version"><?php echo __('Version ', 'mec-utility'); ?><?php echo MEC_UTILITY_VERSION; ?></span>
	</div>

	<a href="#" class="page-title-action" id="mec-utility-add-app-access">
		<?php esc_html_e( 'Create New App Access', 'mec-utility' ); ?>
	</a>

	<div class="mec-utility-intro">
		<p><?php esc_html_e( 'Create app access credentials to allow mobile apps to connect to your MEC events. Each access includes both API credentials and a QR code for easy setup.', 'mec-utility' ); ?></p>
	</div>

	<!-- Create App Access Form -->
	<div id="mec-utility-app-access-form" class="mec-utility-form-container" style="display: none;">
		<div class="mec-utility-form-wrapper">
			<h2><?php esc_html_e( 'Create New App Access', 'mec-utility' ); ?></h2>

			<form method="post" action="">
				<?php wp_nonce_field( 'mec_utility_action', 'mec_utility_nonce' ); ?>
				<input type="hidden" name="action" value="create_app_access">

				<table class="form-table">
					<tr class="mec-form-row">
						<th scope="row">
							<label for="app_name"><?php esc_html_e( 'App Name', 'mec-utility' ); ?> <span class="required">*</span></label>
						</th>
						<td>
							<input type="text" id="app_name" name="app_name" class="regular-text" required>
							<p class="description"><?php esc_html_e( 'Enter a descriptive name for this app access (e.g., "Mobile App", "iOS App", etc.)', 'mec-utility' ); ?></p>
						</td>
					</tr>

					<tr class="mec-form-row">
						<th scope="row"><?php esc_html_e( 'Permissions', 'mec-utility' ); ?></th>
						<td>
							<fieldset>
								<legend class="screen-reader-text"><?php esc_html_e( 'Permissions', 'mec-utility' ); ?></legend>

								<?php
								echo mec_utility_render_permission_checkboxes(
									array( 'read_events' ) // default selection
								);
								?>

								<div class="mec-utility-permission-actions">
									<button type="button" class="button button-small mec-utility-select-all" id="mec-utility-select-all-permissions">
										<?php esc_html_e( 'Select All', 'mec-utility' ); ?>
									</button>
									<button type="button" class="button button-small mec-utility-select-none" id="mec-utility-select-none-permissions">
										<?php esc_html_e( 'Select None', 'mec-utility' ); ?>
									</button>
									<button type="button" class="button button-small mec-utility-select-read" id="mec-utility-select-read-only">
										<?php esc_html_e( 'Read Only', 'mec-utility' ); ?>
									</button>
									<button type="button" class="button button-small mec-utility-select-admin" id="mec-utility-select-admin">
										<?php esc_html_e( 'Admin Access', 'mec-utility' ); ?>
									</button>
								</div>
							</fieldset>
							<p class="description"><?php esc_html_e( 'Select the permissions for this app access. These permissions control what actions the app can perform via the API.', 'mec-utility' ); ?></p>
						</td>
					</tr>
				</table>

				<p class="submit">
					<input type="submit" class="button button-primary mec-button-primary" value="<?php esc_attr_e( 'Create App Access', 'mec-utility' ); ?>">
					<button type="button" class="button mec-button-primary" id="mec-utility-cancel-app-access"><?php esc_html_e( 'Cancel', 'mec-utility' ); ?></button>
				</p>
			</form>
		</div>
	</div>

	<!-- App Access List -->
	<?php if ( empty( $app_access ) ) : ?>
		<div class="mec-utility-empty-state">
			<div class="mec-utility-empty-icon">
				<span class="dashicons dashicons-smartphone"></span>
			</div>
			<h3><?php esc_html_e( 'No App Access Created Yet', 'mec-utility' ); ?></h3>
			<p><?php esc_html_e( 'Create your first app access to allow mobile apps to connect to your MEC events.', 'mec-utility' ); ?></p>
			<button class="button button-primary" id="mec-utility-create-first-access">
				<?php esc_html_e( 'Create Your First App Access', 'mec-utility' ); ?>
			</button>
		</div>
	<?php else : ?>
		<div class="mec-utility-app-access-list">
			<?php foreach ( $app_access as $access ) : ?>
				<?php
				$permissions       = json_decode( $access->permissions, true );
				$selected_permissions = is_array( $permissions ) ? $permissions : array();
				$permissions_list  = is_array( $permissions ) ? implode( ', ', $permissions ) : '';
				?>
				<div class="mec-utility-access-card">
					<div class="mec-utility-access-header">
						<h3><?php echo esc_html( $access->name ); ?></h3>
						<div class="mec-utility-access-status">
							<span class="mec-utility-status <?php echo $access->is_active ? 'active' : 'inactive'; ?>">
								<?php echo $access->is_active ? esc_html__( 'Active', 'mec-utility' ) : esc_html__( 'Inactive', 'mec-utility' ); ?>
							</span>
						</div>
					</div>

					<div class="mec-utility-access-content">
						<div class="mec-utility-access-methods">
							<!-- API Credentials -->
							<div class="mec-utility-access-method">
								<h4>
									<span class="dashicons dashicons-admin-network"></span>
									<?php esc_html_e( 'API Credentials', 'mec-utility' ); ?>
								</h4>

								<div class="mec-utility-credential-row">
									<label><?php esc_html_e( 'Website URL', 'mec-utility' ); ?></label>
									<div class="mec-utility-credential-value">
										<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( $website_url ); ?>">
											<?php echo esc_html( $website_url ); ?>
											<button type="button" class="pure-button pure-button-primary mec-utility-copy-btn"><?php echo esc_html('Copy' , 'mec-utility'); ?></button>
										</code>
									</div>
								</div>

								<div class="mec-utility-credential-row">
									<label><?php esc_html_e( 'API Key', 'mec-utility' ); ?></label>
									<div class="mec-utility-credential-value">
										<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( $access->api_key ); ?>">
											<span class="mec-utility-key-preview" style="display: none;"><?php echo esc_html( substr( $access->api_key, 0, 20 ) . '...' ); ?></span>
											<span class="mec-utility-key-full"><?php echo esc_html( $access->api_key ); ?></span>
											<button type="button" class="pure-button pure-button-primary mec-utility-copy-btn"><?php echo esc_html('Copy' , 'mec-utility'); ?></button>
										</code>
										<!-- <button type="button" class="button button-small mec-utility-toggle-key"><?php esc_html_e( 'Show', 'mec-utility' ); ?></button> -->
									</div>
								</div>

								<!-- <div class="mec-utility-credential-row">
									<label><?php esc_html_e( 'API Secret:', 'mec-utility' ); ?></label>
									<div class="mec-utility-credential-value">
										<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( $access->api_secret ); ?>">
											<span class="mec-utility-secret-preview"><?php echo esc_html( substr( $access->api_secret, 0, 20 ) . '...' ); ?></span>
											<span class="mec-utility-secret-full" style="display: none;"><?php echo esc_html( $access->api_secret ); ?></span>
											<span class="dashicons dashicons-admin-page mec-utility-copy-btn" title="<?php esc_attr_e( 'Copy to clipboard', 'mec-utility' ); ?>"></span>
										</code>
										<button type="button" class="button button-small mec-utility-toggle-secret"><?php esc_html_e( 'Show', 'mec-utility' ); ?></button>
									</div>
								</div> -->
							</div>

							<!-- QR Code -->
							<div class="mec-utility-access-method">
								<h4>
									<span class="dashicons dashicons-smartphone"></span>
									<?php esc_html_e( 'QR Code', 'mec-utility' ); ?>
								</h4>

								<?php if ( $access->qr_token ) : ?>
									<div class="mec-utility-qr-display">
										<div class="mec-utility-qr-visual">
											<div class="mec-utility-qr-code" data-qr="<?php echo esc_attr( $access->qr_token ); ?>"></div>
										</div>
										<div class="mec-utility-qr-actions">
											<input type="hidden" class="mec-utility-qr-token" value="<?php echo esc_attr( $access->qr_token ); ?>">
											<button type="button" class="button button-small mec-utility-download-qr button button-primary">
												<?php esc_html_e( 'Download', 'mec-utility' ); ?>
											</button>
										</div>
									</div>
								<?php else : ?>
									<p class="description"><?php esc_html_e( 'No QR code available for this access.', 'mec-utility' ); ?></p>
								<?php endif; ?>
							</div>
						</div>

						<div class="mec-utility-access-details">
							<div class="mec-utility-detail-row">
								<label><?php esc_html_e( 'Permissions:', 'mec-utility' ); ?></label>
								<span><?php echo esc_html( $permissions_list ?: __( 'None', 'mec-utility' ) ); ?></span>
							</div>
							<div class="mec-utility-detail-row">
								<label><?php esc_html_e( 'Created:', 'mec-utility' ); ?></label>
								<span><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $access->created_at ) ) ); ?></span>
							</div>
							<div class="mec-utility-detail-row">
								<label><?php esc_html_e( 'Last Access:', 'mec-utility' ); ?></label>
								<span><?php echo $access->last_access ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $access->last_access ) ) ) : esc_html__( 'Never', 'mec-utility' ); ?></span>
							</div>
						</div>

						<div class="mec-utility-access-actions">
							<button type="button"
								class="button mec-button-primary mec-utility-edit-access"
								data-target="#mec-utility-edit-access-<?php echo esc_attr( $access->id ); ?>">
								<?php esc_html_e( 'Edit Permissions', 'mec-utility' ); ?>
							</button>
							<form method="post" action="" style="display: inline;" onsubmit="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this app access? This will remove both the API key and QR code.', 'mec-utility' ); ?>')">
								<?php wp_nonce_field( 'mec_utility_action', 'mec_utility_nonce' ); ?>
								<input type="hidden" name="action" value="delete_app_access">
								<input type="hidden" name="api_key_id" value="<?php echo esc_attr( $access->id ); ?>">
								<button type="submit" class="button button-link-delete mec-button-primary">
									<?php esc_html_e( 'Delete Access', 'mec-utility' ); ?>
								</button>
							</form>
						</div>

						<div class="mec-utility-access-edit" id="mec-utility-edit-access-<?php echo esc_attr( $access->id ); ?>" style="display: none;">
							<form method="post" action="" class="mec-utility-edit-form">
								<?php wp_nonce_field( 'mec_utility_action', 'mec_utility_nonce' ); ?>
								<input type="hidden" name="action" value="update_app_access">
								<input type="hidden" name="api_key_id" value="<?php echo esc_attr( $access->id ); ?>">

								<table class="form-table">
									<tr class="mec-form-row">
										<th scope="row">
											<label for="app_name_<?php echo esc_attr( $access->id ); ?>"><?php esc_html_e( 'App Name', 'mec-utility' ); ?> <span class="required">*</span></label>
										</th>
										<td>
											<input type="text"
												id="app_name_<?php echo esc_attr( $access->id ); ?>"
												name="app_name"
												class="regular-text"
												value="<?php echo esc_attr( $access->name ); ?>"
												required
											>
										</td>
									</tr>
									<tr class="mec-form-row">
										<th scope="row"><?php esc_html_e( 'Permissions', 'mec-utility' ); ?></th>
										<td>
											<fieldset>
												<legend class="screen-reader-text"><?php esc_html_e( 'Permissions', 'mec-utility' ); ?></legend>
												<?php echo mec_utility_render_permission_checkboxes( $selected_permissions ); ?>
												<div class="mec-utility-permission-actions">
													<button type="button" class="button button-small mec-utility-select-all">
														<?php esc_html_e( 'Select All', 'mec-utility' ); ?>
													</button>
													<button type="button" class="button button-small mec-utility-select-none">
														<?php esc_html_e( 'Select None', 'mec-utility' ); ?>
													</button>
													<button type="button" class="button button-small mec-utility-select-read">
														<?php esc_html_e( 'Read Only', 'mec-utility' ); ?>
													</button>
													<button type="button" class="button button-small mec-utility-select-admin">
														<?php esc_html_e( 'Admin Access', 'mec-utility' ); ?>
													</button>
												</div>
											</fieldset>
										</td>
									</tr>
								</table>

								<p class="submit">
									<input type="submit" class="button button-primary mec-button-primary" value="<?php esc_attr_e( 'Save Changes', 'mec-utility' ); ?>">
									<button type="button" class="button mec-button-primary mec-utility-cancel-edit" data-target="#mec-utility-edit-access-<?php echo esc_attr( $access->id ); ?>">
										<?php esc_html_e( 'Cancel', 'mec-utility' ); ?>
									</button>
								</p>
							</form>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

</div>

<script>
jQuery(document).ready(function($) {
	// Show/Hide app access form
	$('#mec-utility-add-app-access, #mec-utility-create-first-access').on('click', function(e) {
		e.preventDefault();
		$('#mec-utility-app-access-form').slideDown();
		$('#app_name').focus();
	});

	$('#mec-utility-cancel-app-access').on('click', function() {
		$('#mec-utility-app-access-form').slideUp();
	});

	// Toggle API key/secret visibility
	$('.mec-utility-toggle-key').on('click', function() {
		var $btn = $(this);
		var $row = $btn.closest('.mec-utility-credential-row');
		var $preview = $row.find('.mec-utility-key-preview');
		var $full = $row.find('.mec-utility-key-full');

		if ($preview.is(':visible')) {
			$preview.hide();
			$full.show();
			$btn.text('<?php esc_js_e( 'Hide', 'mec-utility' ); ?>');
		} else {
			$preview.show();
			$full.hide();
			$btn.text('<?php esc_js_e( 'Show', 'mec-utility' ); ?>');
		}
	});

	$('.mec-utility-toggle-secret').on('click', function() {
		var $btn = $(this);
		var $row = $btn.closest('.mec-utility-credential-row');
		var $preview = $row.find('.mec-utility-secret-preview');
		var $full = $row.find('.mec-utility-secret-full');

		if ($preview.is(':visible')) {
			$preview.hide();
			$full.show();
			$btn.text('<?php esc_js_e( 'Hide', 'mec-utility' ); ?>');
		} else {
			$preview.show();
			$full.hide();
			$btn.text('<?php esc_js_e( 'Show', 'mec-utility' ); ?>');
		}
	});

	// Copy to clipboard functionality
	$('.mec-utility-copy-btn').on('click', function() {
		var textToCopy = $(this).parent().data('copy');
		navigator.clipboard.writeText(textToCopy).then(function() {
			// Show success feedback
			var $btn = $(this);
			$btn.addClass('copied');
			setTimeout(function() {
				$btn.removeClass('copied');
			}, 2000);
		}.bind(this));
	});

	// Generate and display QR codes on page load
	$('.mec-utility-qr-code').each(function() {
		var $qrContainer = $(this);
		var qrToken = $qrContainer.data('qr');

		if (qrToken) {
			$qrContainer.html('<div class="mec-utility-qr-loading">Loading QR Code...</div>');

			$.ajax({
				url: mecUtilityAjax.ajax_url,
				type: 'POST',
				data: {
					action: 'mec_utility_generate_qr',
					qr_token: qrToken,
					size: 200,
					nonce: mecUtilityAjax.nonce
				},
				success: function(response) {
					if (response.success && response.data.qr_code) {
						$qrContainer.html('<img src="' + response.data.qr_code + '" alt="QR Code" />');
					} else {
						$qrContainer.html('<div class="mec-utility-qr-error">Failed to load QR code</div>');
					}
				},
				error: function() {
					$qrContainer.html('<div class="mec-utility-qr-error">Error loading QR code</div>');
				}
			});
		}
	});

	// Download QR code functionality
	$('.mec-utility-download-qr').on('click', function() {
		var qrToken = $(this).siblings('.mec-utility-qr-token').val();
		var $btn = $(this);
		var originalText = $btn.text();

		$btn.text('<?php esc_js_e( 'Generating...', 'mec-utility' ); ?>').prop('disabled', true);

		$.ajax({
			url: mecUtilityAjax.ajax_url,
			type: 'POST',
			data: {
				action: 'mec_utility_download_qr',
				qr_token: qrToken,
				nonce: mecUtilityAjax.nonce
			},
			success: function(response) {
				if (response.success && response.data.qr_code) {
					var link = document.createElement('a');
					link.href = response.data.qr_code;
					link.download = response.data.filename;
					document.body.appendChild(link);
					link.click();
					document.body.removeChild(link);
				} else {
					alert('<?php esc_js_e( 'Failed to generate QR code for download', 'mec-utility' ); ?>');
				}
			},
			error: function() {
				alert('<?php esc_js_e( 'Error downloading QR code. Please try again.', 'mec-utility' ); ?>');
			},
			complete: function() {
				$btn.text(originalText).prop('disabled', false);
			}
		});
	});

	// Permission management buttons
	$(document).on('click', '.mec-utility-select-all', function() {
		const $grid = $(this).closest('.mec-utility-permission-actions').siblings('.mec-utility-permissions-grid');
		$grid.find('input[name="permissions[]"]').prop('checked', true);
	});

	$(document).on('click', '.mec-utility-select-none', function() {
		const $grid = $(this).closest('.mec-utility-permission-actions').siblings('.mec-utility-permissions-grid');
		$grid.find('input[name="permissions[]"]').prop('checked', false);
	});

	$(document).on('click', '.mec-utility-select-read', function() {
		const $grid = $(this).closest('.mec-utility-permission-actions').siblings('.mec-utility-permissions-grid');
		const readOnlyPermissions = [
			'read_events',
			'read_bookings',
			'read_attendees',
			'read_waiting_list',
			'read_invoices',
			'read_rsvp',
			'view_logs',
			'view_reports',
			'view_stats'
		];
		$grid.find('input[name="permissions[]"]').prop('checked', false);
		readOnlyPermissions.forEach(function(permission) {
			$grid.find('input[name="permissions[]"][value="' + permission + '"]').prop('checked', true);
		});
	});

	$(document).on('click', '.mec-utility-select-admin', function() {
		const $grid = $(this).closest('.mec-utility-permission-actions').siblings('.mec-utility-permissions-grid');
		$grid.find('input[name="permissions[]"]').prop('checked', true);
	});

	// Toggle edit forms
	$(document).on('click', '.mec-utility-edit-access', function(e) {
		e.preventDefault();
		const target = $(this).data('target');
		$(target).slideToggle();
	});

	$(document).on('click', '.mec-utility-cancel-edit', function() {
		const target = $(this).data('target');
		$(target).slideUp();
	});
});
</script>
