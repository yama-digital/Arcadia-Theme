<?php
/**
 * Admin API Keys Management Page
 *
 * @link       https://your-domain.com
 * @since      1.0.0
 *
 * @package    MecUtility
 * @subpackage MecUtility/admin/partials
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap">
	<h1 class="wp-heading-inline">
		<?php esc_html_e( 'API Keys Management', 'mec-utility' ); ?>
	</h1>

	<a href="#" class="page-title-action" id="mec-utility-add-api-key">
		<?php esc_html_e( 'Add New API Key', 'mec-utility' ); ?>
	</a>

	<hr class="wp-header-end">

	<!-- Website URL Info -->
	<div class="notice notice-info">
		<p>
			<strong><?php esc_html_e( 'Your Website URL:', 'mec-utility' ); ?></strong>
			<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( $website_url ); ?>">
				<?php echo esc_url( $website_url ); ?>
				<span class="dashicons dashicons-admin-page mec-utility-copy-btn" title="<?php esc_attr_e( 'Copy to clipboard', 'mec-utility' ); ?>"></span>
			</code>
		</p>
		<p class="description">
			<?php esc_html_e( 'Use this URL along with your API key to authenticate in your mobile application.', 'mec-utility' ); ?>
		</p>
	</div>

	<!-- Add New API Key Form (Hidden by default) -->
	<div id="mec-utility-api-key-form" class="mec-utility-form-container" style="display: none;">
		<div class="mec-utility-form-wrapper">
			<h2><?php esc_html_e( 'Create New API Key', 'mec-utility' ); ?></h2>

			<form method="post" action="">
				<?php wp_nonce_field( 'mec_utility_action', 'mec_utility_nonce' ); ?>
				<input type="hidden" name="action" value="create_api_key">

				<table class="form-table">
					<tr>
						<th scope="row">
							<label for="api_key_name"><?php esc_html_e( 'API Key Name', 'mec-utility' ); ?></label>
						</th>
						<td>
							<input type="text" id="api_key_name" name="api_key_name" class="regular-text" required>
							<p class="description"><?php esc_html_e( 'Enter a descriptive name for this API key (e.g., "Mobile App", "iOS App", etc.)', 'mec-utility' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Permissions', 'mec-utility' ); ?></th>
						<td>
							<fieldset>
								<label>
									<input type="checkbox" name="permissions[]" value="read_events" checked>
									<?php esc_html_e( 'Read Events', 'mec-utility' ); ?>
								</label><br>

								<label>
									<input type="checkbox" name="permissions[]" value="create_events">
									<?php esc_html_e( 'Create Events', 'mec-utility' ); ?>
								</label><br>

								<label>
									<input type="checkbox" name="permissions[]" value="update_events">
									<?php esc_html_e( 'Update Events', 'mec-utility' ); ?>
								</label><br>

								<label>
									<input type="checkbox" name="permissions[]" value="delete_events">
									<?php esc_html_e( 'Delete Events', 'mec-utility' ); ?>
								</label><br>

								<label>
									<input type="checkbox" name="permissions[]" value="manage_bookings">
									<?php esc_html_e( 'Manage Bookings', 'mec-utility' ); ?>
								</label>
							</fieldset>
							<p class="description"><?php esc_html_e( 'Select the permissions for this API key.', 'mec-utility' ); ?></p>
						</td>
					</tr>
				</table>

				<p class="submit">
					<input type="submit" class="button button-primary" value="<?php esc_attr_e( 'Create API Key', 'mec-utility' ); ?>">
					<button type="button" class="button" id="mec-utility-cancel-api-key"><?php esc_html_e( 'Cancel', 'mec-utility' ); ?></button>
				</p>
			</form>
		</div>
	</div>

	<!-- API Keys List -->
	<div class="mec-utility-api-keys-list">
		<?php if ( empty( $api_keys ) ) : ?>
			<div class="mec-utility-empty-state">
				<div class="mec-utility-empty-icon">
					<span class="dashicons dashicons-admin-network"></span>
				</div>
				<h3><?php esc_html_e( 'No API Keys Found', 'mec-utility' ); ?></h3>
				<p><?php esc_html_e( 'Create your first API key to start using the mobile app integration.', 'mec-utility' ); ?></p>
				<button class="button button-primary" id="mec-utility-create-first-key">
					<?php esc_html_e( 'Create Your First API Key', 'mec-utility' ); ?>
				</button>
			</div>
		<?php else : ?>
			<div class="mec-utility-api-keys-table">
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Name', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'API Key', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Permissions', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Status', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Created', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Actions', 'mec-utility' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $api_keys as $api_key ) : ?>
							<tr>
								<td>
									<strong><?php echo esc_html( $api_key->name ); ?></strong>
									<?php if ( $api_key->name === 'Default API Key' ) : ?>
										<span class="mec-utility-badge mec-utility-badge-default"><?php esc_html_e( 'Default', 'mec-utility' ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<code class="mec-utility-api-key-display">
										<span class="mec-utility-key-preview"><?php echo esc_html( substr( $api_key->api_key, 0, 20 ) . '...' ); ?></span>
										<span class="mec-utility-key-full" style="display: none;"><?php echo esc_html( $api_key->api_key ); ?></span>
										<button type="button" class="button button-small mec-utility-toggle-key" data-key-id="<?php echo esc_attr( $api_key->id ); ?>">
											<?php esc_html_e( 'Show', 'mec-utility' ); ?>
										</button>
										<button type="button" class="button button-small mec-utility-copy-key" data-copy="<?php echo esc_attr( $api_key->api_key ); ?>" style="display: none;">
											<?php esc_html_e( 'Copy', 'mec-utility' ); ?>
										</button>
									</code>
								</td>
								<td>
									<?php
									$permissions = json_decode( $api_key->permissions, true );
									if ( ! empty( $permissions ) ) {
										echo '<ul class="mec-utility-permissions-list">';
										foreach ( $permissions as $permission ) {
											echo '<li>' . esc_html( ucwords( str_replace( '_', ' ', $permission ) ) ) . '</li>';
										}
										echo '</ul>';
									} else {
										echo '<span class="mec-utility-no-permissions">' . esc_html__( 'No permissions', 'mec-utility' ) . '</span>';
									}
									?>
								</td>
								<td>
									<span class="mec-utility-status <?php echo $api_key->is_active ? 'active' : 'inactive'; ?>">
										<?php echo $api_key->is_active ? esc_html__( 'Active', 'mec-utility' ) : esc_html__( 'Inactive', 'mec-utility' ); ?>
									</span>
								</td>
								<td>
									<?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $api_key->created_at ) ) ); ?>
								</td>
								<td>
									<div class="mec-utility-actions">
										<?php if ( $api_key->name !== 'Default API Key' ) : ?>
											<form method="post" style="display: inline;" onsubmit="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this API key?', 'mec-utility' ); ?>');">
												<?php wp_nonce_field( 'mec_utility_action', 'mec_utility_nonce' ); ?>
												<input type="hidden" name="action" value="delete_api_key">
												<input type="hidden" name="api_key_id" value="<?php echo esc_attr( $api_key->id ); ?>">
												<button type="submit" class="button button-small button-link-delete">
													<?php esc_html_e( 'Delete', 'mec-utility' ); ?>
												</button>
											</form>
										<?php else : ?>
											<span class="mec-utility-protected"><?php esc_html_e( 'Protected', 'mec-utility' ); ?></span>
										<?php endif; ?>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	</div>

	<!-- Usage Instructions -->
	<div class="mec-utility-usage-instructions">
		<h2><?php esc_html_e( 'How to Use API Keys', 'mec-utility' ); ?></h2>

		<div class="mec-utility-instruction-cards">
			<div class="mec-utility-instruction-card">
				<h3><?php esc_html_e( 'Mobile App Setup', 'mec-utility' ); ?></h3>
				<ol>
					<li><?php esc_html_e( 'Copy your Website URL and API Key', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'Open your mobile app', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'Go to Settings > Connect to Website', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'Enter the Website URL and API Key', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'Tap "Connect" to authenticate', 'mec-utility' ); ?></li>
				</ol>
			</div>

			<div class="mec-utility-instruction-card">
				<h3><?php esc_html_e( 'API Integration', 'mec-utility' ); ?></h3>
				<p><?php esc_html_e( 'For custom integrations, include the API key in your request headers:', 'mec-utility' ); ?></p>
				<code>Authorization: Bearer YOUR_API_KEY</code>
				<p><?php esc_html_e( 'Base URL:', 'mec-utility' ); ?> <code><?php echo esc_url( $website_url . '/wp-json/mec-utility/v1/' ); ?></code></p>
			</div>
		</div>
	</div>
</div>

<script>
jQuery(document).ready(function($) {
	// Show/Hide API Key form
	$('#mec-utility-add-api-key, #mec-utility-create-first-key').on('click', function(e) {
		e.preventDefault();
		$('#mec-utility-api-key-form').slideDown();
		$('#api_key_name').focus();
	});

	$('#mec-utility-cancel-api-key').on('click', function() {
		$('#mec-utility-api-key-form').slideUp();
	});

	// Toggle API Key visibility
	$('.mec-utility-toggle-key').on('click', function() {
		var $row = $(this).closest('tr');
		var $preview = $row.find('.mec-utility-key-preview');
		var $full = $row.find('.mec-utility-key-full');
		var $copyBtn = $row.find('.mec-utility-copy-key');

		if ($preview.is(':visible')) {
			$preview.hide();
			$full.show();
			$copyBtn.show();
			$(this).text('<?php esc_html_e( 'Hide', 'mec-utility' ); ?>');
		} else {
			$preview.show();
			$full.hide();
			$copyBtn.hide();
			$(this).text('<?php esc_html_e( 'Show', 'mec-utility' ); ?>');
		}
	});

	// Copy to clipboard functionality
	$('.mec-utility-copy-btn, .mec-utility-copy-key').on('click', function() {
		var textToCopy = $(this).data('copy') || $(this).parent().data('copy');
		navigator.clipboard.writeText(textToCopy).then(function() {
			// Show success feedback
			var $btn = $(this);
			var originalText = $btn.text();
			$btn.text('<?php esc_html_e( 'Copied!', 'mec-utility' ); ?>');
			setTimeout(function() {
				$btn.text(originalText);
			}, 2000);
		}.bind(this));
	});
});
</script>
