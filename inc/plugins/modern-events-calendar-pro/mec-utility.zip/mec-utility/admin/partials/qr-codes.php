<?php
/**
 * Admin QR Codes Management Page
 *
 * @link       https://your-domain.com
 * @since      1.0.0
 *
 * @package    MecUtility
 * @subpackage MecUtility/admin/partials
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap">
	<h1 class="wp-heading-inline">
		<?php esc_html_e( 'QR Codes Management', 'mec-utility' ); ?>
	</h1>

	<a href="#" class="page-title-action" id="mec-utility-generate-qr">
		<?php esc_html_e( 'Generate New QR Code', 'mec-utility' ); ?>
	</a>

	<hr class="wp-header-end">

	<!-- Current Active QR Code -->
	<?php if ( $default_qr ) : ?>
		<div class="mec-utility-current-qr">
			<h2><?php esc_html_e( 'Current Active QR Code', 'mec-utility' ); ?></h2>

			<div class="mec-utility-qr-display-large">
				<div class="mec-utility-qr-visual">
					<div id="mec-utility-current-qr" data-qr="<?php echo esc_attr( $default_qr->qr_token ); ?>"></div>
				</div>

				<div class="mec-utility-qr-info">
					<div class="mec-utility-qr-details">
						<h3><?php esc_html_e( 'QR Code Details', 'mec-utility' ); ?></h3>

						<div class="mec-utility-detail-row">
							<label><?php esc_html_e( 'Token:', 'mec-utility' ); ?></label>
							<code class="mec-utility-copy-text" data-copy="<?php echo esc_attr( $default_qr->qr_token ); ?>">
								<?php echo esc_html( substr( $default_qr->qr_token, 0, 20 ) . '...' ); ?>
								<span class="dashicons dashicons-admin-page mec-utility-copy-btn" title="<?php esc_attr_e( 'Copy to clipboard', 'mec-utility' ); ?>"></span>
							</code>
						</div>

						<div class="mec-utility-detail-row">
							<label><?php esc_html_e( 'Status:', 'mec-utility' ); ?></label>
							<span class="mec-utility-status <?php echo $default_qr->is_used ? 'used' : 'active'; ?>">
								<?php echo $default_qr->is_used ? esc_html__( 'Used', 'mec-utility' ) : esc_html__( 'Active', 'mec-utility' ); ?>
							</span>
						</div>

						<div class="mec-utility-detail-row">
							<label><?php esc_html_e( 'Type:', 'mec-utility' ); ?></label>
							<span class="mec-utility-status permanent">
								<?php esc_html_e( 'Permanent (No Expiry)', 'mec-utility' ); ?>
							</span>
						</div>

						<div class="mec-utility-detail-row">
							<label><?php esc_html_e( 'Created:', 'mec-utility' ); ?></label>
							<span><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $default_qr->created_at ) ) ); ?></span>
						</div>
					</div>

					<div class="mec-utility-qr-actions">
						<button type="button" class="button button-primary" id="mec-utility-download-qr">
							<span class="dashicons dashicons-download"></span>
							<?php esc_html_e( 'Download QR Code', 'mec-utility' ); ?>
						</button>

						<button type="button" class="button button-secondary" id="mec-utility-refresh-qr">
							<span class="dashicons dashicons-update"></span>
							<?php esc_html_e( 'Generate New', 'mec-utility' ); ?>
						</button>
					</div>
				</div>
			</div>
		</div>
	<?php else : ?>
		<div class="notice notice-info">
			<p>
				<?php esc_html_e( 'No active QR code found. Generate one to allow mobile app users to connect quickly.', 'mec-utility' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<!-- Generate QR Code Form -->
	<div id="mec-utility-qr-form" class="mec-utility-form-container" style="display: none;">
		<div class="mec-utility-form-wrapper">
			<h2><?php esc_html_e( 'Generate New QR Code', 'mec-utility' ); ?></h2>

			<form method="post" action="">
				<?php wp_nonce_field( 'mec_utility_action', 'mec_utility_nonce' ); ?>
				<input type="hidden" name="action" value="generate_qr_code">

				<table class="form-table">
					<tr>
						<th scope="row"><?php esc_html_e( 'QR Code Type', 'mec-utility' ); ?></th>
						<td>
							<p class="description">
								<strong><?php esc_html_e( 'Permanent QR Code', 'mec-utility' ); ?></strong><br>
								<?php esc_html_e( 'This QR code will remain valid indefinitely and can be used multiple times.', 'mec-utility' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Auto-Replace', 'mec-utility' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="auto_replace" value="1" checked>
								<?php esc_html_e( 'Replace the current active QR code', 'mec-utility' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'If checked, the current QR code will be marked as used.', 'mec-utility' ); ?></p>
						</td>
					</tr>
				</table>

				<p class="submit">
					<input type="submit" class="button button-primary" value="<?php esc_attr_e( 'Generate QR Code', 'mec-utility' ); ?>">
					<button type="button" class="button" id="mec-utility-cancel-qr"><?php esc_html_e( 'Cancel', 'mec-utility' ); ?></button>
				</p>
			</form>
		</div>
	</div>

	<!-- QR Codes History -->
	<div class="mec-utility-qr-history">
		<h2><?php esc_html_e( 'QR Codes History', 'mec-utility' ); ?></h2>

		<?php if ( empty( $qr_codes ) ) : ?>
			<div class="mec-utility-empty-state">
				<div class="mec-utility-empty-icon">
					<span class="dashicons dashicons-smartphone"></span>
				</div>
				<h3><?php esc_html_e( 'No QR Codes Generated Yet', 'mec-utility' ); ?></h3>
				<p><?php esc_html_e( 'Generate your first QR code to allow mobile users to connect quickly.', 'mec-utility' ); ?></p>
				<button class="button button-primary" id="mec-utility-generate-first-qr">
					<?php esc_html_e( 'Generate Your First QR Code', 'mec-utility' ); ?>
				</button>
			</div>
		<?php else : ?>
			<div class="mec-utility-qr-table">
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th scope="col" class="manage-column"><?php esc_html_e( 'QR Code', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Token', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Status', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Created', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Type', 'mec-utility' ); ?></th>
							<th scope="col" class="manage-column"><?php esc_html_e( 'Used', 'mec-utility' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $qr_codes as $qr_code ) : ?>
							<?php
							$status_class = $qr_code->is_used ? 'used' : 'active';
							$status_text = $qr_code->is_used ? __( 'Used', 'mec-utility' ) : __( 'Active', 'mec-utility' );
							?>
							<tr>
								<td>
									<div class="mec-utility-qr-mini" data-qr="<?php echo esc_attr( $qr_code->qr_token ); ?>"></div>
								</td>
								<td>
									<code><?php echo esc_html( substr( $qr_code->qr_token, 0, 20 ) . '...' ); ?></code>
								</td>
								<td>
									<span class="mec-utility-status <?php echo esc_attr( $status_class ); ?>">
										<?php echo esc_html( $status_text ); ?>
									</span>
								</td>
								<td>
									<?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $qr_code->created_at ) ) ); ?>
								</td>
								<td>
									<span class="mec-utility-status permanent">
										<?php esc_html_e( 'Permanent', 'mec-utility' ); ?>
									</span>
								</td>
								<td>
									<?php if ( $qr_code->is_used ) : ?>
										<span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span>
									<?php else : ?>
										<span class="dashicons dashicons-minus" style="color: #ddd;"></span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	</div>

	<!-- Usage Instructions -->
	<div class="mec-utility-usage-instructions">
		<h2><?php esc_html_e( 'How to Use QR Codes', 'mec-utility' ); ?></h2>

		<div class="mec-utility-instruction-cards">
			<div class="mec-utility-instruction-card">
				<h3><?php esc_html_e( 'For Mobile App Users', 'mec-utility' ); ?></h3>
				<ol>
					<li><?php esc_html_e( 'Open your mobile app', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'Tap "Scan QR Code" or "Quick Connect"', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'Point your camera at the QR code above', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'The app will automatically connect to your website', 'mec-utility' ); ?></li>
				</ol>
			</div>

			<div class="mec-utility-instruction-card">
				<h3><?php esc_html_e( 'Security Features', 'mec-utility' ); ?></h3>
				<ul>
					<li><?php esc_html_e( 'QR codes are permanent and do not expire', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'QR codes can be used multiple times for convenience', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'Generate new codes to replace old ones when needed', 'mec-utility' ); ?></li>
					<li><?php esc_html_e( 'All connections are logged for audit purposes', 'mec-utility' ); ?></li>
				</ul>
			</div>
		</div>
	</div>
</div>

<script>
jQuery(document).ready(function($) {
	// Show/Hide QR form
	$('#mec-utility-generate-qr, #mec-utility-generate-first-qr, #mec-utility-refresh-qr').on('click', function(e) {
		e.preventDefault();
		$('#mec-utility-qr-form').slideDown();
	});

	$('#mec-utility-cancel-qr').on('click', function() {
		$('#mec-utility-qr-form').slideUp();
	});

	// Copy to clipboard functionality
	$('.mec-utility-copy-btn').on('click', function() {
		var textToCopy = $(this).parent().data('copy');
		navigator.clipboard.writeText(textToCopy).then(function() {
			// Show success feedback
			var $btn = $(this);
			$btn.addClass('copied');
			setTimeout(function() {
				$btn.removeClass('copied');
			}, 2000);
		}.bind(this));
	});

	// Generate QR codes (placeholder - you'll need a QR library)
	function generateQRCode(element, data) {
		var $element = $(element);
		var size = $element.hasClass('mec-utility-qr-mini') ? 50 : 200;

		// Placeholder QR code generation
		$element.html('<div class="mec-utility-qr-placeholder" style="width:' + size + 'px;height:' + size + 'px;">QR: ' + data.substring(0, 8) + '...</div>');
	}

	// Generate QR codes for all elements
	$('[data-qr]').each(function() {
		var qrData = {
			website_url: '<?php echo esc_js( home_url() ); ?>',
			qr_token: $(this).data('qr'),
			timestamp: '<?php echo esc_js( current_time( 'timestamp' ) ); ?>'
		};
		generateQRCode(this, JSON.stringify(qrData));
	});

	// Download QR code functionality
	$('#mec-utility-download-qr').on('click', function() {
		// Download functionality is handled by admin.js
	});
});
</script>
