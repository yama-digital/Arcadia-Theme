<?php

/**
 * QR Code Service
 *
 * @link       https://your-domain.com
 * @since      1.0.0
 *
 * @package    MecUtility
 * @subpackage MecUtility/Services
 */

namespace MecUtility\Services;

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;

/**
 * QR Code Service Class
 *
 * Handles QR code generation using the endroid/qr-code library.
 *
 * @package    MecUtility
 * @subpackage MecUtility/Services
 * @author     Your Name <your-email@domain.com>
 */
class QrCodeService {

	/**
	 * Generate QR code image
	 *
	 * @since 1.0.0
	 * @param string $data The data to encode in the QR code
	 * @param int    $size The size of the QR code (default: 200)
	 * @param string $label Optional label for the QR code
	 * @return string Base64 encoded PNG image
	 */
	public static function generate_qr_code( $data, $size = 200, $label = '' ) {
		// Check if endroid/qr-code library is available
		if (class_exists('Endroid\QrCode\Builder\Builder')) {
			return self::generate_qr_code_endroid( $data, $size, $label );
		}

		// Fallback to Google Charts API or simple placeholder
		return self::generate_qr_code_fallback( $data, $size, $label );
	}

	/**
	 * Generate QR code using endroid/qr-code library
	 *
	 * @since 1.0.0
	 * @param string $data The data to encode in the QR code
	 * @param int    $size The size of the QR code (default: 200)
	 * @param string $label Optional label for the QR code
	 * @return string Base64 encoded PNG image
	 */
	private static function generate_qr_code_endroid( $data, $size = 200, $label = '' ) {
		try {
			$builder = Builder::create()
				->writer( new PngWriter() )
				->writerOptions( [] )
				->data( $data )
				->encoding( new Encoding( 'UTF-8' ) )
				->errorCorrectionLevel( new ErrorCorrectionLevelHigh() )
				->size( $size )
				->margin( 10 )
				->roundBlockSizeMode( new RoundBlockSizeModeMargin() );

			$result = $builder->build();

			// Return base64 encoded image
			return base64_encode( $result->getString() );

		} catch ( \Exception $e ) {
			return false;
		}
	}

	/**
	 * Generate QR code using Google Charts API (fallback)
	 *
	 * @since 1.0.0
	 * @param string $data The data to encode in the QR code
	 * @param int    $size The size of the QR code (default: 200)
	 * @param string $label Optional label for the QR code
	 * @return string Base64 encoded PNG image
	 */
	private static function generate_qr_code_fallback( $data, $size = 200, $label = '' ) {
		try {
			// Use Google Charts API as fallback
			$url = 'https://chart.googleapis.com/chart?cht=qr&chs=' . $size . 'x' . $size . '&chl=' . urlencode( $data );

			$response = wp_remote_get( $url, array(
				'timeout' => 30,
				'sslverify' => false
			) );

			if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
				$image_data = wp_remote_retrieve_body( $response );
				return base64_encode( $image_data );
			}

			// If Google Charts also fails, create a simple placeholder
			return self::generate_qr_placeholder( $data, $size );

		} catch ( \Exception $e ) {
			return self::generate_qr_placeholder( $data, $size );
		}
	}

	/**
	 * Generate a simple SVG placeholder when QR generation fails
	 *
	 * @since 1.0.0
	 * @param string $data The data that would be encoded
	 * @param int    $size The size of the placeholder
	 * @return string Base64 encoded SVG
	 */
	private static function generate_qr_placeholder( $data, $size = 200 ) {
		$svg = '<svg width="' . $size . '" height="' . $size . '" xmlns="http://www.w3.org/2000/svg">
			<rect width="100%" height="100%" fill="#f0f0f0" stroke="#ccc" strokeWidth="2"/>
			<text x="50%" y="40%" text-anchor="middle" font-family="Arial, sans-serif" font-size="14" fill="#666">QR Code</text>
			<text x="50%" y="60%" text-anchor="middle" font-family="Arial, sans-serif" font-size="12" fill="#999">Placeholder</text>
			<text x="50%" y="75%" text-anchor="middle" font-family="Arial, sans-serif" font-size="10" fill="#ccc">Install endroid/qr-code</text>
		</svg>';

		return base64_encode( $svg );
	}

	/**
	 * Generate QR code and save to file
	 *
	 * @since 1.0.0
	 * @param string $data The data to encode in the QR code
	 * @param string $file_path Path where to save the QR code image
	 * @param int    $size The size of the QR code (default: 200)
	 * @param string $label Optional label for the QR code
	 * @return bool Success status
	 */
	public static function generate_qr_code_file( $data, $file_path, $size = 200, $label = '' ) {
		// Check if endroid/qr-code library is available
		if (class_exists('Endroid\QrCode\Builder\Builder')) {
			return self::generate_qr_code_file_endroid( $data, $file_path, $size, $label );
		}

		// Fallback method
		$base64_data = self::generate_qr_code_fallback( $data, $size, $label );
		if ( $base64_data ) {
			$image_data = base64_decode( $base64_data );
			return file_put_contents( $file_path, $image_data ) !== false;
		}

		return false;
	}

	/**
	 * Generate QR code file using endroid/qr-code library
	 *
	 * @since 1.0.0
	 * @param string $data The data to encode in the QR code
	 * @param string $file_path Path where to save the QR code image
	 * @param int    $size The size of the QR code (default: 200)
	 * @param string $label Optional label for the QR code
	 * @return bool Success status
	 */
	private static function generate_qr_code_file_endroid( $data, $file_path, $size = 200, $label = '' ) {
		try {
			$builder = Builder::create()
				->writer( new PngWriter() )
				->writerOptions( [] )
				->data( $data )
				->encoding( new Encoding( 'UTF-8' ) )
				->errorCorrectionLevel( new ErrorCorrectionLevelHigh() )
				->size( $size )
				->margin( 10 )
				->roundBlockSizeMode( new RoundBlockSizeModeMargin() );

			$result = $builder->build();

			// Save to file
			$result->saveToFile( $file_path );

			return true;

		} catch ( \Exception $e ) {
			return false;
		}
	}

	/**
	 * Generate QR code data URL for direct embedding
	 *
	 * @since 1.0.0
	 * @param string $data The data to encode in the QR code
	 * @param int    $size The size of the QR code (default: 200)
	 * @param string $label Optional label for the QR code
	 * @return string|false Data URL or false on failure
	 */
	public static function generate_qr_code_data_url( $data, $size = 200, $label = '' ) {
		$base64 = self::generate_qr_code( $data, $size, $label );

		if ( $base64 ) {
			return 'data:image/png;base64,' . $base64;
		}

		return false;
	}

	/**
	 * Generate QR code for MEC Utility token
	 *
	 * @since 1.0.0
	 * @param string $qr_token The QR token
	 * @param int    $size The size of the QR code (default: 200)
	 * @return string|false Data URL or false on failure
	 */
	public static function generate_mec_qr_code( $qr_token, $size = 200 ) {
		$qr_data = array(
			'website_url' => home_url(),
			'qr_token'    => $qr_token,
			'timestamp'   => current_time( 'timestamp' ),
			'plugin'      => 'mec-utility',
			'version'     => defined( 'MEC_UTILITY_VERSION' ) ? MEC_UTILITY_VERSION : '1.0.0'
		);

		$data = wp_json_encode( $qr_data );

		return self::generate_qr_code_data_url( $data, $size );
	}
}
