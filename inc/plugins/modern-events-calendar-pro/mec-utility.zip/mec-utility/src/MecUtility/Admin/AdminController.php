<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://your-domain.com
 * @since      1.0.0
 *
 * @package    MecUtility
 * @subpackage MecUtility/Admin
 */

namespace MecUtility\Admin;

use MecUtility\Services\QrCodeService;

/**
 * The admin-specific functionality of the plugin.
 *
 * Handles API key management, QR code generation, and admin interface.
 *
 * @package    MecUtility
 * @subpackage MecUtility/Admin
 * @author     Your Name <your-email@domain.com>
 */
class AdminController {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param    string $plugin_name       The name of this plugin.
	 * @param    string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {
		wp_enqueue_style(
			$this->plugin_name . '-admin',
			MEC_UTILITY_PLUGIN_URL . 'admin/css/admin.css',
			array(),
			$this->version,
			'all'
		);

		// Enqueue WordPress admin styles
		wp_enqueue_style( 'wp-color-picker' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {
		wp_enqueue_script(
			$this->plugin_name . '-admin',
			MEC_UTILITY_PLUGIN_URL . 'admin/js/admin.js',
			array( 'jquery', 'wp-color-picker' ),
			$this->version,
			false
		);

		// Localize script for AJAX
		wp_localize_script(
			$this->plugin_name . '-admin',
			'mecUtilityAjax',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'mec_utility_ajax_nonce' ),
				'strings'  => array(
					'confirm_delete'     => __( 'Are you sure you want to delete this item?', 'mec-utility' ),
					'qr_generation_error' => __( 'Failed to generate QR code. Please try again.', 'mec-utility' ),
				),
			)
		);
	}

	/**
	 * Add admin menu.
	 *
	 * @since    1.0.0
	 */
	public function add_admin_menu() {
		// Main menu page
		add_menu_page(
			__( 'MEC Utility', 'mec-utility' ),
			__( 'MEC Utility', 'mec-utility' ),
			'manage_options',
			'mec-utility',
			array( $this, 'dashboard_page' ),
			plugin_dir_url(__FILE__) . '../../../admin/img/mec-utility.svg',
			30
		);

		// App Access submenu (replaces separate API Keys and QR Codes)
		add_submenu_page(
			'mec-utility',
			__( 'App Access', 'mec-utility' ),
			__( 'App Access', 'mec-utility' ),
			'manage_options',
			'mec-utility-app-access',
			array( $this, 'app_access_page' )
		);

		// Language App submenu
		add_submenu_page(
			'mec-utility',
			__( 'App Language', 'mec-utility' ),
			__( 'App Language', 'mec-utility' ),
			'manage_options',
			'mec-utility-language-app',
			array( $this, 'language_app_page' )
		);
	}

	/**
	 * Initialize admin settings.
	 *
	 * @since    1.0.0
	 */
	public function admin_init() {
		// Register settings
		register_setting( 'mec_utility_settings', 'mec_utility_api_enabled' );
		register_setting( 'mec_utility_settings', 'mec_utility_qr_enabled' );
		register_setting( 'mec_utility_settings', 'mec_utility_qr_expiry' );
		register_setting( 'mec_utility_settings', 'mec_utility_rate_limit' );
		register_setting( 'mec_utility_settings', 'mec_utility_require_ssl' );
		register_setting( 'mec_utility_settings', 'mec_utility_allowed_origins' );

		// Handle form submissions
		$this->handle_form_submissions();
	}

	/**
	 * Handle form submissions.
	 *
	 * @since    1.0.0
	 */
	private function handle_form_submissions() {
		if ( ! isset( $_POST['mec_utility_nonce'] ) || ! wp_verify_nonce( $_POST['mec_utility_nonce'], 'mec_utility_action' ) ) {
			return;
		}

		if ( isset( $_POST['action'] ) ) {
			switch ( $_POST['action'] ) {
				case 'create_app_access':
					$this->create_app_access();
					break;
				case 'update_app_access':
					$this->update_app_access();
					break;
				case 'delete_app_access':
					$this->delete_app_access();
					break;
				case 'create_api_key': // Legacy support
					$this->create_app_access();
					break;
				case 'delete_api_key': // Legacy support
					$this->delete_app_access();
					break;
				case 'generate_qr_code': // Legacy support
					$this->create_app_access();
					break;
			}
		}
	}

	/**
	 * Dashboard page.
	 *
	 * @since    1.0.0
	 */
	public function dashboard_page() {
		$api_keys_count = $this->get_api_keys_count();
		$qr_codes_count = $this->get_qr_codes_count();
		$default_api_key = $this->get_default_api_key();
		$latest_api_key = null;

		// If no default API key exists, fetch the latest created API key for display
		if ( ! $default_api_key ) {
			$all_keys = $this->get_api_keys();
			if ( is_array( $all_keys ) && ! empty( $all_keys ) ) {
				$latest_api_key = $all_keys[0];
			}
		}

		include MEC_UTILITY_PLUGIN_DIR . 'admin/partials/dashboard.php';
	}

	/**
	 * App Access page.
	 *
	 * @since    1.0.0
	 */
	public function app_access_page() {
		include MEC_UTILITY_PLUGIN_DIR . 'admin/partials/app-access.php';
	}



	/**
	 * Create new app access (API key + QR code).
	 *
	 * @since    1.0.0
	 */
	private function create_app_access() {
		global $wpdb;

		$name = sanitize_text_field( $_POST['app_name'] ?? $_POST['api_key_name'] ?? '' );
		$permissions = isset( $_POST['permissions'] ) ? array_map( 'sanitize_text_field', $_POST['permissions'] ) : array();

		if ( empty( $name ) ) {
			$this->add_admin_notice( __( 'App name is required.', 'mec-utility' ), 'error' );
			return;
		}

		// Generate API credentials
		$api_key = $this->generate_api_key();
		$api_secret = $this->generate_api_secret();

		// Generate QR token
		$qr_token = $this->generate_qr_token();

		// Start transaction
		$wpdb->query( 'START TRANSACTION' );

		try {
			// Create API key
			$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
			$api_result = $wpdb->insert(
				$api_keys_table,
				array(
					'user_id'     => get_current_user_id(),
					'api_key'     => $api_key,
					'api_secret'  => $api_secret,
					'name'        => $name,
					'permissions' => wp_json_encode( $permissions ),
					'is_active'   => 1,
					'created_at'  => current_time( 'mysql' ),
				),
				array( '%d', '%s', '%s', '%s', '%s', '%d', '%s' )
			);

			if ( ! $api_result ) {
				throw new \Exception( 'Failed to create API key' );
			}

			$api_key_id = $wpdb->insert_id;

			// Create QR code linked to API key
			$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
			$session_data = array(
				'website_url'  => home_url(),
				'generated_at' => current_time( 'mysql' ),
				'user_id'      => get_current_user_id(),
				'api_key_id'   => $api_key_id,
				'app_name'     => $name,
				'permissions'  => $permissions,
			);

			$qr_result = $wpdb->insert(
				$qr_sessions_table,
				array(
					'user_id'      => get_current_user_id(),
					'qr_token'     => $qr_token,
					'session_data' => wp_json_encode( $session_data ),
					'expires_at'   => null, // Permanent
					'is_used'      => 0,
					'created_at'   => current_time( 'mysql' ),
				),
				array( '%d', '%s', '%s', '%s', '%d', '%s' )
			);

			if ( ! $qr_result ) {
				throw new \Exception( 'Failed to create QR code' );
			}

			// Commit transaction
			$wpdb->query( 'COMMIT' );

			$this->add_admin_notice(
				sprintf(
					__( 'App access "%s" created successfully! Both API key and QR code are ready to use.', 'mec-utility' ),
					$name
				),
				'success'
			);

		} catch ( \Exception $e ) {
			// Rollback transaction
			$wpdb->query( 'ROLLBACK' );
			$this->add_admin_notice(
				sprintf(
					__( 'Failed to create app access: %s', 'mec-utility' ),
					$e->getMessage()
				),
				'error'
			);
		}
	}

	/**
	 * Delete app access (API key + associated QR code).
	 *
	 * @since    1.0.0
	 */
	private function delete_app_access() {
		global $wpdb;

		$api_key_id = intval( $_POST['api_key_id'] );

		if ( empty( $api_key_id ) ) {
			$this->add_admin_notice( __( 'Invalid app access ID.', 'mec-utility' ), 'error' );
			return;
		}

		// Start transaction
		$wpdb->query( 'START TRANSACTION' );

		try {
			// Delete API key
			$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
			$api_result = $wpdb->delete(
				$api_keys_table,
				array( 'id' => $api_key_id ),
				array( '%d' )
			);

			// Delete associated QR codes
			$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$qr_sessions_table} WHERE session_data LIKE %s",
					'%"api_key_id":' . $api_key_id . '%'
				)
			);

			if ( $api_result ) {
				$wpdb->query( 'COMMIT' );
				$this->add_admin_notice( __( 'App access deleted successfully!', 'mec-utility' ), 'success' );
			} else {
				throw new \Exception( 'Failed to delete API key' );
			}

		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			$this->add_admin_notice(
				sprintf(
					__( 'Failed to delete app access: %s', 'mec-utility' ),
					$e->getMessage()
				),
				'error'
			);
		}
	}

	/**
	 * Update existing app access permissions and name.
	 *
	 * @since 1.0.0
	 */
	private function update_app_access() {
		global $wpdb;

		$api_key_id = isset( $_POST['api_key_id'] ) ? intval( $_POST['api_key_id'] ) : 0;
		$name       = sanitize_text_field( $_POST['app_name'] ?? '' );
		$permissions = isset( $_POST['permissions'] ) ? array_map( 'sanitize_text_field', (array) $_POST['permissions'] ) : array();

		if ( ! $api_key_id ) {
			$this->add_admin_notice( __( 'Invalid app access ID.', 'mec-utility' ), 'error' );
			return;
		}

		if ( '' === $name ) {
			$this->add_admin_notice( __( 'App name is required.', 'mec-utility' ), 'error' );
			return;
		}

		$permissions = array_values( array_unique( $permissions ) );

		$api_keys_table     = $wpdb->prefix . 'mec_utility_api_keys';
		$qr_sessions_table  = $wpdb->prefix . 'mec_utility_qr_sessions';

		$api_key = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$api_keys_table} WHERE id = %d",
				$api_key_id
			)
		);

		if ( ! $api_key ) {
			$this->add_admin_notice( __( 'App access not found.', 'mec-utility' ), 'error' );
			return;
		}

		$update_result = $wpdb->update(
			$api_keys_table,
			array(
				'name'        => $name,
				'permissions' => wp_json_encode( $permissions ),
			),
			array( 'id' => $api_key_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $update_result ) {
			$this->add_admin_notice( __( 'Failed to update app access.', 'mec-utility' ), 'error' );
			return;
		}

		// Sync QR session metadata with the updated permissions/name.
		$qr_sessions = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, session_data FROM {$qr_sessions_table} WHERE session_data LIKE %s",
				'%"api_key_id":' . $api_key_id . '%'
			)
		);

		if ( ! empty( $qr_sessions ) ) {
			foreach ( $qr_sessions as $session ) {
				$session_data = json_decode( $session->session_data, true );

				if ( is_array( $session_data ) ) {
					$session_data['app_name']    = $name;
					$session_data['permissions'] = $permissions;

					$wpdb->update(
						$qr_sessions_table,
						array( 'session_data' => wp_json_encode( $session_data ) ),
						array( 'id' => $session->id ),
						array( '%s' ),
						array( '%d' )
					);
				}
			}
		}

		$this->add_admin_notice(
			sprintf(
				__( 'App access "%s" updated successfully.', 'mec-utility' ),
				$name
			),
			'success'
		);
	}

	/**
	 * Get app access data (API keys with associated QR codes).
	 *
	 * @since    1.0.0
	 * @return   array
	 */
	private function get_app_access() {
		global $wpdb;

		try {
			$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
			$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';

			// Get all API keys first
			$api_keys = $wpdb->get_results(
				"SELECT * FROM {$api_keys_table} ORDER BY created_at DESC"
			);

			if ( empty( $api_keys ) ) {
				return array();
			}

			// For each API key, find associated QR codes
			foreach ( $api_keys as $key => $api_key ) {
				// First try to find QR codes with the new format (has api_key_id)
				$qr_code = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT qr_token, is_used, created_at
						FROM {$qr_sessions_table}
						WHERE session_data LIKE %s
						ORDER BY created_at DESC
						LIMIT 1",
						'%"api_key_id":' . $api_key->id . '%'
					)
				);

				// If no QR code found with new format, and this is the Default API Key,
				// try to find the old format QR code
				if ( ! $qr_code && $api_key->name === 'Default API Key' ) {
					$qr_code = $wpdb->get_row(
						$wpdb->prepare(
							"SELECT qr_token, is_used, created_at
							FROM {$qr_sessions_table}
							WHERE session_data LIKE %s
							ORDER BY created_at DESC
							LIMIT 1",
							'%"type":"default"%'
						)
					);
				}

				// Add QR code data to the API key object
				if ( $qr_code ) {
					$api_keys[$key]->qr_token = $qr_code->qr_token;
					$api_keys[$key]->qr_is_used = $qr_code->is_used;
					$api_keys[$key]->qr_created_at = $qr_code->created_at;
				} else {
					$api_keys[$key]->qr_token = null;
					$api_keys[$key]->qr_is_used = null;
					$api_keys[$key]->qr_created_at = null;
				}
			}

			return $api_keys;

		} catch ( Exception $e ) {
			return array();
		}
	}

	/**
	 * Filter the displayed author name for MEC events
	 * Show the app access name when event was created via API
	 *
	 * @param string $display_name Original author display name.
	 * @return string Filtered author name.
	 */
	public function filter_mec_event_author_name( $display_name ) {
		global $post;

		if ( ! $post || 'mec-events' !== $post->post_type ) {
			return $display_name;
		}

		$api_author_name = get_post_meta( $post->ID, 'mec_utility_api_author_name', true );

		if ( ! empty( $api_author_name ) ) {
			return $api_author_name;
		}

		return $display_name;
	}

	/**
	 * Filter author display name for mec-events in admin lists
	 *
	 * @param string $display_name The author's display name.
	 * @param int    $user_id      The user ID.
	 * @return string The filtered display name.
	 */
	public function filter_mec_event_author_display_name( $display_name, $user_id ) {
		global $post;

		if ( ! $post || 'mec-events' !== $post->post_type ) {
			return $display_name;
		}

		$api_author_name = get_post_meta( $post->ID, 'mec_utility_api_author_name', true );

		if ( ! empty( $api_author_name ) ) {
			return $api_author_name;
		}

		return $display_name;
	}

	/**
	 * Get API keys.
	 *
	 * @since    1.0.0
	 * @return   array
	 */
	private function get_api_keys() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mec_utility_api_keys';

		return $wpdb->get_results(
			"SELECT * FROM {$table_name} ORDER BY created_at DESC"
		);
	}

	/**
	 * Get API keys count.
	 *
	 * @since    1.0.0
	 * @return   int
	 */
	private function get_api_keys_count() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mec_utility_api_keys';

		return $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
	}

	/**
	 * Get QR codes.
	 *
	 * @since    1.0.0
	 * @return   array
	 */
	private function get_qr_codes() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mec_utility_qr_sessions';

		return $wpdb->get_results(
			"SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT 20"
		);
	}

	/**
	 * Get QR codes count.
	 *
	 * @since    1.0.0
	 * @return   int
	 */
	private function get_qr_codes_count() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mec_utility_qr_sessions';

		return $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
	}

	/**
	 * Get default API key.
	 *
	 * @since    1.0.0
	 * @return   object|null
	 */
	private function get_default_api_key() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mec_utility_api_keys';

		return $wpdb->get_row(
			"SELECT * FROM {$table_name} WHERE name = 'Default API Key' LIMIT 1"
		);
	}

	/**
	 * Get default QR code.
	 *
	 * @since    1.0.0
	 * @return   object|null
	 */
	private function get_default_qr_code() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mec_utility_qr_sessions';

		// Remove expiry filter - get the latest QR code regardless of expiry
		return $wpdb->get_row(
			"SELECT * FROM {$table_name} WHERE is_used = 0 ORDER BY created_at DESC LIMIT 1"
		);
	}

	/**
	 * Generate API key.
	 *
	 * @since    1.0.0
	 * @return   string
	 */
	private function generate_api_key() {
		return 'mec_' . wp_generate_password( 32, false );
	}

	/**
	 * Generate API secret.
	 *
	 * @since    1.0.0
	 * @return   string
	 */
	private function generate_api_secret() {
		return wp_generate_password( 64, true, true );
	}

	/**
	 * Generate QR token.
	 *
	 * @since    1.0.0
	 * @return   string
	 */
	private function generate_qr_token() {
		return 'qr_' . wp_generate_password( 32, false );
	}

	/**
	 * Add admin notice.
	 *
	 * @since    1.0.0
	 * @param    string $message
	 * @param    string $type
	 */
	private function add_admin_notice( $message, $type = 'info' ) {
		add_action( 'admin_notices', function() use ( $message, $type ) {
			echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible">';
			echo '<p>' . esc_html( $message ) . '</p>';
			echo '</div>';
		});
	}

	/**
	 * Initialize admin hooks
	 *
	 * @since    1.0.0
	 */
	public function init_hooks() {
		// Add AJAX handlers
		add_action( 'wp_ajax_mec_utility_generate_qr', array( $this, 'ajax_generate_qr_code' ) );
		add_action( 'wp_ajax_mec_utility_download_qr', array( $this, 'ajax_download_qr_code' ) );
		add_action( 'wp_ajax_mec_utility_update_translate_app', array( $this, 'ajax_update_translate_app' ) );
		add_action( 'wp_ajax_mec_utility_get_translate_tab', array( $this, 'ajax_get_translate_tab' ) );
	}

	/**
	 * AJAX handler for QR code generation
	 *
	 * @since    1.0.0
	 */
	public function ajax_generate_qr_code() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'mec_utility_ajax_nonce' ) ) {
			wp_die( 'Security check failed' );
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Insufficient permissions' );
		}

		$qr_token = sanitize_text_field( $_POST['qr_token'] );
		$size = intval( $_POST['size'] ?? 200 );

		if ( empty( $qr_token ) ) {
			wp_send_json_error( 'Invalid QR token' );
		}

		// Generate QR code
		$qr_data_url = QrCodeService::generate_mec_qr_code( $qr_token, $size );

		if ( $qr_data_url ) {
			wp_send_json_success( array(
				'qr_code' => $qr_data_url,
				'token' => $qr_token
			) );
		} else {
			wp_send_json_error( 'Failed to generate QR code' );
		}
	}

	/**
	 * AJAX handler for downloading QR code as PNG
	 *
	 * @since    1.0.0
	 */
	public function ajax_download_qr_code() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'mec_utility_ajax_nonce' ) ) {
			wp_die( 'Security check failed' );
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Insufficient permissions' );
		}

		$qr_token = sanitize_text_field( $_POST['qr_token'] );

		if ( empty( $qr_token ) ) {
			wp_send_json_error( 'Invalid QR token' );
		}

		// Generate QR code
		$qr_data_url = QrCodeService::generate_mec_qr_code( $qr_token, 300 ); // Larger size for download

		if ( $qr_data_url ) {
			wp_send_json_success( array(
				'qr_code' => $qr_data_url,
				'token' => $qr_token,
				'filename' => 'mec_qr_code_' . substr( $qr_token, 3, 8 ) . '.png'
			) );
		} else {
			wp_send_json_error( 'Failed to generate QR code' );
		}
	}

	/**
	 * Retrieve translation context for admin UI.
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	private function get_translation_context() {
		$settings_translate = json_decode( \get_option( 'mec_utility_translations', null ) );
		$enable = 0;
		$saved_translations = array();

		if ( $settings_translate instanceof \stdClass ) {
			$enable = isset( $settings_translate->enable ) ? intval( $settings_translate->enable ) : 0;

			if ( isset( $settings_translate->translate ) ) {
				if ( is_array( $settings_translate->translate ) ) {
					$saved_translations = $settings_translate->translate;
				} else {
					$saved_translations = (array) $settings_translate->translate;
				}
			}
		}

		$translate_controller = new \MecUtility\Controllers\TranslateController();
		$default_translations = $translate_controller->get_default_translations();
		$translations = array_merge( $default_translations, $saved_translations );

		return array(
			'enable' => $enable,
			'defaults' => $default_translations,
			'translations' => $translations,
		);
	}

	/**
	 * Get translation groups definitions.
	 *
	 * @since 1.0.0
	 *
	 * @param array $default_translations Default translation map.
	 *
	 * @return array
	 */
	private function get_translation_groups( $default_translations ) {
		$all_fields = array();

		foreach ( $default_translations as $key => $default_label ) {
			$all_fields[] = array(
				'key' => $key,
				'label' => $default_label,
			);
		}

		return array(
			'all' => array(
				'title' => __( 'All Translations', 'mec-utility' ),
				'fields' => $all_fields,
			),
			'calendar' => array(
				'title' => __( 'Calendar Page', 'mec-utility' ),
				'fields' => array(
					array( 'key' => 'Calendar', 'label' => 'Calendar' ),
					array( 'key' => 'SelectDate', 'label' => 'Pick Date' ),
					array( 'key' => 'NoEventsFound', 'label' => 'No events found for this date' ),
				),
			),
			'list' => array(
				'title' => __( 'Events Page', 'mec-utility' ),
				'fields' => array(
					array( 'key' => 'SelectAll', 'label' => 'Select all' ),
					array( 'key' => 'Edit', 'label' => 'Edit' ),
					array( 'key' => 'Attendees', 'label' => 'Attendees' ),
					array( 'key' => 'RSVPs', 'label' => 'RSVPs' ),
					array( 'key' => 'Bookings', 'label' => 'Bookings' ),
					array( 'key' => 'SetFilters', 'label' => 'Set Filters' ),
					array( 'key' => 'AllDates', 'label' => 'All dates' ),
					array( 'key' => 'UpcomingEvents', 'label' => 'Upcoming events' ),
					array( 'key' => 'PastEvents', 'label' => 'Past events' ),
					array( 'key' => 'ShowAllLabels', 'label' => 'Show all labels' ),
					array( 'key' => 'ShowAllLocations', 'label' => 'Show all locations' ),
					array( 'key' => 'StartDate', 'label' => 'Start Date' ),
					array( 'key' => 'ShowAllOrganizers', 'label' => 'Show all organizers' ),
					array( 'key' => 'ShowResults', 'label' => 'Show Results' ),
					array( 'key' => 'Reset', 'label' => 'Reset' ),
					array( 'key' => 'EventsList', 'label' => 'Events List' ),
					array( 'key' => 'MoveToTrash', 'label' => 'Move to Trash' ),
					array( 'key' => 'List', 'label' => 'Events' ),
				),
			),
			'booking' => array(
				'title' => __( 'Booking Page', 'mec-utility' ),
				'fields' => array(
					array( 'key' => 'Payment', 'label' => 'Payment' ),
					array( 'key' => 'Booking', 'label' => 'Booking' ),
					array( 'key' => 'Bookings', 'label' => 'Bookings' ),
					array( 'key' => 'Attendees', 'label' => 'Attendees' ),
					array( 'key' => 'TotalAttendees', 'label' => 'Total Attendees' ),
					array( 'key' => 'Pending', 'label' => 'Pending' ),
					array( 'key' => 'Waiting', 'label' => 'Waiting' ),
					array( 'key' => 'Update', 'label' => 'Update' ),
					array( 'key' => 'Verify', 'label' => 'Verify' ),
					array( 'key' => 'DownloadInvoice', 'label' => 'Download the invoice' ),
					array( 'key' => 'Paid', 'label' => 'Paid' ),
					array( 'key' => 'Confirmation', 'label' => 'Confirmation' ),
					array( 'key' => 'Verified', 'label' => 'Verified' ),
					array( 'key' => 'BookingDetails', 'label' => 'Booking Details' ),
					array( 'key' => 'InvoiceNumber', 'label' => 'Invoice number' ),
					array( 'key' => 'TotalPayment', 'label' => 'Total Payment' ),
					array( 'key' => 'PurchaseTime', 'label' => 'Purchase time' ),
					array( 'key' => 'Price', 'label' => 'Price' ),
					array( 'key' => 'PaidAmount', 'label' => 'Paid Amount' ),
					array( 'key' => 'Gateway', 'label' => 'Gateway' ),
					array( 'key' => 'TransactionID', 'label' => 'Transaction ID' ),
					array( 'key' => 'Name', 'label' => 'Name' ),
					array( 'key' => 'Email', 'label' => 'Email' ),
					array( 'key' => 'Ticket', 'label' => 'Ticket' ),
					array( 'key' => 'Billing', 'label' => 'Billing' ),
					array( 'key' => 'Subtotal', 'label' => 'Subtotal' ),
					array( 'key' => 'Discount', 'label' => 'Discount' ),
					array( 'key' => 'Tax', 'label' => 'Tax' ),
					array( 'key' => 'Total', 'label' => 'Total' ),
				),
			),
			'attendees' => array(
				'title' => __( 'Attendees Page', 'mec-utility' ),
				'fields' => array(
					array( 'key' => 'SearchByName', 'label' => 'Search by name...' ),
				),
			),
			'waiting-list' => array(
				'title' => __( 'Waiting List Page', 'mec-utility' ),
				'fields' => array(
					array( 'key' => 'WaitingList', 'label' => 'Waiting List' ),
					array( 'key' => 'SearchByName', 'label' => 'Search by name...' ),
					array( 'key' => 'WaitingListDate', 'label' => 'Waiting List Date' ),
					array( 'key' => 'Attendees', 'label' => 'Attendees' ),
					array( 'key' => 'Verification', 'label' => 'Verification' ),
					array( 'key' => 'Pending', 'label' => 'Pending' ),
					array( 'key' => 'Verified', 'label' => 'Verified' ),
					array( 'key' => 'Canceled', 'label' => 'Canceled' ),
					array( 'key' => 'Confirmed', 'label' => 'Confirmed' ),
					array( 'key' => 'Reject', 'label' => 'Reject' ),
					array( 'key' => 'WaitingDetail', 'label' => 'Waiting Detail' ),
					array( 'key' => 'Event', 'label' => 'Event' ),
					array( 'key' => 'TotalAttendees', 'label' => 'Total Attendees' ),
					array( 'key' => 'StatusInvoice', 'label' => 'Status & Invoice' ),
					array( 'key' => 'Waiting', 'label' => 'Waiting' ),
					array( 'key' => 'Update', 'label' => 'Update' ),
					array( 'key' => 'MoveToTrash', 'label' => 'Move to Trash' ),
					array( 'key' => 'EditDetails', 'label' => 'Edit Details' ),
					array( 'key' => 'AddAttendees', 'label' => 'Add Attendees' ),
					array( 'key' => 'Date', 'label' => 'Date' ),
					array( 'key' => 'Name', 'label' => 'Name' ),
					array( 'key' => 'Email', 'label' => 'Email' ),
					array( 'key' => 'Ticket', 'label' => 'Ticket' ),
				),
			),
			'settings' => array(
				'title' => __( 'Settings Page', 'mec-utility' ),
				'fields' => array(
					array( 'key' => 'General', 'label' => 'General' ),
					array( 'key' => 'MecSettings', 'label' => 'Mec Settings' ),
					array( 'key' => 'WPDashboard', 'label' => 'WP Dashboard' ),
					array( 'key' => 'ViewSite', 'label' => 'View Site' ),
					array( 'key' => 'ConnectionInfo', 'label' => 'Connection info' ),
					array( 'key' => 'Settings', 'label' => 'Settings' ),
					array( 'key' => 'Sound', 'label' => 'Sound' ),
					array( 'key' => 'Vibration', 'label' => 'Vibration' ),
					array( 'key' => 'WEBSITE', 'label' => 'WEBSITE' ),
					array( 'key' => 'Website', 'label' => 'Website' ),
					array( 'key' => 'API', 'label' => 'API' ),
					array( 'key' => 'Connected', 'label' => 'Connected!' ),
					array( 'key' => 'Logout', 'label' => 'Logout' ),
				),
			),
		);
	}

	/**
	 * Render translation fields for a tab.
	 *
	 * @since 1.0.0
	 *
	 * @param string $group_key            Tab identifier.
	 * @param array  $translations         Current translations.
	 * @param array  $default_translations Default translations.
	 *
	 * @return string|\WP_Error
	 */
	private function render_translation_tab_html( $group_key, $translations, $default_translations ) {
		$groups = $this->get_translation_groups( $default_translations );

		if ( ! isset( $groups[ $group_key ] ) ) {
			return new \WP_Error( 'invalid_tab', __( 'Invalid translation tab requested.', 'mec-utility' ) );
		}

		$fields = $groups[ $group_key ]['fields'];

		ob_start();

		foreach ( $fields as $field ) {
			$key = $field['key'];
			$label = $field['label'];
			$default_value = isset( $default_translations[ $key ] ) ? $default_translations[ $key ] : '';
			$value = isset( $translations[ $key ] ) ? $translations[ $key ] : $default_value;
			?>
			<div class="mec-col-3 mec-utility-translate-item">
				<label class="mec-col-12" for="mec-utility-translate-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
				<input class="mec-col-12" id="mec-utility-translate-<?php echo esc_attr( $key ); ?>" data-key="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>" type="text" name="<?php echo esc_attr( $key ); ?>" />
			</div>
			<?php
		}

		return ob_get_clean();
	}

	/**
	 * Language App page.
	 *
	 * @since    1.0.0
	 */
	public function language_app_page() {
		$context = $this->get_translation_context();
		$enable = $context['enable'];
		$default_translations = $context['defaults'];
		$translations = $context['translations'];

		$translation_groups = $this->get_translation_groups( $default_translations );
		$initial_tab = 'all';
		$initial_tab_markup = $this->render_translation_tab_html( $initial_tab, $translations, $default_translations );

		if ( is_wp_error( $initial_tab_markup ) ) {
			$initial_tab_markup = '<p class="mec-util-error">' . esc_html( $initial_tab_markup->get_error_message() ) . '</p>';
		}

		$ajax_nonce = \wp_create_nonce( 'mec_utility_ajax_nonce' );
		?>
		<div id="mec-utility-wrap" class="mec-utility-wrap">

		<div class="mec-utility-header">
			<h1>
				<?php esc_html_e( 'App Language', 'mec-utility' ); ?>
			</h1>
			<span class="w-theme-version"><?php echo __('Version ', 'mec-utility'); ?><?php echo MEC_UTILITY_VERSION; ?></span>
		</div>

			<div class="mec-invoice-container">
				<div>
					<form id="mec_utility_language_app_form">
						<div class="mec-form-row">
							<label>
								<input value="1" type="checkbox" name="activeLanguageApp" <?php checked( $enable, 1 ); ?> /> <?php \esc_html_e( 'Enable Editing', 'mec-utility' ); ?>
							</label>
						</div>
						<div id="mec_utility_language_app_container_toggle" class="<?php echo $enable == 1 ? '' : 'mec-util-hidden'; ?>">
							<div class="mec-translation-tabs">
								<?php foreach ( $translation_groups as $group_key => $group_config ) : ?>
									<button type="button" class="mec-translation-tab-button <?php echo $group_key === $initial_tab ? 'active' : ''; ?>" data-tab="<?php echo esc_attr( $group_key ); ?>">
										<?php echo esc_html( $group_config['title'] ); ?>
									</button>
								<?php endforeach; ?>
							</div>
							<div id="mec_utility_translation_tab_content" class="mec-form-row">
								<?php echo $initial_tab_markup; ?>
							</div>
							<div class="mec-form-row">
								<div class="mec-col-12">
									<a class="button-translate-save"><?php \esc_html_e( 'Save Translate', 'mec-utility' ); ?></a>
								</div>
							</div>
						</div>
					</form>
				</div>

				<div class="mec-wizard-loading"><div class="mec-loader"></div></div>
			</div>

			<script>
				jQuery( function( $ ) {
					let mecTranslateState = <?php echo wp_json_encode( $translations ); ?>;
					const mecTranslateAjax = {
						url: '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',
						nonce: '<?php echo esc_js( $ajax_nonce ); ?>'
					};
					let mecCurrentTab = '<?php echo esc_js( $initial_tab ); ?>';

					function setActiveTab( tab ) {
						$( '.mec-translation-tab-button' ).removeClass( 'active' );
						$( '.mec-translation-tab-button[data-tab="' + tab + '"]' ).addClass( 'active' );
					}

					function syncCurrentInputsWithState() {
						$( '#mec_utility_translation_tab_content' ).find( 'input[data-key]' ).each( function() {
							const $input = $( this );
							const key = $input.data( 'key' );

							if ( Object.prototype.hasOwnProperty.call( mecTranslateState, key ) ) {
								$input.val( mecTranslateState[key] );
							}
						} );
					}

					function bindTranslationInputs() {
						const $inputs = $( '#mec_utility_translation_tab_content' ).find( 'input[data-key]' );

						$inputs.off( 'input.mecTranslate' ).on( 'input.mecTranslate', function() {
							const key = $( this ).data( 'key' );
							mecTranslateState[key] = $( this ).val();
						} );

						syncCurrentInputsWithState();
					}

					function loadTranslationTab( tab ) {
						if ( tab === mecCurrentTab ) {
							return;
						}

						$.ajax( {
							type: 'POST',
							url: mecTranslateAjax.url,
							dataType: 'json',
							data: {
								action: 'mec_utility_get_translate_tab',
								nonce: mecTranslateAjax.nonce,
								tab: tab
							},
							beforeSend: function () {
								save_loading( true );
							},
							success: function( response ) {
								if ( response.success && response.data && response.data.html ) {
									$( '#mec_utility_translation_tab_content' ).html( response.data.html );
									mecCurrentTab = tab;
									setActiveTab( tab );
									bindTranslationInputs();
								} else {
									const message = response.data && response.data.message ? response.data.message : 'Unable to load translations.';
									window.alert( message );
								}
							},
							error: function() {
								window.alert( 'Error loading translations!' );
							},
							complete: function() {
								save_loading( false );
							}
						} );
					}

					$( '.mec-translation-tab-button' ).on( 'click', function() {
						loadTranslationTab( $( this ).data( 'tab' ) );
					} );

					$( "input[name='activeLanguageApp']" ).on( 'change', function() {
						$( '#mec_utility_language_app_container_toggle' ).toggle( $( this ).is( ':checked' ) );
					} );

					$( '.button-translate-save' ).on( 'click', function() {
						const activeValue = $( "input[name='activeLanguageApp']" ).is( ':checked' ) ? 1 : 0;

						$.ajax( {
							type: 'POST',
							url: mecTranslateAjax.url,
							data: {
								action: 'mec_utility_update_translate_app',
								nonce: mecTranslateAjax.nonce,
								active: activeValue,
								translate_string: JSON.stringify( mecTranslateState )
							},
							dataType: 'json',
							beforeSend: function () {
								save_loading( true );
							},
							success: function( data ) {
								if ( data && data.data && data.data.translate ) {
									mecTranslateState = $.extend( {}, data.data.translate );
									syncCurrentInputsWithState();
								}

								window.alert( 'Translations saved successfully!' );
							},
							error: function() {
								window.alert( 'Error saving translations!' );
							},
							complete: function () {
								save_loading( false );
							}
						} );
					} );

					setActiveTab( mecCurrentTab );
					bindTranslationInputs();
					save_loading( false );
				} );

				function save_loading( value ) {
					if ( value ) {
						jQuery( '.mec-wizard-loading' ).show();
					} else {
						jQuery( '.mec-wizard-loading' ).hide();
					}
				}
			</script>
		</div>
		<?php
	}

	/**
	 * AJAX handler for fetching translation tab content
	 *
	 * @since    1.0.0
	 */
	public function ajax_get_translate_tab() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'mec_utility_ajax_nonce' ) ) {
			wp_die( 'Security check failed' );
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Insufficient permissions' );
		}

		$tab = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'all';

		$context = $this->get_translation_context();
		$default_translations = $context['defaults'];
		$translations = $context['translations'];

		$markup = $this->render_translation_tab_html( $tab, $translations, $default_translations );

		if ( is_wp_error( $markup ) ) {
			wp_send_json_error( array(
				'message' => $markup->get_error_message(),
			), 400 );
		}

		wp_send_json_success( array(
			'html' => $markup,
		) );
	}

	/**
	 * AJAX handler for updating translations
	 *
	 * @since    1.0.0
	 */
	public function ajax_update_translate_app() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'mec_utility_ajax_nonce' ) ) {
			wp_die( 'Security check failed' );
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Insufficient permissions' );
		}

		if ( isset( $_POST['active'], $_POST['translate_string'] ) ) {
			$decoded_translate = json_decode( wp_unslash( $_POST['translate_string'] ), true );

			if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $decoded_translate ) ) {
				wp_send_json_error( array(
					'status' => 0,
					'message' => __( 'Invalid translate payload.', 'mec-utility' ),
				), 400 );
			}

			$translate_controller = new \MecUtility\Controllers\TranslateController();
			$default_translations = $translate_controller->get_default_translations();
			$merged_translations = array_merge( $default_translations, $decoded_translate );
			$enable = intval( $_POST['active'] );

			\update_option( 'mec_utility_translations', \wp_json_encode( array(
				'enable' => $enable,
				'translate' => $merged_translations,
			) ) );

			wp_send_json_success( array(
				'status' => 1,
				'text' => __( 'Updated Translate App.', 'mec-utility' ),
				'data' => array(
					'enable' => $enable,
					'translate' => $merged_translations,
				),
			) );
		}

		wp_send_json_error( array(
			'status' => 0,
			'message' => __( 'Missing required parameters.', 'mec-utility' ),
		), 400 );
	}
}
