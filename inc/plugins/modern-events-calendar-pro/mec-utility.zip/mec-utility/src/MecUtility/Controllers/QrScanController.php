<?php
/**
 * QR Scan Controller
 *
 * @package MecUtility
 * @subpackage Controllers
 * @since 1.0.0
 */

namespace MecUtility\Controllers;

class QrScanController {

    /**
     * Register QR scan routes
     */
    public function register_routes() {
        \register_rest_route('mec-utility/v1', '/qr/scan', array(
            'methods' => 'POST',
            'callback' => array($this, 'scan_qr_code'),
            'permission_callback' => '__return_true'
        ));

        // Register short URL QR scan route
        \register_rest_route('mec-utility/v1', '/qr/scan-short', array(
            'methods' => 'POST',
            'callback' => array($this, 'scan_qr_code'),
            'permission_callback' => '__return_true'
        ));
    }

    /**
     * Extract parameters from short URL or full URL
     */
    private function extract_qr_parameters($url_or_hash)
    {
        $debug_info = [
            'input' => $url_or_hash,
            'has_query' => strpos($url_or_hash, '?') !== false,
            'has_invoice_path' => strpos($url_or_hash, '/invoice/') !== false
        ];

        // If it's already a full URL with parameters, parse it directly
        if (strpos($url_or_hash, '?') !== false) {
            $url_components = parse_url($url_or_hash);
            parse_str($url_components['query'], $params);
            $debug_info['parsed_params'] = $params;
            return ['params' => $params, 'debug_info' => $debug_info];
        }

        // If it's a short hash (like stmz13pWBk0-k), extract the full URL first
        if (strpos($url_or_hash, '/invoice/') !== false) {
            $hash = preg_replace('#(.*?)\/invoice\/#', '', $url_or_hash);
        } else {
            $hash = $url_or_hash;
        }

        $debug_info['extracted_hash'] = $hash;

        // Get the full URL from the short hash
        $full_url = \MEC_Invoice\Helper::getShortLinkDes($hash);
        $debug_info['full_url'] = $full_url;

        if (!$full_url) {
            $debug_info['error'] = 'Failed to resolve short link';
            return false;
        }

        // Parse the full URL to get parameters
        $url_components = parse_url($full_url);
        parse_str($url_components['query'], $params);

        $debug_info['final_params'] = $params;

        // For debugging purposes, let's also check what's in the database
        global $wpdb;
        $short_link_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}mec_short_links WHERE short_link = %s",
            $hash
        ));
        $debug_info['database_record'] = $short_link_data;

        return ['params' => $params, 'debug_info' => $debug_info];
    }

    /**
     * Scan QR code for check-in/check-out
     */
    public function scan_qr_code($request) {
        $data = $request->get_params();

        // Check API key (optional - only if set)
        $api_key = \get_option("mec_utility_api_key");
        if (!empty($api_key)) {
            // Check both header (X-API-Key) and body parameter (key) for backward compatibility
            $provided_key = $request->get_header('X-API-Key') ?? $data['key'] ?? null;
            
            if (empty($provided_key) || $api_key !== $provided_key) {
                return $this->response_api(array(
                    'status' => 404,
                    'status_scan' => -1,
                    'msg' => "Invalid Key.",
                    'data' => null
                ), 404);
            }
        }

        // Handle short URL or QR hash
        $short_url = $data['short_url'] ?? null;
        $qr_hash = $data['qr_hash'] ?? null;

        // Debug information
        $debug_info = [
            'short_url' => $short_url,
            'qr_hash' => $qr_hash,
            'initial_data' => $data
        ];

        if ($short_url || $qr_hash) {
            $extracted_result = $this->extract_qr_parameters($short_url ?: $qr_hash);
            $debug_info['extraction_debug'] = $extracted_result['debug_info'] ?? null;

            if ($extracted_result && isset($extracted_result['params'])) {
                $extracted_params = $extracted_result['params'];
                $debug_info['extracted_params'] = $extracted_params;

                // Directly assign extracted parameters, overriding any existing values
                if (isset($extracted_params['invoiceID'])) {
                    $data['invoice_id'] = (int) $extracted_params['invoiceID'];
                }
                if (isset($extracted_params['checkIn'])) {
                    $data['email'] = \sanitize_email($extracted_params['checkIn']);
                }
                if (isset($extracted_params['place'])) {
                    $data['place'] = (int) $extracted_params['place'];
                }
                if (isset($extracted_params['Hash'])) {
                    $data['Hash'] = $extracted_params['Hash'];
                }
                if (isset($extracted_params['doCheckin'])) {
                    $data['doCheckin'] = $extracted_params['doCheckin'];
                }
                if (isset($extracted_params['makePreview'])) {
                    $data['makePreview'] = $extracted_params['makePreview'];
                }
            } else {
                return $this->response_api(array(
                    'status' => 404,
                    'status_scan' => -1,
                    'msg' => "Invalid short URL or QR hash.",
                    'data' => null,
                    'debug' => $debug_info
                ), 404);
            }
        }

        $debug_info['final_data'] = $data;

        // Check required parameters
        if (!isset($data['book_id']) && !isset($data['invoice_id'])) {
            return $this->response_api(array(
                'status' => 404,
                'status_scan' => -1,
                'msg' => "Missing Parameters.",
                'data' => null
            ), 404);
        }

        $book_id = $data['book_id'] ?? null;
        $invoice_id = $data['invoice_id'] ?? null;

        // If we have invoice_id but no book_id, get book_id from invoice
        if ($invoice_id && !$book_id) {
            $book_id = \get_post_meta($invoice_id, 'book_id', true);
        }

        // Check if booking is verified
        $verified = \get_post_meta($book_id, 'mec_verified', true);
        if ($verified !== '1') {
            return $this->response_api(array(
                'status' => 404,
                'status_scan' => -1,
                'msg' => "Booking Is Not Verified!",
                'data' => null,
                'debug' => $debug_info
            ), 404);
        }

        // --- RE-ORDERED LOGIC ---
        // Handle bulk check-in (doCheckin flow) - This should be checked BEFORE individual parameters
        if (isset($data['doCheckin'])) {
            // Hash validation removed for backward compatibility with mec-invoice
            // Original mec-invoice didn't validate doCheckin hash

            return $this->handle_bulk_scan($book_id, $invoice_id, $debug_info);
        }

        // Handle bulk check-in/out (all_checked === 'all')
        if (isset($data['all_checked']) && $data['all_checked'] == "all") {
            return $this->handle_bulk_scan($book_id, $invoice_id, $debug_info);
        }

        // Individual attendee - Only check this if not doing bulk operations
        if (!isset($data['doCheckin']) && (!isset($data['email']) || !(isset($data['key_checkin']) || isset($data['place'])))) {
            return $this->response_api(array(
                'status' => 404,
                'status_scan' => -1,
                'msg' => "Missing email or place parameter.",
                'data' => null,
                'debug' => $debug_info
            ), 404);
        }

        // Handle single attendee scan
        $key_checkin = $data['key_checkin'] ?? $data['place'] ?? null;
        return $this->handle_single_scan($book_id, $invoice_id, $data['email'], $key_checkin, $debug_info);
    }

    /**
     * Handle bulk check-in/out for all attendees
     */
    private function handle_bulk_scan($book_id, $invoice_id, $debug_info = []) {
        $attendees = \get_post_meta($book_id, 'mec_attendees', true);

        if (!is_array($attendees)) {
            return $this->response_api(array(
                'status' => 404,
                'status_scan' => -1,
                'msg' => "No Attendee Found.",
                'data' => null,
                'debug' => $debug_info
            ), 404);
        }

        $checkin_count = 0;
        $already_checked_count = 0;
        $j = 1;

        foreach ($attendees as $attendee) {
            if (!class_exists('MEC_Invoice\\Attendee')) {
                continue;
            }

            if (!\MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $attendee['email'], $j)) {
                \MEC_Invoice\Attendee::doCheckIn($invoice_id, $attendee['email'], $j, null, true);
                $checkin_count++;
            } else {
                // Do not toggle to checkout. Only allow check-in.
                $already_checked_count++;
            }
            $j++;
        }

        if ($checkin_count > 0) {
            $text = "Check-in Completed";
            $status = 1;
            $status_scan = 1;
        } else {
            $text = "All Already Checked In!";
            $status = 1;
            $status_scan = 1;
        }

        // Get event information for response
        $event_id = \get_post_meta($book_id, 'mec_event_id', true);
        $event_title = \get_the_title($event_id);
        $event_start_date = \get_post_meta($event_id, 'mec_start_date', true);
        $event_end_date = \get_post_meta($event_id, 'mec_end_date', true);

        // Calculate attendee statistics
        $total_event_attendees = count($attendees);
        $checked_in_event_attendees = 0;
        foreach ($attendees as $key => $attendee) {
            $place_number = $key + 1;
            if (\MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $attendee['email'], $place_number)) {
                $checked_in_event_attendees++;
            }
        }

        // Get total attendees across all events for this specific event
        $total_all_events_attendees = 0;
        $all_events = \get_posts([
            'post_type' => 'mec_events',
            'numberposts' => -1,
            'post_status' => 'publish'
        ]);

        foreach ($all_events as $event) {
            $event_bookings = \get_posts([
                'post_type' => 'mec_bookings',
                'numberposts' => -1,
                'post_status' => 'publish',
                'meta_query' => [
                    [
                        'key' => 'mec_event_id',
                        'value' => $event->ID,
                        'compare' => '='
                    ]
                ]
            ]);

            foreach ($event_bookings as $booking) {
                $booking_attendees = \get_post_meta($booking->ID, 'mec_attendees', true);
                if (is_array($booking_attendees)) {
                    $total_all_events_attendees += count($booking_attendees);
                }
            }
        }

        return $this->response_api(array(
            'status' => 200,
            'status_scan' => $status_scan,
            'msg' => $text,
            'data' => array(
                'status' => $status,
                'checkin_count' => $checkin_count,
                'already_checked_count' => $already_checked_count,
                'event_info' => array(
                    'id' => $event_id,
                    'title' => $event_title,
                    'start_date' => $event_start_date,
                    'end_date' => $event_end_date,
                ),
                'attendee_stats' => array(
                    'total_event_attendees' => $total_event_attendees,
                    'checked_in_event_attendees' => $checked_in_event_attendees,
                    'unchecked_event_attendees' => $total_event_attendees - $checked_in_event_attendees,
                    'total_all_events_attendees' => $total_all_events_attendees,
                ),
            ),
            'debug' => $debug_info
        ), 200);
    }

    /**
     * Handle single attendee scan
     */
    private function handle_single_scan($book_id, $invoice_id, $email, $key_checkin, $debug_info = []) {
        if (!class_exists('MEC_Invoice\\Attendee')) {
            return $this->response_api(array(
                'status' => 503,
                'status_scan' => -1,
                'msg' => "MEC Invoice plugin not available.",
                'data' => null
            ), 503);
        }

        $is_checked_in = \MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $email, $key_checkin);

        if (!$is_checked_in) {
            \MEC_Invoice\Attendee::doCheckIn($invoice_id, $email, $key_checkin, null, true);
            $text = "Checked In";
            $status = 1;
            $status_scan = 1;
        } else {
            // Do not toggle to checkout. Only allow check-in.
            $text = "Already Checked!";
            $status = 1;
            $status_scan = 1;
        }

        // Get event information for response
        $event_id = \get_post_meta($book_id, 'mec_event_id', true);
        $event_title = \get_the_title($event_id);
        $event_start_date = \get_post_meta($event_id, 'mec_start_date', true);
        $event_end_date = \get_post_meta($event_id, 'mec_end_date', true);

        // Get all attendees for statistics
        $attendees = \get_post_meta($book_id, 'mec_attendees', true);
        $total_event_attendees = count($attendees);
        $checked_in_event_attendees = 0;
        foreach ($attendees as $key => $attendee) {
            $place_number = $key + 1;
            if (\MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $attendee['email'], $place_number)) {
                $checked_in_event_attendees++;
            }
        }

        // Get total attendees across all events for this specific event
        $total_all_events_attendees = 0;
        $all_events = \get_posts([
            'post_type' => 'mec_events',
            'numberposts' => -1,
            'post_status' => 'publish'
        ]);

        foreach ($all_events as $event) {
            $event_bookings = \get_posts([
                'post_type' => 'mec_bookings',
                'numberposts' => -1,
                'post_status' => 'publish',
                'meta_query' => [
                    [
                        'key' => 'mec_event_id',
                        'value' => $event->ID,
                        'compare' => '='
                    ]
                ]
            ]);

            foreach ($event_bookings as $booking) {
                $booking_attendees = \get_post_meta($booking->ID, 'mec_attendees', true);
                if (is_array($booking_attendees)) {
                    $total_all_events_attendees += count($booking_attendees);
                }
            }
        }

        return $this->response_api(array(
            'status' => 200,
            'status_scan' => $status_scan,
            'msg' => $text,
            'data' => array(
                'status' => $status,
                'book_id' => $book_id,
                'invoice_id' => $invoice_id,
                'email' => $email,
                'key_checkin' => $key_checkin,
                'timestamp' => \current_time('mysql'),
                'event_info' => array(
                    'id' => $event_id,
                    'title' => $event_title,
                    'start_date' => $event_start_date,
                    'end_date' => $event_end_date,
                ),
                'attendee_stats' => array(
                    'total_event_attendees' => $total_event_attendees,
                    'checked_in_event_attendees' => $checked_in_event_attendees,
                    'unchecked_event_attendees' => $total_event_attendees - $checked_in_event_attendees,
                    'total_all_events_attendees' => $total_all_events_attendees,
                ),
            ),
            'debug' => $debug_info
        ), 200);
    }

    /**
     * API response helper
     */
    private function response_api($data, $status) {
        $response = new \WP_REST_Response($data);
        $response->set_status($status);
        return $response;
    }
}
