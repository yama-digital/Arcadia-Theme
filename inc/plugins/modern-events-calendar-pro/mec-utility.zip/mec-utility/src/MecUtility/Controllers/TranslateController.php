<?php
/**
 * Translate Controller
 *
 * @package MecUtility
 * @subpackage Controllers
 * @since 1.0.0
 */

namespace MecUtility\Controllers;

class TranslateController {

    /**
     * Register translate routes
     */
    public function register_routes() {
        \register_rest_route('mec-utility/v1', '/translate', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_translations'),
            'permission_callback' => '__return_true'
        ));

        \register_rest_route('mec-utility/v1', '/translate/update', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_translations'),
            'permission_callback' => '__return_true'
        ));
    }

    /**
     * Get translations for mobile app
     */
    public function get_translations($request) {
        $data = $request->get_params();

        // Check API key (optional)
        $api_key = \get_option("mec_utility_api_key");
        if (!empty($api_key)) {
            if (!isset($data['key']) || $api_key !== $data['key']) {
                return $this->response_api(array(
                    'status' => 404,
                    'msg' => "Invalid Key.",
                    'data' => null
                ), 404);
            }
        }

        // Get stored translations
        $stored_translations = \get_option('mec_utility_translations', null);
        $default_translations = $this->get_default_translations();

        if ( ! empty( $stored_translations ) ) {
            $decoded = \json_decode( $stored_translations );

            if ( $decoded instanceof \stdClass ) {
                $saved_translations = isset( $decoded->translate )
                    ? (array) $decoded->translate
                    : array();

                $decoded->translate = (object) array_merge( $default_translations, $saved_translations );
                $decoded->enable = isset( $decoded->enable ) ? $decoded->enable : 0;
                $translations = $decoded;
            } else {
                $translations = (object) array(
                    'enable' => 0,
                    'translate' => (object) $default_translations
                );
            }
        } else {
            $translations = (object) array(
                'enable' => 0,
                'translate' => (object) $default_translations
            );
        }

        return $this->response_api(array(
            'status' => 200,
            'msg' => "Translations retrieved successfully",
            'data' => $translations
        ), 200);
    }

    /**
     * Update translations
     */
    public function update_translations($request) {
        $data = $request->get_params();

        // Check API key (optional)
        $api_key = \get_option("mec_utility_api_key");
        if (!empty($api_key)) {
            if (!isset($data['key']) || $api_key !== $data['key']) {
                return $this->response_api(array(
                    'status' => 404,
                    'msg' => "Invalid Key.",
                    'data' => null
                ), 404);
            }
        }

        // Update translations
        if (isset($data['active']) && isset($data['translate_string'])) {
            $decoded_translate = \json_decode( \stripslashes( $data['translate_string'] ), true );

            if ( \json_last_error() !== JSON_ERROR_NONE || ! is_array( $decoded_translate ) ) {
                return $this->response_api(array(
                    'status' => 400,
                    'msg' => "Invalid translate payload",
                    'data' => null
                ), 400);
            }

            $default_translations = $this->get_default_translations();
            $merged_translations  = array_merge( $default_translations, $decoded_translate );

            $payload = array(
                'enable' => intval( $data['active'] ),
                'translate' => $merged_translations
            );

            \update_option( 'mec_utility_translations', \wp_json_encode( $payload ) );

            $response_payload = (object) array(
                'enable' => $payload['enable'],
                'translate' => (object) $merged_translations
            );

            return $this->response_api(array(
                'status' => 200,
                'msg' => "Translations updated successfully",
                'data' => $response_payload
            ), 200);
        }

        return $this->response_api(array(
            'status' => 400,
            'msg' => "Missing required parameters",
            'data' => null
        ), 400);
    }

    /**
     * Get default translation strings
     */
    public function get_default_translations() {
        return array(
            'Calendar' => 'Calendar',
            'SelectDate' => 'Pick Date',
            'SelectMonth' => 'Select Month',
            'SelectYears' => 'Select Years',
            'ShowAttendees' => 'Show Attendees',
            'peopleAreAttendees' => 'people are attendees',
            'Today' => 'Today',
            'AllEvents' => 'All Events',
            'Events' => 'Events',
            'Settings' => 'Settings',
            'System' => 'System',
            'Sound' => 'Sound',
            'Vibration' => 'Vibration',
            'Connected' => 'Connected!',
            'Logout' => 'Logout',
            'StartScanning' => 'Start Scanning',
            'CheckedinAttendees' => 'Checked-in',
            'TotalAttendees' => 'Total Attendees',
            'AllAttendees' => 'All',
            'DisplayJustCheckin' => 'Checked-In',
            'NoEventsFound' => 'No events found for this date',
            'SelectAll' => 'Select all',
            'Edit' => 'Edit',
            'Attendees' => 'Attendees',
            'RSVPs' => 'RSVPs',
            'Bookings' => 'Bookings',
            'SetFilters' => 'Set Filters',
            'AllDates' => 'All dates',
            'UpcomingEvents' => 'Upcoming events',
            'PastEvents' => 'Past events',
            'ShowAllLabels' => 'Show all labels',
            'ShowAllLocations' => 'Show all locations',
            'StartDate' => 'Start Date',
            'ShowAllOrganizers' => 'Show all organizers',
            'ShowResults' => 'Show Results',
            'Reset' => 'Reset',
            'EventsList' => 'Events List',
            'MoveToTrash' => 'Move to Trash',
            'Payment' => 'Payment',
            'Booking' => 'Booking',
            'Pending' => 'Pending',
            'Update' => 'Update',
            'Verify' => 'Verify',
            'DownloadInvoice' => 'Download the invoice',
            'Paid' => 'Paid',
            'Confirmation' => 'Confirmation',
            'Verified' => 'Verified',
            'Waiting' => 'Waiting',
            'BookingDetails' => 'Booking Details',
            'InvoiceNumber' => 'Invoice number',
            'TotalPayment' => 'Total Payment',
            'PurchaseTime' => 'Purchase time',
            'Price' => 'Price',
            'PaidAmount' => 'Paid Amount',
            'Gateway' => 'Gateway',
            'TransactionID' => 'Transaction ID',
            'Name' => 'Name',
            'Email' => 'Email',
            'Ticket' => 'Ticket',
            'Billing' => 'Billing',
            'Subtotal' => 'Subtotal',
            'Discount' => 'Discount',
            'Tax' => 'Tax',
            'Total' => 'Total',
            'SearchByName' => 'Search by name...',
            'General' => 'General',
            'MecSettings' => 'Mec Settings',
            'WPDashboard' => 'WP Dashboard',
            'ViewSite' => 'View Site',
            'ConnectionInfo' => 'Connection info',
            'Website' => 'Website',
            'WEBSITE' => 'WEBSITE',
            'API' => 'API',
            'WaitingList' => 'Waiting List',
            'WaitingListDate' => 'Waiting List Date',
            'Verification' => 'Verification',
            'Canceled' => 'Canceled',
            'Confirmed' => 'Confirmed',
            'Reject' => 'Reject',
            'WaitingDetail' => 'Waiting Detail',
            'Event' => 'Event',
            'StatusInvoice' => 'Status & Invoice',
            'EditDetails' => 'Edit Details',
            'AddAttendees' => 'Add Attendees',
            'Date' => 'Date'
        );
    }

    /**
     * API Response Helper
     */
    private function response_api($data, $status) {
        return new \WP_REST_Response($data, $status);
    }
}
