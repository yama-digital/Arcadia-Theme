<?php
/**
 * QR Generate Controller
 *
 * @package MecUtility
 * @subpackage Controllers
 * @since 1.0.0
 */

namespace MecUtility\Controllers;

class QrGenerateController {

    /**
     * Register QR generate routes
     */
    public function register_routes() {
        register_rest_route('mec-utility/v1', '/qr/generate', array(
            'methods' => 'POST',
            'callback' => array($this, 'generate_qr_code'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route('mec-utility/v1', '/qr/generate-bulk', array(
            'methods' => 'POST',
            'callback' => array($this, 'generate_bulk_qr'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route('mec-utility/v1', '/qr/image', array(
            'methods' => 'GET',
            'callback' => array($this, 'generate_qr_image'),
            'permission_callback' => '__return_true'
        ));
    }

    /**
     * Generate QR code for single attendee
     */
    public function generate_qr_code($request) {
        $data = $request->get_params();

        // Check API key (optional - only if set)
        $api_key = get_option("mec_utility_api_key");
        if (!empty($api_key)) {
            if (!isset($data['key']) || $api_key !== $data['key']) {
                return $this->response_api(array(
                    'status' => 404,
                    'msg' => "Invalid Key.",
                    'data' => null
                ), 404);
            }
        }

        // Validate required parameters
        if (empty($data['book_id'])) {
            return $this->response_api(array(
                'status' => 400,
                'msg' => "book_id is required",
                'data' => null
            ), 400);
        }

        try {
            // Find invoice
            $invoices = get_posts(array(
                'post_type' => 'mec_invoice',
                'meta_query' => array(
                    array(
                        'key' => 'book_id',
                        'value' => $data['book_id'],
                        'compare' => '='
                    )
                ),
                'posts_per_page' => 1
            ));

            if (empty($invoices)) {
                return $this->response_api(array(
                    'status' => 404,
                    'msg' => "Invoice not found",
                    'data' => null
                ), 404);
            }

            $invoice = $invoices[0];
            $invoice_id = $invoice->ID;
            $hash = get_post_meta($invoice_id, 'invoiceID', true);

            // Generate QR data
            if (isset($data['email']) && isset($data['attendee_key'])) {
                // Individual attendee QR
                $attendee_data = array(
                    'email' => $data['email'],
                    'attendee_key' => $data['attendee_key']
                );
                $qr_url = $this->get_qr_url($invoice_id, $hash, $attendee_data);
            } else {
                // General invoice QR
                $qr_url = $this->get_qr_url($invoice_id, $hash);
            }

            // Generate QR image URL
            $qr_image_url = get_site_url(null, 'wp-json/mec-utility/v1/qr/image?invoice_id=' . $invoice_id);
            if (isset($data['email']) && isset($data['attendee_key'])) {
                $place = $data['attendee_key'] + 1;
                $qr_image_url .= '&email=' . urlencode($data['email']) . '&place=' . $place;
            }

            return $this->response_api(array(
                'status' => 200,
                'msg' => "QR code generated successfully",
                'data' => array(
                    'qr_url' => $qr_url,
                    'qr_image_url' => $qr_image_url,
                    'invoice_id' => $invoice_id,
                    'book_id' => $data['book_id'],
                    'hash' => $hash
                )
            ), 200);

        } catch (Exception $e) {
            return $this->response_api(array(
                'status' => 500,
                'msg' => "Error generating QR code: " . $e->getMessage(),
                'data' => null
            ), 500);
        }
    }

    /**
     * Generate QR codes for all attendees in bulk
     */
    public function generate_bulk_qr($request) {
        $data = $request->get_params();

        // Check API key (optional)
        $api_key = get_option("mec_utility_api_key");
        if (!empty($api_key)) {
            if (!isset($data['key']) || $api_key !== $data['key']) {
                return $this->response_api(array(
                    'status' => 404,
                    'msg' => "Invalid Key.",
                    'data' => null
                ), 404);
            }
        }

        // Validate required parameters
        if (empty($data['book_id'])) {
            return $this->response_api(array(
                'status' => 400,
                'msg' => "book_id is required",
                'data' => null
            ), 400);
        }

        try {
            // Find invoice
            $invoices = get_posts(array(
                'post_type' => 'mec_invoice',
                'meta_query' => array(
                    array(
                        'key' => 'book_id',
                        'value' => $data['book_id'],
                        'compare' => '='
                    )
                ),
                'posts_per_page' => 1
            ));

            if (empty($invoices)) {
                return $this->response_api(array(
                    'status' => 404,
                    'msg' => "Invoice not found",
                    'data' => null
                ), 404);
            }

            $invoice = $invoices[0];
            $invoice_id = $invoice->ID;
            $hash = get_post_meta($invoice_id, 'invoiceID', true);

            // Get attendees
            $attendees = get_post_meta($data['book_id'], 'mec_attendees', true);
            if (empty($attendees)) {
                return $this->response_api(array(
                    'status' => 404,
                    'msg' => "No attendee found",
                    'data' => null
                ), 404);
            }

            $qr_codes = array();
            foreach ($attendees as $key => $attendee) {
                $attendee_data = array(
                    'email' => $attendee['email'],
                    'attendee_key' => $key
                );
                $qr_url = $this->get_qr_url($invoice_id, $hash, $attendee_data);

                $qr_codes[] = array(
                    'attendee_key' => $key,
                    'email' => $attendee['email'],
                    'name' => $attendee['name'] ?? '',
                    'qr_url' => $qr_url
                );
            }

            return $this->response_api(array(
                'status' => 200,
                'msg' => "Bulk QR codes generated successfully",
                'data' => array(
                    'invoice_id' => $invoice_id,
                    'book_id' => $data['book_id'],
                    'total_attendees' => count($qr_codes),
                    'qr_codes' => $qr_codes
                )
            ), 200);

        } catch (Exception $e) {
            return $this->response_api(array(
                'status' => 500,
                'msg' => "Error generating bulk QR codes: " . $e->getMessage(),
                'data' => null
            ), 500);
        }
    }

    /**
     * Generate QR URL based on MEC Invoice structure
     */
    private function get_qr_url($invoice_id, $hash, $attendee = null) {
        if ($attendee) {
            $email = $attendee['email'];
            $attendee_key = $attendee['attendee_key'];
            $place = $attendee_key + 1;

            return get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $hash . '&attendee=' . $email . '&place=' . $place . '&Hash=' . $hash);
        } else {
            return get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $hash);
        }
    }

    /**
     * Generate QR image directly (like MEC Invoice)
     */
    public function generate_qr_image($request) {
        $data = $request->get_params();

        // Check API key (optional)
        $api_key = get_option("mec_utility_api_key");
        if (!empty($api_key)) {
            if (!isset($data['key']) || $api_key !== $data['key']) {
                http_response_code(404);
                header('Content-Type: application/json');
                echo json_encode(array('error' => 'Invalid Key'));
                exit();
            }
        }

        // Validate required parameters
        if (empty($data['invoice_id'])) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'invoice_id is required'));
            exit();
        }

        try {
            // Get invoice data
            $invoice_id = $data['invoice_id'];
            $invoice = get_post($invoice_id);

            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                http_response_code(404);
                header('Content-Type: application/json');
                echo json_encode(array('error' => 'Invoice not found'));
                exit();
            }

            $hash = get_post_meta($invoice_id, 'invoiceID', true);

            // Generate QR URL
            if (isset($data['email']) && isset($data['place'])) {
                // Individual attendee QR
                $qr_url = get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $hash . '&attendee=' . $data['email'] . '&place=' . $data['place'] . '&Hash=' . $hash);
            } else {
                // General invoice QR
                $qr_url = get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $hash);
            }

            // Use MEC Invoice phpqrcode library
            $phpqrcode_path = WP_PLUGIN_DIR . '/mec-invoice/libraries/phpqrcode/qrlib.php';
            if (file_exists($phpqrcode_path)) {
                include_once($phpqrcode_path);

                // Generate QR code image directly (like MEC Invoice)
                ob_get_clean();
                header('Expires: 0');
                header('Content-Type: image/png');
                header("Content-Disposition: inline; filename=\"{$invoice_id}-qrcode.png\"");

                \QRcode::png($qr_url);
                exit();
            } else {
                http_response_code(500);
                header('Content-Type: application/json');
                echo json_encode(array('error' => 'QR code library not found'));
                exit();
            }

        } catch (Exception $e) {
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Error generating QR image: ' . $e->getMessage()));
            exit();
        }
    }

    /**
     * API Response Helper
     */
    private function response_api($data, $status) {
        return new \WP_REST_Response($data, $status);
    }
}
