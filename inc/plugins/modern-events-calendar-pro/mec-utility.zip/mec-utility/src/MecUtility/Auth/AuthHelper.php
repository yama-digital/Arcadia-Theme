<?php

/**
 * Authentication and Authorization Helper
 *
 * @package    MecUtility
 * @subpackage MecUtility/Auth
 * @since      1.0.0
 */

namespace MecUtility\Auth;

/**
 * AuthHelper class for handling API authentication and authorization
 */
class AuthHelper
{
    /**
     * Available permissions for API access
     */
    const PERMISSIONS = [
        // Event Management
        'read_events'        => 'Read Events',
        'create_events'      => 'Create Events', 
        'update_events'      => 'Update Events',
        'delete_events'      => 'Delete Events',
        'publish_events'     => 'Publish Events',
        
        // Booking Management
        'read_bookings'      => 'Read Bookings',
        'manage_bookings'    => 'Manage Bookings',
        'create_bookings'    => 'Create Bookings',
        'update_bookings'    => 'Update Bookings',
        'delete_bookings'    => 'Delete Bookings',
        'confirm_bookings'   => 'Confirm Bookings',
        
        // Attendee Management
        'read_attendees'     => 'Read Attendees',
        'manage_attendees'   => 'Manage Attendees',
        'checkin_attendees'  => 'Check-in Attendees',
        'export_attendees'   => 'Export Attendees',
        
        // Booking Form Management
        'read_booking_fields'    => 'Read Booking Form Fields',
        'create_booking_fields'  => 'Create Booking Form Fields',
        'update_booking_fields'  => 'Update Booking Form Fields',
        'delete_booking_fields'  => 'Delete Booking Form Fields',
        'manage_booking_fields'  => 'Manage Booking Form Fields',
        
        // RSVP Management
        'read_rsvp'              => 'Read RSVP',
        'create_rsvp'            => 'Create RSVP',
        'update_rsvp'            => 'Update RSVP',
        'delete_rsvp'            => 'Delete RSVP',
        'manage_rsvp'            => 'Manage RSVP',
        'confirm_rsvp'           => 'Confirm RSVP',
        'verify_rsvp'            => 'Verify RSVP',
        'export_rsvp'            => 'Export RSVP',
        'bulk_rsvp'              => 'Bulk RSVP Operations',
        'mec_rsvp'               => 'MEC RSVP Management',
        
        // Waiting List Management
        'read_waiting_list'      => 'Read Waiting List',
        'create_waiting_list'    => 'Create Waiting List',
        'update_waiting_list'    => 'Update Waiting List',
        'delete_waiting_list'    => 'Delete Waiting List',
        'manage_waiting_list'    => 'Manage Waiting List',
        'confirm_waiting_list'   => 'Confirm Waiting List',
        'verify_waiting_list'    => 'Verify Waiting List',
        'export_waiting_list'    => 'Export Waiting List',
        'bulk_waiting_list'      => 'Bulk Waiting List Operations',
        
        // Invoice Management
        'read_invoices'          => 'Read Invoices',
        'manage_invoices'        => 'Manage Invoices',
        'view_invoice_pdf'       => 'View Invoice PDF',
        'invoice_qr_codes'       => 'Invoice QR Codes',
        
        // QR Code & Check-in
        'generate_qr'        => 'Generate QR Codes',
        'scan_qr'            => 'Scan QR Codes',
        'bulk_checkin'       => 'Bulk Check-in',
        
        // Reports & Analytics
        'view_reports'       => 'View Reports',
        'view_stats'         => 'View Statistics',
        'export_reports'     => 'Export Reports',
        
        // System & Configuration
        'manage_settings'    => 'Manage Settings',
        'manage_translations' => 'Manage Translations',
        'view_logs'          => 'View Logs'
    ];

    /**
     * Verify API authentication
     *
     * @param WP_REST_Request $request The REST request
     * @return array|WP_Error User data on success, WP_Error on failure
     */
    public static function verify_authentication(\WP_REST_Request $request)
    {
        global $wpdb;

        // Get API key from request
        $api_key = self::get_api_key_from_request($request);
        
        if (\is_wp_error($api_key)) {
            return $api_key;
        }

        // Verify API key
        $api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
        $api_key_data = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$api_keys_table} WHERE api_key = %s AND is_active = 1",
                $api_key
            )
        );

        if (!$api_key_data) {
            self::log_authentication_attempt($request, $api_key, false);
            return new \WP_Error(
                'invalid_api_key',
                \__('Invalid or inactive API key.', 'mec-utility'),
                array('status' => 401)
            );
        }

        // Update last access time
        $wpdb->update(
            $api_keys_table,
            array('last_access' => \current_time('mysql')),
            array('id' => $api_key_data->id),
            array('%s'),
            array('%d')
        );

        // Get user permissions
        $permissions = json_decode($api_key_data->permissions, true) ?: array();
        
        self::log_authentication_attempt($request, $api_key, true, $api_key_data->user_id);

        return array(
            'api_key_id'  => $api_key_data->id,
            'user_id'     => $api_key_data->user_id,
            'name'        => $api_key_data->name,
            'permissions' => $permissions,
            'api_key_data' => $api_key_data
        );
    }

    /**
     * Check if user has specific permission
     *
     * @param array $user_data User data from verify_authentication
     * @param string $permission Required permission
     * @return bool|WP_Error True if has permission, WP_Error if not
     */
    public static function check_permission($user_data, $permission)
    {
        if (!isset($user_data['permissions']) || !is_array($user_data['permissions'])) {
            return new \WP_Error(
                'no_permissions',
                \__('No permissions defined for this API key.', 'mec-utility'),
                array('status' => 403)
            );
        }

        // Check for exact permission match
        if (in_array($permission, $user_data['permissions'])) {
            return true;
        }

        // Check for broader permissions
        $permission_mappings = [
            'manage_rsvp' => ['read_rsvp', 'create_rsvp', 'update_rsvp', 'delete_rsvp', 'confirm_rsvp', 'verify_rsvp', 'export_rsvp', 'bulk_rsvp'],
            'read_rsvp' => ['read_rsvp'],
            'mec_rsvp' => ['read_rsvp', 'create_rsvp', 'update_rsvp', 'delete_rsvp', 'confirm_rsvp', 'verify_rsvp', 'export_rsvp', 'bulk_rsvp'],
            'manage_waiting_list' => ['read_waiting_list', 'create_waiting_list', 'update_waiting_list', 'delete_waiting_list', 'confirm_waiting_list', 'verify_waiting_list', 'export_waiting_list', 'bulk_waiting_list'],
            'read_waiting_list' => ['read_waiting_list'],
            'manage_invoices' => ['read_invoices', 'view_invoice_pdf', 'invoice_qr_codes'],
            'manage_bookings' => ['read_bookings', 'create_bookings', 'update_bookings', 'delete_bookings', 'confirm_bookings'],
            'read_bookings' => ['read_bookings'],
            'generate_qr' => ['invoice_qr_codes'],
        ];
        
        foreach ($permission_mappings as $broad_perm => $specific_perms) {
            if (in_array($permission, $specific_perms) && in_array($broad_perm, $user_data['permissions'])) {
                return true;
            }
        }

        // Backward compatibility: map old permissions to new ones
        $old_permission_mappings = self::get_permission_mappings();
        
        foreach ($old_permission_mappings as $old_perm => $new_perms) {
            if (in_array($permission, $new_perms) && in_array($old_perm, $user_data['permissions'])) {
                return true;
            }
        }

        return new \WP_Error(
            'insufficient_permissions',
            sprintf(
                \__('Permission "%s" is required for this action.', 'mec-utility'),
                $permission
            ),
            array('status' => 403)
        );
    }

    /**
     * Combined authentication and permission check
     *
     * @param WP_REST_Request $request The REST request
     * @param string $required_permission Required permission
     * @return array|WP_Error User data on success, WP_Error on failure
     */
    public static function verify_with_permission(\WP_REST_Request $request, $required_permission)
    {
        // First verify authentication
        $user_data = self::verify_authentication($request);
        
        if (\is_wp_error($user_data)) {
            return $user_data;
        }

        // Then check permission
        $permission_check = self::check_permission($user_data, $required_permission);
        
        if (\is_wp_error($permission_check)) {
            return $permission_check;
        }

        return $user_data;
    }

    /**
     * Get API key from request headers
     *
     * @param WP_REST_Request $request The REST request
     * @return string|WP_Error API key or WP_Error
     */
    private static function get_api_key_from_request(\WP_REST_Request $request)
    {
        // First try Authorization header
        $authorization = $request->get_header('Authorization');
        if ($authorization && strpos($authorization, 'Bearer ') === 0) {
            $api_key = substr($authorization, 7);
            return \sanitize_text_field($api_key);
        }

        // Try X-API-Key header
        $api_key = $request->get_header('X-API-Key');
        if ($api_key) {
            return \sanitize_text_field($api_key);
        }

        // Try request parameters (less secure, for development)
        $api_key = $request->get_param('api_key');
        if ($api_key) {
            return \sanitize_text_field($api_key);
        }

        return new \WP_Error(
            'missing_api_key',
            \__('API key is required. Send via Authorization header (Bearer token), X-API-Key header, or as api_key parameter.', 'mec-utility'),
            array('status' => 401)
        );
    }

    /**
     * Log authentication attempt
     *
     * @param WP_REST_Request $request The request object
     * @param string $api_key The API key used
     * @param bool $success Whether authentication succeeded
     * @param int|null $user_id User ID if successful
     */
    private static function log_authentication_attempt(\WP_REST_Request $request, $api_key, $success, $user_id = null)
    {
        global $wpdb;

        $activity_logs_table = $wpdb->prefix . 'mec_utility_activity_logs';

        $log_data = array(
            'user_id'       => $user_id,
            'action'        => $success ? 'api_auth_success' : 'api_auth_failed',
            'object_type'   => 'authentication',
            'ip_address'    => self::get_client_ip($request),
            'user_agent'    => $request->get_header('User-Agent'),
            'request_data'  => \wp_json_encode(array(
                'api_key_preview' => substr($api_key, 0, 10) . '...',
                'route' => $request->get_route(),
                'method' => $request->get_method(),
            )),
            'status'        => $success ? 'success' : 'failed',
            'created_at'    => \current_time('mysql'),
        );

        $wpdb->insert($activity_logs_table, $log_data);
    }

    /**
     * Get client IP address
     *
     * @param WP_REST_Request $request The request object
     * @return string
     */
    private static function get_client_ip(\WP_REST_Request $request)
    {
        $ip_headers = array(
            'HTTP_CF_CONNECTING_IP',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        );

        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim($ips[0]);

                if (\filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }

        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    /**
     * Create permission callback for specific permission
     *
     * @param string $permission Required permission
     * @return callable Permission callback function
     */
    public static function permission_callback($permission)
    {
        return function(\WP_REST_Request $request) use ($permission) {
            $result = self::verify_with_permission($request, $permission);
            return !\is_wp_error($result);
        };
    }

    /**
     * Get all available permissions
     *
     * @return array
     */
    public static function get_available_permissions()
    {
        return self::PERMISSIONS;
    }

    /**
     * Get permission mappings for backward compatibility
     * Maps old permissions to new permissions
     *
     * @return array
     */
    private static function get_permission_mappings()
    {
        return [
            // Old booking permission maps to all new booking permissions
            'manage_bookings' => [
                'read_bookings',
                'create_bookings', 
                'update_bookings',
                'delete_bookings',
                'confirm_bookings',
                'manage_bookings'
            ],
            
            // Old booking form management (backward compatibility)
            'manage_booking_fields' => [
                'read_booking_fields',
                'create_booking_fields',
                'update_booking_fields',
                'delete_booking_fields',
                'manage_booking_fields'
            ],
            
            // Old event permissions (if any existed)
            'read_events' => ['read_events'],
            'create_events' => ['create_events'],
            'update_events' => ['update_events'],
            'delete_events' => ['delete_events'],
            
            // Map any old "admin" or "all" permissions to new ones
            'all_permissions' => array_keys(self::PERMISSIONS),
            'admin_access' => array_keys(self::PERMISSIONS),
        ];
    }
} 