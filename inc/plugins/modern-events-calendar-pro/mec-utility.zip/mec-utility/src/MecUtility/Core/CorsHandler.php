<?php

namespace MecUtility\Core;

/**
 * CORS Handler for Mobile Apps and Web Applications
 *
 * This class handles Cross-Origin Resource Sharing (CORS) headers
 * to ensure compatibility with mobile apps and web applications.
 */
class CorsHandler
{
    /**
     * Initialize CORS handling
     */
    public static function init()
    {
        // Add CORS headers for all requests
        \add_action('init', [self::class, 'handleCors'], 1);

        // Handle preflight OPTIONS requests
        \add_action('init', [self::class, 'handlePreflight'], 1);
    }

    /**
     * Handle CORS headers
     */
    public static function handleCors()
    {
        // Get allowed origins from settings or use wildcard for development
        $allowed_origins = self::getAllowedOrigins();

        // Get the origin from the request
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

        // Check if origin is allowed or use wildcard for mobile apps
        if (empty($allowed_origins) || in_array('*', $allowed_origins) || in_array($origin, $allowed_origins)) {
            // Set CORS headers
            header('Access-Control-Allow-Origin: ' . ($origin ?: '*'));
            header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, PATCH');
            header('Access-Control-Allow-Headers: X-API-Key, X-API-Secret, Content-Type, Authorization, Accept, Origin, X-Requested-With, Cache-Control, Pragma, User-Agent, X-Website-URL, api_key, website_url');
            header('Access-Control-Allow-Credentials: true');
            header('Access-Control-Expose-Headers: Content-Length, Content-Range, X-Total-Count');
            header('Access-Control-Max-Age: 86400');

            // Additional iOS-specific headers
            header('Vary: Origin, Access-Control-Request-Method, Access-Control-Request-Headers');

            // Prevent caching issues on iOS
            if (self::isMobileApp() || strpos($_SERVER['HTTP_USER_AGENT'] ?? '', 'MEC-Events-App') !== false) {
                header('Cache-Control: no-cache, no-store, must-revalidate, private');
                header('Pragma: no-cache');
                header('Expires: 0');
            }
        }
    }

    /**
     * Handle preflight OPTIONS requests
     */
    public static function handlePreflight()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            // Set CORS headers for preflight
            self::handleCors();

            // Set additional headers for preflight
            if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
                header('Access-Control-Allow-Methods: ' . $_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']);
            }

            if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
                header('Access-Control-Allow-Headers: ' . $_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']);
            }

            // Return 200 OK for preflight requests
            http_response_code(200);
            exit;
        }
    }

    /**
     * Get allowed origins from settings
     */
    private static function getAllowedOrigins()
    {
        // Get from WordPress options
        $allowed_origins = \get_option('mec_utility_allowed_origins', '');

        if (empty($allowed_origins)) {
            // Default origins for development and mobile apps
            return [
                '*', // Allow all origins for mobile apps
                'http://localhost',
                'http://localhost:3000',
                'http://127.0.0.1',
                'http://127.0.0.1:3000',
                'https://localhost',
                'https://localhost:3000',
                'https://127.0.0.1',
                'https://127.0.0.1:3000',
                'capacitor://localhost',
                'ionic://localhost',
                'file://',
                'http://192.168.1.100:3000',
                'http://192.168.1.102:3000',
            ];
        }

        // Convert comma-separated string to array
        if (is_string($allowed_origins)) {
            return array_map('trim', explode(',', $allowed_origins));
        }

        return $allowed_origins;
    }

    /**
     * Check if request is from mobile app
     */
    public static function isMobileApp()
    {
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

        // Check for common mobile app user agents
        $mobile_app_indicators = [
            'Capacitor',
            'Ionic',
            'Cordova',
            'React Native',
            'Flutter',
            'Xamarin',
            'Mobile App',
            'MEC-Events-App',
            'Darwin', // iOS WebKit
            'iPhone',
            'iPad',
            'CFNetwork', // iOS networking framework
            'okhttp', // Android HTTP client
        ];

        foreach ($mobile_app_indicators as $indicator) {
            if (stripos($user_agent, $indicator) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Add CORS headers for specific API endpoints
     */
    public static function addApiCorsHeaders()
    {
        // Check if this is an API request
        if (self::isApiRequest()) {
            self::handleCors();

            // Additional headers for API requests
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-cache, no-store, must-revalidate');
            header('Pragma: no-cache');
            header('Expires: 0');
        }
    }

    /**
     * Check if current request is an API request
     */
    private static function isApiRequest()
    {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

        // Check for API endpoints
        $api_patterns = [
            '/wp-json/',
            '/api/',
            'mec_api=',
            'action=mec_utility',
        ];

        foreach ($api_patterns as $pattern) {
            if (strpos($request_uri, $pattern) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Log CORS issues for debugging
     */
    public static function logCorsIssue($message, $data = [])
    {
        if (defined('\WP_DEBUG') && \WP_DEBUG) {
            \error_log('MEC Utility CORS Issue: ' . $message . ' - ' . \json_encode($data));
        }
    }
}
