<?php

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @package    MecUtility
 * @subpackage MecUtility/Core
 * @since      1.0.0
 */

namespace MecUtility\Core;

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    MecUtility
 * @subpackage MecUtility/Core
 */
class I18n {



	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since 1.0.0
	 */
	public function load_plugin_textdomain() {
		load_plugin_textdomain(
			MEC_UTILITY_TEXT_DOMAIN,
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}

	/**
	 * Get available languages for the plugin.
	 *
	 * @since 1.0.0
	 * @return array Array of available language codes.
	 */
	public function get_available_languages() {
		$languages    = array();
		$language_dir = MEC_UTILITY_PLUGIN_DIR . 'languages/';

		if ( is_dir( $language_dir ) ) {
			$files = glob( $language_dir . '*.mo' );
			foreach ( $files as $file ) {
				$filename = basename( $file, '.mo' );
				if ( preg_match( '/^' . MEC_UTILITY_TEXT_DOMAIN . '-(.+)$/', $filename, $matches ) ) {
					$languages[] = $matches[1];
				}
			}
		}

		return $languages;
	}

	/**
	 * Get the current language code.
	 *
	 * @since 1.0.0
	 * @return string Current language code.
	 */
	public function get_current_language() {
		return get_locale();
	}

	/**
	 * Check if a specific language is available.
	 *
	 * @since 1.0.0
	 * @param string $language_code The language code to check.
	 * @return bool True if language is available, false otherwise.
	 */
	public function is_language_available( $language_code ) {
		$available_languages = $this->get_available_languages();
		return in_array( $language_code, $available_languages, true );
	}

	/**
	 * Get language file path for a specific language.
	 *
	 * @since 1.0.0
	 * @param string $language_code The language code.
	 * @param string $type          The file type ('mo' or 'po'). Default 'mo'.
	 * @return string|false The file path if exists, false otherwise.
	 */
	public function get_language_file_path( $language_code, $type = 'mo' ) {
		$filename = MEC_UTILITY_TEXT_DOMAIN . '-' . $language_code . '.' . $type;
		$filepath = MEC_UTILITY_PLUGIN_DIR . 'languages/' . $filename;

		return file_exists( $filepath ) ? $filepath : false;
	}

	/**
	 * Load a specific language file.
	 *
	 * @since 1.0.0
	 * @param string $language_code The language code to load.
	 * @return bool True if loaded successfully, false otherwise.
	 */
	public function load_language( $language_code ) {
		$mo_file = $this->get_language_file_path( $language_code, 'mo' );

		if ( $mo_file ) {
			return load_textdomain( MEC_UTILITY_TEXT_DOMAIN, $mo_file );
		}

		return false;
	}

	/**
	 * Get plugin translation statistics.
	 *
	 * @since 1.0.0
	 * @return array Translation statistics.
	 */
	public function get_translation_stats() {
		$stats = array(
			'total_languages'     => 0,
			'available_languages' => array(),
			'current_language'    => $this->get_current_language(),
			'text_domain'         => MEC_UTILITY_TEXT_DOMAIN,
			'language_dir'        => MEC_UTILITY_PLUGIN_DIR . 'languages/',
		);

		$available_languages          = $this->get_available_languages();
		$stats['total_languages']     = count( $available_languages );
		$stats['available_languages'] = $available_languages;

		return $stats;
	}

	/**
	 * Register JavaScript translations.
	 *
	 * @since 1.0.0
	 * @param string $handle The script handle.
	 */
	public function set_script_translations( $handle ) {
		wp_set_script_translations(
			$handle,
			MEC_UTILITY_TEXT_DOMAIN,
			MEC_UTILITY_PLUGIN_DIR . 'languages'
		);
	}

	/**
	 * Get RTL (Right-to-Left) languages.
	 *
	 * @since 1.0.0
	 * @return array Array of RTL language codes.
	 */
	public function get_rtl_languages() {
		return array(
			'ar',    // Arabic
			'he_IL', // Hebrew
			'fa_IR', // Persian
			'ur',    // Urdu
			'ps',    // Pashto
			'sd_PK', // Sindhi
			'ug_CN', // Uighur
		);
	}

	/**
	 * Check if current language is RTL.
	 *
	 * @since 1.0.0
	 * @return bool True if current language is RTL, false otherwise.
	 */
	public function is_rtl() {
		$current_language = $this->get_current_language();
		$rtl_languages    = $this->get_rtl_languages();

		return in_array( $current_language, $rtl_languages, true ) || is_rtl();
	}

	/**
	 * Get language name from language code.
	 *
	 * @since 1.0.0
	 * @param string $language_code The language code.
	 * @return string The language name or the code if name not found.
	 */
	public function get_language_name( $language_code ) {
		$language_names = array(
			'en_US' => __( 'English (United States)', MEC_UTILITY_TEXT_DOMAIN ),
			'es_ES' => __( 'Spanish (Spain)', MEC_UTILITY_TEXT_DOMAIN ),
			'fr_FR' => __( 'French (France)', MEC_UTILITY_TEXT_DOMAIN ),
			'de_DE' => __( 'German', MEC_UTILITY_TEXT_DOMAIN ),
			'it_IT' => __( 'Italian', MEC_UTILITY_TEXT_DOMAIN ),
			'pt_BR' => __( 'Portuguese (Brazil)', MEC_UTILITY_TEXT_DOMAIN ),
			'ru_RU' => __( 'Russian', MEC_UTILITY_TEXT_DOMAIN ),
			'zh_CN' => __( 'Chinese (Simplified)', MEC_UTILITY_TEXT_DOMAIN ),
			'ja'    => __( 'Japanese', MEC_UTILITY_TEXT_DOMAIN ),
			'ko_KR' => __( 'Korean', MEC_UTILITY_TEXT_DOMAIN ),
			'ar'    => __( 'Arabic', MEC_UTILITY_TEXT_DOMAIN ),
			'he_IL' => __( 'Hebrew', MEC_UTILITY_TEXT_DOMAIN ),
		);

		return isset( $language_names[ $language_code ] ) ? $language_names[ $language_code ] : $language_code;
	}
}
