<?php

/**
 * The main plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * @package    MecUtility
 * @subpackage MecUtility/Core
 * @since      1.0.0
 */

namespace MecUtility\Core;

/**
 * The main plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    MecUtility
 * @subpackage MecUtility/Core
 */
class Plugin {





	/**
	 * The single instance of the class.
	 *
	 * @since 1.0.0
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * The loader that's responsible for maintaining and registering all hooks.
	 *
	 * @since 1.0.0
	 * @var Loader
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		$this->version     = MEC_UTILITY_VERSION;
		$this->plugin_name = 'mec-utility';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->define_api_hooks();
	}

	/**
	 * Get the single instance of the class.
	 *
	 * @since 1.0.0
	 * @return Plugin
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since 1.0.0
	 */
	private function load_dependencies() {
		$this->loader = new Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the I18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since 1.0.0
	 */
	private function set_locale() {
		$plugin_i18n = new I18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since 1.0.0
	 */
	private function define_admin_hooks() {
		// Only load admin functionality in admin area.
		if ( ! is_admin() ) {
			return;
		}

		// Check if admin classes exist before loading.
		if ( class_exists( 'MecUtility\Admin\AdminController' ) ) {
			$plugin_admin = new \MecUtility\Admin\AdminController( $this->get_plugin_name(), $this->get_version() );

			$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
			$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
			$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_admin_menu' );
			$this->loader->add_action( 'admin_init', $plugin_admin, 'admin_init' );

			// Filter author display name for mec-events to show App Access name
			$this->loader->add_filter( 'the_author', $plugin_admin, 'filter_mec_event_author_name', 10, 1 );
			$this->loader->add_filter( 'get_the_author_display_name', $plugin_admin, 'filter_mec_event_author_display_name', 10, 2 );

			// Initialize admin hooks (AJAX handlers, etc.)
			$plugin_admin->init_hooks();
		}
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since 1.0.0
	 */
	private function define_public_hooks() {
		// Check if public classes exist before loading.
		if ( class_exists( 'MecUtility\PublicArea\PublicController' ) ) {
			$plugin_public = new \MecUtility\PublicArea\PublicController( $this->get_plugin_name(), $this->get_version() );

			$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
			$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		}
	}

	/**
	 * Register all of the hooks related to the API functionality
	 * of the plugin.
	 *
	 * @since 1.0.0
	 */
	private function define_api_hooks() {
		// Check if API classes exist before loading.
		if ( class_exists( 'MecUtility\Api\ApiController' ) ) {
			$plugin_api = new \MecUtility\Api\ApiController( $this->get_plugin_name(), $this->get_version() );

			$this->loader->add_action( 'rest_api_init', $plugin_api, 'register_routes' );
		}

		// Add additional API validation
		$this->loader->add_action( 'rest_api_init', $this, 'validate_mec_dependency' );
	}

	/**
	 * Validate MEC dependency for API endpoints
	 *
	 * @since 1.0.0
	 */
	public function validate_mec_dependency() {
		// Check if either MEC Pro or MEC Lite is active
		$mec_pro_active = \is_plugin_active( 'modern-events-calendar/mec.php' );
		$mec_lite_active = \is_plugin_active( 'modern-events-calendar-lite/modern-events-calendar-lite.php' );
		
		// Ensure at least one version of MEC is active when API is accessed
		if ( ! $mec_pro_active && ! $mec_lite_active ) {
			\add_filter( 'rest_pre_dispatch', function( $result, $server, $request ) {
				if ( strpos( $request->get_route(), '/mec-utility/' ) === 0 ) {
					return new \WP_Error(
						'mec_utility_dependency_missing',
						\__( 'Modern Events Calendar plugin (Pro or Lite) is required for this API.', 'mec-utility' ),
						array( 'status' => 503 )
					);
				}
				return $result;
			}, 10, 3 );
		}
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since 1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since 1.0.0
	 * @return string The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since 1.0.0
	 * @return Loader Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since 1.0.0
	 * @return string The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

	/**
	 * Check if MEC plugin is active and compatible.
	 *
	 * @since 1.0.0
	 * @return bool True if MEC is active and compatible, false otherwise.
	 */
	public function is_mec_compatible() {
		// Check if MEC is active.
		if ( ! is_plugin_active( MEC_UTILITY_REQUIRED_MEC_SLUG ) ) {
			return false;
		}

		// Check if MEC main class exists.
		if ( ! class_exists( 'MEC' ) ) {
			return false;
		}

		// Check MEC version if available.
		if ( defined( 'MEC_VERSION' ) ) {
			$required_mec_version = '6.0.0'; // Minimum required MEC version.
			if ( version_compare( MEC_VERSION, $required_mec_version, '<' ) ) {
				add_action(
					'admin_notices',
					function () use ( $required_mec_version ) {
						echo '<div class="notice notice-warning is-dismissible">';
						echo '<p>';
						printf(
							/* translators: %1$s: Current MEC version, %2$s: Required MEC version */
							esc_html__( '<strong>MEC Utility:</strong> Modern Events Calendar version %1$s is installed, but version %2$s or higher is recommended for full compatibility.', 'mec-utility' ),
							esc_html( MEC_VERSION ),
							esc_html( $required_mec_version )
						);
						echo '</p>';
						echo '</div>';
					}
				);
			}
		}

		return true;
	}

	/**
	 * Get MEC plugin information.
	 *
	 * @since 1.0.0
	 * @return array MEC plugin information.
	 */
	public function get_mec_info() {
		$mec_info = array(
			'active'  => is_plugin_active( MEC_UTILITY_REQUIRED_MEC_SLUG ),
			'version' => defined( 'MEC_VERSION' ) ? MEC_VERSION : 'unknown',
			'path'    => WP_PLUGIN_DIR . '/' . MEC_UTILITY_REQUIRED_MEC_SLUG,
			'exists'  => file_exists( WP_PLUGIN_DIR . '/' . MEC_UTILITY_REQUIRED_MEC_SLUG ),
		);

		return $mec_info;
	}

	/**
	 * Prevent cloning of the instance.
	 *
	 * @since 1.0.0
	 */
	private function __clone() {}

	/**
	 * Prevent unserialization of the instance.
	 *
	 * @since 1.0.0
	 * @throws \Exception When trying to unserialize singleton.
	 */
	public function __wakeup() {
		throw new \Exception( esc_html__( 'Cannot unserialize singleton', 'mec-utility' ) );
	}
}
