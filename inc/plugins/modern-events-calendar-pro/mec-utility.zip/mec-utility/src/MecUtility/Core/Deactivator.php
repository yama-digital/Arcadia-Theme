<?php

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @package    MecUtility
 * @subpackage MecUtility/Core
 * @since      1.0.0
 */

namespace MecUtility\Core;

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    MecUtility
 * @subpackage MecUtility/Core
 */
class Deactivator {



	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since 1.0.0
	 */
	public static function deactivate() {
		// Clear scheduled cron events.
		self::clear_cron_events();

		// Flush rewrite rules.
		flush_rewrite_rules();

		// Clear any cached data.
		self::clear_cache();

		// Log deactivation.
		self::log_deactivation();

		// Optional: Clean up temporary data.
		self::cleanup_temporary_data();
	}

	/**
	 * Clear scheduled cron events.
	 *
	 * @since 1.0.0
	 */
	private static function clear_cron_events() {
		// Clear QR code cleanup cron.
		$timestamp = wp_next_scheduled( 'mec_utility_cleanup_qr_codes' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'mec_utility_cleanup_qr_codes' );
		}

		// Clear logs cleanup cron.
		$timestamp = wp_next_scheduled( 'mec_utility_cleanup_logs' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'mec_utility_cleanup_logs' );
		}

		// Clear all instances of our cron hooks.
		wp_clear_scheduled_hook( 'mec_utility_cleanup_qr_codes' );
		wp_clear_scheduled_hook( 'mec_utility_cleanup_logs' );
	}

	/**
	 * Clear any cached data.
	 *
	 * @since 1.0.0
	 */
	private static function clear_cache() {
		// Clear WordPress object cache.
		wp_cache_flush();

		// Clear any plugin-specific transients.
		self::clear_transients();

		// Clear any third-party cache if needed.
		self::clear_third_party_cache();
	}

	/**
	 * Clear plugin-specific transients.
	 *
	 * @since 1.0.0
	 */
	private static function clear_transients() {
		global $wpdb;

		// Delete all transients that start with our prefix.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				'_transient_mec_utility_%',
				'_transient_timeout_mec_utility_%'
			)
		);
	}

	/**
	 * Clear third-party cache plugins.
	 *
	 * @since 1.0.0
	 */
	private static function clear_third_party_cache() {
		// WP Rocket.
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}

		// W3 Total Cache.
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
		}

		// WP Super Cache.
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
		}
	}

	/**
	 * Log plugin deactivation.
	 *
	 * @since 1.0.0
	 */
	private static function log_deactivation() {
		$log_data = array(
			'action'            => 'plugin_deactivated',
			'plugin_version'    => MEC_UTILITY_VERSION,
			'wordpress_version' => get_bloginfo( 'version' ),
			'php_version'       => PHP_VERSION,
			'deactivated_at'    => current_time( 'mysql' ),
			'active_duration'   => self::get_active_duration(),
		);

		// Store deactivation log.
		update_option( 'mec_utility_deactivation_log', $log_data );

		// Log to WordPress debug log if enabled.
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( 'MEC Utility Plugin Deactivated: ' . wp_json_encode( $log_data ) );
		}
	}

	/**
	 * Get the duration the plugin was active.
	 *
	 * @since 1.0.0
	 * @return string Human readable duration.
	 */
	private static function get_active_duration() {
		$activated_at = get_option( 'mec_utility_activated_at' );
		if ( ! $activated_at ) {
			return __( 'Unknown', MEC_UTILITY_TEXT_DOMAIN );
		}

		$activated_timestamp = strtotime( $activated_at );
		$current_timestamp   = current_time( 'timestamp' );
		$duration            = $current_timestamp - $activated_timestamp;

		return human_time_diff( $activated_timestamp, $current_timestamp );
	}

	/**
	 * Clean up temporary data.
	 *
	 * @since 1.0.0
	 */
	private static function cleanup_temporary_data() {
		global $wpdb;

		// Clean up expired QR codes.
		$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$qr_sessions_table} WHERE expires_at < %s",
				current_time( 'mysql' )
			)
		);

		// Clean up old activity logs (keep last 100 entries).
		$activity_logs_table = $wpdb->prefix . 'mec_utility_activity_logs';
		$wpdb->query(
			"DELETE FROM {$activity_logs_table} 
             WHERE id NOT IN (
                 SELECT id FROM (
                     SELECT id FROM {$activity_logs_table} 
                     ORDER BY created_at DESC 
                     LIMIT 100
                 ) AS temp
             )"
		);

		// Clean up temporary files.
		self::cleanup_temporary_files();
	}

	/**
	 * Clean up temporary files.
	 *
	 * @since 1.0.0
	 */
	private static function cleanup_temporary_files() {
		$upload_dir      = wp_upload_dir();
		$mec_utility_dir = $upload_dir['basedir'] . '/mec-utility';

		if ( is_dir( $mec_utility_dir ) ) {
			// Clean up QR code images.
			$qr_codes_dir = $mec_utility_dir . '/qr-codes';
			if ( is_dir( $qr_codes_dir ) ) {
				$files = glob( $qr_codes_dir . '/*.png' );
				foreach ( $files as $file ) {
					if ( is_file( $file ) ) {
						unlink( $file );
					}
				}
			}

			// Clean up temporary export files.
			$exports_dir = $mec_utility_dir . '/exports';
			if ( is_dir( $exports_dir ) ) {
				$files = glob( $exports_dir . '/*' );
				foreach ( $files as $file ) {
					if ( is_file( $file ) && filemtime( $file ) < ( time() - 3600 ) ) { // Older than 1 hour
						unlink( $file );
					}
				}
			}
		}
	}

	/**
	 * Get plugin statistics for deactivation feedback.
	 *
	 * @since 1.0.0
	 * @return array Plugin usage statistics.
	 */
	public static function get_plugin_stats() {
		global $wpdb;

		$stats = array();

		// API Keys count.
		$api_keys_table           = $wpdb->prefix . 'mec_utility_api_keys';
		$stats['total_api_keys']  = $wpdb->get_var( "SELECT COUNT(*) FROM {$api_keys_table}" );
		$stats['active_api_keys'] = $wpdb->get_var( "SELECT COUNT(*) FROM {$api_keys_table} WHERE is_active = 1" );

		// QR Sessions count.
		$qr_sessions_table          = $wpdb->prefix . 'mec_utility_qr_sessions';
		$stats['total_qr_sessions'] = $wpdb->get_var( "SELECT COUNT(*) FROM {$qr_sessions_table}" );
		$stats['used_qr_sessions']  = $wpdb->get_var( "SELECT COUNT(*) FROM {$qr_sessions_table} WHERE is_used = 1" );

		// Activity Logs count.
		$activity_logs_table          = $wpdb->prefix . 'mec_utility_activity_logs';
		$stats['total_api_requests']  = $wpdb->get_var( "SELECT COUNT(*) FROM {$activity_logs_table}" );
		$stats['successful_requests'] = $wpdb->get_var( "SELECT COUNT(*) FROM {$activity_logs_table} WHERE status = 'success'" );

		// Plugin settings.
		$stats['settings'] = array(
			'api_enabled' => get_option( 'mec_utility_api_enabled', 0 ),
			'qr_enabled'  => get_option( 'mec_utility_qr_enabled', 0 ),
			'rate_limit'  => get_option( 'mec_utility_rate_limit', 100 ),
		);

		return $stats;
	}

	/**
	 * Preserve important data during deactivation.
	 *
	 * @since 1.0.0
	 */
	private static function preserve_important_data() {
		// Create a backup of important settings.
		$important_settings = array(
			'mec_utility_api_enabled',
			'mec_utility_qr_enabled',
			'mec_utility_rate_limit',
			'mec_utility_jwt_secret',
			'mec_utility_allowed_origins',
		);

		$backup_data = array();
		foreach ( $important_settings as $setting ) {
			$backup_data[ $setting ] = get_option( $setting );
		}

		update_option( 'mec_utility_settings_backup', $backup_data );
	}

	/**
	 * Check if plugin should perform cleanup on deactivation.
	 *
	 * @since 1.0.0
	 * @return bool True if cleanup should be performed.
	 */
	private static function should_cleanup() {
		// Check if admin has enabled cleanup on deactivation.
		return get_option( 'mec_utility_cleanup_on_deactivation', false );
	}

	/**
	 * Send deactivation feedback (if user opted in).
	 *
	 * @since 1.0.0
	 */
	private static function send_deactivation_feedback() {
		// Only send if user has opted in for feedback.
		if ( ! get_option( 'mec_utility_send_feedback', false ) ) {
			return;
		}

		$feedback_data = array(
			'plugin_version'    => MEC_UTILITY_VERSION,
			'wordpress_version' => get_bloginfo( 'version' ),
			'php_version'       => PHP_VERSION,
			'site_url'          => get_site_url(),
			'stats'             => self::get_plugin_stats(),
			'deactivated_at'    => current_time( 'c' ),
		);

		// Send feedback to your server (implement as needed).
		// wp_remote_post('https://your-domain.com/api/feedback', [
		// 'body' => wp_json_encode($feedback_data),.
		// 'headers' => ['Content-Type' => 'application/json'],.
		// ]);.
	}
}
