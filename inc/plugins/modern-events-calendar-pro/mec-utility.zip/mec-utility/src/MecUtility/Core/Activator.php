<?php

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @package    MecUtility
 * @subpackage MecUtility/Core
 * @since      1.0.0
 */

namespace MecUtility\Core;

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    MecUtility
 * @subpackage MecUtility/Core
 */
class Activator {









	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since 1.0.0
	 */
	public static function activate() {
		// Check WordPress version.
		self::check_wordpress_version();

		// Check PHP version.
		self::check_php_version();

		// Check if MEC is installed and active.
		self::check_mec_dependency();

		// Check if wp-json is accessible.
		self::check_wp_json_accessibility();

		// Create database tables.
		self::create_database_tables();

		// Set default options.
		self::set_default_options();

		// Create necessary directories.
		self::create_directories();

		// Create default API key and QR code.
		self::create_default_credentials();

		// Set plugin version.
		self::set_plugin_version();

		// Schedule cron events.
		self::schedule_cron_events();

		// Flush rewrite rules.
		flush_rewrite_rules();

		// Log activation.
		self::log_activation();
	}

	/**
	 * Check WordPress version compatibility.
	 *
	 * @since 1.0.0
	 */
	private static function check_wordpress_version() {
		global $wp_version;
		$required_wp_version = '5.0';

		if ( version_compare( $wp_version, $required_wp_version, '<' ) ) {
			wp_die(
				sprintf(
					/* translators: %1$s: Plugin name, %2$s: Required WordPress version, %3$s: Current WordPress version */
					esc_html__( '%1$s requires WordPress version %2$s or higher. You are running version %3$s.', 'mec-utility' ),
					'MEC Utility',
					esc_html( $required_wp_version ),
					esc_html( $wp_version )
				),
				esc_html__( 'Plugin Activation Error', 'mec-utility' ),
				array( 'back_link' => true )
			);
		}
	}

	/**
	 * Check PHP version compatibility.
	 *
	 * @since 1.0.0
	 */
	private static function check_php_version() {
		$required_php_version = '7.4';
		$current_php_version  = PHP_VERSION;

		if ( version_compare( $current_php_version, $required_php_version, '<' ) ) {
			wp_die(
				sprintf(
					/* translators: %1$s: Plugin name, %2$s: Required PHP version, %3$s: Current PHP version */
					esc_html__( '%1$s requires PHP version %2$s or higher. You are running version %3$s.', 'mec-utility' ),
					'MEC Utility',
					esc_html( $required_php_version ),
					esc_html( $current_php_version )
				),
				esc_html__( 'Plugin Activation Error', 'mec-utility' ),
				array( 'back_link' => true )
			);
		}
	}

	/**
	 * Check MEC plugin dependency.
	 *
	 * @since 1.0.0
	 */
	private static function check_mec_dependency() {
		// Ensure plugin.php is loaded
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		// Check if any version of MEC (Pro or Lite) is active
		$mec_pro_active  = is_plugin_active( 'modern-events-calendar/mec.php' );
		$mec_lite_active = is_plugin_active( 'modern-events-calendar-lite/modern-events-calendar-lite.php' );

		if ( ! $mec_pro_active && ! $mec_lite_active ) {
			wp_die(
				sprintf(
					/* translators: %s: Required plugin name */
					esc_html__( 'MEC Utility requires %s plugin to be installed and activated.', 'mec-utility' ),
					'Modern Events Calendar'
				),
				esc_html__( 'Plugin Activation Error', 'mec-utility' ),
				array( 'back_link' => true )
			);
		}
	}

	/**
	 * Check if wp-json is accessible and show admin notice if not.
	 *
	 * @since 1.0.0
	 */
	private static function check_wp_json_accessibility() {
		// Test wp-json endpoint
		$wp_json_url = get_rest_url();
		$response = wp_remote_get($wp_json_url, array(
			'timeout' => 10,
			'user-agent' => 'MEC-Utility-Plugin/1.0.0'
		));

		// Check if wp-json is accessible
		if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
			// Store flag to show admin notice
			update_option('mec_utility_wp_json_disabled', true);
			update_option('mec_utility_wp_json_disabled_time', current_time('mysql'));
		} else {
			// Clear the flag if wp-json is working
			delete_option('mec_utility_wp_json_disabled');
			delete_option('mec_utility_wp_json_disabled_time');
		}
	}

	/**
	 * Create database tables.
	 *
	 * @since 1.0.0
	 */
	private static function create_database_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// API Keys table.
		$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
		$api_keys_sql   = "CREATE TABLE $api_keys_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            api_key varchar(64) NOT NULL,
            api_secret varchar(64) NOT NULL,
            name varchar(200) NOT NULL,
            permissions text,
            last_access datetime DEFAULT NULL,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY api_key (api_key),
            KEY user_id (user_id),
            KEY is_active (is_active)
        ) $charset_collate;";

		// QR Sessions table.
		$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
		$qr_sessions_sql   = "CREATE TABLE $qr_sessions_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            qr_token varchar(64) NOT NULL,
            session_data text,
            expires_at datetime DEFAULT NULL,
            used_at datetime DEFAULT NULL,
            is_used tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY qr_token (qr_token),
            KEY user_id (user_id),
            KEY expires_at (expires_at),
            KEY is_used (is_used)
        ) $charset_collate;";

		// Activity Logs table.
		$activity_logs_table = $wpdb->prefix . 'mec_utility_activity_logs';
		$activity_logs_sql   = "CREATE TABLE $activity_logs_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned DEFAULT NULL,
            api_key_id bigint(20) unsigned DEFAULT NULL,
            action varchar(100) NOT NULL,
            object_type varchar(50) DEFAULT NULL,
            object_id bigint(20) unsigned DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            user_agent text,
            request_data text,
            response_data text,
            status varchar(20) DEFAULT 'success',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY api_key_id (api_key_id),
            KEY action (action),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $api_keys_sql );
		dbDelta( $qr_sessions_sql );
		dbDelta( $activity_logs_sql );
	}

	/**
	 * Set default plugin options.
	 *
	 * @since 1.0.0
	 */
	private static function set_default_options() {
		$default_options = array(
			'mec_utility_api_enabled'     => 1,
			'mec_utility_qr_enabled'      => 1,
			'mec_utility_qr_expiry'       => 300, // 5 minutes.
			'mec_utility_rate_limit'      => 100, // requests per hour.
			'mec_utility_log_retention'   => 30, // days.
			'mec_utility_require_ssl'     => 0,
			'mec_utility_allowed_origins' => '',
			'mec_utility_jwt_secret'      => wp_generate_password( 64, true, true ),
		);

		foreach ( $default_options as $option_name => $option_value ) {
			if ( get_option( $option_name ) === false ) {
				add_option( $option_name, $option_value );
			}
		}
	}

	/**
	 * Create default API key and QR code.
	 *
	 * @since 1.0.0
	 */
	private static function create_default_credentials() {
		global $wpdb;

		// Check if default API key already exists.
		$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
		$existing_key   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$api_keys_table} WHERE name = %s",
				'Default API Key'
			)
		);

		if ( ! $existing_key ) {
			// Create default API key.
			$api_key    = 'mec_' . wp_generate_password( 32, false );
			$api_secret = wp_generate_password( 64, true, true );
			$admin_user = get_user_by( 'email', get_option( 'admin_email' ) );
			$user_id    = $admin_user ? $admin_user->ID : 1;

			$default_permissions = array(
				'read_events',
				'create_events',
				'update_events',
				'manage_bookings',
				'read_invoices',
				'manage_invoices',
				'view_invoice_pdf',
				'invoice_qr_codes',
				'generate_qr',
				'scan_qr',
			);

			$result = $wpdb->insert(
				$api_keys_table,
				array(
					'user_id'     => $user_id,
					'api_key'     => $api_key,
					'api_secret'  => $api_secret,
					'name'        => 'Default API Key',
					'permissions' => wp_json_encode( $default_permissions ),
					'is_active'   => 1,
					'created_at'  => current_time( 'mysql' ),
				),
				array( '%d', '%s', '%s', '%s', '%s', '%d', '%s' )
			);

			if ( $result ) {
				// Log the creation.
				self::log_activity( 'api_key_created', 'api_key', $wpdb->insert_id, $user_id );
			}
		}

		// Create default QR code.
		self::create_default_qr_code();
	}

	/**
	 * Create default QR code.
	 *
	 * @since 1.0.0
	 */
	private static function create_default_qr_code() {
		global $wpdb;

		$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
		$admin_user        = get_user_by( 'email', get_option( 'admin_email' ) );
		$user_id           = $admin_user ? $admin_user->ID : 1;

		// Generate QR token.
		$qr_token   = 'qr_' . wp_generate_password( 32, false );
		// Remove time limit - set expires_at to NULL for permanent QR codes
		$expires_at = null;

		$session_data = array(
			'website_url'  => home_url(),
			'generated_at' => current_time( 'mysql' ),
			'user_id'      => $user_id,
			'type'         => 'default',
		);

		$result = $wpdb->insert(
			$qr_sessions_table,
			array(
				'user_id'      => $user_id,
				'qr_token'     => $qr_token,
				'session_data' => wp_json_encode( $session_data ),
				'expires_at'   => $expires_at,
				'is_used'      => 0,
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%d', '%s' )
		);

		if ( $result ) {
			// Log the creation.
			self::log_activity( 'qr_code_created', 'qr_session', $wpdb->insert_id, $user_id );
		}
	}

	/**
	 * Log activity.
	 *
	 * @since 1.0.0
	 * @param string $action      The action performed.
	 * @param string $object_type The type of object.
	 * @param int    $object_id   The object ID.
	 * @param int    $user_id     The user ID.
	 */
	private static function log_activity( $action, $object_type, $object_id, $user_id = null ) {
		global $wpdb;

		$activity_logs_table = $wpdb->prefix . 'mec_utility_activity_logs';

		$wpdb->insert(
			$activity_logs_table,
			array(
				'user_id'     => $user_id,
				'action'      => $action,
				'object_type' => $object_type,
				'object_id'   => $object_id,
				'ip_address'  => self::get_client_ip(),
				'user_agent'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
				'status'      => 'success',
				'created_at'  => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Get client IP address.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function get_client_ip() {
		$ip_keys = array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );

		foreach ( $ip_keys as $key ) {
			if ( array_key_exists( $key, $_SERVER ) === true ) {
				$ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) !== false ) {
					return $ip;
				}
			}
		}

		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '127.0.0.1';
	}

	/**
	 * Create necessary directories.
	 *
	 * @since 1.0.0
	 */
	private static function create_directories() {
		$upload_dir      = wp_upload_dir();
		$mec_utility_dir = $upload_dir['basedir'] . '/mec-utility';

		if ( ! file_exists( $mec_utility_dir ) ) {
			wp_mkdir_p( $mec_utility_dir );
		}

		// Create subdirectories.
		$subdirs = array( 'logs', 'qr-codes', 'exports' );
		foreach ( $subdirs as $subdir ) {
			$dir_path = $mec_utility_dir . '/' . $subdir;
			if ( ! file_exists( $dir_path ) ) {
				wp_mkdir_p( $dir_path );
			}
		}

		// Create .htaccess file to protect directories.
		$htaccess_content = "Order deny,allow\nDeny from all\n";
		$htaccess_file    = $mec_utility_dir . '/.htaccess';

		// Use WordPress filesystem API.
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . '/wp-admin/includes/file.php';
			WP_Filesystem();
		}

		if ( $wp_filesystem ) {
			$wp_filesystem->put_contents( $htaccess_file, $htaccess_content, FS_CHMOD_FILE );
		}
	}

	/**
	 * Set plugin version.
	 *
	 * @since 1.0.0
	 */
	private static function set_plugin_version() {
		update_option( 'mec_utility_version', MEC_UTILITY_VERSION );
		update_option( 'mec_utility_activated_at', current_time( 'mysql' ) );
	}

	/**
	 * Schedule cron events.
	 *
	 * @since 1.0.0
	 */
	private static function schedule_cron_events() {
		// Schedule cleanup of expired QR codes.
		if ( ! wp_next_scheduled( 'mec_utility_cleanup_qr_codes' ) ) {
			wp_schedule_event( time(), 'hourly', 'mec_utility_cleanup_qr_codes' );
		}

		// Schedule cleanup of old activity logs.
		if ( ! wp_next_scheduled( 'mec_utility_cleanup_logs' ) ) {
			wp_schedule_event( time(), 'daily', 'mec_utility_cleanup_logs' );
		}
	}

	/**
	 * Log plugin activation.
	 *
	 * @since 1.0.0
	 */
	private static function log_activation() {
		$log_data = array(
			'action'            => 'plugin_activated',
			'plugin_version'    => MEC_UTILITY_VERSION,
			'wordpress_version' => get_bloginfo( 'version' ),
			'php_version'       => PHP_VERSION,
			'mec_version'       => defined( 'MEC_VERSION' ) ? MEC_VERSION : 'unknown',
			'timestamp'         => current_time( 'mysql' ),
		);

		// Store activation log.
		update_option( 'mec_utility_activation_log', $log_data );

		// Log to WordPress debug log if enabled.
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( 'MEC Utility Plugin Activated: ' . wp_json_encode( $log_data ) );
		}
	}

	/**
	 * Check if this is a fresh installation or an upgrade.
	 *
	 * @since 1.0.0
	 * @return bool True if fresh installation, false if upgrade.
	 */
	private static function is_fresh_installation() {
		return get_option( 'mec_utility_version' ) === false;
	}

	/**
	 * Run upgrade routines if needed.
	 *
	 * @since 1.0.0
	 */
	private static function maybe_upgrade() {
		$current_version = get_option( 'mec_utility_version' );

		if ( $current_version && version_compare( $current_version, MEC_UTILITY_VERSION, '<' ) ) {
			// Run upgrade routines.
			self::run_upgrade_routines( $current_version );
		}
	}

	/**
	 * Run upgrade routines for specific versions.
	 *
	 * @since 1.0.0
	 * @param string $from_version The version being upgraded from.
	 */
	private static function run_upgrade_routines( $from_version ) {
		// Example upgrade routine.
		// if (version_compare($from_version, '1.1.0', '<')) {
		// Upgrade to 1.1.0
		// }.

		// Update version after all upgrades.
		update_option( 'mec_utility_version', MEC_UTILITY_VERSION );
	}
}
