<?php

/**
 * Direct API Routes (Backup Method)
 *
 * @package    MecUtility
 * @subpackage MecUtility/Api
 * @since      1.0.0
 */

namespace MecUtility\Api;

use MecUtility\Auth\AuthHelper;

/**
 * Direct Routes Registration
 *
 * This is a backup method for registering API routes directly without class structure.
 * Used as fallback when main controller structure doesn't work.
 */
class DirectRoutes
{
    /**
     * Register cleanup hook
     */
    public static function init()
    {
        add_action('mec_utility_delete_temp_file', array(__CLASS__, 'delete_temp_file'), 10, 2);
    }

    /**
     * Delete temporary file and attachment
     */
    public static function delete_temp_file($file_path, $attachment_id)
    {
        // Delete physical file
        if (file_exists($file_path)) {
            @unlink($file_path);
        }

        // Delete attachment from media library
        if ($attachment_id) {
            wp_delete_attachment($attachment_id, true);
        }
    }

    /**
     * Clean HTML entities and tags from title
     *
     * @param string $title The title to clean
     * @return string Clean title
     */
    private static function clean_title($title)
    {
        if (empty($title)) {
            return $title;
        }

        // Decode HTML entities (&#8217; -> ')
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Remove HTML tags
        $title = strip_tags($title);

        // Clean up any remaining entities
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Trim whitespace
        return trim($title);
    }

    /**
     * Ensure MEC regenerates occurrences in mec_dates after changes
     */
    private static function reschedule_event($event_id)
    {
        try {
            if (!class_exists('MEC_schedule') && function_exists('mec_init')) {
                mec_init();
            }

            if (class_exists('MEC_schedule')) {
                $schedule = new \MEC_schedule();
                // For non-recurring and simple events use reschedule to fully rebuild
                $repeat_type = \get_post_meta($event_id, 'mec_repeat_type', true);
                if ($repeat_type === '' || $repeat_type === 'custom_days') {
                    $schedule->reschedule($event_id, 200);
                } else {
                    // For recurring, append is enough; but reschedule is safer after edits
                    $schedule->reschedule($event_id, $schedule->get_reschedule_maximum($repeat_type));
                }
            }
        } catch (\Throwable $e) {
            // Fail silently to avoid breaking API response
        }
    }

    /**
     * Register all direct API routes
     */
    public static function register_routes()
    {
        // Check if MEC Invoice plugin is active for invoice/QR routes
        $mec_invoice_active = class_exists('MEC_Invoice\\Attendee');

        // Bookings endpoints

        // Get all bookings with filters
        \register_rest_route(
            'mec-utility/v1',
            '/bookings',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_bookings'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Get single booking
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/(?P<booking_id>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_single_booking'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Get bookings for specific event
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/bookings',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_event_bookings'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Get attendees for specific event (flattened across bookings) - COMMENTED OUT
        // This route conflicts with AttendeesController which handles /events/{id}/attendees
        // Use /events/{id}/attendees/flat instead for flattened list
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/attendees/flat',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_event_attendees'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Get bookings statistics
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/stats',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_bookings_stats'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Update booking
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/(?P<booking_id>[\d]+)',
            array(
                'methods'             => 'PUT,PATCH,POST',
                'callback'            => array(__CLASS__, 'api_update_booking'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Delete booking (Trash or Force delete)
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/(?P<booking_id>[\d]+)',
            array(
                'methods'             => 'DELETE',
                'callback'            => array(__CLASS__, 'api_delete_booking'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
                'args'                => array(
                    'force' => array(
                        'description' => 'Permanently delete instead of trashing.',
                        'type'        => 'boolean',
                        'required'    => false,
                    ),
                ),
            )
        );

        // Upload media file
        \register_rest_route(
            'mec-utility/v1',
            '/media/upload',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_upload_media'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
            )
        );

        // Get detailed booking information
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/(?P<booking_id>[\d]+)/details',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_booking_details'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Get bookings for specific event occurrence
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/bookings/(?P<occurrence>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_event_bookings'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
            )
        );

        // Invoice endpoints - Only register if MEC Invoice plugin is active
        if ($mec_invoice_active) {
            // Get all invoices
            \register_rest_route(
                'mec-utility/v1',
                '/invoices',
                array(
                    'methods'             => 'GET',
                    'callback'            => array(__CLASS__, 'api_invoices'),
                    'permission_callback' => AuthHelper::permission_callback('read_invoices'),
                )
            );
        } else {
            // Register placeholder route that returns plugin not available error
            \register_rest_route(
                'mec-utility/v1',
                '/invoices',
                array(
                    'methods'             => 'GET',
                    'callback'            => array(__CLASS__, 'api_plugin_not_available'),
                    'permission_callback' => AuthHelper::permission_callback('read_invoices'),
                )
            );
        }

        // Get single invoice
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_single_invoice'),
                'permission_callback' => AuthHelper::permission_callback('read_invoices'),
            )
        );

        // Update invoice
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)',
            array(
                'methods'             => 'PUT,PATCH',
                'callback'            => array(__CLASS__, 'api_update_invoice'),
                'permission_callback' => AuthHelper::permission_callback('manage_invoices'),
            )
        );

        // Get invoice PDF
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)/pdf',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_invoice_pdf'),
                'permission_callback' => AuthHelper::permission_callback('view_invoice_pdf'),
            )
        );

        // Get invoice QR codes
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)/qr-codes',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_invoice_qr_codes'),
                'permission_callback' => AuthHelper::permission_callback('invoice_qr_codes'),
            )
        );

        // Invoice attendees list (from invoice -> book_id -> mec_attendees)
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)/attendees',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_invoice_attendees'),
                'permission_callback' => AuthHelper::permission_callback('read_invoices'),
            )
        );

        // Manual check-in/out for a specific invoice attendee
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)/attendees/check',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_invoice_attendee_check'),
                'permission_callback' => AuthHelper::permission_callback('manage_invoices'),
            )
        );

        // Export invoice attendees (bulk)
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/export/attendees',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_export_invoice_attendees'),
                'permission_callback' => AuthHelper::permission_callback('read_invoices'),
                'args'                => array(
                    'invoice_ids' => array(
                        'description' => 'Array of invoice IDs or comma-separated string.',
                        'type'        => 'array',
                        'required'    => true,
                    ),
                    'format' => array(
                        'description' => 'Return format: json or csv.',
                        'type'        => 'string',
                        'required'    => false,
                        'default'     => 'json',
                    ),
                ),
            )
        );

        // Export Bookings CSV
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/export/csv',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_export_bookings_csv'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
                'args'                => array(
                    'booking_ids' => array(
                        'required' => true,
                        'type'     => 'array',
                        'items'    => array(
                            'type' => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Export Bookings Excel
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/export/excel',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_export_bookings_excel'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
                'args'                => array(
                    'booking_ids' => array(
                        'required' => true,
                        'type'     => 'array',
                        'items'    => array(
                            'type' => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Status endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/status',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_status'),
                'permission_callback' => '__return_true',
            )
        );

        // Events endpoint - GET
        \register_rest_route(
            'mec-utility/v1',
            '/events',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_events'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'per_page' => array(
                        'description' => 'Maximum number of items to return.',
                        'type'        => 'integer',
                        'default'     => 10,
                        'minimum'     => 1,
                        'maximum'     => 100,
                    ),
                    'page' => array(
                        'description' => 'Current page of the collection.',
                        'type'        => 'integer',
                        'default'     => 1,
                        'minimum'     => 1,
                    ),
                    'status' => array(
                        'description' => 'Filter by post status. Use "any" for all statuses, "publish", "draft", "pending", "private", "trash".',
                        'type'        => 'string',
                        'default'     => 'any',
                        'enum'        => array('any', 'publish', 'draft', 'pending', 'private', 'trash', 'future'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'search' => array(
                        'description' => 'Search query string.',
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'start_date' => array(
                        'description' => 'Start date filter (Y-m-d format).',
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'end_date' => array(
                        'description' => 'End date filter (Y-m-d format).',
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'date_filter' => array(
                        'description' => 'Date filter type: upcoming, past, today, this_week, this_month.',
                        'type'        => 'string',
                        'enum'        => array('upcoming', 'past', 'today', 'this_week', 'this_month'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'month' => array(
                        'description' => 'Filter events by month number (1-12).',
                        'type'        => 'integer',
                        'minimum'     => 1,
                        'maximum'     => 12,
                    ),
                    'year' => array(
                        'description' => 'Filter events by year (e.g., 2025).',
                        'type'        => 'integer',
                        'minimum'     => 1970,
                        'maximum'     => 2100,
                    ),
                    'category' => array(
                        'description' => 'Event category ID or slug.',
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'location' => array(
                        'description' => 'Event location ID.',
                        'type'        => 'integer',
                    ),
                    'organizer' => array(
                        'description' => 'Event organizer ID.',
                        'type'        => 'integer',
                    ),
                    'orderby' => array(
                        'description' => 'Sort collection by object attribute.',
                        'type'        => 'string',
                        'default'     => 'date',
                        'enum'        => array('date', 'title', 'start_date'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'order' => array(
                        'description' => 'Order sort attribute ascending or descending.',
                        'type'        => 'string',
                        'default'     => 'asc',
                        'enum'        => array('asc', 'desc'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // Lightweight Event List endpoint - GET
        \register_rest_route(
            'mec-utility/v1',
            '/event-list',
            array(
                'methods'             => array('GET', 'POST'),
                'callback'            => array(__CLASS__, 'api_event_list'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'per_page' => array(
                        'description' => 'Maximum number of items to return.',
                        'type'        => 'integer',
                        'default'     => 10,
                        'minimum'     => 1,
                        'maximum'     => 100,
                    ),
                    'page' => array(
                        'description' => 'Current page of the collection.',
                        'type'        => 'integer',
                        'default'     => 1,
                        'minimum'     => 1,
                    ),
                    'status' => array(
                        'description' => 'Filter by post status. Use "any" for all statuses, "publish", "draft", "pending", "private", "trash".',
                        'type'        => 'string',
                        'default'     => 'any',
                        'enum'        => array('any', 'publish', 'draft', 'pending', 'private', 'trash', 'future'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'search' => array(
                        'description' => 'Search query string.',
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'labels' => array(
                        'description' => 'Filter by event label IDs.',
                        'type'        => 'array',
                        'items'       => array(
                            'type' => 'integer',
                        ),
                        'default' => array(),
                        'sanitize_callback' => array(__CLASS__, 'sanitize_id_array_param'),
                    ),
                    'locations' => array(
                        'description' => 'Filter by location term IDs.',
                        'type'        => 'array',
                        'items'       => array(
                            'type' => 'integer',
                        ),
                        'default' => array(),
                        'sanitize_callback' => array(__CLASS__, 'sanitize_id_array_param'),
                    ),
                    'organizers' => array(
                        'description' => 'Filter by organizer term IDs.',
                        'type'        => 'array',
                        'items'       => array(
                            'type' => 'integer',
                        ),
                        'default' => array(),
                        'sanitize_callback' => array(__CLASS__, 'sanitize_id_array_param'),
                    ),
                    'start_date' => array(
                        'description' => 'Start date filter (Y-m-d format).',
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'end_date' => array(
                        'description' => 'End date filter (Y-m-d format).',
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'date_filter' => array(
                        'description' => 'Date filter type: upcoming, past, today, this_week, this_month.',
                        'type'        => 'string',
                        'enum'        => array('upcoming', 'past', 'today', 'this_week', 'this_month'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'month' => array(
                        'description' => 'Filter events by month number (1-12).',
                        'type'        => 'integer',
                        'minimum'     => 1,
                        'maximum'     => 12,
                    ),
                    'year' => array(
                        'description' => 'Filter events by year (e.g., 2025).',
                        'type'        => 'integer',
                        'minimum'     => 1970,
                        'maximum'     => 2100,
                    ),
                    'orderby' => array(
                        'description' => 'Sort collection by object attribute.',
                        'type'        => 'string',
                        'default'     => 'date',
                        'enum'        => array('date', 'title', 'start_date'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'order' => array(
                        'description' => 'Order sort attribute ascending or descending.',
                        'type'        => 'string',
                        'default'     => 'asc',
                        'enum'        => array('asc', 'desc'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'occurrences_limit' => array(
                        'description' => 'Maximum number of occurrences to include per event.',
                        'type'        => 'integer',
                        'default'     => 10,
                        'minimum'     => 0,
                        'maximum'     => 200,
                    ),
                    'is_expired' => array(
                        'description' => 'Filter by expired status. true for expired events, false for available events.',
                        'type'        => 'boolean',
                        'default'     => null,
                    ),
                    'is_available' => array(
                        'description' => 'Filter by available status. true for available events, false for expired events.',
                        'type'        => 'boolean',
                        'default'     => null,
                    ),
                ),
            )
        );

        // Events endpoint - POST (Create)
        \register_rest_route(
            'mec-utility/v1',
            '/events',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_create_event'),
                'permission_callback' => AuthHelper::permission_callback('create_events'),
            )
        );

        // Single event endpoint - GET
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<id>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_single_event'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
            )
        );

        // Single event endpoint - PUT (Update)
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<id>[\d]+)',
            array(
                'methods'             => 'PUT,PATCH',
                'callback'            => array(__CLASS__, 'api_update_event'),
                'permission_callback' => AuthHelper::permission_callback('update_events'),
            )
        );

        // Single event endpoint - DELETE
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<id>[\d]+)',
            array(
                'methods'             => 'DELETE',
                'callback'            => array(__CLASS__, 'api_delete_event'),
                'permission_callback' => AuthHelper::permission_callback('delete_events'),
            )
        );

        // Search events endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/events/search',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_search_events'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'query' => array(
                        'description' => 'Search query string.',
                        'type'        => 'string',
                        'required'    => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'per_page' => array(
                        'description' => 'Maximum number of items to return.',
                        'type'        => 'integer',
                        'default'     => 10,
                        'minimum'     => 1,
                        'maximum'     => 100,
                    ),
                    'page' => array(
                        'description' => 'Current page of the collection.',
                        'type'        => 'integer',
                        'default'     => 1,
                        'minimum'     => 1,
                    ),
                    'status' => array(
                        'description' => 'Filter by post status. Use "any" for all statuses.',
                        'type'        => 'string',
                        'default'     => 'any',
                        'enum'        => array('any', 'publish', 'draft', 'pending', 'private', 'trash', 'future'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // Event colors endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/event-colors',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_event_colors'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'date' => array(
                        'description' => 'Date or month to get colors for (Y-m or Y-m-d format).',
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'status' => array(
                        'description' => 'Filter by post status. Use "any" for all statuses.',
                        'type'        => 'string',
                        'default'     => 'any',
                        'enum'        => array('any', 'publish', 'draft', 'pending', 'private', 'trash', 'future'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // QR Code endpoints

        // QR Scan endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/qr/scan',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_qr_scan'),
                'permission_callback' => AuthHelper::permission_callback('scan_qr'),
            )
        );

        // QR Scan endpoint - compatible with original structure
        \register_rest_route(
            'mec-utility/v1',
            '/attendees/check',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_qr_scan'),
                'permission_callback' => AuthHelper::permission_callback('scan_qr'),
            )
        );

        // QR Generate endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/qr/generate',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_qr_generate'),
                'permission_callback' => AuthHelper::permission_callback('generate_qr'),
            )
        );

        // QR Generate Bulk endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/qr/generate-bulk',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_qr_generate_bulk'),
                'permission_callback' => AuthHelper::permission_callback('generate_qr'),
            )
        );

        // QR Image endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/qr/image',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_qr_image'),
                'permission_callback' => AuthHelper::permission_callback('generate_qr'),
            )
        );

        // Translation endpoints

        // Get translations
        \register_rest_route(
            'mec-utility/v1',
            '/translate',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_get_translations'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
            )
        );

        // Update translations
        \register_rest_route(
            'mec-utility/v1',
            '/translate/update',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_update_translations'),
                'permission_callback' => AuthHelper::permission_callback('manage_translations'),
            )
        );

        // Taxonomy Routes
        register_rest_route('mec-utility/v1', '/taxonomies/(?P<taxonomy>[\w-]+)', [
            'methods' => \WP_REST_Server::READABLE,
            'callback' => [__CLASS__, 'api_get_taxonomy_terms'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('mec-utility/v1', '/taxonomies/(?P<taxonomy>[\w-]+)', [
            'methods' => \WP_REST_Server::CREATABLE,
            'callback' => [__CLASS__, 'api_create_taxonomy_term'],
            'permission_callback' => [__CLASS__, 'taxonomy_permissions_check'],
        ]);

        // Invoice endpoints

        // Get all invoices with filters
        \register_rest_route(
            'mec-utility/v1',
            '/invoices',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_invoices'),
                'permission_callback' => AuthHelper::permission_callback('read_invoices'),
                'args'                => array(
                    'per_page' => array(
                        'description' => 'Maximum number of items to return.',
                        'type'        => 'integer',
                        'default'     => 10,
                        'minimum'     => 1,
                        'maximum'     => 100,
                    ),
                    'page' => array(
                        'description' => 'Current page of the collection.',
                        'type'        => 'integer',
                        'default'     => 1,
                        'minimum'     => 1,
                    ),
                    'search' => array(
                        'description' => 'Search query string.',
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'event_id' => array(
                        'description' => 'Filter by event ID.',
                        'type'        => 'integer',
                        'sanitize_callback' => 'absint',
                    ),
                    'status' => array(
                        'description' => 'Filter by invoice status.',
                        'type'        => 'string',
                        'enum'        => array('open', 'closed', 'all'),
                        'default'     => 'all',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'confirmed' => array(
                        'description' => 'Filter by confirmation status.',
                        'type'        => 'boolean',
                    ),
                    'date_from' => array(
                        'description' => 'Filter invoices from date (Y-m-d format).',
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'date_to' => array(
                        'description' => 'Filter invoices to date (Y-m-d format).',
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'orderby' => array(
                        'description' => 'Sort collection by object attribute.',
                        'type'        => 'string',
                        'default'     => 'date',
                        'enum'        => array('date', 'title', 'price', 'event'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'order' => array(
                        'description' => 'Order sort attribute ascending or descending.',
                        'type'        => 'string',
                        'default'     => 'desc',
                        'enum'        => array('asc', 'desc'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // Get single invoice
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_single_invoice'),
                'permission_callback' => AuthHelper::permission_callback('read_invoices'),
            )
        );

        // Update invoice
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)',
            array(
                'methods'             => 'PUT,PATCH',
                'callback'            => array(__CLASS__, 'api_update_invoice'),
                'permission_callback' => AuthHelper::permission_callback('manage_invoices'),
            )
        );

        // Get invoice PDF
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)/pdf',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_invoice_pdf'),
                'permission_callback' => AuthHelper::permission_callback('view_invoice_pdf'),
            )
        );

        // Get invoice QR codes
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)/qr-codes',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_invoice_qr_codes'),
                'permission_callback' => AuthHelper::permission_callback('invoice_qr_codes'),
            )
        );

        // RSVP List with advanced filters
        \register_rest_route(
            'mec-utility/v1',
            '/rsvps',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_rsvps'),
                'permission_callback' => AuthHelper::permission_callback('view_bookings'),
                'args'                => array(
                    'page' => array(
                        'default' => 1,
                        'type'    => 'integer',
                    ),
                    'per_page' => array(
                        'default' => 20,
                        'type'    => 'integer',
                    ),
                    'search' => array(
                        'type' => 'string',
                    ),
                    'event_id' => array(
                        'type' => 'integer',
                    ),
                    'location' => array(
                        'type' => 'string',
                    ),
                    'response' => array(
                        'type' => 'string',
                        'enum' => ['accepted', 'declined', 'pending', 'all'],
                    ),
                    'confirmation' => array(
                        'type' => 'string',
                        'enum' => ['confirmed', 'pending', 'rejected', 'all'],
                    ),
                    'verification' => array(
                        'type' => 'string',
                        'enum' => ['verified', 'pending', 'rejected', 'all'],
                    ),
                    'date_filter' => array(
                        'type' => 'string',
                        'enum' => ['all', 'today', 'tomorrow', 'this_week', 'next_week', 'this_month', 'next_month'],
                    ),
                    'order_date' => array(
                        'type' => 'string',
                        'enum' => ['today', 'yesterday', 'this_week', 'last_week', 'this_month', 'last_month', 'all'],
                    ),
                    'type_creation' => array(
                        'type' => 'string',
                        'enum' => ['manual', 'frontend', 'import', 'all'],
                    ),
                    'start_date' => array(
                        'type' => 'string',
                        'format' => 'date',
                    ),
                    'end_date' => array(
                        'type' => 'string',
                        'format' => 'date',
                    ),
                    'order_by' => array(
                        'type' => 'string',
                        'enum' => ['date', 'event', 'name', 'email', 'response', 'confirmation', 'verification'],
                        'default' => 'date',
                    ),
                    'order' => array(
                        'type' => 'string',
                        'enum' => ['asc', 'desc'],
                        'default' => 'desc',
                    ),
                ),
            )
        );

        // Single RSVP Details
        \register_rest_route(
            'mec-utility/v1',
            '/rsvps/(?P<rsvp_id>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_single_rsvp'),
                'permission_callback' => AuthHelper::permission_callback('view_bookings'),
                'args'                => array(
                    'rsvp_id' => array(
                        'required' => true,
                        'type'     => 'integer',
                    ),
                ),
            )
        );

        // Update RSVP (confirmation/verification)
        \register_rest_route(
            'mec-utility/v1',
            '/rsvps/(?P<rsvp_id>[\d]+)',
            array(
                'methods'             => 'PUT',
                'callback'            => array(__CLASS__, 'api_update_rsvp'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
                'args'                => array(
                    'rsvp_id' => array(
                        'required' => true,
                        'type'     => 'integer',
                    ),
                    'confirmation' => array(
                        'type' => 'string',
                        'sanitize_callback' => function ($value) {
                            // Convert numeric values to strings
                            if ($value === 1 || $value === '1' || $value === 1) return 'confirmed';
                            if ($value === -1 || $value === '-1' || $value === -1) return 'rejected';
                            if ($value === 0 || $value === '0' || $value === 0) return 'pending';

                            // Handle string values
                            if (in_array($value, ['confirmed', 'pending', 'rejected'])) {
                                return $value;
                            }

                            // Default to pending if invalid
                            return 'pending';
                        },
                        'validate_callback' => function ($value) {
                            // Accept both string and integer values
                            return in_array($value, ['confirmed', 'pending', 'rejected', 1, 0, -1, '1', '0', '-1'], true);
                        },
                    ),
                    'verification' => array(
                        'type' => 'string',
                        'sanitize_callback' => function ($value) {
                            // Convert numeric values to strings
                            if ($value === 1 || $value === '1' || $value === 1) return 'verified';
                            if ($value === -1 || $value === '-1' || $value === -1) return 'rejected';
                            if ($value === 0 || $value === '0' || $value === 0) return 'pending';

                            // Handle string values
                            if (in_array($value, ['verified', 'pending', 'rejected'])) {
                                return $value;
                            }

                            // Default to pending if invalid
                            return 'pending';
                        },
                        'validate_callback' => function ($value) {
                            // Accept both string and integer values
                            return in_array($value, ['verified', 'pending', 'rejected', 1, 0, -1, '1', '0', '-1'], true);
                        },
                    ),
                    'response' => array(
                        'type' => 'string',
                        'enum' => ['accepted', 'declined', 'pending'],
                    ),
                    'attendees' => array(
                        'type' => 'array',
                    ),
                    'notes' => array(
                        'type' => 'string',
                    ),
                ),
            )
        );

        // Export RSVPs CSV
        \register_rest_route(
            'mec-utility/v1',
            '/rsvps/export/csv',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_export_rsvps_csv'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
                'args'                => array(
                    'rsvp_ids' => array(
                        'required' => true,
                        'type'     => 'array',
                        'items'    => array(
                            'type' => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Export RSVPs Excel
        \register_rest_route(
            'mec-utility/v1',
            '/rsvps/export/excel',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'api_export_rsvps_excel'),
                'permission_callback' => AuthHelper::permission_callback('manage_bookings'),
                'args'                => array(
                    'rsvp_ids' => array(
                        'required' => true,
                        'type'     => 'array',
                        'items'    => array(
                            'type' => 'integer',
                        ),
                    ),
                ),
            )
        );

        // RSVP Stats
        \register_rest_route(
            'mec-utility/v1',
            '/rsvps/stats',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_rsvp_stats'),
                'permission_callback' => AuthHelper::permission_callback('view_bookings'),
                'args'                => array(
                    'event_id' => array(
                        'type' => 'integer',
                    ),
                    'date_filter' => array(
                        'type' => 'string',
                        'enum' => ['all', 'today', 'this_week', 'this_month'],
                    ),
                ),
            )
        );

        // Status endpoint
        \register_rest_route(
            'mec-utility/v1',
            '/status',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'api_status'),
                'permission_callback' => '__return_true',
            )
        );
    }

    /**
     * API plugin not available callback
     */
    public static function api_plugin_not_available($request)
    {
        return new \WP_Error(
            'plugin_not_available',
            __('MEC Invoice plugin is not installed or activated. Please install and activate the MEC Invoice plugin to use this feature.', 'mec-utility'),
            array('status' => 501)
        );
    }

    /**
     * API status callback
     */
    public static function api_status($request)
    {
        return \rest_ensure_response(array(
            'status'      => 'active',
            'version'     => MEC_UTILITY_VERSION,
            'plugin'      => 'mec-utility',
            'namespace'   => 'mec-utility/v1',
            'method'      => 'direct_registration',
            'timestamp'   => \current_time('mysql'),
            'mec_active'  => \is_plugin_active('modern-events-calendar/mec.php'),
        ));
    }

    /**
     * API events callback
     */
    public static function api_events($request)
    {
        // No pagination: fetch all matching events
        $per_page = -1;
        $page = 1;
        $search = $request->get_param('search') ?: '';
        $status = $request->get_param('status') ?: 'any'; // Support all post statuses by default
        $orderby = $request->get_param('orderby') ?: 'date';
        $order = $request->get_param('order') ?: 'asc';

        // Date filters
        $start_date = $request->get_param('start_date');
        $end_date = $request->get_param('end_date');
        $date_filter = $request->get_param('date_filter');
        $month_param = $request->get_param('month');
        $year_param = $request->get_param('year');

        if ($month_param !== null && $month_param !== '') {
            $month = intval($month_param);
            if ($month >= 1 && $month <= 12) {
                $year = ($year_param !== null && $year_param !== '') ? intval($year_param) : intval(\current_time('Y'));
                if ($year < 1970) {
                    $year = 1970;
                } elseif ($year > 2100) {
                    $year = 2100;
                }
                $month_start = sprintf('%04d-%02d-01', $year, $month);
                $month_end = date('Y-m-t', strtotime($month_start));
                $start_date = $month_start;
                $end_date = $month_end;
            }
        }

        // Other filters
        $category = $request->get_param('category');
        $location = $request->get_param('location');
        $organizer = $request->get_param('organizer');

        $args = array(
            'post_type'      => 'mec-events',
            'post_status'    => $status, // Changed from hardcoded 'publish' to support all statuses
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'meta_query'     => array(
                array(
                    'key'     => 'mec_start_date',
                    'compare' => 'EXISTS',
                ),
            ),
        );

        // Add search query
        if (! empty($search)) {
            $args['s'] = $search;
        }

        // Add date filters using mec_events table
        $args = self::apply_date_filters($args, $start_date, $end_date, $date_filter);

        // Add taxonomy filters
        if (! empty($category)) {
            $args['tax_query'][] = array(
                'taxonomy' => 'mec_category',
                'field'    => is_numeric($category) ? 'term_id' : 'slug',
                'terms'    => $category,
            );
        }

        // Add meta filters for location and organizer
        if (! empty($location)) {
            $args['meta_query'][] = array(
                'key'     => 'mec_location_id',
                'value'   => $location,
                'compare' => '=',
            );
        }

        if (! empty($organizer)) {
            $args['meta_query'][] = array(
                'key'     => 'mec_organizer_id',
                'value'   => $organizer,
                'compare' => '=',
            );
        }

        // Set ordering
        if ($orderby === 'start_date') {
            $args['meta_key'] = 'mec_start_date';
            $args['orderby'] = 'meta_value';
            $args['order'] = strtoupper($order);
        } else {
            $args['orderby'] = $orderby;
            $args['order'] = strtoupper($order);
        }

        $query = new \WP_Query($args);
        $events = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $event_id = \get_the_ID();
                $events[] = self::prepare_event_data(\get_post($event_id));
            }
            \wp_reset_postdata();
        }

        // Calculate pagination info
        $total_items = $query->found_posts;
        $total_pages = $query->max_num_pages;

        $response_data = [
            'events' => $events,
            'pagination' => [
                'total' => $total_items,
                'per_page' => $per_page,
                'current_page' => $page,
                'total_pages' => $total_pages,
                'has_more' => $page < $total_pages
            ]
        ];

        $response = \rest_ensure_response($response_data);
        $response->header('X-WP-Total', $total_items);
        $response->header('X-WP-TotalPages', $total_pages);

        return $response;
    }

    /**
     * Lightweight Event List API
     * Returns a minimal set of fields for performance-sensitive clients
     */
    public static function api_event_list($request)
    {
        global $wpdb;

        // No pagination: fetch all matching events
        $per_page = -1;
        $page = 1;

        $status_param = $request->get_param('status');
        $status = ($status_param !== null && $status_param !== '') ? sanitize_text_field($status_param) : 'any'; // Support all post statuses by default

        $orderby_param = $request->get_param('orderby');
        $orderby = ($orderby_param !== null && $orderby_param !== '') ? sanitize_text_field($orderby_param) : 'date';

        $order_param = $request->get_param('order');
        $order = ($order_param !== null && $order_param !== '') ? strtoupper(sanitize_text_field($order_param)) : 'ASC';

        $search_param = $request->get_param('search');
        $search = ($search_param !== null && $search_param !== '') ? sanitize_text_field($search_param) : '';

        $labels = self::sanitize_id_array_param($request->get_param('labels'));
        $locations = self::sanitize_id_array_param($request->get_param('locations'));
        $organizers = self::sanitize_id_array_param($request->get_param('organizers'));

        // Date filters
        $start_date_param = $request->get_param('start_date');
        $end_date_param = $request->get_param('end_date');
        $date_filter_param = $request->get_param('date_filter');

        $start_date = ($start_date_param !== null && $start_date_param !== '') ? sanitize_text_field($start_date_param) : '';
        $end_date = ($end_date_param !== null && $end_date_param !== '') ? sanitize_text_field($end_date_param) : '';
        $date_filter = ($date_filter_param !== null && $date_filter_param !== '') ? sanitize_text_field($date_filter_param) : '';
        $month_param = $request->get_param('month');
        $year_param = $request->get_param('year');

        if ($month_param !== null && $month_param !== '') {
            $month = intval($month_param);
            if ($month >= 1 && $month <= 12) {
                $year = ($year_param !== null && $year_param !== '') ? intval($year_param) : intval(\current_time('Y'));
                if ($year < 1970) {
                    $year = 1970;
                } elseif ($year > 2100) {
                    $year = 2100;
                }
                $start_date = sprintf('%04d-%02d-01', $year, $month);
                $end_date = date('Y-m-t', strtotime($start_date));
            }
        }

        // Expired/Available filters
        $is_expired_param = $request->get_param('is_expired');
        $is_available_param = $request->get_param('is_available');
        $filter_expired = ($is_expired_param !== null) ? filter_var($is_expired_param, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) : null;
        $filter_available = ($is_available_param !== null) ? filter_var($is_available_param, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) : null;

        $args = array(
            'post_type'      => 'mec-events',
            'post_status'    => $status, // Changed from hardcoded 'publish' to support all statuses
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'     => 'mec_start_date',
                    'compare' => 'EXISTS',
                ),
            ),
        );

        // Apply date filters via helper used in api_events
        $args = self::apply_date_filters($args, $start_date, $end_date, $date_filter);

        if (!empty($search)) {
            $args['s'] = $search;
        }

        $tax_query = array();

        if (!empty($labels)) {
            $tax_query[] = array(
                'taxonomy' => 'mec_label',
                'field' => 'term_id',
                'terms' => array_map('absint', $labels),
                'include_children' => false,
            );
        }

        if (!empty($locations)) {
            $tax_query[] = array(
                'taxonomy' => 'mec_location',
                'field' => 'term_id',
                'terms' => array_map('absint', $locations),
                'include_children' => false,
            );
        }

        if (!empty($organizers)) {
            $tax_query[] = array(
                'taxonomy' => 'mec_organizer',
                'field' => 'term_id',
                'terms' => array_map('absint', $organizers),
                'include_children' => false,
            );
        }

        if (!empty($tax_query)) {
            if (count($tax_query) > 1) {
                $tax_query['relation'] = 'AND';
            }
            $args['tax_query'] = $tax_query;
        }

        // Ordering
        if ($orderby === 'start_date') {
            $args['meta_key'] = 'mec_start_date';
            $args['orderby'] = 'meta_value';
            $args['order'] = $order;
        } else {
            $args['orderby'] = $orderby;
            $args['order'] = $order;
        }

        $query = new \WP_Query($args);
        $event_ids = $query->posts;

        // Preload minimal fields
        $events = array();

        // Occurrence limit per event
        $occ_limit = (int) ($request->get_param('occurrences_limit') ?: 10);

        $now_ts = current_time('timestamp');

        foreach ($event_ids as $event_id) {
            $title = self::clean_title(get_the_title($event_id));
            $meta_color = get_post_meta($event_id, 'mec_color', true);

            // Preferred display date
            $start_date_val = get_post_meta($event_id, 'mec_start_date', true);
            $event_date_fallback = get_post_meta($event_id, 'event_date', true);

            // raw_mec_data.start via mec_events table
            $mec_row = $wpdb->get_row($wpdb->prepare("SELECT `start` FROM {$wpdb->prefix}mec_events WHERE post_id = %d", $event_id));
            $raw_start = $mec_row ? $mec_row->start : '';

            // mec_data.start_date equals mec_start_date
            $display_date = $start_date_val ?: ($event_date_fallback ?: ($raw_start ?: $start_date_val));

            // Build occurrences: recurring via mec_dates, non-recurring via multi-day expansion
            $occurrences = array();
            if ($occ_limit > 0) {
                $occurrence_index_counter = 0;
                // Determine if recurring
                $repeat_status = get_post_meta($event_id, 'mec_repeat_status', true);
                $is_recurring = ($repeat_status === '1');

                if ($is_recurring) {
                    // Optional date window filters for occurrences
                    $tstart_clause = '';
                    $tend_clause = '';
                    if (!empty($start_date)) {
                        $tstart_clause = $wpdb->prepare(' AND `tstart` >= %d', strtotime($start_date . ' 00:00:00'));
                    }
                    if (!empty($end_date)) {
                        $tend_clause = $wpdb->prepare(' AND `tstart` <= %d', strtotime($end_date . ' 23:59:59'));
                    }

                    $occ_sql = $wpdb->prepare(
                        "SELECT `tstart`,`tend` FROM `{$wpdb->prefix}mec_dates` WHERE `post_id`=%d AND `public`=1" . $tstart_clause . $tend_clause . " ORDER BY `tstart` ASC LIMIT %d",
                        $event_id,
                        $occ_limit
                    );
                    $rows = $wpdb->get_results($occ_sql);
                    foreach ($rows as $row) {
                        $tstart = (int) $row->tstart;
                        $tend = (int) $row->tend;
                        $current_index = $occurrence_index_counter++;
                        $occurrences[] = array(
                            'occurrence_id' => $event_id . '_' . $tstart,
                            'start_date' => date('Y-m-d', $tstart),
                            'end_date' => date('Y-m-d', $tend),
                            'start_time' => date('H:i:s', $tstart),
                            'end_time' => date('H:i:s', $tend),
                            'start_datetime' => date('Y-m-d H:i:s', $tstart),
                            'end_datetime' => date('Y-m-d H:i:s', $tend),
                            'is_today' => date('Y-m-d', $tstart) === date('Y-m-d', $now_ts),
                            'is_past' => $tend < $now_ts,
                            'is_upcoming' => $tstart > $now_ts,
                            'attendee_count' => self::fast_occurrence_attendee_count($event_id, $tstart),
                            'occurrence_index' => $current_index,
                        );
                    }
                } else {
                    // Multi-day or single-day non-recurring: expand per day within optional window
                    $allday = get_post_meta($event_id, 'mec_allday', true);
                    $start_meta = get_post_meta($event_id, 'mec_start_date', true);
                    $end_meta = get_post_meta($event_id, 'mec_end_date', true);
                    if (empty($start_meta)) {
                        $start_meta = $display_date;
                    }
                    if (empty($end_meta)) {
                        $end_meta = $start_meta;
                    }

                    // Clip span to requested window if provided
                    $span_start_ts = strtotime($start_meta);
                    $span_end_ts = strtotime($end_meta);
                    if (!empty($start_date)) {
                        $span_start_ts = max($span_start_ts, strtotime($start_date));
                    }
                    if (!empty($end_date)) {
                        $span_end_ts = min($span_end_ts, strtotime($end_date));
                    }

                    // Time components
                    $start_time_hour = intval(get_post_meta($event_id, 'mec_start_time_hour', true));
                    $start_time_minutes = intval(get_post_meta($event_id, 'mec_start_time_minutes', true));
                    $start_time_ampm = strtoupper(get_post_meta($event_id, 'mec_start_time_ampm', true));
                    $end_time_hour = intval(get_post_meta($event_id, 'mec_end_time_hour', true));
                    $end_time_minutes = intval(get_post_meta($event_id, 'mec_end_time_minutes', true));
                    $end_time_ampm = strtoupper(get_post_meta($event_id, 'mec_end_time_ampm', true));

                    $to_seconds = function ($hour, $minutes, $ampm) {
                        $hour = (int) $hour;
                        $minutes = (int) $minutes;
                        $ampm = strtoupper($ampm ?: 'AM');
                        if ($ampm === 'AM' && $hour === 12) $hour = 0;
                        elseif ($ampm === 'PM' && $hour !== 12) $hour += 12;
                        return ($hour * 3600) + ($minutes * 60);
                    };

                    $start_seconds = $to_seconds($start_time_hour ?: 8, $start_time_minutes ?: 0, $start_time_ampm ?: 'AM');
                    $end_seconds = $to_seconds($end_time_hour ?: 6, $end_time_minutes ?: 0, $end_time_ampm ?: 'PM');

                    $count = 0;
                    for ($day_ts = $span_start_ts; $day_ts <= $span_end_ts && $count < $occ_limit; $day_ts = strtotime('+1 day', $day_ts)) {
                        $date_key = date('Y-m-d', $day_ts);
                        if ($allday == '1') {
                            $tstart = strtotime($date_key . ' 00:00:00');
                            $tend = strtotime($date_key . ' 23:59:59');
                        } else {
                            $tstart = strtotime($date_key . ' 00:00:00') + $start_seconds;
                            $tend = strtotime($date_key . ' 00:00:00') + $end_seconds;
                            if ($tend <= $tstart) {
                                $tend = strtotime($date_key . ' 00:00:00') + 24 * 3600 + max(0, $end_seconds);
                            }
                        }

                        $current_index = $occurrence_index_counter++;
                        $occurrences[] = array(
                            'occurrence_id' => $event_id . '_' . $tstart,
                            'start_date' => date('Y-m-d', $tstart),
                            'end_date' => date('Y-m-d', $tend),
                            'start_time' => date('H:i:s', $tstart),
                            'end_time' => date('H:i:s', $tend),
                            'start_datetime' => date('Y-m-d H:i:s', $tstart),
                            'end_datetime' => date('Y-m-d H:i:s', $tend),
                            'is_today' => date('Y-m-d', $tstart) === date('Y-m-d', $now_ts),
                            'is_past' => $tend < $now_ts,
                            'is_upcoming' => $tstart > $now_ts,
                            'attendee_count' => self::fast_occurrence_attendee_count($event_id, $tstart),
                            'occurrence_index' => $current_index,
                        );
                        $count++;
                    }
                }
            }

            // If no occurrences, fallback attendee total via attendees stats endpoint logic (fast query)
            $fallback_attendee_total = null;
            if (empty($occurrences)) {
                $fallback_attendee_total = self::fast_event_attendee_total($event_id);
            } else {
                // For events with occurrences, still provide total attendee count
                $fallback_attendee_total = self::fast_event_attendee_total($event_id);
            }

            // Get all location terms for this event
            $location_terms = wp_get_post_terms($event_id, 'mec_location', ['fields' => 'all']);
            $locations_data = array();
            if (!is_wp_error($location_terms) && is_array($location_terms)) {
                foreach ($location_terms as $location_term) {
                    $location_meta = get_term_meta($location_term->term_id);
                    $locations_data[] = array(
                        'id' => (int) $location_term->term_id,
                        'name' => $location_term->name,
                        'label' => $location_term->name, // Location label (same as name)
                        'slug' => $location_term->slug,
                        'description' => $location_term->description,
                        'address' => isset($location_meta['address'][0]) ? $location_meta['address'][0] : '',
                        'latitude' => isset($location_meta['latitude'][0]) ? $location_meta['latitude'][0] : '',
                        'longitude' => isset($location_meta['longitude'][0]) ? $location_meta['longitude'][0] : '',
                        'url' => isset($location_meta['url'][0]) ? $location_meta['url'][0] : '',
                        'tel' => isset($location_meta['tel'][0]) ? $location_meta['tel'][0] : '',
                        'thumbnail' => isset($location_meta['thumbnail'][0]) ? $location_meta['thumbnail'][0] : '',
                    );
                }
            }

            // Get all organizer terms for this event
            $organizer_terms = wp_get_post_terms($event_id, 'mec_organizer', ['fields' => 'all']);
            $organizers_data = array();
            if (!is_wp_error($organizer_terms) && is_array($organizer_terms)) {
                foreach ($organizer_terms as $organizer_term) {
                    $organizer_meta = get_term_meta($organizer_term->term_id);
                    $organizers_data[] = array(
                        'id' => (int) $organizer_term->term_id,
                        'name' => $organizer_term->name,
                        'slug' => $organizer_term->slug,
                        'description' => $organizer_term->description,
                        'email' => isset($organizer_meta['email'][0]) ? $organizer_meta['email'][0] : '',
                        'tel' => isset($organizer_meta['tel'][0]) ? $organizer_meta['tel'][0] : '',
                        'url' => isset($organizer_meta['url'][0]) ? $organizer_meta['url'][0] : '',
                        'page_label' => isset($organizer_meta['page_label'][0]) ? $organizer_meta['page_label'][0] : '',
                        'thumbnail' => isset($organizer_meta['thumbnail'][0]) ? $organizer_meta['thumbnail'][0] : '',
                    );
                }
            }

            // Determine if event is expired/available
            // Check based on end date and time
            $end_date_meta = get_post_meta($event_id, 'mec_end_date', true);
            $end_time_hour = intval(get_post_meta($event_id, 'mec_end_time_hour', true));
            $end_time_minutes = intval(get_post_meta($event_id, 'mec_end_time_minutes', true));
            $end_time_ampm = strtoupper(get_post_meta($event_id, 'mec_end_time_ampm', true));
            $allday = get_post_meta($event_id, 'mec_allday', true);

            $is_expired = false;
            if (!empty($end_date_meta)) {
                // Convert time to 24-hour format
                $to_24hour = function ($hour, $minutes, $ampm) {
                    $hour = (int) $hour;
                    $minutes = (int) $minutes;
                    $ampm = strtoupper($ampm ?: 'AM');
                    if ($ampm === 'AM' && $hour === 12) $hour = 0;
                    elseif ($ampm === 'PM' && $hour !== 12) $hour += 12;
                    return sprintf('%02d:%02d:00', $hour, $minutes);
                };

                if ($allday == '1') {
                    // For all-day events, check if end date is past today
                    $end_timestamp = strtotime($end_date_meta . ' 23:59:59');
                    $is_expired = $end_timestamp < $now_ts;
                } else {
                    // For timed events, check end datetime
                    $end_time_str = $to_24hour($end_time_hour ?: 6, $end_time_minutes ?: 0, $end_time_ampm ?: 'PM');
                    $end_datetime = $end_date_meta . ' ' . $end_time_str;
                    $end_timestamp = strtotime($end_datetime);
                    $is_expired = $end_timestamp < $now_ts;
                }
            } else {
                // If no end date, check if start date is past
                if (!empty($display_date)) {
                    $start_timestamp = strtotime($display_date . ' 00:00:00');
                    $is_expired = $start_timestamp < $now_ts;
                }
            }

            $is_available = !$is_expired;

            // Apply expired/available filter if specified
            if ($filter_expired !== null && $is_expired !== $filter_expired) {
                continue;
            }
            if ($filter_available !== null && $is_available !== $filter_available) {
                continue;
            }

            $events[] = array(
                'id' => (int) $event_id,
                'title' => $title,
                'meta' => array(
                    'mec_color' => $meta_color,
                ),
                'start_date' => $display_date,
                'occurrences' => $occurrences,
                'attendee_count' => $fallback_attendee_total,
                'locations' => $locations_data,
                'organizers' => $organizers_data,
                'is_expired' => $is_expired,
                'is_available' => $is_available,
                'hourly_schedules' => self::get_hourly_schedule_data($event_id),
            );
        }

        return \rest_ensure_response(array(
            'events' => $events
        ));
    }

    /**
     * Fast attendee count for a specific occurrence (timestamp)
     */
    /**
     * Check if an attendee is valid (not deleted/empty)
     */
    private static function is_valid_attendee($attendee)
    {
        if (!is_array($attendee)) {
            return false;
        }
        
        // An attendee is valid if it has at least name or email (basic validation)
        // Empty arrays or null values are considered invalid
        $has_name = !empty($attendee['name']) && trim($attendee['name']) !== '';
        $has_email = !empty($attendee['email']) && trim($attendee['email']) !== '';
        
        return $has_name || $has_email;
    }

    private static function fast_occurrence_attendee_count($event_id, $occurrence_ts)
    {
        global $wpdb;
        // Count attendees across verified+confirmed bookings for this occurrence timestamp
        $bookings = $wpdb->get_results($wpdb->prepare(
            "SELECT `booking_id` FROM `{$wpdb->prefix}mec_bookings` WHERE `event_id`=%d AND `timestamp`=%d AND `status` IN ('publish','future') AND `confirmed`='1' AND `verified`='1'",
            $event_id,
            $occurrence_ts
        ));
        $total = 0;
        foreach ($bookings as $b) {
            $atts = get_post_meta($b->booking_id, 'mec_attendees', true);
            if (is_array($atts)) {
                foreach ($atts as $k => $v) {
                    // Only count numeric keys (exclude 'attachments' etc.) and validate attendee is not empty/deleted
                    if (is_numeric($k) && self::is_valid_attendee($v)) {
                        $total++;
                    }
                }
            }
        }
        return $total;
    }

    /**
     * Fast attendee total for non-occurrence scenario (all verified+confirmed bookings)
     */
    private static function fast_event_attendee_total($event_id)
    {
        global $wpdb;
        $bookings = $wpdb->get_results($wpdb->prepare(
            "SELECT `booking_id` FROM `{$wpdb->prefix}mec_bookings` WHERE `event_id`=%d AND `status` IN ('publish','future') AND `confirmed`='1' AND `verified`='1'",
            $event_id
        ));
        $total = 0;
        foreach ($bookings as $b) {
            $atts = get_post_meta($b->booking_id, 'mec_attendees', true);
            if (is_array($atts)) {
                foreach ($atts as $k => $v) {
                    // Only count numeric keys (exclude 'attachments' etc.) and validate attendee is not empty/deleted
                    if (is_numeric($k) && self::is_valid_attendee($v)) {
                        $total++;
                    }
                }
            }
        }
        return $total;
    }

    /**
     * Normalize the "more_info_target" value coming from API clients into
     * the canonical MEC values: "_self" or "_blank".
     *
     * Clients (like the mobile app) may send human-readable labels
     * such as "Current Window" or "New Window". This helper ensures
     * the stored meta always matches what MEC core expects.
     *
     * @param string $value Raw target value from client
     * @return string Normalized target ("_self" or "_blank")
     */
    private static function normalize_more_info_target($value)
    {
        $v = strtolower(trim((string) $value));

        if (in_array($v, ['_blank', 'new window', 'new_window', 'blank'], true)) {
            return '_blank';
        }

        // Default and all other cases map to "_self"
        return '_self';
    }

    /**
     * Sanitize array-style request parameters containing IDs
     */
    public static function sanitize_id_array_param($value)
    {
        if ($value === null || $value === '' || $value === 'all' || $value === 'any') {
            return array();
        }

        if ($value instanceof \Traversable) {
            $value = iterator_to_array($value);
        }

        if (!is_array($value)) {
            $value = explode(',', (string) $value);
        }

        $value = array_map('absint', (array) $value);
        $value = array_filter($value, function ($id) {
            return $id > 0;
        });

        return array_values(array_unique($value));
    }

    /**
     * Apply Zoom meta payload to event
     */
    private static function apply_zoom_meta($post_id, array $zoom_data)
    {
        if (empty($zoom_data)) {
            return;
        }

        $map = [
            'event_type' => [
                'meta' => 'mec_zoom_event',
                'type' => 'enum',
                'options' => ['none', 'webinar', 'meeting'],
                'default' => 'none',
            ],
            'badge_shortcode' => [
                'meta' => 'mec_zoom_badge_shortcode',
                'type' => 'bool',
            ],
            'badge_single' => [
                'meta' => 'mec_zoom_badge_single',
                'type' => 'bool',
            ],
            'display_booking_history' => [
                'meta' => 'mec_display_booking_history',
                'type' => 'flag',
            ],
            'join_url' => [
                'meta' => 'mec_zoom_join_url',
                'type' => 'url',
            ],
            'join_title' => [
                'meta' => 'mec_zoom_join_title',
                'type' => 'text',
            ],
            'join_target' => [
                'meta' => 'mec_zoom_join_target',
                'type' => 'enum',
                'options' => ['_self', '_blank'],
                'default' => '_self',
            ],
            'display_join_in_booking' => [
                'meta' => 'mec_zoom_display_join_in_booking',
                'type' => 'bool',
            ],
            'link_url' => [
                'meta' => 'mec_zoom_link_url',
                'type' => 'url',
            ],
            'link_title' => [
                'meta' => 'mec_zoom_link_title',
                'type' => 'text',
            ],
            'link_target' => [
                'meta' => 'mec_zoom_link_target',
                'type' => 'enum',
                'options' => ['_self', '_blank'],
                'default' => '_self',
            ],
            'display_link_in_booking' => [
                'meta' => 'mec_zoom_display_link_in_booking',
                'type' => 'bool',
            ],
            'embed' => [
                'meta' => 'mec_zoom_embed',
                'type' => 'textarea',
            ],
            'display_embed_in_booking' => [
                'meta' => 'mec_zoom_display_embed_in_booking',
                'type' => 'bool',
            ],
            'hide_info_before_start' => [
                'meta' => 'mec_zoom_hide_info_before_start',
                'type' => 'bool',
            ],
            'show_info_time' => [
                'meta' => 'mec_zoom_show_info_time',
                'type' => 'int',
            ],
            'show_info_hm' => [
                'meta' => 'mec_zoom_show_info_hm',
                'type' => 'enum',
                'options' => ['day', 'hour', 'minute'],
                'default' => 'day',
            ],
            'hide_info_when_live' => [
                'meta' => 'mec_zoom_hide_info',
                'type' => 'bool',
            ],
            'password' => [
                'meta' => 'mec_zoom_password',
                'type' => 'text',
            ],
            'display_password_in_booking' => [
                'meta' => 'mec_zoom_display_password_in_booking',
                'type' => 'bool',
            ],
            'meeting_id' => [
                'meta' => 'mec_zoom_meeting_id',
                'type' => 'text',
            ],
            'display_meeting_id_in_booking' => [
                'meta' => 'mec_zoom_display_meeting_id_in_booking',
                'type' => 'bool',
            ],
        ];

        self::apply_meta_map($post_id, $zoom_data, $map);
    }

    /**
     * Apply Virtual Event meta payload to event
     */
    private static function apply_virtual_event_meta($post_id, array $virtual_data)
    {
        if (empty($virtual_data)) {
            return;
        }

        $map = [
            'enabled' => [
                'meta' => 'mec_virtual_event',
                'type' => 'bool',
            ],
            'badge_shortcode' => [
                'meta' => 'mec_virtual_badge_shortcode',
                'type' => 'bool',
            ],
            'badge_single' => [
                'meta' => 'mec_virtual_badge_single',
                'type' => 'bool',
            ],
            'display_user_booking_history' => [
                'meta' => 'mec_virtual_display_user_booking_history',
                'type' => 'yesno',
            ],
            'link_url' => [
                'meta' => 'mec_virtual_link_url',
                'type' => 'url',
            ],
            'link_title' => [
                'meta' => 'mec_virtual_link_title',
                'type' => 'text',
            ],
            'link_target' => [
                'meta' => 'mec_virtual_link_target',
                'type' => 'enum',
                'options' => ['_self', '_blank'],
                'default' => '_self',
            ],
            'display_link_in_booking' => [
                'meta' => 'mec_virtual_display_link_in_booking',
                'type' => 'bool',
            ],
            'password' => [
                'meta' => 'mec_virtual_password',
                'type' => 'text',
            ],
            'display_password_in_booking' => [
                'meta' => 'mec_virtual_display_password_in_booking',
                'type' => 'bool',
            ],
            'embed' => [
                'meta' => 'mec_virtual_embed',
                'type' => 'textarea',
            ],
            'display_embed_in_booking' => [
                'meta' => 'mec_virtual_display_embed_in_booking',
                'type' => 'bool',
            ],
            'hide_info_before_start' => [
                'meta' => 'mec_virtual_hide_info_before_start',
                'type' => 'bool',
            ],
            'show_info_time' => [
                'meta' => 'mec_virtual_show_info_time',
                'type' => 'int',
            ],
            'show_info_hm' => [
                'meta' => 'mec_virtual_show_info_hm',
                'type' => 'enum',
                'options' => ['day', 'hour', 'minute'],
                'default' => 'day',
            ],
            'hide_info_when_live' => [
                'meta' => 'mec_virtual_hide_info',
                'type' => 'bool',
            ],
        ];

        self::apply_meta_map($post_id, $virtual_data, $map);
    }

    /**
     * Generic meta applier using field map definitions
     *
     * @param int   $post_id
     * @param array $payload
     * @param array $map
     * @return void
     */
    private static function apply_meta_map($post_id, array $payload, array $map)
    {
        foreach ($map as $public_key => $config) {
            if (empty($config['meta'])) {
                continue;
            }

            $meta_key = $config['meta'];
            $candidate_keys = [$public_key];

            if ($public_key !== $meta_key) {
                $candidate_keys[] = $meta_key;
            }

            if (!empty($config['aliases']) && is_array($config['aliases'])) {
                $candidate_keys = array_merge($candidate_keys, $config['aliases']);
            }

            $found = false;
            $raw_value = null;

            foreach ($candidate_keys as $candidate) {
                if (array_key_exists($candidate, $payload)) {
                    $raw_value = $payload[$candidate];
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                continue;
            }

            $sanitized = self::sanitize_meta_map_value($raw_value, $config);
            \update_post_meta($post_id, $meta_key, $sanitized);
        }
    }

    /**
     * Sanitize mapped meta value according to configuration
     *
     * @param mixed $value
     * @param array $config
     * @return mixed
     */
    private static function sanitize_meta_map_value($value, array $config)
    {
        $type = $config['type'] ?? 'text';

        switch ($type) {
            case 'bool':
                return self::to_bool($value);
            case 'flag':
                return self::to_bool($value) ? '1' : '0';
            case 'yesno':
                if (is_string($value)) {
                    $compare = strtolower(trim($value));
                    if (in_array($compare, ['yes', 'no'], true)) {
                        return $compare;
                    }
                }
                return self::to_bool($value) ? 'yes' : 'no';
            case 'int':
                return \absint($value);
            case 'url':
                return $value !== null ? \esc_url_raw((string) $value) : '';
            case 'textarea':
                return $value !== null ? \wp_kses_post((string) $value) : '';
            case 'enum':
                $options = $config['options'] ?? [];
                $default = $config['default'] ?? ($options[0] ?? '');
                $candidate = $value !== null ? strtolower(trim((string) $value)) : '';
                foreach ($options as $option) {
                    if (strtolower($option) === $candidate) {
                        return $option;
                    }
                }
                return $default;
            case 'text':
            default:
                return $value !== null ? \sanitize_text_field((string) $value) : '';
        }
    }

    /**
     * Convert mixed value to boolean
     */
    private static function to_bool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return ((int) $value) === 1;
        }

        if (is_string($value)) {
            $trimmed = strtolower(trim($value));
            return in_array($trimmed, ['1', 'true', 'yes', 'on'], true);
        }

        return (bool) $value;
    }

    /**
     * Get Zoom meta formatted for API response
     */
    private static function get_zoom_meta($event_id): array
    {
        $event_type = \get_post_meta($event_id, 'mec_zoom_event', true);

        return [
            'event_type' => $event_type !== '' ? $event_type : 'none',
            'badge_shortcode' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_badge_shortcode', true)),
            'badge_single' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_badge_single', true)),
            'display_booking_history' => self::to_bool(\get_post_meta($event_id, 'mec_display_booking_history', true)),
            'join_url' => \get_post_meta($event_id, 'mec_zoom_join_url', true) ?: '',
            'join_title' => \get_post_meta($event_id, 'mec_zoom_join_title', true) ?: '',
            'join_target' => \get_post_meta($event_id, 'mec_zoom_join_target', true) ?: '_self',
            'display_join_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_display_join_in_booking', true)),
            'link_url' => \get_post_meta($event_id, 'mec_zoom_link_url', true) ?: '',
            'link_title' => \get_post_meta($event_id, 'mec_zoom_link_title', true) ?: '',
            'link_target' => \get_post_meta($event_id, 'mec_zoom_link_target', true) ?: '_self',
            'display_link_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_display_link_in_booking', true)),
            'embed' => \get_post_meta($event_id, 'mec_zoom_embed', true) ?: '',
            'display_embed_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_display_embed_in_booking', true)),
            'hide_info_before_start' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_hide_info_before_start', true)),
            'show_info_time' => \absint(\get_post_meta($event_id, 'mec_zoom_show_info_time', true)),
            'show_info_hm' => \get_post_meta($event_id, 'mec_zoom_show_info_hm', true) ?: 'day',
            'hide_info_when_live' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_hide_info', true)),
            'password' => \get_post_meta($event_id, 'mec_zoom_password', true) ?: '',
            'display_password_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_display_password_in_booking', true)),
            'meeting_id' => \get_post_meta($event_id, 'mec_zoom_meeting_id', true) ?: '',
            'display_meeting_id_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_zoom_display_meeting_id_in_booking', true)),
        ];
    }

    /**
     * Get Virtual Event meta formatted for API response
     */
    private static function get_virtual_event_meta($event_id): array
    {
        $booking_history_raw = \get_post_meta($event_id, 'mec_virtual_display_user_booking_history', true);

        return [
            'enabled' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_event', true)),
            'badge_shortcode' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_badge_shortcode', true)),
            'badge_single' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_badge_single', true)),
            'display_user_booking_history' => ($booking_history_raw === 'yes'),
            'link_url' => \get_post_meta($event_id, 'mec_virtual_link_url', true) ?: '',
            'link_title' => \get_post_meta($event_id, 'mec_virtual_link_title', true) ?: '',
            'link_target' => \get_post_meta($event_id, 'mec_virtual_link_target', true) ?: '_self',
            'display_link_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_display_link_in_booking', true)),
            'password' => \get_post_meta($event_id, 'mec_virtual_password', true) ?: '',
            'display_password_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_display_password_in_booking', true)),
            'embed' => \get_post_meta($event_id, 'mec_virtual_embed', true) ?: '',
            'display_embed_in_booking' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_display_embed_in_booking', true)),
            'hide_info_before_start' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_hide_info_before_start', true)),
            'show_info_time' => \absint(\get_post_meta($event_id, 'mec_virtual_show_info_time', true)),
            'show_info_hm' => \get_post_meta($event_id, 'mec_virtual_show_info_hm', true) ?: 'day',
            'hide_info_when_live' => self::to_bool(\get_post_meta($event_id, 'mec_virtual_hide_info', true)),
        ];
    }

    /**
     * Get formatted hourly schedule data for an event
     */
    private static function get_hourly_schedule_data($event_id): array
    {
        $raw = \get_post_meta($event_id, 'mec_hourly_schedules', true);
        if (empty($raw)) {
            return [];
        }

        if (!is_array($raw)) {
            $raw = \maybe_unserialize($raw);
        }

        if (!is_array($raw)) {
            return [];
        }

        $result = [];
        foreach ($raw as $day) {
            if (!is_array($day)) {
                continue;
            }

            $day_title = isset($day['title']) ? sanitize_text_field($day['title']) : '';
            $schedules = [];

            if (!empty($day['schedules']) && is_array($day['schedules'])) {
                foreach ($day['schedules'] as $schedule) {
                    if (!is_array($schedule)) {
                        continue;
                    }

                    $speakers = [];
                    if (isset($schedule['speakers'])) {
                        $speakers = array_map('absint', (array) $schedule['speakers']);
                        $speakers = array_values(array_filter($speakers, function ($speaker) {
                            return $speaker > 0;
                        }));
                    }

                    $schedules[] = array(
                        'from' => isset($schedule['from']) ? sanitize_text_field($schedule['from']) : '',
                        'to' => isset($schedule['to']) ? sanitize_text_field($schedule['to']) : '',
                        'title' => isset($schedule['title']) ? sanitize_text_field($schedule['title']) : '',
                        'description' => isset($schedule['description']) ? \wp_kses_post($schedule['description']) : '',
                        'speakers' => $speakers,
                    );
                }
            }

            $result[] = array(
                'title' => $day_title,
                'schedules' => $schedules,
            );
        }

        return $result;
    }

    /**
     * API single event callback
     */
    public static function api_single_event($request)
    {
        $event_id = $request->get_param('id');
        $event = \get_post($event_id);

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new \WP_Error(
                'event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        return \rest_ensure_response(self::prepare_event_data($event));
    }

    /**
     * API create event callback
     */
    public static function api_create_event($request)
    {
        // Get request data
        $data = $request->get_json_params();
        if (empty($data)) {
            $data = $request->get_params();
        }

        // Basic validation
        if (empty($data['title'])) {
            return new WP_Error('missing_title', 'Title is required', array('status' => 400));
        }

        // Create the post
        $post_data = array(
            'post_title' => sanitize_text_field($data['title']),
            'post_content' => isset($data['content']) ? wp_kses_post($data['content']) : '',
            'post_excerpt' => isset($data['excerpt']) ? sanitize_text_field($data['excerpt']) : '',
            'post_type' => 'mec-events',
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
        );

        $post_id = wp_insert_post($post_data);
        if (is_wp_error($post_id)) {
            return $post_id;
        }

        // Handle featured image - supports URL, attachment ID, or file upload
        if (isset($_FILES['featured_image'])) {
            // File upload
            $attachment_id = self::handle_image_upload($_FILES['featured_image']);
            if ($attachment_id) {
                set_post_thumbnail($post_id, $attachment_id);
                $image_url = wp_get_attachment_url($attachment_id);
                if ($image_url) {
                    update_post_meta($post_id, 'mec_image', $image_url);
                }
            }
        } elseif (isset($data['featured_image']) && !empty($data['featured_image'])) {
            $featured_image = $data['featured_image'];

            // Check if it's a numeric ID
            if (is_numeric($featured_image)) {
                $attachment_id = (int)$featured_image;
                $image_url = wp_get_attachment_url($attachment_id);
                if ($image_url) {
                    update_post_meta($post_id, 'mec_image', $image_url);
                    set_post_thumbnail($post_id, $attachment_id);
                }
            }
            // Check if it's a URL
            elseif (is_string($featured_image) && filter_var($featured_image, FILTER_VALIDATE_URL)) {
                // Save URL directly to mec_image
                update_post_meta($post_id, 'mec_image', sanitize_text_field($featured_image));

                // Try to find attachment ID (only works for same-domain URLs)
                $attachment_id = attachment_url_to_postid($featured_image);
                if ($attachment_id) {
                    set_post_thumbnail($post_id, $attachment_id);
                } else {
                    // If URL is external or not found, try alternative method
                    $attachment_id = self::get_attachment_id_from_url($featured_image);
                    if ($attachment_id) {
                        set_post_thumbnail($post_id, $attachment_id);
                    }
                }
            }
        }

        // Handle gallery images - supports both URLs and attachment IDs
        if (isset($data['images']) && is_array($data['images']) && !empty($data['images'])) {
            $gallery_ids = array();
            $gallery_urls = array();

            foreach ($data['images'] as $image) {
                // If it's already a numeric ID
                if (is_numeric($image)) {
                    $id = (int)$image;
                    // Verify it's a valid attachment
                    if (wp_get_attachment_url($id)) {
                        $gallery_ids[] = $id;
                    }
                }
                // If it's a URL
                elseif (is_string($image) && filter_var($image, FILTER_VALIDATE_URL)) {
                    // Try to find attachment ID from URL
                    $attachment_id = attachment_url_to_postid($image);
                    if (!$attachment_id) {
                        // Try alternative method
                        $attachment_id = self::get_attachment_id_from_url($image);
                    }

                    if ($attachment_id) {
                        $gallery_ids[] = $attachment_id;
                    } else {
                        // If can't find attachment, store URL for potential later use
                        $gallery_urls[] = sanitize_text_field($image);
                    }
                }
            }

            // Save attachment IDs if found
            if (!empty($gallery_ids)) {
                update_post_meta($post_id, 'mec_event_gallery', $gallery_ids);
                update_post_meta($post_id, 'mec_gallery', $gallery_ids);
            }

            // Save URLs separately if no attachments found but URLs provided
            if (empty($gallery_ids) && !empty($gallery_urls)) {
                // Store URLs in a custom meta for later reference
                update_post_meta($post_id, 'mec_gallery_urls', $gallery_urls);
            }
        }

        self::handle_event_taxonomies($post_id, $data);

        // === DATE AND TIME SECTION ===
        $start_date = isset($data['start_date']) ? sanitize_text_field($data['start_date']) : date('Y-m-d');
        $end_date = isset($data['end_date']) ? sanitize_text_field($data['end_date']) : $start_date;

        // Time fields
        $start_time_hour = isset($data['start_time_hour']) ? intval($data['start_time_hour']) : 8;
        $start_time_minutes = isset($data['start_time_minutes']) ? intval($data['start_time_minutes']) : 0;
        $start_time_ampm = isset($data['start_time_ampm']) ? strtoupper(sanitize_text_field($data['start_time_ampm'])) : 'AM';

        $end_time_hour = isset($data['end_time_hour']) ? intval($data['end_time_hour']) : 6;
        $end_time_minutes = isset($data['end_time_minutes']) ? intval($data['end_time_minutes']) : 0;
        $end_time_ampm = isset($data['end_time_ampm']) ? strtoupper(sanitize_text_field($data['end_time_ampm'])) : 'PM';

        // Date/Time options
        $allday = isset($data['allday']) ? (bool)$data['allday'] : false;
        $hide_time = isset($data['hide_time']) ? (bool)$data['hide_time'] : false;
        $hide_end_time = isset($data['hide_end_time']) ? (bool)$data['hide_end_time'] : false;
        $comment = isset($data['comment']) ? sanitize_text_field($data['comment']) : '';
        $timezone = isset($data['timezone']) ? sanitize_text_field($data['timezone']) : 'global';
        $countdown_method = isset($data['countdown_method']) ? sanitize_text_field($data['countdown_method']) : 'global';

        // Calculate day seconds
        $day_start_seconds = self::time_to_seconds($start_time_hour, $start_time_minutes, $start_time_ampm);
        $day_end_seconds = self::time_to_seconds($end_time_hour, $end_time_minutes, $end_time_ampm);

        // Create date array for MEC
        $date_array = array(
            'start' => array(
                'date' => $start_date,
                'hour' => $start_time_hour,
                'minutes' => $start_time_minutes,
                'ampm' => $start_time_ampm,
            ),
            'end' => array(
                'date' => $end_date,
                'hour' => $end_time_hour,
                'minutes' => $end_time_minutes,
                'ampm' => $end_time_ampm,
            ),
            'allday' => $allday ? 1 : 0,
            'hide_time' => $hide_time ? 1 : 0,
            'hide_end_time' => $hide_end_time ? 1 : 0,
            'comment' => $comment,
        );

        // === EVENT REPEATING SECTION ===
        $repeat_status = isset($data['repeat_status']) ? (bool)$data['repeat_status'] : false;
        $repeat_type = isset($data['repeat_type']) ? sanitize_text_field($data['repeat_type']) : 'daily';
        $repeat_interval = isset($data['repeat_interval']) ? intval($data['repeat_interval']) : 1;
        $repeat_end = isset($data['repeat_end']) ? sanitize_text_field($data['repeat_end']) : 'never';
        $repeat_end_at_date = isset($data['repeat_end_at_date']) ? sanitize_text_field($data['repeat_end_at_date']) : '';
        // MEC stores occurrences as (user_input - 1) internally, adds +1 on display
        $repeat_end_at_occurrences = isset($data['repeat_end_at_occurrences']) ? (intval($data['repeat_end_at_occurrences']) - 1) : 9;
        $one_occurrence = isset($data['one_occurrence']) ? (bool)$data['one_occurrence'] : false;

        // Handle certain weekdays for repeat
        $certain_weekdays = array();
        if ($repeat_type === 'certain_weekdays' && isset($data['certain_weekdays']) && is_array($data['certain_weekdays'])) {
            $certain_weekdays = array_map('intval', $data['certain_weekdays']);
        }

        // Handle specific repeat days
        if (isset($data['repeat_monday']) && $data['repeat_monday']) $certain_weekdays[] = 1;
        if (isset($data['repeat_tuesday']) && $data['repeat_tuesday']) $certain_weekdays[] = 2;
        if (isset($data['repeat_wednesday']) && $data['repeat_wednesday']) $certain_weekdays[] = 3;
        if (isset($data['repeat_thursday']) && $data['repeat_thursday']) $certain_weekdays[] = 4;
        if (isset($data['repeat_friday']) && $data['repeat_friday']) $certain_weekdays[] = 5;
        if (isset($data['repeat_saturday']) && $data['repeat_saturday']) $certain_weekdays[] = 6;
        if (isset($data['repeat_sunday']) && $data['repeat_sunday']) $certain_weekdays[] = 0;

        $certain_weekdays = array_unique($certain_weekdays);

        // Advanced days for advanced repeat
        $advanced_days = isset($data['advanced_days']) && is_array($data['advanced_days']) ? $data['advanced_days'] : array();

        // Create repeat array
        $repeat_array = array(
            'status' => $repeat_status ? 1 : 0,
            'type' => $repeat_type,
            'interval' => $repeat_interval,
            'end' => $repeat_end,
            'end_at_date' => $repeat_end_at_date,
            'end_at_occurrences' => $repeat_end_at_occurrences,
        );

        // Add repeat to date array
        $date_array['repeat'] = $repeat_array;

        // === EXCEPTIONAL DAYS ===
        $not_in_days = isset($data['not_in_days']) && is_array($data['not_in_days']) ? array_map('sanitize_text_field', $data['not_in_days']) : array();
        $in_days = isset($data['in_days']) && is_array($data['in_days']) ? array_map('sanitize_text_field', $data['in_days']) : array();

        // === LOCATION AND ORGANIZER ===
        $location_id = isset($data['location_id']) ? intval($data['location_id']) : 0;
        $dont_show_map = isset($data['dont_show_map']) ? (bool)$data['dont_show_map'] : false;
        $organizer_id = isset($data['organizer_id']) ? intval($data['organizer_id']) : 0;

        // Handle additional locations and organizers
        $additional_location_ids = isset($data['additional_location_ids']) && is_array($data['additional_location_ids']) ? array_map('intval', $data['additional_location_ids']) : array();
        $additional_organizer_ids = isset($data['additional_organizer_ids']) && is_array($data['additional_organizer_ids']) ? array_map('intval', $data['additional_organizer_ids']) : array();

        // Create new location if location_name is provided
        if (empty($location_id) && !empty($data['location_name'])) {
            $location_id = self::create_location($data);
        }

        // Create new organizer if organizer_name is provided
        if (empty($organizer_id) && !empty($data['organizer_name'])) {
            $organizer_id = self::create_organizer($data);
        }

        // === LINKS SECTION ===
        $read_more = isset($data['read_more']) ? esc_url_raw($data['read_more']) : '';
        $more_info = isset($data['more_info']) ? esc_url_raw($data['more_info']) : '';
        $more_info_title = isset($data['more_info_title']) ? sanitize_text_field($data['more_info_title']) : '';
        // Normalize more_info_target to MEC-compatible values (_self / _blank),
        // even if the client sends human-readable labels like "Current Window" / "New Window".
        $raw_more_info_target = isset($data['more_info_target']) ? $data['more_info_target'] : '_self';
        $more_info_target = self::normalize_more_info_target($raw_more_info_target);
        $trailer_url = isset($data['trailer_url']) ? esc_url_raw($data['trailer_url']) : '';
        $trailer_title = isset($data['trailer_title']) ? sanitize_text_field($data['trailer_title']) : '';

        // === COST SECTION ===
        $cost = isset($data['cost']) ? sanitize_text_field($data['cost']) : '';
        $cost_auto_calculate = isset($data['cost_auto_calculate']) ? (bool)$data['cost_auto_calculate'] : false;
        $cost_per_date = isset($data['cost_per_date']) ? (bool)$data['cost_per_date'] : false;
        $cost_per_date_type = isset($data['cost_per_date_type']) ? sanitize_text_field($data['cost_per_date_type']) : 'days';

        // Currency options
        $currency_options = isset($data['currency']) && is_array($data['currency']) ? $data['currency'] : array();

        // === SEO SCHEMA / EVENT STATUS ===
        $event_status = isset($data['event_status']) ? sanitize_text_field($data['event_status']) : 'EventScheduled';
        $moved_online_link = isset($data['moved_online_link']) ? esc_url_raw($data['moved_online_link']) : '';
        $cancelled_reason = isset($data['cancelled_reason']) ? sanitize_text_field($data['cancelled_reason']) : '';
        $display_cancellation_reason = isset($data['display_cancellation_reason_in_single_page']) ? (bool)$data['display_cancellation_reason_in_single_page'] : false;
        $public = isset($data['public']) ? (bool)$data['public'] : true;
        $style_per_event = isset($data['style_per_event']) ? sanitize_text_field($data['style_per_event']) : 'global';

        // === BOOKING SECTION ===
        $booking_options = array();
        if (isset($data['bookings_limit'])) $booking_options['bookings_limit'] = intval($data['bookings_limit']);
        if (isset($data['bookings_limit_unlimited'])) $booking_options['bookings_limit_unlimited'] = (bool)$data['bookings_limit_unlimited'];
        if (isset($data['bookings_date_selection'])) $booking_options['bookings_date_selection'] = sanitize_text_field($data['bookings_date_selection']);
        if (isset($data['bookings_minimum_per_booking'])) $booking_options['bookings_minimum_per_booking'] = intval($data['bookings_minimum_per_booking']);
        if (isset($data['bookings_all_occurrences'])) $booking_options['bookings_all_occurrences'] = (bool)$data['bookings_all_occurrences'];
        if (isset($data['automatic_approval'])) $booking_options['automatic_approval'] = (bool)$data['automatic_approval'];
        if (isset($data['booking_button_label'])) $booking_options['booking_button_label'] = sanitize_text_field($data['booking_button_label']);
        if (isset($data['last_few_tickets_percentage'])) $booking_options['last_few_tickets_percentage'] = intval($data['last_few_tickets_percentage']);
        if (isset($data['thankyou_page'])) $booking_options['thankyou_page'] = intval($data['thankyou_page']);
        if (isset($data['total_user_booking_limits'])) $booking_options['total_user_booking_limits'] = intval($data['total_user_booking_limits']);

        // Discount options
        if (isset($data['loggedin_discount'])) $booking_options['loggedin_discount'] = floatval($data['loggedin_discount']);
        if (isset($data['roles_discount']) && is_array($data['roles_discount'])) {
            $booking_options['roles_discount'] = array_map('floatval', $data['roles_discount']);
        }

        // === TICKETS SECTION ===
        $tickets = array();
        if (isset($data['tickets']) && is_array($data['tickets'])) {
            foreach ($data['tickets'] as $index => $ticket_data) {
                $ticket = array(
                    'id' => $index + 1,
                    'name' => isset($ticket_data['name']) ? sanitize_text_field($ticket_data['name']) : '',
                    'price' => isset($ticket_data['price']) ? sanitize_text_field($ticket_data['price']) : '',
                    'price_label' => isset($ticket_data['price_label']) ? sanitize_text_field($ticket_data['price_label']) : '',
                    'limit' => isset($ticket_data['limit']) ? intval($ticket_data['limit']) : '',
                    'description' => isset($ticket_data['description']) ? sanitize_text_field($ticket_data['description']) : '',
                    'minimum_ticket' => isset($ticket_data['minimum_ticket']) ? intval($ticket_data['minimum_ticket']) : 1,
                );
                $tickets[] = $ticket;
            }
        }

        // === HOURLY SCHEDULE ===
        $hourly_schedules = array();
        if (isset($data['hourly_schedules']) && is_array($data['hourly_schedules'])) {
            foreach ($data['hourly_schedules'] as $day) {
                $day_schedules = array();
                if (isset($day['schedules']) && is_array($day['schedules'])) {
                    foreach ($day['schedules'] as $schedule) {
                        $day_schedules[] = array(
                            'from' => isset($schedule['from']) ? sanitize_text_field($schedule['from']) : '',
                            'to' => isset($schedule['to']) ? sanitize_text_field($schedule['to']) : '',
                            'title' => isset($schedule['title']) ? sanitize_text_field($schedule['title']) : '',
                            'description' => isset($schedule['description']) ? sanitize_text_field($schedule['description']) : '',
                            'speakers' => isset($schedule['speakers']) && is_array($schedule['speakers']) ? array_map('intval', $schedule['speakers']) : array(),
                        );
                    }
                }
                $hourly_schedules[] = array(
                    'title' => isset($day['title']) ? sanitize_text_field($day['title']) : '',
                    'schedules' => $day_schedules,
                );
            }
        }

        // === PUBLIC DOWNLOAD ===
        $public_dl_file = isset($data['public_download_module_file']) ? sanitize_text_field($data['public_download_module_file']) : '';
        $public_dl_title = isset($data['public_download_module_title']) ? sanitize_text_field($data['public_download_module_title']) : '';
        $public_dl_description = isset($data['public_download_module_description']) ? sanitize_text_field($data['public_download_module_description']) : '';

        // === EVENT BANNER ===
        $event_banner = array();
        if (isset($data['banner']) && is_array($data['banner'])) {
            $event_banner = array(
                'title' => isset($data['banner']['title']) ? sanitize_text_field($data['banner']['title']) : '',
                'description' => isset($data['banner']['description']) ? sanitize_text_field($data['banner']['description']) : '',
                'image' => isset($data['banner']['image']) ? intval($data['banner']['image']) : 0,
            );
        }

        // === NOTIFICATIONS ===
        $notifications = array();
        if (isset($data['notifications']) && is_array($data['notifications'])) {
            $notifications = array_map('sanitize_text_field', $data['notifications']);
        }

        // === RELATED EVENTS ===
        $related_events = array();
        if (isset($data['related_events']) && is_array($data['related_events'])) {
            $related_events = array_map('intval', $data['related_events']);
        }

        // === EVENT GALLERY ===
        $event_gallery = array();
        if (isset($data['event_gallery']) && is_array($data['event_gallery'])) {
            $event_gallery = array_map('intval', $data['event_gallery']);
        }

        // Basic meta
        update_post_meta($post_id, 'mec_location_id', $location_id);
        update_post_meta($post_id, 'mec_dont_show_map', $dont_show_map ? 1 : 0);
        update_post_meta($post_id, 'mec_organizer_id', $organizer_id);
        update_post_meta($post_id, 'mec_additional_location_ids', $additional_location_ids);
        update_post_meta($post_id, 'mec_additional_organizer_ids', $additional_organizer_ids);

        // Date and time meta
        update_post_meta($post_id, 'mec_date', $date_array);
        update_post_meta($post_id, 'mec_start_date', $start_date);
        update_post_meta($post_id, 'mec_start_time_hour', $start_time_hour);
        update_post_meta($post_id, 'mec_start_time_minutes', $start_time_minutes);
        update_post_meta($post_id, 'mec_start_time_ampm', $start_time_ampm);
        update_post_meta($post_id, 'mec_start_day_seconds', $day_start_seconds);
        update_post_meta($post_id, 'mec_end_date', $end_date);
        update_post_meta($post_id, 'mec_end_time_hour', $end_time_hour);
        update_post_meta($post_id, 'mec_end_time_minutes', $end_time_minutes);
        update_post_meta($post_id, 'mec_end_time_ampm', $end_time_ampm);
        update_post_meta($post_id, 'mec_end_day_seconds', $day_end_seconds);
        update_post_meta($post_id, 'mec_allday', $allday ? 1 : 0);
        update_post_meta($post_id, 'mec_hide_time', $hide_time ? 1 : 0);
        update_post_meta($post_id, 'mec_hide_end_time', $hide_end_time ? 1 : 0);
        update_post_meta($post_id, 'mec_comment', $comment);
        update_post_meta($post_id, 'mec_timezone', $timezone);
        update_post_meta($post_id, 'mec_countdown_method', $countdown_method);

        // Repeat meta
        update_post_meta($post_id, 'mec_repeat', $repeat_array);
        update_post_meta($post_id, 'mec_repeat_status', $repeat_status ? 1 : 0);
        update_post_meta($post_id, 'mec_repeat_type', $repeat_type);
        update_post_meta($post_id, 'mec_repeat_interval', $repeat_interval);
        update_post_meta($post_id, 'mec_repeat_end', $repeat_end);
        update_post_meta($post_id, 'mec_repeat_end_at_date', $repeat_end_at_date);
        update_post_meta($post_id, 'mec_repeat_end_at_occurrences', $repeat_end_at_occurrences);
        update_post_meta($post_id, 'mec_certain_weekdays', $certain_weekdays);
        update_post_meta($post_id, 'mec_advanced_days', $advanced_days);
        update_post_meta($post_id, 'one_occurrence', $one_occurrence ? 1 : 0);

        // Exceptional days
        update_post_meta($post_id, 'mec_not_in_days', implode(',', $not_in_days));
        update_post_meta($post_id, 'mec_in_days', implode(',', $in_days));

        // Links meta
        update_post_meta($post_id, 'mec_read_more', $read_more);
        update_post_meta($post_id, 'mec_more_info', $more_info);
        update_post_meta($post_id, 'mec_more_info_title', $more_info_title);
        update_post_meta($post_id, 'mec_more_info_target', $more_info_target);
        update_post_meta($post_id, 'mec_trailer_url', $trailer_url);
        update_post_meta($post_id, 'mec_trailer_title', $trailer_title);

        // Cost meta
        update_post_meta($post_id, 'mec_cost', $cost);
        update_post_meta($post_id, 'mec_cost_auto_calculate', $cost_auto_calculate ? 1 : 0);
        update_post_meta($post_id, 'mec_currency', $currency_options);

        // SEO Schema / Event Status
        update_post_meta($post_id, 'mec_event_status', $event_status);
        update_post_meta($post_id, 'mec_moved_online_link', $moved_online_link);
        update_post_meta($post_id, 'mec_cancelled_reason', $cancelled_reason);
        update_post_meta($post_id, 'mec_display_cancellation_reason_in_single_page', $display_cancellation_reason ? 1 : 0);
        update_post_meta($post_id, 'mec_public', $public ? 1 : 0);
        update_post_meta($post_id, 'mec_style_per_event', $style_per_event);

        // Booking and tickets
        update_post_meta($post_id, 'mec_booking', $booking_options);
        update_post_meta($post_id, 'mec_tickets', $tickets);

        // Hourly schedules
        update_post_meta($post_id, 'mec_hourly_schedules', $hourly_schedules);

        // Public download
        update_post_meta($post_id, 'mec_public_dl_file', $public_dl_file);
        update_post_meta($post_id, 'mec_public_dl_title', $public_dl_title);
        update_post_meta($post_id, 'mec_public_dl_description', $public_dl_description);

        // Event banner
        update_post_meta($post_id, 'mec_banner', $event_banner);

        // Notifications
        update_post_meta($post_id, 'mec_notifications', $notifications);

        // Related events
        update_post_meta($post_id, 'mec_related_events', $related_events);

        // Event gallery
        update_post_meta($post_id, 'mec_event_gallery', $event_gallery);

        if (isset($data['zoom']) && is_array($data['zoom'])) {
            self::apply_zoom_meta($post_id, $data['zoom']);
        }

        if (isset($data['virtual_event']) && is_array($data['virtual_event'])) {
            self::apply_virtual_event_meta($post_id, $data['virtual_event']);
        }

        // Insert into MEC events table
        self::insert_mec_events_data($post_id, $start_date, $end_date, $repeat_status, $repeat_interval, $repeat_type, $day_start_seconds, $day_end_seconds);

        // Regenerate MEC occurrences (mec_dates) so frontend shows correct dates
        self::reschedule_event($post_id);

        // Handle taxonomies including categories, labels, speakers, sponsors, tags
        $taxonomy_data = array();

        // Build taxonomy data from request
        if (isset($data['mec_category'])) $taxonomy_data['mec_category'] = $data['mec_category'];
        if (isset($data['mec_label'])) $taxonomy_data['mec_label'] = $data['mec_label'];
        if (isset($data['mec_speaker'])) $taxonomy_data['mec_speaker'] = $data['mec_speaker'];
        if (isset($data['mec_sponsor'])) $taxonomy_data['mec_sponsor'] = $data['mec_sponsor'];
        if (isset($data['post_tag'])) $taxonomy_data['post_tag'] = $data['post_tag'];

        // Handle event taxonomies
        self::handle_event_taxonomies($post_id, $taxonomy_data);

        // Set taxonomies
        if ($location_id) {
            wp_set_object_terms($post_id, $location_id, 'mec_location');
        }
        if ($organizer_id) {
            wp_set_object_terms($post_id, $organizer_id, 'mec_organizer');
        }

        // Set additional locations and organizers
        foreach ($additional_location_ids as $additional_location_id) {
            wp_set_object_terms($post_id, $additional_location_id, 'mec_location', true);
        }
        foreach ($additional_organizer_ids as $additional_organizer_id) {
            wp_set_object_terms($post_id, $additional_organizer_id, 'mec_organizer', true);
        }

        // Return the created event data
        $event = get_post($post_id);
        return self::prepare_event_data($event);
    }

    /**
     * API update event callback
     */
    public static function api_update_event($request)
    {
        $event_id = $request->get_param('id');
        $event = \get_post($event_id);

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new \WP_Error(
                'event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Get current event data to preserve existing values
        $current_meta = \get_post_meta($event_id);
        $current_booking = \get_post_meta($event_id, 'mec_booking', true);
        if (!is_array($current_booking)) $current_booking = [];

        // Basic fields
        $title = $request->get_param('title');
        $content = $request->get_param('content');
        $start_date = $request->get_param('start_date');
        $end_date = $request->get_param('end_date');

        // Validate start_date if provided
        if (!empty($start_date) && !self::is_valid_date($start_date)) {
            return new \WP_Error('invalid_date', 'Valid start_date format required (Y-m-d)', ['status' => 400]);
        }

        // Prepare post data
        $post_data = array('ID' => $event_id);

        if (!empty($title)) {
            $post_data['post_title'] = \sanitize_text_field($title);
        }

        if (!empty($content)) {
            $post_data['post_content'] = \wp_kses_post($content);
        }

        // Update basic post fields
        $updated_id = \wp_update_post($post_data, true);
        if (\is_wp_error($updated_id)) {
            return $updated_id;
        }

        // Update meta fields only if provided
        $meta_updates = [];

        // Date and time fields
        if (!empty($start_date)) {
            $meta_updates['mec_start_date'] = \sanitize_text_field($start_date);
        }
        if (!empty($end_date)) {
            $meta_updates['mec_end_date'] = \sanitize_text_field($end_date);
        }

        // Time fields
        $time_fields = ['start_time_hour', 'start_time_minutes', 'start_time_ampm', 'end_time_hour', 'end_time_minutes', 'end_time_ampm'];
        foreach ($time_fields as $field) {
            $value = $request->get_param($field);
            if (!empty($value)) {
                $meta_updates['mec_' . $field] = \sanitize_text_field($value);
            }
        }

        // Boolean fields
        $boolean_fields = ['allday', 'hide_time', 'hide_end_time', 'repeat_status', 'cost_per_date', 'dont_show_map'];
        foreach ($boolean_fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $meta_updates['mec_' . $field] = filter_var($value, FILTER_VALIDATE_BOOLEAN) ? '1' : '0';
            }
        }

        // Weekly repeat fields
        $weekly_fields = ['repeat_monday', 'repeat_tuesday', 'repeat_wednesday', 'repeat_thursday', 'repeat_friday', 'repeat_saturday', 'repeat_sunday'];
        foreach ($weekly_fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $meta_updates['mec_' . str_replace('repeat_', 'repeat_', $field)] = filter_var($value, FILTER_VALIDATE_BOOLEAN) ? '1' : '0';
            }
        }

        // Text fields
        $text_fields = ['timezone', 'countdown_method', 'comment', 'repeat_type', 'repeat_end', 'repeat_interval', 'repeat_end_at_date', 'repeat_end_at_occurrences', 'repeat_monthly_day', 'repeat_monthly_week', 'repeat_monthly_advanced', 'repeat_monthly_advanced_week', 'cost', 'cost_per_date_type', 'more_info_title', 'more_info_target', 'read_more_title', 'read_more_target', 'location_id', 'organizer_id', 'event_color'];
        foreach ($text_fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                // Normalize more_info_target when updating via API as well
                if ($field === 'more_info_target') {
                    $meta_updates['mec_more_info_target'] = self::normalize_more_info_target($value);
                } else {
                    $meta_updates['mec_' . $field] = \sanitize_text_field($value);
                }
            }
        }

        // SEO Schema / Event Status (for updates)
        $raw_event_status = $request->get_param('event_status');
        if ($raw_event_status !== null) {
            $event_status = sanitize_text_field($raw_event_status);
            $valid_statuses = array('EventScheduled', 'EventRescheduled', 'EventPostponed', 'EventCancelled', 'EventMovedOnline');
            if (!in_array($event_status, $valid_statuses, true)) {
                $event_status = 'EventScheduled';
            }
            $meta_updates['mec_event_status'] = $event_status;

            // Handle cancelled reason + display flag
            if ($event_status === 'EventCancelled') {
                $raw_cancelled_reason = $request->get_param('cancelled_reason');
                $raw_display_cancel = $request->get_param('display_cancellation_reason_in_single_page');

                $cancelled_reason = $raw_cancelled_reason ? sanitize_text_field($raw_cancelled_reason) : '';
                $display_cancellation = $raw_display_cancel !== null ? (bool)$raw_display_cancel : false;

                $meta_updates['mec_cancelled_reason'] = $cancelled_reason;
                $meta_updates['mec_display_cancellation_reason_in_single_page'] = $display_cancellation ? 1 : 0;
            } else {
                // Clear cancellation data when status is not cancelled
                $meta_updates['mec_cancelled_reason'] = '';
                $meta_updates['mec_display_cancellation_reason_in_single_page'] = 0;
            }

            // Handle moved online link
            if ($event_status === 'EventMovedOnline') {
                $raw_moved_link = $request->get_param('moved_online_link');
                $moved_online_link = $raw_moved_link ? esc_url_raw($raw_moved_link) : '';
                $meta_updates['mec_moved_online_link'] = $moved_online_link;
            } else {
                // Clear moved online link when status is not moved online
                $meta_updates['mec_moved_online_link'] = '';
            }
        }

        // URL fields
        $url_fields = ['more_info', 'read_more'];
        foreach ($url_fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $meta_updates['mec_' . $field] = \esc_url_raw($value);
            }
        }

        // Array fields
        $array_fields = ['additional_organizer_ids', 'tickets', 'fees'];
        foreach ($array_fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                $meta_updates['mec_' . $field] = $value;
            }
        }

        // Handle location creation
        $location_name = $request->get_param('location_name');
        $location_address = $request->get_param('location_address');
        if (!empty($location_name) && empty($meta_updates['mec_location_id'])) {
            $location_term = \wp_insert_term($location_name, 'mec_location');
            if (!is_wp_error($location_term)) {
                $meta_updates['mec_location_id'] = $location_term['term_id'];
                if (!empty($location_address)) {
                    \update_term_meta($location_term['term_id'], 'address', $location_address);
                }
            }
        }

        // Handle organizer creation
        $organizer_name = $request->get_param('organizer_name');
        $organizer_email = $request->get_param('organizer_email');
        $organizer_tel = $request->get_param('organizer_tel');
        if (!empty($organizer_name) && empty($meta_updates['mec_organizer_id'])) {
            $organizer_term = \wp_insert_term($organizer_name, 'mec_organizer');
            if (!is_wp_error($organizer_term)) {
                $meta_updates['mec_organizer_id'] = $organizer_term['term_id'];
                if (!empty($organizer_email)) {
                    \update_term_meta($organizer_term['term_id'], 'email', $organizer_email);
                }
                if (!empty($organizer_tel)) {
                    \update_term_meta($organizer_term['term_id'], 'tel', $organizer_tel);
                }
            }
        }

        // Handle advancedSettings (repeat settings)
        $advanced_settings = $request->get_param('advancedSettings');
        if (is_array($advanced_settings)) {
            // Direct repeat settings from advancedSettings
            $repeat_settings = [
                'mec_repeat_status' => $advanced_settings['mec_repeat_status'] ?? null,
                'mec_repeat_type' => $advanced_settings['mec_repeat_type'] ?? null,
                'mec_repeat_interval' => $advanced_settings['mec_repeat_interval'] ?? null,
                'mec_repeat_end' => $advanced_settings['mec_repeat_end'] ?? null,
                'mec_repeat_end_at_date' => $advanced_settings['mec_repeat_end_at_date'] ?? null,
                'mec_repeat_end_at_occurrences' => $advanced_settings['mec_repeat_end_at_occurrences'] ?? null,
                'mec_advanced_days' => $advanced_settings['mec_advanced_days'] ?? null,
                'mec_repeat_days' => $advanced_settings['mec_repeat_days'] ?? null,
                'mec_custom_days' => $advanced_settings['mec_custom_days'] ?? null,
                'mec_allday' => $advanced_settings['mec_allday'] ?? null,
                'mec_public' => $advanced_settings['mec_public'] ?? null,
            ];

            foreach ($repeat_settings as $key => $value) {
                if ($value !== null) {
                    if ($key === 'mec_repeat_status' || $key === 'mec_allday' || $key === 'mec_public') {
                        $meta_updates[$key] = ($value === '1' || $value === 1) ? '1' : '0';
                    } elseif ($key === 'mec_advanced_days' || $key === 'mec_repeat_days' || $key === 'mec_custom_days') {
                        if (is_array($value)) {
                            $meta_updates[$key] = $value;
                        }
                    } elseif ($key === 'mec_repeat_end_at_occurrences') {
                        // MEC stores occurrences as (user_input - 1) internally
                        $meta_updates[$key] = (intval($value) - 1);
                    } else {
                        $meta_updates[$key] = \sanitize_text_field($value);
                    }
                }
            }

            // Handle certain weekdays for repeat
            if (isset($meta_updates['mec_repeat_type']) && $meta_updates['mec_repeat_type'] === 'certain_weekdays' && isset($meta_updates['mec_repeat_days'])) {
                $days_nums = array_map('intval', $meta_updates['mec_repeat_days']);
                $meta_updates['mec_certain_weekdays'] = $days_nums;
            }

            // Handle advanced days
            if (isset($meta_updates['mec_repeat_type']) && $meta_updates['mec_repeat_type'] === 'advanced' && isset($meta_updates['mec_advanced_days'])) {
                $advanced_str = implode(',', $meta_updates['mec_advanced_days']);
                $meta_updates['mec_repeat_advanced'] = $advanced_str;
            }

            // Handle custom days
            if (isset($meta_updates['mec_repeat_type']) && $meta_updates['mec_repeat_type'] === 'custom_days' && isset($meta_updates['mec_custom_days'])) {
                $meta_updates['mec_in_days'] = $meta_updates['mec_custom_days'];
            }
        }

        // Handle mec_data (direct repeat settings)
        $mec_data = $request->get_param('mec_data');
        if (is_array($mec_data)) {
            // Direct repeat settings from mec_data
            $mec_repeat_settings = [
                'mec_repeat_status' => $mec_data['repeat_status'] ?? null,
                'mec_repeat_type' => $mec_data['repeat_type'] ?? null,
                'mec_repeat_interval' => $mec_data['repeat_interval'] ?? null,
                'mec_repeat_end' => $mec_data['repeat_end'] ?? null,
                'mec_repeat_end_at_date' => $mec_data['repeat_end_at_date'] ?? null,
                'mec_repeat_end_at_occurrences' => $mec_data['repeat_end_at_occurrences'] ?? null,
                'mec_allday' => $mec_data['allday'] ?? null,
                'mec_public' => $mec_data['public'] ?? null,
            ];

            foreach ($mec_repeat_settings as $key => $value) {
                if ($value !== null) {
                    if ($key === 'mec_repeat_status' || $key === 'mec_allday' || $key === 'mec_public') {
                        $meta_updates[$key] = ($value === '1' || $value === 1) ? '1' : '0';
                    } elseif ($key === 'mec_repeat_end_at_occurrences') {
                        // MEC stores occurrences as (user_input - 1) internally
                        $meta_updates[$key] = (intval($value) - 1);
                    } else {
                        $meta_updates[$key] = \sanitize_text_field($value);
                    }
                }
            }

            // Handle custom_days from mec_data
            if (isset($mec_data['custom_days']) && is_array($mec_data['custom_days'])) {
                $meta_updates['mec_custom_days'] = $mec_data['custom_days'];
                $meta_updates['mec_in_days'] = $mec_data['custom_days'];
            }
        }

        // Handle booking fields
        $booking_fields = ['bookings_limit', 'bookings_limit_unlimited', 'bookings_date_selection', 'bookings_minimum_per_booking', 'bookings_all_occurrences', 'bookings_all_occurrences_multiple', 'automatic_approval', 'booking_button_label', 'last_few_tickets_percentage', 'thankyou_page', 'total_user_booking_limits', 'loggedin_discount'];

        $booking_updates = [];
        foreach ($booking_fields as $field) {
            $value = $request->get_param($field);
            if ($value !== null) {
                if (in_array($field, ['bookings_limit_unlimited', 'bookings_all_occurrences', 'bookings_all_occurrences_multiple', 'automatic_approval'])) {
                    $booking_updates[$field] = filter_var($value, FILTER_VALIDATE_BOOLEAN) ? '1' : '0';
                } else {
                    $booking_updates[$field] = \sanitize_text_field($value);
                }
            }
        }

        // Handle roles discount
        $roles_discount = $request->get_param('roles_discount');
        if (is_array($roles_discount)) {
            foreach ($roles_discount as $role => $discount) {
                $booking_updates['roles_discount_' . $role] = \sanitize_text_field($discount);
            }
        }

        // Update booking meta if any booking fields were provided
        if (!empty($booking_updates)) {
            $updated_booking = array_merge($current_booking, $booking_updates);
            $meta_updates['mec_booking'] = $updated_booking;
        }

        // Apply all meta updates
        foreach ($meta_updates as $key => $value) {
            \update_post_meta($event_id, $key, $value);
        }

        $zoom_payload = $request->get_param('zoom');
        if (is_array($zoom_payload)) {
            self::apply_zoom_meta($event_id, $zoom_payload);
        }

        $virtual_payload = $request->get_param('virtual_event');
        if (is_array($virtual_payload)) {
            self::apply_virtual_event_meta($event_id, $virtual_payload);
        }

        // Update taxonomies
        $taxonomies = [
            'categories' => 'mec_category',
            'speakers' => 'mec_speaker',
            'sponsors' => 'mec_sponsor',
            'labels' => 'mec_label',
            'tags' => 'mec_tag'
        ];

        foreach ($taxonomies as $param => $taxonomy) {
            $terms = $request->get_param($param);
            if (is_array($terms) && !empty($terms)) {
                \wp_set_object_terms($event_id, $terms, $taxonomy);
            }
        }

        // Set location and organizer as taxonomy terms
        if (!empty($meta_updates['mec_location_id'])) {
            \wp_set_object_terms($event_id, (int) $meta_updates['mec_location_id'], 'mec_location');
        }

        if (!empty($meta_updates['mec_organizer_id'])) {
            \wp_set_object_terms($event_id, (int) $meta_updates['mec_organizer_id'], 'mec_organizer');
        }

        // Set additional organizers
        if (!empty($meta_updates['mec_additional_organizer_ids'])) {
            foreach ($meta_updates['mec_additional_organizer_ids'] as $additional_organizer_id) {
                \wp_set_object_terms($event_id, (int) $additional_organizer_id, 'mec_organizer', true);
            }
        }

        // Update featured image
        $featured_image = $request->get_param('featured_image');
        if (!empty($featured_image)) {
            if (filter_var($featured_image, FILTER_VALIDATE_URL)) {
                $attachment_id = self::get_attachment_id_from_url($featured_image);
                if ($attachment_id) {
                    \set_post_thumbnail($event_id, $attachment_id);
                }
            } else {
                \set_post_thumbnail($event_id, $featured_image);
            }
        }

        // Update mec_events table if date/time/repeat fields were changed
        if (
            !empty($meta_updates['mec_start_date']) || !empty($meta_updates['mec_end_date']) ||
            !empty($meta_updates['mec_start_time_hour']) || !empty($meta_updates['mec_end_time_hour']) ||
            !empty($meta_updates['mec_repeat_status']) || !empty($meta_updates['mec_repeat_type']) ||
            !empty($mec_data) // Also update if mec_data is provided
        ) {

            $current_start_date = !empty($meta_updates['mec_start_date']) ? $meta_updates['mec_start_date'] : \get_post_meta($event_id, 'mec_start_date', true);
            $current_end_date = !empty($meta_updates['mec_end_date']) ? $meta_updates['mec_end_date'] : \get_post_meta($event_id, 'mec_end_date', true);
            $current_repeat_status = !empty($meta_updates['mec_repeat_status']) ? ($meta_updates['mec_repeat_status'] === '1') : (\get_post_meta($event_id, 'mec_repeat_status', true) === '1');
            $current_repeat_interval = !empty($meta_updates['mec_repeat_interval']) ? $meta_updates['mec_repeat_interval'] : \get_post_meta($event_id, 'mec_repeat_interval', true);
            $current_repeat_type = !empty($meta_updates['mec_repeat_type']) ? $meta_updates['mec_repeat_type'] : \get_post_meta($event_id, 'mec_repeat_type', true);
            $current_start_time_hour = !empty($meta_updates['mec_start_time_hour']) ? $meta_updates['mec_start_time_hour'] : \get_post_meta($event_id, 'mec_start_time_hour', true);
            $current_start_time_minutes = !empty($meta_updates['mec_start_time_minutes']) ? $meta_updates['mec_start_time_minutes'] : \get_post_meta($event_id, 'mec_start_time_minutes', true);
            $current_start_time_ampm = !empty($meta_updates['mec_start_time_ampm']) ? $meta_updates['mec_start_time_ampm'] : \get_post_meta($event_id, 'mec_start_time_ampm', true);
            $current_end_time_hour = !empty($meta_updates['mec_end_time_hour']) ? $meta_updates['mec_end_time_hour'] : \get_post_meta($event_id, 'mec_end_time_hour', true);
            $current_end_time_minutes = !empty($meta_updates['mec_end_time_minutes']) ? $meta_updates['mec_end_time_minutes'] : \get_post_meta($event_id, 'mec_end_time_minutes', true);
            $current_end_time_ampm = !empty($meta_updates['mec_end_time_ampm']) ? $meta_updates['mec_end_time_ampm'] : \get_post_meta($event_id, 'mec_end_time_ampm', true);
            $current_allday = !empty($meta_updates['mec_allday']) ? ($meta_updates['mec_allday'] === '1') : (\get_post_meta($event_id, 'mec_allday', true) === '1');

            // Convert time to seconds for mec_events table
            $start_time_seconds = self::time_to_seconds($current_start_time_hour, $current_start_time_minutes, $current_start_time_ampm);
            $end_time_seconds = self::time_to_seconds($current_end_time_hour, $current_end_time_minutes, $current_end_time_ampm);

            self::insert_mec_events_data($event_id, $current_start_date, $current_end_date, $current_repeat_status, $current_repeat_interval, $current_repeat_type, $start_time_seconds, $end_time_seconds);

            // Regenerate MEC occurrences (mec_dates) so frontend shows correct dates
            self::reschedule_event($event_id);
        }

        // Get updated event and return
        $updated_event = \get_post($event_id);
        return self::prepare_event_data($updated_event);
    }

    /**
     * API delete event callback
     */
    public static function api_delete_event($request)
    {
        $event_id = $request->get_param('id');
        $force = $request->get_param('force');
        $event = \get_post($event_id);

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new \WP_Error(
                'event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        $previous = self::prepare_event_data($event);

        if ($force) {
            $result = \wp_delete_post($event_id, true);
        } else {
            $result = \wp_trash_post($event_id);
        }

        if (! $result) {
            return new \WP_Error(
                'cannot_delete',
                \__('The event cannot be deleted.', 'mec-utility'),
                array('status' => 500)
            );
        }

        return \rest_ensure_response(array(
            'deleted'  => true,
            'previous' => $previous,
        ));
    }

    /**
     * API search events callback
     */
    public static function api_search_events($request)
    {
        // Basic parameters
        $query = $request->get_param('query') ?: '';
        $per_page = $request->get_param('per_page') ?: 10;
        $page = $request->get_param('page') ?: 1;
        $status = $request->get_param('status') ?: 'any'; // Support all post statuses by default
        $orderby = $request->get_param('orderby') ?: 'date';
        $order = $request->get_param('order') ?: 'asc';

        // Date filters
        $start_date = $request->get_param('start_date');
        $end_date = $request->get_param('end_date');
        $date_filter = $request->get_param('date_filter');

        // Other filters
        $category = $request->get_param('category');
        $location = $request->get_param('location');
        $organizer = $request->get_param('organizer');

        $args = array(
            'post_type'      => 'mec-events',
            'post_status'    => $status, // Changed from hardcoded 'publish' to support all statuses
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'meta_query'     => array(
                array(
                    'key'     => 'mec_start_date',
                    'compare' => 'EXISTS',
                ),
            ),
        );

        // Add search query
        if (! empty($query)) {
            $args['s'] = $query;
        }

        // Add date filters using mec_events table
        $args = self::apply_date_filters($args, $start_date, $end_date, $date_filter);

        // Add taxonomy filters
        if (! empty($category)) {
            $args['tax_query'][] = array(
                'taxonomy' => 'mec_category',
                'field'    => is_numeric($category) ? 'term_id' : 'slug',
                'terms'    => $category,
            );
        }

        // Add meta filters for location and organizer
        if (! empty($location)) {
            $args['meta_query'][] = array(
                'key'     => 'mec_location_id',
                'value'   => $location,
                'compare' => '=',
            );
        }

        if (! empty($organizer)) {
            $args['meta_query'][] = array(
                'key'     => 'mec_organizer_id',
                'value'   => $organizer,
                'compare' => '=',
            );
        }

        // Set ordering
        if ($orderby === 'start_date') {
            $args['meta_key'] = 'mec_start_date';
            $args['orderby'] = 'meta_value';
            $args['order'] = strtoupper($order);
        } else {
            $args['orderby'] = $orderby;
            $args['order'] = strtoupper($order);
        }

        $search_query = new \WP_Query($args);
        $events = array();

        if ($search_query->have_posts()) {
            while ($search_query->have_posts()) {
                $search_query->the_post();
                $event_id = \get_the_ID();
                $events[] = self::prepare_event_data(\get_post($event_id));
            }
            \wp_reset_postdata();
        }

        // Calculate pagination info
        $total_items = $search_query->found_posts;
        $total_pages = $search_query->max_num_pages;

        $response_data = [
            'events' => $events,
            'pagination' => [
                'total' => $total_items,
                'per_page' => $per_page,
                'current_page' => $page,
                'total_pages' => $total_pages,
                'has_more' => $page < $total_pages
            ]
        ];

        $response = \rest_ensure_response($response_data);
        $response->header('X-WP-Total', $total_items);
        $response->header('X-WP-TotalPages', $total_pages);

        return $response;
    }

    /**
     * Prepare event data for response
     */
    private static function prepare_event_data($event)
    {
        global $wpdb;

        // Get all meta data
        $meta = \get_post_meta($event->ID);
        $formatted_meta = [];
        foreach ($meta as $key => $value) {
            $formatted_meta[$key] = is_array($value) && count($value) === 1 ? $value[0] : $value;
        }

        // Get taxonomies
        $categories = \wp_get_post_terms($event->ID, 'mec_category', ['fields' => 'all']);
        $speakers = \wp_get_post_terms($event->ID, 'mec_speaker', ['fields' => 'all']);
        $sponsors = \wp_get_post_terms($event->ID, 'mec_sponsor', ['fields' => 'all']);
        $labels = \wp_get_post_terms($event->ID, 'mec_label', ['fields' => 'all']);
        $tag_taxonomy = apply_filters('mec_taxonomy_tag', 'post_tag');
        $tags = \wp_get_post_terms($event->ID, $tag_taxonomy, ['fields' => 'all']);

        // Format taxonomies
        $format_terms = function ($terms) {
            return array_map(function ($term) {
                return [
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                    'description' => $term->description
                ];
            }, $terms);
        };

        // Get MEC event data
        $mec_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}mec_events WHERE post_id = %d",
            $event->ID
        ));

        // Format dates
        $start_date = $formatted_meta['mec_start_date'] ?? '';
        $end_date = $formatted_meta['mec_end_date'] ?? '';
        $start_time_hour = $formatted_meta['mec_start_time_hour'] ?? '8';
        $start_time_minutes = $formatted_meta['mec_start_time_minutes'] ?? '0';
        $start_time_ampm = $formatted_meta['mec_start_time_ampm'] ?? 'AM';
        $end_time_hour = $formatted_meta['mec_end_time_hour'] ?? '6';
        $end_time_minutes = $formatted_meta['mec_end_time_minutes'] ?? '0';
        $end_time_ampm = $formatted_meta['mec_end_time_ampm'] ?? 'PM';

        $start_time_formatted = sprintf('%02d:%02d %s', $start_time_hour, $start_time_minutes, $start_time_ampm);
        $end_time_formatted = sprintf('%02d:%02d %s', $end_time_hour, $end_time_minutes, $end_time_ampm);

        // Convert to seconds for time_start and time_end
        $start_time_seconds = self::time_to_seconds($start_time_hour, $start_time_minutes, $start_time_ampm);
        $end_time_seconds = self::time_to_seconds($end_time_hour, $end_time_minutes, $end_time_ampm);

        // Get location details
        $location_id = $formatted_meta['mec_location_id'] ?? '';
        $location_details = [];
        if ($location_id) {
            $location_term = \get_term($location_id, 'mec_location');
            if ($location_term && !is_wp_error($location_term)) {
                $location_meta = \get_term_meta($location_id);
                $location_details = [
                    'id' => (int) $location_term->term_id,
                    'name' => $location_term->name,
                    'slug' => $location_term->slug,
                    'description' => $location_term->description,
                    'address' => $location_meta['address'][0] ?? '',
                    'latitude' => $location_meta['latitude'][0] ?? '',
                    'longitude' => $location_meta['longitude'][0] ?? '',
                    'url' => $location_meta['url'][0] ?? '',
                    'tel' => $location_meta['tel'][0] ?? '',
                    'thumbnail' => $location_meta['thumbnail'][0] ?? '',
                ];
            }
        }

        // Get organizer details
        $organizer_id = $formatted_meta['mec_organizer_id'] ?? '';
        $organizer_details = [];
        if ($organizer_id) {
            $organizer_term = \get_term($organizer_id, 'mec_organizer');
            if ($organizer_term && !is_wp_error($organizer_term)) {
                $organizer_meta = \get_term_meta($organizer_id);
                $organizer_details = [
                    'id' => (int) $organizer_term->term_id,
                    'name' => $organizer_term->name,
                    'slug' => $organizer_term->slug,
                    'description' => $organizer_term->description,
                    'email' => $organizer_meta['email'][0] ?? '',
                    'tel' => $organizer_meta['tel'][0] ?? '',
                    'url' => $organizer_meta['url'][0] ?? '',
                    'thumbnail' => $organizer_meta['thumbnail'][0] ?? '',
                ];
            }
        }

        // Get author details
        $author_id = $event->post_author;
        $author_details = [];
        if ($author_id) {
            $author = \get_userdata($author_id);
            if ($author) {
                $author_details = [
                    'id' => (int) $author->ID,
                    'username' => $author->user_login,
                    'email' => $author->user_email,
                    'display_name' => $author->display_name,
                    'first_name' => $author->first_name,
                    'last_name' => $author->last_name,
                    'avatar' => \get_avatar_url($author->ID),
                ];
            }
        }

        // Get featured image details
        $featured_image_id = \get_post_thumbnail_id($event->ID);
        $featured_image_details = [];
        if ($featured_image_id) {
            $featured_image_details = [
                'id' => (int) $featured_image_id,
                'url' => \wp_get_attachment_url($featured_image_id),
                'thumbnail' => \wp_get_attachment_image_url($featured_image_id, 'thumbnail'),
                'medium' => \wp_get_attachment_image_url($featured_image_id, 'medium'),
                'large' => \wp_get_attachment_image_url($featured_image_id, 'large'),
                'full' => \wp_get_attachment_image_url($featured_image_id, 'full'),
                'alt' => \get_post_meta($featured_image_id, '_wp_attachment_image_alt', true),
                'caption' => \wp_get_attachment_caption($featured_image_id),
            ];
        }

        // Get booking settings
        $booking_settings = [];
        if (isset($formatted_meta['mec_booking'])) {
            $booking_data = maybe_unserialize($formatted_meta['mec_booking']);
            if (is_array($booking_data)) {
                $booking_settings = [
                    'enabled' => $booking_data['bookings_enabled'] ?? '0',
                    'limit' => $booking_data['bookings_limit'] ?? '0',
                    'limit_for_users' => $booking_data['bookings_limit_for_users'] ?? '0',
                    'user_limit' => $booking_data['bookings_user_limit'] ?? '0',
                    'form_id' => $booking_data['bookings_form_id'] ?? '',
                    'auto_confirm' => $booking_data['bookings_auto_confirm'] ?? '0',
                    'auto_verify' => $booking_data['bookings_auto_verify'] ?? '0',
                    'dates' => $booking_data['bookings_dates'] ?? [],
                    'times' => $booking_data['bookings_times'] ?? [],
                    'all_data' => $booking_data
                ];
            }
        }

        // Get tickets info
        $tickets_info = [];
        if (isset($formatted_meta['mec_tickets'])) {
            $tickets_data = maybe_unserialize($formatted_meta['mec_tickets']);
            if (is_array($tickets_data)) {
                foreach ($tickets_data as $ticket_id => $ticket) {
                    $tickets_info[] = [
                        'id' => $ticket_id,
                        'name' => $ticket['name'] ?? '',
                        'price' => $ticket['price'] ?? '0',
                        'price_label' => $ticket['price_label'] ?? '',
                        'description' => $ticket['description'] ?? '',
                        'limit' => $ticket['limit'] ?? '0',
                        'minimum' => $ticket['minimum'] ?? '1',
                        'maximum' => $ticket['maximum'] ?? '0',
                        'dates' => $ticket['dates'] ?? [],
                        'times' => $ticket['times'] ?? [],
                        'ticket_start_time' => $ticket['ticket_start_time'] ?? '',
                        'ticket_end_time' => $ticket['ticket_end_time'] ?? '',
                    ];
                }
            }
        }

        // Get fees info
        $fees_info = [];
        if (isset($formatted_meta['mec_fees'])) {
            $fees_data = maybe_unserialize($formatted_meta['mec_fees']);
            if (is_array($fees_data)) {
                foreach ($fees_data as $fee) {
                    $fees_info[] = [
                        'title' => $fee['title'] ?? '',
                        'amount' => $fee['amount'] ?? '0',
                        'type' => $fee['type'] ?? 'fixed',
                        'description' => $fee['description'] ?? '',
                    ];
                }
            }
        }

        // Get gallery images
        $images = [];
        $gallery_ids = [];

        // Try multiple meta keys for gallery
        if (isset($formatted_meta['mec_event_gallery'])) {
            $gallery_ids = maybe_unserialize($formatted_meta['mec_event_gallery']);
        } elseif (isset($formatted_meta['mec_gallery'])) {
            $gallery_ids = maybe_unserialize($formatted_meta['mec_gallery']);
        }

        if (is_array($gallery_ids) && !empty($gallery_ids)) {
            foreach ($gallery_ids as $att_id) {
                $file_url = \wp_get_attachment_url($att_id);
                if ($file_url) {
                    $file_path = \get_attached_file($att_id);
                    $size_bytes = ($file_path && file_exists($file_path)) ? filesize($file_path) : null;
                    $images[] = [
                        'id' => (int)$att_id,
                        'name' => \get_the_title($att_id),
                        'size' => $size_bytes,
                        'url' => $file_url,
                        'thumbnail' => \wp_get_attachment_image_url($att_id, 'thumbnail') ?: $file_url,
                        'medium' => \wp_get_attachment_image_url($att_id, 'medium') ?: $file_url,
                        'large' => \wp_get_attachment_image_url($att_id, 'large') ?: $file_url,
                        'full' => \wp_get_attachment_image_url($att_id, 'full') ?: $file_url,
                        'alt' => \get_post_meta($att_id, '_wp_attachment_image_alt', true) ?: '',
                        'caption' => \wp_get_attachment_caption($att_id) ?: '',
                    ];
                }
            }
        }

        // Fallback: check for gallery URLs if no IDs found
        if (empty($images) && isset($formatted_meta['mec_gallery_urls'])) {
            $gallery_urls = maybe_unserialize($formatted_meta['mec_gallery_urls']);
            if (is_array($gallery_urls)) {
                foreach ($gallery_urls as $url) {
                    $images[] = [
                        'id' => 0,
                        'url' => $url,
                        'thumbnail' => $url,
                        'medium' => $url,
                        'large' => $url,
                        'full' => $url,
                    ];
                }
            }
        }

        return array(
            'id' => $event->ID,
            'title' => self::clean_title(\get_the_title($event->ID)),
            'content' => $event->post_content,
            'excerpt' => \get_the_excerpt($event->ID),
            'status' => $event->post_status,
            'permalink' => \get_permalink($event->ID),
            'featured_image' => $featured_image_details ?: false,
            'images' => $images,
            'date_created' => $event->post_date,
            'date_modified' => $event->post_modified,
            'author' => $author_details,
            'location' => $location_details,
            'organizer' => $organizer_details,
            'mec_data' => array(
                'start_date' => $start_date,
                'end_date' => $end_date,
                'start_time' => $start_time_seconds,
                'end_time' => $end_time_seconds,
                'start_time_formatted' => $start_time_formatted,
                'end_time_formatted' => $end_time_formatted,
                'start_time_hour' => $start_time_hour,
                'start_time_minutes' => $start_time_minutes,
                'start_time_ampm' => $start_time_ampm,
                'end_time_hour' => $end_time_hour,
                'end_time_minutes' => $end_time_minutes,
                'end_time_ampm' => $end_time_ampm,
                'allday' => $formatted_meta['mec_allday'] ?? '0',
                'hide_time' => $formatted_meta['mec_hide_time'] ?? '0',
                'hide_end_time' => $formatted_meta['mec_hide_end_time'] ?? '0',
                'timezone' => $formatted_meta['mec_timezone'] ?? 'global',
                'comment' => $formatted_meta['mec_comment'] ?? '',
                'repeat_status' => $formatted_meta['mec_repeat_status'] ?? '0',
                'repeat_type' => $formatted_meta['mec_repeat_type'] ?? '',
                'repeat_interval' => $formatted_meta['mec_repeat_interval'] ?? null,
                'repeat_end' => $formatted_meta['mec_repeat_end'] ?? 'never',
                'repeat_end_at_date' => $formatted_meta['mec_repeat_end_at_date'] ?? '',
                // MEC stores internally as -1, add +1 for display (UI expects displayed value)
                'repeat_end_at_occurrences' => isset($formatted_meta['mec_repeat_end_at_occurrences']) ? (intval($formatted_meta['mec_repeat_end_at_occurrences']) + 1) : 10,
                'event_color' => $formatted_meta['mec_color'] ?? '',
                'cost' => $formatted_meta['mec_cost'] ?? '',
                'location_id' => $formatted_meta['mec_location_id'] ?? '',
                'organizer_id' => $formatted_meta['mec_organizer_id'] ?? '',
                'more_info' => $formatted_meta['mec_more_info'] ?? '',
                'more_info_title' => $formatted_meta['mec_more_info_title'] ?? '',
                'more_info_target' => $formatted_meta['mec_more_info_target'] ?? '_self',
                'read_more' => $formatted_meta['mec_read_more'] ?? '',
                'note' => $formatted_meta['mec_note'] ?? '',
                'public' => isset($formatted_meta['mec_public']) ? ($formatted_meta['mec_public'] == '1' ? '1' : '0') : '1',
                'visibility' => isset($formatted_meta['mec_public']) ? ($formatted_meta['mec_public'] == '1') : true,
                'visibility_label' => isset($formatted_meta['mec_public']) && $formatted_meta['mec_public'] == '1' ? 'Show on Shortcodes' : 'Hide on Shortcodes',
                'style_per_event' => $formatted_meta['mec_style_per_event'] ?? 'global',
                'details_page_style' => $formatted_meta['mec_style_per_event'] ?? 'global',
            ),
            'booking' => $booking_settings,
            'tickets' => $tickets_info,
            'fees' => $fees_info,
            'categories' => $format_terms($categories ?: []),
            'speakers' => $format_terms($speakers ?: []),
            'sponsors' => $format_terms($sponsors ?: []),
            'labels' => $format_terms($labels ?: []),
            'tags' => $format_terms($tags ?: []),
            'formatted_dates' => array(
                'start_date_formatted' => $start_date . ' ' . sprintf(
                    '%02d:%02d:%02d',
                    ($start_time_ampm === 'PM' && $start_time_hour != 12) ? $start_time_hour + 12 : (($start_time_ampm === 'AM' && $start_time_hour == 12) ? 0 : $start_time_hour),
                    $start_time_minutes,
                    0
                ),
                'end_date_formatted' => $end_date . ' ' . sprintf(
                    '%02d:%02d:%02d',
                    ($end_time_ampm === 'PM' && $end_time_hour != 12) ? $end_time_hour + 12 : (($end_time_ampm === 'AM' && $end_time_hour == 12) ? 0 : $end_time_hour),
                    $end_time_minutes,
                    0
                ),
            ),
            'zoom' => self::get_zoom_meta($event->ID),
            'virtual_event' => self::get_virtual_event_meta($event->ID),
            'meta' => $formatted_meta,
            'raw_mec_data' => $mec_data
        );
    }

    /**
     * Permission check for creating events
     */
    public static function create_permissions_check($request)
    {
        return \current_user_can('edit_posts');
    }

    /**
     * Permission check for updating events
     */
    public static function update_permissions_check($request)
    {
        $event_id = $request->get_param('id');
        return \current_user_can('edit_post', $event_id);
    }

    /**
     * Permission check for deleting events
     */
    public static function delete_permissions_check($request)
    {
        $event_id = $request->get_param('id');
        return \current_user_can('delete_post', $event_id);
    }

    /**
     * Permission check for taxonomy operations
     */
    public static function taxonomy_permissions_check($request)
    {
        // Use the same authentication system as events
        $user_data = \MecUtility\Auth\AuthHelper::verify_authentication($request);

        if (\is_wp_error($user_data)) {
            return false;
        }

        // Allow users with create_events or update_events permission
        $create_check = \MecUtility\Auth\AuthHelper::check_permission($user_data, 'create_events');
        $update_check = \MecUtility\Auth\AuthHelper::check_permission($user_data, 'update_events');

        return (!\is_wp_error($create_check)) || (!\is_wp_error($update_check));
    }

    /**
     * Apply date filters to WP_Query using JOIN with mec_events table
     *
     * @param array $args WP_Query arguments
     * @param string $start_date Start date filter
     * @param string $end_date End date filter
     * @param string $date_filter Predefined date filter
     * @return array Modified WP_Query arguments
     */
    private static function apply_date_filters($args, $start_date = null, $end_date = null, $date_filter = null)
    {
        global $wpdb;

        // Handle predefined date filters
        if (! empty($date_filter)) {
            $today = \current_time('Y-m-d');

            switch ($date_filter) {
                case 'today':
                    $start_date = $today;
                    $end_date = $today;
                    break;

                case 'upcoming':
                    $start_date = $today;
                    $end_date = null; // No end limit
                    break;

                case 'past':
                    $start_date = null; // No start limit
                    $end_date = date('Y-m-d', strtotime($today . ' -1 day'));
                    break;

                case 'this_week':
                    $start_date = date('Y-m-d', strtotime('monday this week'));
                    $end_date = date('Y-m-d', strtotime('sunday this week'));
                    break;

                case 'this_month':
                    $start_date = date('Y-m-01');
                    $end_date = date('Y-m-t');
                    break;
            }
        }

        // Validate dates
        if (! empty($start_date) && ! self::is_valid_date($start_date)) {
            $start_date = null;
        }
        if (! empty($end_date) && ! self::is_valid_date($end_date)) {
            $end_date = null;
        }

        // If we have date filters, we need to modify the query
        if (! empty($start_date) || ! empty($end_date)) {
            // Get post IDs that match date criteria from mec_events table
            $date_where = array();

            if (! empty($start_date)) {
                // Use exact match for start_date when only start_date is provided
                if (empty($end_date)) {
                    $date_where[] = $wpdb->prepare("start = %s", $start_date);
                } else {
                    $date_where[] = $wpdb->prepare("start >= %s", $start_date);
                }
            }

            if (! empty($end_date)) {
                $date_where[] = $wpdb->prepare("end <= %s", $end_date);
            }

            $date_query = "SELECT post_id FROM {$wpdb->prefix}mec_events WHERE " . implode(' AND ', $date_where);
            $matching_post_ids = $wpdb->get_col($date_query);

            if (empty($matching_post_ids)) {
                // No posts match date criteria, so return no results
                $args['post__in'] = array(0); // This will return no results
            } else {
                // Combine with existing post__in if any
                if (isset($args['post__in'])) {
                    $args['post__in'] = array_intersect($args['post__in'], $matching_post_ids);
                } else {
                    $args['post__in'] = $matching_post_ids;
                }
            }
        }

        return $args;
    }

    /**
     * Validate date format
     *
     * @param string $date Date string to validate
     * @return bool True if valid date
     */
    private static function is_valid_date($date)
    {
        $d = \DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    /**
     * Get attachment ID from URL
     *
     * @param string $url Image URL
     * @return int|false Attachment ID or false if not found
     */
    private static function get_attachment_id_from_url($url)
    {
        global $wpdb;

        $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE guid='%s';", $url));

        if (!empty($attachment)) {
            return $attachment[0];
        }

        // Try with relative URL
        $upload_dir = \wp_upload_dir();
        $relative_url = str_replace($upload_dir['baseurl'], '', $url);

        $attachment = $wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_wp_attached_file' AND meta_value LIKE '%%%s';", ltrim($relative_url, '/')));

        return !empty($attachment) ? $attachment[0] : false;
    }

    /**
     * Insert event data into mec_events table
     */
    private static function insert_mec_events_data($event_id, $start_date, $end_date, $repeat_status, $repeat_interval, $repeat_type, $day_start_seconds, $day_end_seconds)
    {
        global $wpdb;

        // Check if event already exists in mec_events table
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}mec_events WHERE post_id = %d",
            $event_id
        ));

        // Prepare event data for mec_events table
        $event_data = [
            'post_id' => $event_id,
            'start' => $start_date,
            'end' => $end_date,
            'repeat' => $repeat_status ? 1 : 0,
            'rinterval' => $repeat_interval,
            'year' => null,
            'month' => null,
            'day' => null,
            'week' => null,
            'weekday' => null,
            'weekdays' => null,
            'days' => '',
            'not_in_days' => '',
            'time_start' => $day_start_seconds,
            'time_end' => $day_end_seconds,
        ];

        if ($existing) {
            // Update existing record
            $wpdb->update(
                $wpdb->prefix . 'mec_events',
                $event_data,
                ['id' => $existing->id],
                ['%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d'],
                ['%d']
            );
        } else {
            // Insert new record
            $wpdb->insert(
                $wpdb->prefix . 'mec_events',
                $event_data,
                ['%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d']
            );
        }
    }

    /**
     * Get bookings with filters
     */
    public static function api_bookings($request)
    {
        try {
            global $wpdb;

            $params = $request->get_params();

            // === Admin-style filter aliases (from MEC admin UI) ===
            // Map aliases to existing filters so clients can send admin-like params
            // mec_event_id → event_id
            if (!empty($params['mec_event_id']) && empty($params['event_id'])) {
                $params['event_id'] = (int) $params['mec_event_id'];
            }

            // mec_booking_location → location_id
            if (!empty($params['mec_booking_location']) && empty($params['location_id'])) {
                $params['location_id'] = (int) $params['mec_booking_location'];
            }

            // mec_confirmed → confirmed (expects -1,0,1)
            if (isset($params['mec_confirmed']) && $params['mec_confirmed'] !== '' && !isset($params['confirmed'])) {
                $params['confirmed'] = (int) $params['mec_confirmed'];
            }

            // mec_verified → verified (expects -1,0,1)
            if (isset($params['mec_verified']) && $params['mec_verified'] !== '' && !isset($params['verified'])) {
                $params['verified'] = (int) $params['mec_verified'];
            }

            // mec_order_date → order_date (today,yesterday,current_month,last_month,current_year,last_year)
            if (!empty($params['mec_order_date']) && empty($params['order_date'])) {
                $params['order_date'] = sanitize_text_field($params['mec_order_date']);
            }

            // mec_ticket_name -> parses value like "{eventID}:..:, ,{ticketId},"
            // and maps to event_id + ticket_id
            if (!empty($params['mec_ticket_name'])) {
                $raw = sanitize_text_field($params['mec_ticket_name']);
                $parts = explode(':..:', $raw);
                if (count($parts) === 2) {
                    $parsed_event_id = (int) $parts[0];
                    $ticket_part = $parts[1];
                    // ticket_part is like ",{ticketId}," – extract first integer inside commas
                    if (preg_match('/,(\d+),/', $ticket_part, $m)) {
                        $parsed_ticket_id = (int) $m[1];
                        if ($parsed_event_id && empty($params['event_id'])) {
                            $params['event_id'] = $parsed_event_id;
                        }
                        if ($parsed_ticket_id && empty($params['ticket_id'])) {
                            $params['ticket_id'] = $parsed_ticket_id;
                        }
                    }
                }
            }

            // Get filtering parameters
            $per_page = isset($params['per_page']) ? (int) $params['per_page'] : 20;
            $page = isset($params['page']) ? (int) $params['page'] : 1;
            $offset = ($page - 1) * $per_page;

            $where_conditions = [];
            $join_conditions = [];

            // Search functionality
            if (!empty($params['search'])) {
                $search = sanitize_text_field($params['search']);
                $where_conditions[] = $wpdb->prepare("(
                        p.post_title LIKE %s OR
                        b.transaction_id LIKE %s OR
                        pm_attendees.meta_value LIKE %s OR
                        event_p.post_title LIKE %s
                    )", "%$search%", "%$search%", "%$search%", "%$search%");
            }

            // Event filter
            if (!empty($params['event_id'])) {
                $where_conditions[] = $wpdb->prepare("b.event_id = %d", (int) $params['event_id']);
            }

            // Date filter (All dates dropdown)
            if (!empty($params['date_filter'])) {
                $date_filter = sanitize_text_field($params['date_filter']);
                $now = current_time('timestamp');

                switch ($date_filter) {
                    case 'today':
                        $today_start = strtotime('today');
                        $today_end = strtotime('tomorrow') - 1;
                        $where_conditions[] = $wpdb->prepare("b.timestamp BETWEEN %d AND %d", $today_start, $today_end);
                        break;
                    case 'upcoming':
                        $where_conditions[] = $wpdb->prepare("b.timestamp > %d", $now);
                        break;
                    case 'past':
                        $where_conditions[] = $wpdb->prepare("b.timestamp < %d", $now);
                        break;
                    case 'this_week':
                        $week_start = strtotime('monday this week');
                        $week_end = strtotime('sunday this week') + 86399;
                        $where_conditions[] = $wpdb->prepare("b.timestamp BETWEEN %d AND %d", $week_start, $week_end);
                        break;
                    case 'this_month':
                        $month_start = strtotime('first day of this month');
                        $month_end = strtotime('last day of this month') + 86399;
                        $where_conditions[] = $wpdb->prepare("b.timestamp BETWEEN %d AND %d", $month_start, $month_end);
                        break;
                }
            }

            // Specific single date (YYYY-MM-DD) – alias to b.timestamp BETWEEN day start/end
            if (!empty($params['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $params['date'])) {
                $day_start = strtotime($params['date'] . ' 00:00:00');
                $day_end = strtotime($params['date'] . ' 23:59:59');
                $where_conditions[] = $wpdb->prepare("b.timestamp BETWEEN %d AND %d", $day_start, $day_end);
            }

            // mec_occurrence (timestamp of occurrence start) – filter exact match on b.timestamp
            if (!empty($params['mec_occurrence']) && is_numeric($params['mec_occurrence'])) {
                $occ_ts = (int) $params['mec_occurrence'];
                $where_conditions[] = $wpdb->prepare("b.timestamp = %d", $occ_ts);
            }

            // Specific date range
            if (!empty($params['start_date']) && !empty($params['end_date'])) {
                $start_timestamp = strtotime($params['start_date']);
                $end_timestamp = strtotime($params['end_date']) + 86399;
                $where_conditions[] = $wpdb->prepare("b.timestamp BETWEEN %d AND %d", $start_timestamp, $end_timestamp);
            }

            // Ticket filter - support both ticket_id and ticket_name
            if (!empty($params['ticket_id'])) {
                // Filter by ticket ID
                $where_conditions[] = $wpdb->prepare("b.ticket_ids LIKE %s", "%," . (int) $params['ticket_id'] . ",%");
            } elseif (!empty($params['ticket_name'])) {
                // Filter by ticket name - find matching ticket IDs
                $ticket_name = sanitize_text_field($params['ticket_name']);
                $matching_conditions = [];

                // If event_id is provided, search only in that event's tickets
                if (!empty($params['event_id'])) {
                    $event_id = (int) $params['event_id'];
                    $event_tickets = get_post_meta($event_id, 'mec_tickets', true);
                    if (is_array($event_tickets)) {
                        foreach ($event_tickets as $ticket_id => $ticket) {
                            if (isset($ticket['name']) && stripos($ticket['name'], $ticket_name) !== false) {
                                $matching_conditions[] = $wpdb->prepare("b.ticket_ids LIKE %s", "%,$ticket_id,%");
                            }
                        }
                    }
                } else {
                    // No event_id provided - search in attendees meta (contains ticket names)
                    // This is a simpler approach that works across all events
                    $matching_conditions[] = $wpdb->prepare("pm_attendees.meta_value LIKE %s", "%\"name\":\"%$ticket_name%\"%");
                }

                if (!empty($matching_conditions)) {
                    $where_conditions[] = '(' . implode(' OR ', $matching_conditions) . ')';
                } else {
                    // No matching tickets found, return empty result
                    $where_conditions[] = '1=0';
                }
            }

            // Status filter
            if (!empty($params['status'])) {
                $where_conditions[] = $wpdb->prepare("b.status = %s", sanitize_text_field($params['status']));
            }

            // Confirmed filter
            if (isset($params['confirmed']) && $params['confirmed'] !== '') {
                $where_conditions[] = $wpdb->prepare("b.confirmed = %d", (int) $params['confirmed']);
            }

            // Verified filter
            if (isset($params['verified']) && $params['verified'] !== '') {
                $where_conditions[] = $wpdb->prepare("b.verified = %d", (int) $params['verified']);
            }

            // Order Date filter
            if (!empty($params['order_date'])) {
                $order_date = sanitize_text_field($params['order_date']);
                $booking_time_conditions = [];

                switch ($order_date) {
                    case 'today':
                        $today = current_time('Y-m-d');
                        $booking_time_conditions[] = $wpdb->prepare("pm_booking_time.meta_value LIKE %s", "$today%");
                        break;
                    case 'yesterday':
                        $yesterday = date('Y-m-d', strtotime('-1 day'));
                        $booking_time_conditions[] = $wpdb->prepare("pm_booking_time.meta_value LIKE %s", "$yesterday%");
                        break;
                    case 'current_month':
                        $current_month = current_time('Y-m');
                        $booking_time_conditions[] = $wpdb->prepare("pm_booking_time.meta_value LIKE %s", "$current_month%");
                        break;
                    case 'last_month':
                        $last_month = date('Y-m', strtotime('-1 month'));
                        $booking_time_conditions[] = $wpdb->prepare("pm_booking_time.meta_value LIKE %s", "$last_month%");
                        break;
                    case 'current_year':
                        $current_year = current_time('Y');
                        $booking_time_conditions[] = $wpdb->prepare("pm_booking_time.meta_value LIKE %s", "$current_year%");
                        break;
                    case 'last_year':
                        $last_year = date('Y', strtotime('-1 year'));
                        $booking_time_conditions[] = $wpdb->prepare("pm_booking_time.meta_value LIKE %s", "$last_year%");
                        break;
                }

                if (!empty($booking_time_conditions)) {
                    $where_conditions = array_merge($where_conditions, $booking_time_conditions);
                }
            }

            // Location filter - check both booking location and event locations (taxonomy)
            if (!empty($params['location_id'])) {
                $location_id = (int) $params['location_id'];

                // Get all event IDs that have this location (via taxonomy)
                $events_with_location = $wpdb->get_col($wpdb->prepare(
                    "SELECT DISTINCT tr.object_id 
                     FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
                     WHERE tt.taxonomy = 'mec_location' AND tt.term_id = %d",
                    $location_id
                ));

                if (!empty($events_with_location)) {
                    // Sanitize event IDs
                    $events_with_location = array_map('intval', $events_with_location);
                    $events_list = implode(',', $events_with_location);
                    // Filter by booking location OR event has this location
                    // Note: events_list is already sanitized with intval, so safe to use
                    $where_conditions[] = $wpdb->prepare(
                        "(pm_booking_location.meta_value = %d OR b.event_id IN ($events_list))",
                        $location_id
                    );
                } else {
                    // No events with this location, only check booking location
                    $where_conditions[] = $wpdb->prepare("pm_booking_location.meta_value = %d", $location_id);
                }
            }

            // User filter
            if (!empty($params['user_id'])) {
                $where_conditions[] = $wpdb->prepare("b.user_id = %d", (int) $params['user_id']);
            }

            // Build JOIN clauses
            $join_query = "
                    LEFT JOIN {$wpdb->posts} p ON b.booking_id = p.ID
                    LEFT JOIN {$wpdb->posts} event_p ON b.event_id = event_p.ID
                    LEFT JOIN {$wpdb->postmeta} pm_attendees ON (b.booking_id = pm_attendees.post_id AND pm_attendees.meta_key = 'mec_attendees')
                    LEFT JOIN {$wpdb->postmeta} pm_booking_time ON (b.booking_id = pm_booking_time.post_id AND pm_booking_time.meta_key = 'mec_booking_time')
                    LEFT JOIN {$wpdb->postmeta} pm_booking_location ON (b.booking_id = pm_booking_location.post_id AND pm_booking_location.meta_key = 'mec_booking_location')
                ";

            // Build WHERE clause
            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

            // Count query
            $count_sql = "SELECT COUNT(DISTINCT b.booking_id) FROM {$wpdb->prefix}mec_bookings b $join_query $where_clause";
            $total = $wpdb->get_var($count_sql);

            // Data query
            $sql = "SELECT DISTINCT b.*, p.post_title, p.post_date, p.post_status, event_p.post_title as event_title
                    FROM {$wpdb->prefix}mec_bookings b
                    $join_query
                    $where_clause
                    ORDER BY p.post_date DESC
                    LIMIT %d OFFSET %d";

            $results = $wpdb->get_results($wpdb->prepare($sql, $per_page, $offset));

            // Format results
            $bookings = [];
            foreach ($results as $row) {
                $booking_id = (int) $row->booking_id;
                $event_id = (int) $row->event_id;

                // Get attendees
                $attendees = get_post_meta($booking_id, 'mec_attendees', true);
                if (!is_array($attendees)) {
                    $attendees = [];
                }

                // Get fixed fields
                $fixed_fields = get_post_meta($booking_id, 'mec_fixed_fields', true);
                if (!is_array($fixed_fields)) {
                    $fixed_fields = [];
                }

                // Get event details
                $event = get_post($event_id);
                $event_tickets = get_post_meta($event_id, 'mec_tickets', true);
                if (!is_array($event_tickets)) {
                    $event_tickets = [];
                }

                // Get all location details for this event
                $location_id = get_post_meta($event_id, 'mec_location_id', true);
                $location_name = '';
                $locations_data = array();

                // Get all location terms for this event
                $location_terms = wp_get_post_terms($event_id, 'mec_location', ['fields' => 'all']);
                if (!is_wp_error($location_terms) && is_array($location_terms)) {
                    foreach ($location_terms as $location_term) {
                        $location_meta = get_term_meta($location_term->term_id);
                        $locations_data[] = array(
                            'id' => (int) $location_term->term_id,
                            'name' => $location_term->name,
                            'label' => $location_term->name, // Location label (same as name)
                            'slug' => $location_term->slug,
                            'description' => $location_term->description,
                            'address' => isset($location_meta['address'][0]) ? $location_meta['address'][0] : '',
                            'latitude' => isset($location_meta['latitude'][0]) ? $location_meta['latitude'][0] : '',
                            'longitude' => isset($location_meta['longitude'][0]) ? $location_meta['longitude'][0] : '',
                            'url' => isset($location_meta['url'][0]) ? $location_meta['url'][0] : '',
                            'tel' => isset($location_meta['tel'][0]) ? $location_meta['tel'][0] : '',
                            'thumbnail' => isset($location_meta['thumbnail'][0]) ? $location_meta['thumbnail'][0] : '',
                        );
                    }
                }

                // Keep backward compatibility with main location
                if ($location_id) {
                    $location = get_term($location_id, 'mec_location');
                    if ($location && !is_wp_error($location)) {
                        $location_name = $location->name;
                    }
                }

                // Build occurrence options for this event (for date switching UI)
                $occurrence_options = [];
                $occ_sql = $wpdb->prepare(
                    "SELECT d.dstart, d.dend, d.tstart, d.tend\n                     FROM {$wpdb->prefix}mec_dates d\n                     WHERE d.post_id = %d AND d.public = 1\n                     ORDER BY d.tstart ASC",
                    $event_id
                );
                $occ_rows = $wpdb->get_results($occ_sql);
                if (is_array($occ_rows)) {
                    foreach ($occ_rows as $occ) {
                        $start_ts = (int) $occ->tstart;
                        $end_ts = (int) $occ->tend;
                        $start_date = $occ->dstart;
                        $end_date = $occ->dend;

                        // Build a human label similar to MEC admin list
                        if (!empty($start_date) && !empty($end_date) && $start_date !== $end_date) {
                            $label = $start_date . ' - ' . $end_date;
                        } else {
                            $label = $start_date . ' ' . date('H:i', $start_ts) . ' - ' . date('H:i', $end_ts);
                        }

                        $occurrence_options[] = [
                            'timestamp' => $start_ts,
                            'start_date' => $start_date,
                            'end_date' => $end_date,
                            'start_datetime' => date('Y-m-d H:i:s', $start_ts),
                            'end_datetime' => date('Y-m-d H:i:s', $end_ts),
                            'label' => $label
                        ];
                    }
                }

                // Format attendees
                $formatted_attendees = [];
                foreach ($attendees as $key => $attendee) {
                    if (!is_numeric($key)) continue;

                    $ticket_id = $attendee['id'] ?? 0;
                    $ticket_name = isset($event_tickets[$ticket_id]['name']) ? $event_tickets[$ticket_id]['name'] : 'Unknown';

                    $formatted_attendees[] = [
                        'name' => $attendee['name'] ?? '',
                        'email' => $attendee['email'] ?? '',
                        'ticket_id' => $ticket_id,
                        'ticket_name' => $ticket_name,
                        'phone' => $attendee['phone'] ?? '',
                        'birth_date' => $attendee['birth_date'] ?? '',
                        'note' => $attendee['note'] ?? '',
                        'variations' => $attendee['variations'] ?? [],
                        'reg' => $attendee['reg'] ?? []
                    ];
                }

                // Derive booking_date from selected occurrence (mec_date) to reflect UI selection
                $event_start_ts_meta = 0;
                $mec_date_meta = get_post_meta($booking_id, 'mec_date', true);
                if (is_string($mec_date_meta) && strpos($mec_date_meta, ':') !== false) {
                    $parts = explode(':', $mec_date_meta);
                    if (count($parts) === 2 && ctype_digit((string)$parts[0])) {
                        $event_start_ts_meta = (int) $parts[0];
                    }
                }
                $derived_booking_date = $event_start_ts_meta ? date('Y-m-d H:i:s', $event_start_ts_meta) : $row->post_date;

                // Get start date from event
                $start_date = get_post_meta($event_id, 'mec_start_date', true);
                if (empty($start_date)) {
                    $start_date = $row->date;
                }

                $bookings[] = [
                    'id' => $booking_id,
                    'booking_id' => $booking_id,
                    'event_id' => $event_id,
                    'event_title' => $event ? self::clean_title($event->post_title) : 'Unknown Event',
                    'event_date' => $row->date,
                    'event_timestamp' => (int) $row->timestamp,
                    'start_date' => $start_date, // Start Date field
                    'occurrence_options' => $occurrence_options,
                    'transaction_id' => $row->transaction_id,
                    'user_id' => (int) $row->user_id,
                    'status' => $row->status,
                    'confirmed' => (int) $row->confirmed, // Confirmation field
                    'verified' => (int) $row->verified, // Verification field
                    'seats' => (int) $row->seats,
                    'booking_date' => $derived_booking_date,
                    'booking_time' => get_post_meta($booking_id, 'mec_booking_time', true),
                    'price' => get_post_meta($booking_id, 'mec_price', true),
                    'coupon' => get_post_meta($booking_id, 'mec_coupon_code', true),
                    'location' => [
                        'id' => $location_id,
                        'name' => $location_name
                    ],
                    'locations' => $locations_data, // All locations for the event
                    'attendees' => $formatted_attendees,
                    'fixed_fields' => $fixed_fields,
                    'attendees_count' => count($formatted_attendees)
                ];
            }

            $total_pages = ceil($total / $per_page);

            return new \WP_REST_Response([
                'bookings' => $bookings,
                'pagination' => [
                    'total' => (int) $total,
                    'per_page' => $per_page,
                    'current_page' => $page,
                    'total_pages' => $total_pages,
                    'has_more' => $page < $total_pages
                ],
                'filters_applied' => [
                    'search' => $params['search'] ?? '',
                    'event_id' => $params['event_id'] ?? '',
                    'date_filter' => $params['date_filter'] ?? '',
                    'start_date' => $params['start_date'] ?? '',
                    'end_date' => $params['end_date'] ?? '',
                    'ticket_id' => $params['ticket_id'] ?? '',
                    'status' => $params['status'] ?? '',
                    'confirmed' => $params['confirmed'] ?? '',
                    'verified' => $params['verified'] ?? '',
                    'order_date' => $params['order_date'] ?? '',
                    'location_id' => $params['location_id'] ?? '',
                    'user_id' => $params['user_id'] ?? ''
                ]
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('bookings_error', 'Error fetching bookings: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get single booking with full details
     */
    public static function api_single_booking($request)
    {
        try {
            $booking_id = (int) $request['booking_id'];

            // Validate booking exists
            $booking = get_post($booking_id);
            if (!$booking || $booking->post_type !== 'mec-books') {
                return new \WP_Error('booking_not_found', 'Booking not found.', ['status' => 404]);
            }

            global $wpdb;

            // Get booking record
            $booking_record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}mec_bookings WHERE booking_id = %d",
                $booking_id
            ));

            if (!$booking_record) {
                return new \WP_Error('booking_record_not_found', 'Booking record not found.', ['status' => 404]);
            }

            // Get event
            $event_id = (int) $booking_record->event_id;
            $event = get_post($event_id);

            // Get event tickets
            $event_tickets = get_post_meta($event_id, 'mec_tickets', true);
            if (!is_array($event_tickets)) {
                $event_tickets = [];
            }

            // Get attendees
            $attendees = get_post_meta($booking_id, 'mec_attendees', true);
            if (!is_array($attendees)) {
                $attendees = [];
            }

            // Get fixed fields
            $fixed_fields = get_post_meta($booking_id, 'mec_fixed_fields', true);
            if (!is_array($fixed_fields)) {
                $fixed_fields = [];
            }

            // Get payment details
            $transaction_id = get_post_meta($booking_id, 'mec_transaction_id', true);
            $transaction = [];
            if ($transaction_id && function_exists('MEC\Base::get_main')) {
                $main = \MEC\Base::get_main();
                if (method_exists($main, 'get_book')) {
                    $book = $main->get_book();
                    $transaction = $book->get_transaction($transaction_id);
                }
            }

            // Get payment meta fields
            $price = get_post_meta($booking_id, 'mec_price', true);
            $payable = get_post_meta($booking_id, 'mec_payable', true);
            $gateway = get_post_meta($booking_id, 'mec_gateway', true);
            $gateway_label = get_post_meta($booking_id, 'mec_gateway_label', true);
            $gateway_ref_id = get_post_meta($booking_id, 'mec_gateway_ref_id', true);
            $coupon_code = get_post_meta($booking_id, 'mec_coupon_code', true);


            $discount = 0;
            $subtotal = 0;
            $tax = 0;
            $fees = 0;

            // Extract pricing details from transaction
            if (isset($transaction['price_details']) && is_array($transaction['price_details'])) {
                $price_details = $transaction['price_details'];
                $subtotal = isset($price_details['subtotal']) ? $price_details['subtotal'] : 0;
                $tax = isset($price_details['tax']) ? $price_details['tax'] : 0;
                $fees = isset($price_details['fees']) ? $price_details['fees'] : 0;
                $discount = isset($price_details['discount']) ? $price_details['discount'] : 0;
            }

            // Fallback: Get coupon code from transaction if not found in meta
            if (empty($coupon_code) && isset($transaction['coupon'])) {
                $coupon_code = $transaction['coupon'];
            }

            // Calculate invoice number (format: #transaction_id)
            $invoice_number = $transaction_id ? '#' . $transaction_id : '';

            // Get location details
            $location_id = get_post_meta($event_id, 'mec_location_id', true);
            $location_name = '';
            if ($location_id) {
                $location = get_term($location_id, 'mec_location');
                if ($location && !is_wp_error($location)) {
                    $location_name = $location->name;
                }
            }

            // Get registration fields structure from multiple sources
            $reg_fields = [];

            // 1. First try: Get from Event Settings (mec_reg_fields)
            $event_reg_fields = get_post_meta($event_id, 'mec_reg_fields', true);
            if (is_array($event_reg_fields)) {
                foreach ($event_reg_fields as $field_id => $field) {
                    $reg_fields[$field_id] = [
                        'label' => $field['label'] ?? $field_id,
                        'type' => $field['type'] ?? 'text',
                        'options' => $field['options'] ?? []
                    ];
                }
            }

            // 2. Second try: Get from Booking Form
            if (empty($reg_fields)) {
                $booking_form_id = get_post_meta($event_id, 'mec_reg_form', true);

                if (!$booking_form_id) {
                    // Try to get default booking form
                    $booking_form_id = get_post_meta($event_id, 'mec_booking_form', true);
                }

                if ($booking_form_id) {
                    $form_fields = get_post_meta($booking_form_id, 'mec_fields', true);
                    if (is_array($form_fields)) {
                        foreach ($form_fields as $field_id => $field) {
                            $reg_fields[$field_id] = [
                                'label' => $field['label'] ?? '',
                                'type' => $field['type'] ?? 'text',
                                'options' => $field['options'] ?? []
                            ];
                        }
                    }
                }
            }

            // 3. Third try: Get from MEC main class
            if (empty($reg_fields) && class_exists('MEC_feature_books')) {
                $books = new \MEC_feature_books();
                if (method_exists($books, 'get_reg_fields')) {
                    $mec_reg_fields = $books->get_reg_fields($event_id);
                    if (is_array($mec_reg_fields)) {
                        foreach ($mec_reg_fields as $field_id => $field) {
                            $reg_fields[$field_id] = [
                                'label' => $field['label'] ?? $field['name'] ?? "Field $field_id",
                                'type' => $field['type'] ?? 'text',
                                'options' => $field['options'] ?? []
                            ];
                        }
                    }
                }
            }

            // 4. Last resort: Get from global MEC settings
            if (empty($reg_fields)) {
                $mec_settings = get_option('mec_options', []);
                if (isset($mec_settings['reg_fields']) && is_array($mec_settings['reg_fields'])) {
                    foreach ($mec_settings['reg_fields'] as $field_id => $field) {
                        $reg_fields[$field_id] = [
                            'label' => $field['label'] ?? $field_id,
                            'type' => $field['type'] ?? 'text',
                            'options' => $field['options'] ?? []
                        ];
                    }
                }
            }

            // Format attendees with full details
            $formatted_attendees = [];
            foreach ($attendees as $key => $attendee) {
                if (!is_numeric($key)) continue;

                $ticket_id = $attendee['id'] ?? 0;
                $ticket_name = isset($event_tickets[$ticket_id]['name']) ? $event_tickets[$ticket_id]['name'] : 'Unknown';

                // Get ticket variations details using MEC's native method
                $ticket_variations = [];

                // Use MEC main library to get variations (this handles all inheritance logic)
                if (class_exists('MEC_main')) {
                    $mec_main = new \MEC_main();
                    $ticket_variations = $mec_main->ticket_variations($event_id, $ticket_id);
                } elseif (function_exists('MEC\Base::get_main')) {
                    $main = \MEC\Base::get_main();
                    if (method_exists($main, 'ticket_variations')) {
                        $ticket_variations = $main->ticket_variations($event_id, $ticket_id);
                    }
                }

                // Format variations with full details
                $formatted_variations = [];
                if (isset($attendee['variations']) && is_array($attendee['variations'])) {
                    foreach ($attendee['variations'] as $variation_id => $variation_count) {
                        $variation_info = [
                            'variation_id' => (int) $variation_id,
                            'count' => (int) $variation_count
                        ];

                        if (isset($ticket_variations[$variation_id]) && is_array($ticket_variations[$variation_id])) {
                            $variation = $ticket_variations[$variation_id];
                            $variation_info['title'] = $variation['title'] ?? "Variation $variation_id";
                            $variation_info['price'] = isset($variation['price']) ? (float) $variation['price'] : 0;
                            $variation_info['max'] = isset($variation['max']) ? (int) $variation['max'] : 1000;
                            $variation_info['min'] = isset($variation['min']) ? (int) $variation['min'] : 0;
                        } else {
                            // Fallback if variation not found
                            $variation_info['title'] = "Variation $variation_id";
                            $variation_info['price'] = 0;
                            $variation_info['max'] = 1000;
                            $variation_info['min'] = 0;
                        }

                        $formatted_variations[] = $variation_info;
                    }
                }

                // Format registration fields with complete information
                $reg_data = [];
                if (isset($attendee['reg']) && is_array($attendee['reg'])) {
                    foreach ($attendee['reg'] as $field_id => $field_value) {
                        $field_info = [
                            'field_id' => $field_id,
                            'value' => $field_value
                        ];

                        if (isset($reg_fields[$field_id])) {
                            $field_info['label'] = $reg_fields[$field_id]['label'];
                            $field_info['type'] = $reg_fields[$field_id]['type'];

                            // Add options if it's a select/radio/checkbox field
                            if (!empty($reg_fields[$field_id]['options'])) {
                                $field_info['options'] = $reg_fields[$field_id]['options'];

                                // Add selected value information for better UX
                                $selected_value = $field_value;
                                $selected_label = $selected_value;

                                // Find the label for the selected value
                                if (isset($reg_fields[$field_id]['options'][$selected_value])) {
                                    $selected_option = $reg_fields[$field_id]['options'][$selected_value];
                                    if (is_array($selected_option) && isset($selected_option['label'])) {
                                        $selected_label = $selected_option['label'];
                                    } elseif (is_string($selected_option)) {
                                        $selected_label = $selected_option;
                                    }
                                }

                                $field_info['selected'] = [
                                    'value' => $selected_value,
                                    'label' => $selected_label
                                ];
                            }
                        } else {
                            // Fallback: try to detect type from field_id or value
                            $field_info['label'] = ucfirst(str_replace(['_', '-'], ' ', $field_id));
                            $field_info['type'] = 'text';
                        }

                        $reg_data[] = $field_info;
                    }
                }

                $formatted_attendees[] = [
                    'key' => $key,
                    'name' => $attendee['name'] ?? '',
                    'email' => $attendee['email'] ?? '',
                    'ticket_id' => $ticket_id,
                    'ticket_name' => $ticket_name,
                    'phone' => $attendee['phone'] ?? '',
                    'birth_date' => $attendee['birth_date'] ?? '',
                    'note' => $attendee['note'] ?? '',
                    'variations' => $attendee['variations'] ?? [],
                    'variations_formatted' => $formatted_variations,
                    'reg' => $attendee['reg'] ?? [],
                    'reg_formatted' => $reg_data
                ];
            }

            // Get selected occurrence from meta with robust fallbacks
            $selected_start_ts = 0;
            $selected_end_ts = 0;
            $mec_all_dates_meta = get_post_meta($booking_id, 'mec_all_dates', true);
            if (is_array($mec_all_dates_meta) && !empty($mec_all_dates_meta[0]) && is_string($mec_all_dates_meta[0]) && strpos($mec_all_dates_meta[0], ':') !== false) {
                $parts = explode(':', $mec_all_dates_meta[0]);
                if (count($parts) === 2 && ctype_digit((string)$parts[0]) && ctype_digit((string)$parts[1])) {
                    $selected_start_ts = (int) $parts[0];
                    $selected_end_ts = (int) $parts[1];
                }
            }
            if (!$selected_start_ts) {
                $date_info = get_post_meta($booking_id, 'mec_date', true);
                if (is_string($date_info) && strpos($date_info, ':') !== false) {
                    $parts = explode(':', $date_info);
                    if (count($parts) === 2 && ctype_digit((string)$parts[0]) && ctype_digit((string)$parts[1])) {
                        $selected_start_ts = (int) $parts[0];
                        $selected_end_ts = (int) $parts[1];
                    }
                }
            }
            if (!$selected_start_ts) {
                // Final fallback: use booking record timestamps
                $selected_start_ts = (int) $booking_record->timestamp;
                // Try to find matching tend by looking up mec_dates on same day
                $occ_row = $wpdb->get_row($wpdb->prepare(
                    "SELECT tend FROM {$wpdb->prefix}mec_dates WHERE post_id = %d AND dstart = %s AND public = 1 ORDER BY ABS(tstart - %d) ASC LIMIT 1",
                    $event_id,
                    date('Y-m-d', $selected_start_ts),
                    $selected_start_ts
                ));
                $selected_end_ts = $occ_row ? (int) $occ_row->tend : $selected_start_ts;
            }

            // Build occurrence options for this event as well
            $occurrence_options = [];
            $occ_sql = $wpdb->prepare(
                "SELECT d.dstart, d.dend, d.tstart, d.tend\n                 FROM {$wpdb->prefix}mec_dates d\n                 WHERE d.post_id = %d AND d.public = 1\n                 ORDER BY d.tstart ASC",
                $event_id
            );
            $occ_rows = $wpdb->get_results($occ_sql);
            if (is_array($occ_rows)) {
                foreach ($occ_rows as $occ) {
                    $start_ts = (int) $occ->tstart;
                    $end_ts = (int) $occ->tend;
                    $start_date = $occ->dstart;
                    $end_date = $occ->dend;

                    if (!empty($start_date) && !empty($end_date) && $start_date !== $end_date) {
                        $label = $start_date . ' - ' . $end_date;
                    } else {
                        $label = $start_date . ' ' . date('H:i', $start_ts) . ' - ' . date('H:i', $end_ts);
                    }

                    $occurrence_options[] = [
                        'timestamp' => $start_ts,
                        'start_date' => $start_date,
                        'end_date' => $end_date,
                        'start_datetime' => date('Y-m-d H:i:s', $start_ts),
                        'end_datetime' => date('Y-m-d H:i:s', $end_ts),
                        'label' => $label
                    ];
                }
            }

            $booking_data = [
                'id' => $booking_id,
                'booking_id' => $booking_id,
                'event_id' => $event_id,
                'event_title' => $event ? self::clean_title($event->post_title) : 'Unknown Event',
                'event_date' => date('Y-m-d', $selected_start_ts),
                'event_timestamp' => $selected_start_ts,
                'event_start_timestamp' => $selected_start_ts,
                'event_end_timestamp' => $selected_end_ts,
                'occurrence_options' => $occurrence_options,
                'transaction_id' => $booking_record->transaction_id,
                'user_id' => (int) $booking_record->user_id,
                'status' => $booking_record->status,
                'confirmed' => (int) $booking_record->confirmed,
                'verified' => (int) $booking_record->verified,
                'seats' => (int) $booking_record->seats,
                'booking_date' => date('Y-m-d H:i:s', $selected_start_ts),
                'booking_time' => get_post_meta($booking_id, 'mec_booking_time', true),
                'price' => $price,
                'coupon' => $coupon_code,
                'location' => [
                    'id' => $location_id,
                    'name' => $location_name
                ],
                'attendees' => $formatted_attendees,
                'fixed_fields' => $fixed_fields,
                'attendees_count' => count($formatted_attendees),
                'available_tickets' => $event_tickets,

                // Payment and billing details (matching the mobile app UI)
                'invoice_number' => $invoice_number,
                'payment' => [
                    'price' => $price,
                    'paid_amount' => $payable ?: $price,
                    'gateway' => $gateway_label ?: 'Unknown',
                    'gateway_class' => $gateway,
                    'gateway_ref_id' => $gateway_ref_id,
                    'transaction_id' => $transaction_id
                ],
                'billing' => [
                    'subtotal' => $subtotal ?: $price,
                    'discount' => $discount,
                    'tax' => $tax,
                    'fees' => $fees,
                    'total' => $price,
                    'paid' => $payable ?: $price,
                    'coupon_code' => $coupon_code
                ],

                // Status labels for UI
                'confirmation_status' => self::get_confirmation_label($booking_record->confirmed),
                'verification_status' => self::get_verification_label($booking_record->verified)
            ];

            return new \WP_REST_Response($booking_data, 200);
        } catch (\Exception $e) {
            return new \WP_Error('booking_error', 'Error fetching booking: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Update booking
     */
    public static function api_update_booking($request)
    {
        try {
            $booking_id = (int) $request['booking_id'];
            // Merge JSON body params explicitly to be safe across clients
            $params = $request->get_params();
            $json_params = method_exists($request, 'get_json_params') ? (array) $request->get_json_params() : [];
            if (is_array($json_params) && !empty($json_params)) {
                $params = array_merge($params ?: [], $json_params);
            }

            // Validate booking exists
            $booking = get_post($booking_id);
            if (!$booking || $booking->post_type !== 'mec-books') {
                return new \WP_Error('booking_not_found', 'Booking not found.', ['status' => 404]);
            }

            global $wpdb;

            // Load current booking record
            $booking_record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}mec_bookings WHERE booking_id = %d",
                $booking_id
            ));
            if (!$booking_record) {
                return new \WP_Error('booking_record_not_found', 'Booking record not found.', ['status' => 404]);
            }

            // Update booking record in mec_bookings table
            $update_data = [];
            if (isset($params['status'])) {
                $update_data['status'] = sanitize_text_field($params['status']);
            }
            if (isset($params['confirmed'])) {
                $update_data['confirmed'] = (int) $params['confirmed'];
            }
            if (isset($params['verified'])) {
                $update_data['verified'] = (int) $params['verified'];
            }

            if (!empty($update_data)) {
                $wpdb->update(
                    $wpdb->prefix . 'mec_bookings',
                    $update_data,
                    ['booking_id' => $booking_id],
                    [],
                    ['%d']
                );
            }

            // Update post meta
            if (isset($params['confirmed'])) {
                update_post_meta($booking_id, 'mec_confirmed', (int) $params['confirmed']);
            }
            if (isset($params['verified'])) {
                update_post_meta($booking_id, 'mec_verified', (int) $params['verified']);
            }
            if (isset($params['coupon'])) {
                // MEC uses mec_coupon_code for coupon storage
                update_post_meta($booking_id, 'mec_coupon_code', sanitize_text_field($params['coupon']));

                // Also apply coupon to transaction if book class exists
                if (class_exists('MEC_book')) {
                    $book = new \MEC_book();
                    $transaction_id = get_post_meta($booking_id, 'mec_transaction_id', true);
                    if ($transaction_id) {
                        $book->coupon_apply($params['coupon'], $transaction_id);
                    }
                }
            }

            // Update booking date/time
            if (isset($params['booking_date'])) {
                $booking_date = sanitize_text_field($params['booking_date']);
                update_post_meta($booking_id, 'mec_booking_time', $booking_date);

                // Update post_date for WordPress post
                wp_update_post([
                    'ID' => $booking_id,
                    'post_date' => $booking_date
                ]);
            }

            // Update selected occurrence (event date) like MEC admin UI
            // Accept any of: 'occurrence_timestamp', 'mec_occurrence', or direct 'mec_date' pair "tstart:tend"
            $occurrence_timestamp = null;
            $mec_date_pair = null;
            if (isset($params['mec_date']) && is_string($params['mec_date']) && strpos($params['mec_date'], ':') !== false) {
                $mec_date_pair = trim($params['mec_date']);
                $parts = explode(':', $mec_date_pair);
                if (count($parts) === 2 && ctype_digit((string)$parts[0]) && ctype_digit((string)$parts[1])) {
                    $occurrence_timestamp = (int) $parts[0];
                } else {
                    $mec_date_pair = null; // invalid format, fallback to timestamp lookup
                }
            }
            if (!$occurrence_timestamp) {
                if (isset($params['occurrence_timestamp']) && is_numeric($params['occurrence_timestamp'])) {
                    $occurrence_timestamp = (int) $params['occurrence_timestamp'];
                } elseif (isset($params['mec_occurrence']) && is_numeric($params['mec_occurrence'])) {
                    $occurrence_timestamp = (int) $params['mec_occurrence'];
                }
            }
            if ($occurrence_timestamp) {
                // Determine target event ID (use updated event_id if provided)
                $target_event_id = isset($params['event_id']) ? (int) $params['event_id'] : (int) $booking_record->event_id;
                $occ = null;
                if ($mec_date_pair) {
                    $parts = explode(':', $mec_date_pair);
                    $occ = (object) [
                        'dstart' => date('Y-m-d', (int)$parts[0]),
                        'dend' => date('Y-m-d', (int)$parts[1]),
                        'tstart' => (int)$parts[0],
                        'tend' => (int)$parts[1],
                    ];
                } else {
                    $occ = $wpdb->get_row($wpdb->prepare(
                        "SELECT dstart, dend, tstart, tend FROM {$wpdb->prefix}mec_dates WHERE post_id = %d AND tstart = %d AND public = 1",
                        $target_event_id,
                        $occurrence_timestamp
                    ));
                }
                if (!$occ) {
                    // Fallback by day to avoid timezone drifts
                    $date_key = date('Y-m-d', $occurrence_timestamp);
                    $occ = $wpdb->get_row($wpdb->prepare(
                        "SELECT dstart, dend, tstart, tend FROM {$wpdb->prefix}mec_dates WHERE post_id = %d AND dstart = %s AND public = 1 ORDER BY ABS(tstart - %d) ASC LIMIT 1",
                        $target_event_id,
                        $date_key,
                        $occurrence_timestamp
                    ));
                }
                if ($occ) {
                    // Update mec_bookings table timestamp/date
                    $wpdb->update(
                        $wpdb->prefix . 'mec_bookings',
                        [
                            'timestamp' => (int) $occ->tstart,
                            'date' => (string) $occ->dstart,
                        ],
                        ['booking_id' => $booking_id],
                        ['%d', '%s'],
                        ['%d']
                    );

                    // Reflect change in booking post meta and WP post
                    $occ_start_datetime = date('Y-m-d H:i:s', (int)$occ->tstart);
                    update_post_meta($booking_id, 'mec_booking_time', (string)$occ->dstart);
                    wp_update_post([
                        'ID' => $booking_id,
                        'post_date' => $occ_start_datetime,
                        'post_date_gmt' => get_gmt_from_date($occ_start_datetime),
                        'post_modified' => current_time('mysql'),
                        'post_modified_gmt' => current_time('mysql', true),
                        'edit_date' => true,
                    ]);
                    clean_post_cache($booking_id);

                    // Update mec_date as "tstart:tend"
                    $mec_date_pair_out = ((int)$occ->tstart) . ':' . ((int)$occ->tend);
                    update_post_meta($booking_id, 'mec_date', $mec_date_pair_out);

                    // Keep mec_all_dates in sync so admin UI preselects correctly
                    $existing_all_dates = get_post_meta($booking_id, 'mec_all_dates', true);
                    if (!is_array($existing_all_dates)) {
                        $existing_all_dates = [];
                    }
                    $existing_all_dates = array_values(array_filter($existing_all_dates, function ($v) use ($mec_date_pair_out) {
                        return (string)$v !== (string)$mec_date_pair_out;
                    }));
                    array_unshift($existing_all_dates, $mec_date_pair_out);
                    update_post_meta($booking_id, 'mec_all_dates', $existing_all_dates);
                }
            }

            // Update event assignment
            if (isset($params['event_id'])) {
                $new_event_id = (int) $params['event_id'];
                update_post_meta($booking_id, 'mec_event_id', $new_event_id);

                // Update MEC booking record
                $wpdb->update(
                    $wpdb->prefix . 'mec_bookings',
                    ['event_id' => $new_event_id],
                    ['booking_id' => $booking_id],
                    ['%d'],
                    ['%d']
                );
            }

            // Update fixed fields - MEC uses mec_fixed_fields key
            if (isset($params['fixed_fields']) && is_array($params['fixed_fields'])) {
                update_post_meta($booking_id, 'mec_fixed_fields', $params['fixed_fields']);
            }

            // Update attendees with correct MEC structure
            if (isset($params['attendees']) && is_array($params['attendees'])) {
                $existing_attendees = get_post_meta($booking_id, 'mec_attendees', true);
                if (!is_array($existing_attendees)) {
                    $existing_attendees = [];
                }

                // Preserve attachments if they exist
                $attachments = isset($existing_attendees['attachments']) ? $existing_attendees['attachments'] : [];

                // Build new attendees array - only keep attendees that are sent in the request
                // This allows deletion by simply not including attendees in the array
                $updated_attendees = [];

                foreach ($params['attendees'] as $attendee_data) {
                    $key = $attendee_data['key'] ?? count($updated_attendees);

                    if (isset($existing_attendees[$key]) && is_numeric($key)) {
                        // Update existing attendee with proper MEC structure
                        $updated_attendee = $existing_attendees[$key];

                        if (isset($attendee_data['name'])) {
                            $updated_attendee['name'] = sanitize_text_field($attendee_data['name']);
                        }
                        if (isset($attendee_data['email'])) {
                            $updated_attendee['email'] = sanitize_email($attendee_data['email']);
                        }
                        // MEC expects 'id' not 'ticket_id'
                        if (isset($attendee_data['ticket_id'])) {
                            $updated_attendee['id'] = (int) $attendee_data['ticket_id'];
                        }
                        if (isset($attendee_data['phone'])) {
                            $updated_attendee['phone'] = sanitize_text_field($attendee_data['phone']);
                        }
                        if (isset($attendee_data['birth_date'])) {
                            $updated_attendee['birth_date'] = sanitize_text_field($attendee_data['birth_date']);
                        }
                        if (isset($attendee_data['note'])) {
                            $updated_attendee['note'] = sanitize_textarea_field($attendee_data['note']);
                        }
                        if (isset($attendee_data['reg']) && is_array($attendee_data['reg'])) {
                            $updated_attendee['reg'] = $attendee_data['reg'];
                        }
                        if (isset($attendee_data['variations']) && is_array($attendee_data['variations'])) {
                            $updated_attendee['variations'] = $attendee_data['variations'];
                        }

                        // Preserve other important MEC fields
                        if (!isset($updated_attendee['buyerip'])) {
                            $updated_attendee['buyerip'] = $_SERVER['REMOTE_ADDR'] ?? '';
                        }
                        if (!isset($updated_attendee['count'])) {
                            $updated_attendee['count'] = 1;
                        }

                        $updated_attendees[$key] = $updated_attendee;
                    } else {
                        // Add new attendee
                        $new_attendee = [
                            'name' => sanitize_text_field($attendee_data['name'] ?? ''),
                            'email' => sanitize_email($attendee_data['email'] ?? ''),
                            'id' => (int) ($attendee_data['ticket_id'] ?? 0),
                            'phone' => sanitize_text_field($attendee_data['phone'] ?? ''),
                            'birth_date' => sanitize_text_field($attendee_data['birth_date'] ?? ''),
                            'note' => sanitize_textarea_field($attendee_data['note'] ?? ''),
                            'reg' => is_array($attendee_data['reg'] ?? null) ? $attendee_data['reg'] : [],
                            'variations' => is_array($attendee_data['variations'] ?? null) ? $attendee_data['variations'] : [],
                            'buyerip' => $_SERVER['REMOTE_ADDR'] ?? '',
                            'count' => 1
                        ];

                        $updated_attendees[$key] = $new_attendee;
                    }
                }

                // Restore attachments if they exist
                if (!empty($attachments)) {
                    $updated_attendees['attachments'] = $attachments;
                }

                // Update with the new attendees array (this will remove attendees not in the array)
                update_post_meta($booking_id, 'mec_attendees', $updated_attendees);

                // Update ticket_id in correct format for MEC
                $ticket_ids = '';
                foreach ($updated_attendees as $k => $attendee) {
                    if (is_numeric($k) && isset($attendee['id'])) {
                        $ticket_ids .= $attendee['id'] . ',';
                    }
                }
                if ($ticket_ids) {
                    update_post_meta($booking_id, 'mec_ticket_id', ',' . trim($ticket_ids, ',') . ',');
                } else {
                    // If no tickets, clear the meta
                    update_post_meta($booking_id, 'mec_ticket_id', '');
                }

                // Update seats count (only count numeric keys, exclude 'attachments')
                $seats_count = 0;
                foreach ($updated_attendees as $k => $attendee) {
                    if (is_numeric($k)) {
                        $seats_count++;
                    }
                }
                update_post_meta($booking_id, 'mec_seats', $seats_count);

                // Update MEC booking record seats
                $wpdb->update(
                    $wpdb->prefix . 'mec_bookings',
                    ['seats' => $seats_count],
                    ['booking_id' => $booking_id],
                    ['%d'],
                    ['%d']
                );
            }

            // Get updated booking
            $updated_request = new \WP_REST_Request('GET', '/bookings/' . $booking_id);
            $updated_request->set_url_params(['booking_id' => $booking_id]);

            return self::api_single_booking($updated_request);
        } catch (\Exception $e) {
            return new \WP_Error('booking_update_error', 'Error updating booking: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Delete booking (trash or force delete)
     */
    public static function api_delete_booking($request)
    {
        try {
            $booking_id = (int) $request['booking_id'];
            $force = filter_var($request->get_param('force'), FILTER_VALIDATE_BOOLEAN);

            // Validate booking exists
            $booking = get_post($booking_id);
            if (!$booking || $booking->post_type !== 'mec-books') {
                return new \WP_Error('booking_not_found', 'Booking not found.', ['status' => 404]);
            }

            // Previous state for response
            $previous = [
                'id' => $booking_id,
                'status' => $booking->post_status,
                'title' => self::clean_title($booking->post_title),
            ];

            // Clean MEC transaction option if exists (MEC stores transactions in options table)
            $transaction_id = get_post_meta($booking_id, 'mec_transaction_id', true);
            if ($transaction_id) {
                delete_option($transaction_id);
            }

            // Try core delete/trash first
            if ($force) {
                $result = \wp_delete_post($booking_id, true);
                if (!$result) {
                    // Fallback: ensure it's trashed at least
                    \wp_update_post(['ID' => $booking_id, 'post_status' => 'trash']);
                    $result = get_post_status($booking_id) === 'trash';
                }
            } else {
                $current_status = get_post_status($booking_id);
                if ($current_status === 'trash') {
                    // If it's already in trash and client asks to delete (without force), perform permanent delete
                    $result = \wp_delete_post($booking_id, true);
                    // If still not deleted, keep it as trashed (result false will be handled below)
                } else {
                    $result = \wp_trash_post($booking_id);
                }
                if (!$result) {
                    // Fallback: direct status change
                    \wp_update_post(['ID' => $booking_id, 'post_status' => 'trash']);
                    $result = get_post_status($booking_id) === 'trash';
                }
            }

            // Update occurrence (event date) selection
            error_log('[MEC_UTILITY] api_update_booking: booking_id=' . $booking_id . ' raw_params=' . print_r($params, true));
            // Accept any of: 'occurrence_timestamp', 'mec_occurrence', or direct 'mec_date' pair "tstart:tend"
            $occurrence_timestamp = null;
            $mec_date_pair = null;
            if (isset($params['mec_date']) && is_string($params['mec_date']) && strpos($params['mec_date'], ':') !== false) {
                $mec_date_pair = trim($params['mec_date']);
                $parts = explode(':', $mec_date_pair);
                if (count($parts) === 2 && ctype_digit((string)$parts[0]) && ctype_digit((string)$parts[1])) {
                    $occurrence_timestamp = (int) $parts[0];
                } else {
                    $mec_date_pair = null; // invalid format fallback to timestamp lookup
                }
            }
            if (!$occurrence_timestamp) {
                if (isset($params['occurrence_timestamp']) && is_numeric($params['occurrence_timestamp'])) {
                    $occurrence_timestamp = (int) $params['occurrence_timestamp'];
                } elseif (isset($params['mec_occurrence']) && is_numeric($params['mec_occurrence'])) {
                    $occurrence_timestamp = (int) $params['mec_occurrence'];
                }
            }

            if ($occurrence_timestamp) {
                // Determine target event ID (use updated event_id if provided)
                $target_event_id = isset($params['event_id']) ? (int) $params['event_id'] : (int) $booking_record->event_id;
                error_log('[MEC_UTILITY] api_update_booking: resolved target_event_id=' . $target_event_id . ' occurrence_timestamp=' . $occurrence_timestamp . ' mec_date_pair=' . ($mec_date_pair ?: 'NULL'));
                $occ = null;
                if ($mec_date_pair) {
                    // We already have both timestamps
                    $parts = explode(':', $mec_date_pair);
                    $occ = (object) [
                        'dstart' => date('Y-m-d', (int)$parts[0]),
                        'dend' => date('Y-m-d', (int)$parts[1]),
                        'tstart' => (int)$parts[0],
                        'tend' => (int)$parts[1],
                    ];
                } else {
                    // Lookup by tstart
                    $occ = $wpdb->get_row($wpdb->prepare(
                        "SELECT dstart, dend, tstart, tend FROM {$wpdb->prefix}mec_dates WHERE post_id = %d AND tstart = %d AND public = 1",
                        $target_event_id,
                        $occurrence_timestamp
                    ));
                }

                if (!$occ) {
                    // Fallback by date string in case of timezone offset mismatches
                    $date_key = date('Y-m-d', $occurrence_timestamp);
                    $occ = $wpdb->get_row($wpdb->prepare(
                        "SELECT dstart, dend, tstart, tend FROM {$wpdb->prefix}mec_dates WHERE post_id = %d AND dstart = %s AND public = 1 ORDER BY ABS(tstart - %d) ASC LIMIT 1",
                        $target_event_id,
                        $date_key,
                        $occurrence_timestamp
                    ));
                }
                if (!$occ) {
                    error_log('[MEC_UTILITY] api_update_booking: occurrence NOT FOUND for event_id=' . $target_event_id . ' ts=' . $occurrence_timestamp);
                    return new \WP_Error('occurrence_not_found', 'Selected occurrence not found for the event.', ['status' => 404]);
                }
                error_log('[MEC_UTILITY] api_update_booking: matched occurrence dstart=' . $occ->dstart . ' dend=' . $occ->dend . ' tstart=' . $occ->tstart . ' tend=' . $occ->tend);

                // Update mec_bookings table timestamp/date
                $wpdb->update(
                    $wpdb->prefix . 'mec_bookings',
                    [
                        'timestamp' => (int) $occ->tstart,
                        'date' => (string) $occ->dstart,
                    ],
                    ['booking_id' => $booking_id],
                    ['%d', '%s'],
                    ['%d']
                );

                // Reflect change in booking post meta and post_date like MEC UI does
                $occ_start_datetime = date('Y-m-d H:i:s', (int)$occ->tstart);
                // Use dstart directly to avoid timezone drift on day boundary
                $occ_start_date = (string)$occ->dstart;
                update_post_meta($booking_id, 'mec_booking_time', $occ_start_date);
                // Update WP post_date so GET shows updated booking_date (force + fallback)
                $update_result = wp_update_post([
                    'ID' => $booking_id,
                    'post_date' => $occ_start_datetime,
                    'post_date_gmt' => get_gmt_from_date($occ_start_datetime),
                    'post_modified' => current_time('mysql'),
                    'post_modified_gmt' => current_time('mysql', true),
                    'edit_date' => true,
                ], true);
                if (is_wp_error($update_result) || !$update_result) {
                    // Fallback to direct DB update
                    $wpdb->update(
                        $wpdb->posts,
                        [
                            'post_date' => $occ_start_datetime,
                            'post_date_gmt' => get_gmt_from_date($occ_start_datetime),
                            'post_modified' => current_time('mysql'),
                            'post_modified_gmt' => current_time('mysql', true),
                        ],
                        ['ID' => $booking_id],
                        ['%s', '%s', '%s', '%s'],
                        ['%d']
                    );
                }
                clean_post_cache($booking_id);

                // Update booking meta mec_date as "tstart:tend"
                $mec_date_pair_out = ((int)$occ->tstart) . ':' . ((int)$occ->tend);
                update_post_meta($booking_id, 'mec_date', $mec_date_pair_out);

                // Also update mec_all_dates so admin select preselects correctly
                $existing_all_dates = get_post_meta($booking_id, 'mec_all_dates', true);
                if (!is_array($existing_all_dates)) {
                    $existing_all_dates = [];
                }
                $existing_all_dates = array_values(array_filter($existing_all_dates, function ($v) use ($mec_date_pair_out) {
                    return (string)$v !== (string)$mec_date_pair_out;
                }));
                array_unshift($existing_all_dates, $mec_date_pair_out);
                update_post_meta($booking_id, 'mec_all_dates', $existing_all_dates);
                error_log('[MEC_UTILITY] api_update_booking: updated mec_date=' . $mec_date_pair_out . ' mec_booking_time=' . get_post_meta($booking_id, 'mec_booking_time', true));
            }

            // Consider already-trashed as success for non-force, and non-existent as success for force
            if (!$result) {
                $status = get_post_status($booking_id);
                if ((!$force && $status === 'trash') || ($force && !get_post($booking_id))) {
                    $result = true;
                }
            }

            if (!$result) {
                return new \WP_Error('cannot_delete', __('The booking cannot be deleted.', 'mec-utility'), ['status' => 500]);
            }

            return new \WP_REST_Response([
                'deleted' => true,
                'force' => $force,
                'previous' => $previous,
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('booking_delete_error', 'Error deleting booking: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get bookings for specific event
     */
    public static function api_event_bookings($request)
    {
        try {
            $event_id = (int) $request['event_id'];

            // Validate event exists
            if (!\get_post($event_id) || \get_post_type($event_id) !== 'mec-events') {
                return new \WP_Error('event_not_found', 'Event not found.', ['status' => 404]);
            }

            // Add event filter to request params
            $params = $request->get_params();
            $params['event_id'] = $event_id;

            // Create a new request with the event filter
            $modified_request = new \WP_REST_Request('GET', '/bookings');
            $modified_request->set_query_params($params);

            // Call the main bookings API
            $response = self::api_bookings($modified_request);

            // Add event info to response
            if (!is_wp_error($response)) {
                $data = $response->get_data();
                $data['event_id'] = $event_id;
                $response->set_data($data);
            }

            return $response;
        } catch (\Exception $e) {
            return new \WP_Error('event_bookings_error', 'Error fetching event bookings: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get flattened attendees for a specific event
     */
    public static function api_event_attendees($request)
    {
        try {
            $event_id = (int) $request['event_id'];

            if (!$event_id || !get_post($event_id)) {
                return new \WP_Error('event_not_found', 'Event not found.', ['status' => 404]);
            }

            // Query all bookings related to this event (published + future)
            $q = new \WP_Query([
                'post_type'      => 'mec-books',
                'post_status'    => ['future', 'publish'],
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [
                    [
                        'key'     => 'mec_event_id',
                        'value'   => $event_id,
                        'compare' => '=',
                    ],
                ],
            ]);

            $booking_ids = is_array($q->posts) ? $q->posts : [];

            // Tickets for naming
            $tickets = get_post_meta($event_id, 'mec_tickets', true);
            if (!is_array($tickets)) $tickets = [];

            // Build registration fields map similarly to api_single_booking
            $reg_fields = [];
            // 1) Event-specific reg fields
            $event_reg_fields = get_post_meta($event_id, 'mec_reg_fields', true);
            if (is_array($event_reg_fields)) {
                foreach ($event_reg_fields as $field_id => $field) {
                    $reg_fields[$field_id] = [
                        'label' => $field['label'] ?? $field_id,
                        'type' => $field['type'] ?? 'text',
                        'options' => $field['options'] ?? [],
                    ];
                }
            }
            // 2) Booking form attachment if any
            if (empty($reg_fields)) {
                $booking_form_id = get_post_meta($event_id, 'mec_reg_form', true);
                if (!$booking_form_id) $booking_form_id = get_post_meta($event_id, 'mec_booking_form', true);
                if ($booking_form_id) {
                    $form_fields = get_post_meta($booking_form_id, 'mec_fields', true);
                    if (is_array($form_fields)) {
                        foreach ($form_fields as $field_id => $field) {
                            $reg_fields[$field_id] = [
                                'label' => $field['label'] ?? '',
                                'type' => $field['type'] ?? 'text',
                                'options' => $field['options'] ?? [],
                            ];
                        }
                    }
                }
            }
            // 3) MEC main class fallback
            if (empty($reg_fields) && class_exists('MEC_feature_books')) {
                $books = new \MEC_feature_books();
                if (method_exists($books, 'get_reg_fields')) {
                    $mec_reg_fields = $books->get_reg_fields($event_id);
                    if (is_array($mec_reg_fields)) {
                        foreach ($mec_reg_fields as $field_id => $field) {
                            $reg_fields[$field_id] = [
                                'label' => $field['label'] ?? ($field['name'] ?? (string)$field_id),
                                'type' => $field['type'] ?? 'text',
                                'options' => $field['options'] ?? [],
                            ];
                        }
                    }
                }
            }
            // 4) Global settings fallback
            if (empty($reg_fields)) {
                $mec_settings = get_option('mec_options', []);
                if (isset($mec_settings['reg_fields']) && is_array($mec_settings['reg_fields'])) {
                    foreach ($mec_settings['reg_fields'] as $field_id => $field) {
                        $reg_fields[$field_id] = [
                            'label' => $field['label'] ?? (string)$field_id,
                            'type' => $field['type'] ?? 'text',
                            'options' => $field['options'] ?? [],
                        ];
                    }
                }
            }

            $attendees = [];
            foreach ($booking_ids as $booking_id) {
                $mec_attendees = get_post_meta($booking_id, 'mec_attendees', true);
                if (!is_array($mec_attendees) || !count($mec_attendees)) {
                    $fallback = get_post_meta($booking_id, 'mec_attendee', true);
                    $mec_attendees = $fallback ? [$fallback] : [];
                }

                $transaction_id = get_post_meta($booking_id, 'mec_transaction_id', true);
                $price_total = get_post_meta($booking_id, 'mec_price', true);
                $paid = get_post_meta($booking_id, 'mec_payable', true);

                foreach ($mec_attendees as $key => $a) {
                    if ($key === 'attachments') continue;
                    if (isset($a[0]['MEC_TYPE_OF_DATA'])) continue;

                    $ticket_id = isset($a['id']) ? (int)$a['id'] : 0;
                    $ticket_name = isset($tickets[$ticket_id]['name']) ? $tickets[$ticket_id]['name'] : 'Unknown';

                    // Variations
                    $variations_raw = isset($a['variations']) && is_array($a['variations']) ? $a['variations'] : [];
                    $variations_formatted = [];
                    if (isset($a['variations']) && is_array($a['variations']) && count($a['variations'])) {
                        // Try using MEC main if available to enrich
                        $ticket_variations = [];
                        if (class_exists('MEC_main')) {
                            $mec_main = new \MEC_main();
                            $ticket_variations = $mec_main->ticket_variations($event_id, $ticket_id);
                        }
                        foreach ($a['variations'] as $vid => $vcount) {
                            $label = isset($ticket_variations[$vid]['title']) ? $ticket_variations[$vid]['title'] : (string)$vid;
                            $price = isset($ticket_variations[$vid]['price']) ? (float)$ticket_variations[$vid]['price'] : 0;
                            $max   = isset($ticket_variations[$vid]['max']) ? (int)$ticket_variations[$vid]['max'] : 1000;
                            $min   = isset($ticket_variations[$vid]['min']) ? (int)$ticket_variations[$vid]['min'] : 0;
                            $variations_formatted[] = [
                                'variation_id' => (int)$vid,
                                'count' => (int)$vcount,
                                'title' => $label,
                                'price' => $price,
                                'max' => $max,
                                'min' => $min,
                            ];
                        }
                    }

                    // Registration fields formatted
                    $reg_formatted = [];
                    $reg_raw = isset($a['reg']) && is_array($a['reg']) ? $a['reg'] : [];
                    foreach ($reg_raw as $field_id => $value) {
                        $field_info = [
                            'field_id' => is_numeric($field_id) ? (int)$field_id : $field_id,
                            'value'    => $value,
                        ];
                        if (isset($reg_fields[$field_id])) {
                            $field_info['label'] = $reg_fields[$field_id]['label'];
                            $field_info['type']  = $reg_fields[$field_id]['type'];
                            if (!empty($reg_fields[$field_id]['options'])) {
                                $field_info['options'] = $reg_fields[$field_id]['options'];
                                // selected mapping
                                $selected_value = $value;
                                $selected_label = $selected_value;
                                if (isset($reg_fields[$field_id]['options'][$selected_value])) {
                                    $opt = $reg_fields[$field_id]['options'][$selected_value];
                                    $selected_label = is_array($opt) && isset($opt['label']) ? $opt['label'] : (is_string($opt) ? $opt : $selected_label);
                                }
                                $field_info['selected'] = [
                                    'value' => $selected_value,
                                    'label' => $selected_label,
                                ];
                            }
                        } else {
                            $field_info['label'] = ucfirst(str_replace(['_', '-'], ' ', (string)$field_id));
                            $field_info['type']  = 'text';
                        }
                        $reg_formatted[] = $field_info;
                    }

                    $attendees[] = [
                        'key'          => is_numeric($key) ? (int)$key : $key,
                        'booking_id'   => (int)$booking_id,
                        'transaction'  => $transaction_id,
                        'name'         => $a['name'] ?? '',
                        'email'        => $a['email'] ?? '',
                        'ticket_id'    => (string) $ticket_id,
                        'ticket_name'  => $ticket_name,
                        'phone'        => $a['phone'] ?? '',
                        'birth_date'   => $a['birth_date'] ?? '',
                        'note'         => $a['note'] ?? '',
                        'variations'   => $variations_raw,
                        'variations_formatted' => $variations_formatted,
                        'reg'          => $reg_raw,
                        'reg_formatted' => $reg_formatted,
                        'price_total'  => $price_total ?: 0,
                        'paid'         => $paid ?: 0,
                    ];
                }
            }

            return new \WP_REST_Response([
                'event_id'  => $event_id,
                'count'     => count($attendees),
                'attendees' => $attendees,
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('event_attendees_error', 'Error fetching attendees: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get booking statistics
     */
    public static function api_bookings_stats($request)
    {
        try {
            global $wpdb;

            $params = $request->get_params();
            $where_conditions = [];

            // Apply filters
            if (!empty($params['event_id'])) {
                $where_conditions[] = $wpdb->prepare("event_id = %d", (int) $params['event_id']);
            }

            if (!empty($params['date_from'])) {
                $where_conditions[] = $wpdb->prepare("date >= %s", \sanitize_text_field($params['date_from']));
            }

            if (!empty($params['date_to'])) {
                $where_conditions[] = $wpdb->prepare("date <= %s", \sanitize_text_field($params['date_to']));
            }

            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

            // Get overview stats
            $stats = $wpdb->get_row("
                    SELECT
                        COUNT(*) as total_bookings,
                        SUM(seats) as total_attendees,
                        SUM(CASE WHEN confirmed = 1 THEN 1 ELSE 0 END) as confirmed_bookings,
                        SUM(CASE WHEN verified = 1 THEN 1 ELSE 0 END) as verified_bookings,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_bookings,
                        SUM(CASE WHEN status = 'publish' THEN 1 ELSE 0 END) as published_bookings
                    FROM {$wpdb->prefix}mec_bookings
                    $where_clause
                ");

            // Get status breakdown
            $status_breakdown = $wpdb->get_results("
                    SELECT status, COUNT(*) as count
                    FROM {$wpdb->prefix}mec_bookings
                    $where_clause
                    GROUP BY status
                ");

            $status_data = [];
            foreach ($status_breakdown as $status) {
                $status_data[$status->status] = (int) $status->count;
            }

            return new \WP_REST_Response([
                'overview' => [
                    'total_bookings' => (int) $stats->total_bookings,
                    'total_attendees' => (int) $stats->total_attendees,
                    'confirmed_bookings' => (int) $stats->confirmed_bookings,
                    'verified_bookings' => (int) $stats->verified_bookings,
                    'pending_bookings' => (int) $stats->pending_bookings,
                    'published_bookings' => (int) $stats->published_bookings
                ],
                'status_breakdown' => $status_data
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('stats_error', 'Error calculating booking stats: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get detailed booking information
     */
    public static function api_booking_details($request)
    {
        try {
            $booking_id = (int) $request['booking_id'];

            // Validate booking exists
            $booking = \get_post($booking_id);
            if (!$booking) {
                return new \WP_Error('booking_not_found', 'Booking not found.', ['status' => 404]);
            }

            global $wpdb;

            // Get booking record
            $booking_record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}mec_bookings WHERE booking_id = %d",
                $booking_id
            ));

            if (!$booking_record) {
                return new \WP_Error('booking_record_not_found', 'Booking record not found.', ['status' => 404]);
            }

            // Get event with full details
            $event = \get_post($booking_record->event_id);
            $event_details = [];
            if ($event) {
                $event_details = [
                    'id' => (int) $event->ID,
                    'title' => self::clean_title($event->post_title),
                    'content' => $event->post_content,
                    'excerpt' => $event->post_excerpt,
                    'status' => $event->post_status,
                    'url' => \get_permalink($event->ID),
                    'start_date' => \get_post_meta($event->ID, 'mec_start_date', true),
                    'end_date' => \get_post_meta($event->ID, 'mec_end_date', true),
                    'start_time' => \get_post_meta($event->ID, 'mec_start_time_hour', true) . ':' . \get_post_meta($event->ID, 'mec_start_time_minutes', true),
                    'end_time' => \get_post_meta($event->ID, 'mec_end_time_hour', true) . ':' . \get_post_meta($event->ID, 'mec_end_time_minutes', true),
                    'location' => \get_post_meta($event->ID, 'mec_location', true),
                    'organizer' => \get_post_meta($event->ID, 'mec_organizer', true),
                    'categories' => \wp_get_post_terms($event->ID, 'mec_category', ['fields' => 'names']),
                    'tags' => \wp_get_post_terms($event->ID, 'mec_tag', ['fields' => 'names']),
                    'featured_image' => \get_the_post_thumbnail_url($event->ID, 'large'),
                ];
            }

            // Get user details
            $user_details = [];
            if ($booking_record->user_id > 0) {
                $user = \get_userdata($booking_record->user_id);
                if ($user) {
                    $user_details = [
                        'id' => (int) $user->ID,
                        'username' => $user->user_login,
                        'email' => $user->user_email,
                        'display_name' => $user->display_name,
                        'first_name' => $user->first_name,
                        'last_name' => $user->last_name,
                        'registration_date' => $user->user_registered,
                    ];
                }
            }

            // Get all attendees with full details
            $attendees = \get_post_meta($booking_id, 'mec_attendees', true);
            if (!is_array($attendees)) {
                $attendees = [];
            }

            $detailed_attendees = [];
            foreach ($attendees as $key => $attendee) {
                $detailed_attendees[] = [
                    'key' => $key,
                    'name' => $attendee['name'] ?? '',
                    'email' => $attendee['email'] ?? '',
                    'registration_fields' => $attendee['reg'] ?? [],
                    'raw_data' => $attendee // Full raw attendee data
                ];
            }

            // Get all payment and booking metadata
            $all_meta = \get_post_meta($booking_id);
            $payment_details = [
                'price' => \get_post_meta($booking_id, 'mec_price', true),
                'payable' => \get_post_meta($booking_id, 'mec_payable', true),
                'gateway' => \get_post_meta($booking_id, 'mec_gateway_label', true),
                'gateway_transaction_id' => \get_post_meta($booking_id, 'mec_gateway_transaction_id', true),
                'coupon_code' => \get_post_meta($booking_id, 'mec_coupon_code', true),
                'discount_amount' => \get_post_meta($booking_id, 'mec_discount_amount', true),
                'invoice_link' => \get_post_meta($booking_id, 'mec_invoice_link', true),
                'booking_time' => \get_post_meta($booking_id, 'mec_booking_time', true),
                'order_id' => \get_post_meta($booking_id, 'mec_order_id', true),
            ];

            // Get booking attendees from separate table if exists
            $booking_attendees = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}mec_booking_attendees WHERE booking_id = %d",
                $booking_id
            ));

            $booking_data = [
                'id' => (int) $booking_id,
                'booking_id' => (int) $booking_id,
                'event_id' => (int) $booking_record->event_id,
                'transaction_id' => $booking_record->transaction_id,
                'user_id' => (int) $booking_record->user_id,
                'status' => $booking_record->status,
                'confirmed' => (int) $booking_record->confirmed,
                'verified' => (int) $booking_record->verified,
                'seats' => (int) $booking_record->seats,
                'booking_date' => $booking->post_date,
                'booking_modified' => $booking->post_modified,
                'event_date' => $booking_record->date,
                'timestamp' => (int) $booking_record->timestamp,
                'post_status' => $booking->post_status,
                'post_title' => self::clean_title($booking->post_title),
                'post_content' => $booking->post_content,
                'ticket_ids' => $booking_record->ticket_ids,

                // Detailed information
                'event' => $event_details,
                'user' => $user_details,
                'attendees' => $detailed_attendees,
                'attendees_count' => count($detailed_attendees),
                'booking_attendees' => $booking_attendees, // From separate table
                'payment' => $payment_details,

                // All metadata for debugging/comprehensive view
                'all_metadata' => array_map(function ($meta) {
                    return is_array($meta) && count($meta) === 1 ? $meta[0] : $meta;
                }, $all_meta),

                // Additional computed fields
                'is_paid' => !empty($payment_details['gateway']) && !empty($payment_details['gateway_transaction_id']),
                'has_discount' => !empty($payment_details['coupon_code']),
                'total_amount' => $payment_details['payable'] ?: $payment_details['price'],
            ];

            return new \WP_REST_Response($booking_data, 200);
        } catch (\Exception $e) {
            return new \WP_Error('booking_details_error', 'Error fetching booking details: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Generate QR code URL with Hash parameter
     */
    public static function generate_qr_url($invoice_id, $email, $place)
    {
        $checkin_hash = \get_post_meta($invoice_id, 'CheckinHash', true);
        if (!$checkin_hash) {
            $checkin_hash = sha1(md5(microtime()));
            \update_post_meta($invoice_id, 'CheckinHash', $checkin_hash);
        }

        return \get_site_url(null, '?invoiceID=' . $invoice_id . '&checkIn=' . $email . '&place=' . $place . '&Hash=' . $checkin_hash);
    }

    /**
     * Extract parameters from short URL or full URL
     */
    public static function extract_qr_parameters($url_or_hash)
    {
        $debug_info = [
            'input' => $url_or_hash,
            'has_query' => strpos($url_or_hash, '?') !== false,
            'has_invoice_path' => strpos($url_or_hash, '/invoice/') !== false
        ];

        // If it's already a full URL with parameters, parse it directly
        if (strpos($url_or_hash, '?') !== false) {
            $url_components = parse_url($url_or_hash);
            parse_str($url_components['query'], $params);
            $debug_info['parsed_params'] = $params;
            return $params;
        }

        // If it's a short hash (like stmz13pWBk0-k), extract the full URL first
        if (strpos($url_or_hash, '/invoice/') !== false) {
            $hash = preg_replace('#(.*?)\/invoice\/#', '', $url_or_hash);
        } else {
            $hash = $url_or_hash;
        }

        $debug_info['extracted_hash'] = $hash;

        // Get the full URL from the short hash
        $full_url = \MEC_Invoice\Helper::getShortLinkDes($hash);
        $debug_info['full_url'] = $full_url;

        if (!$full_url) {
            $debug_info['error'] = 'Failed to resolve short link';
            return false;
        }

        // Parse the full URL to get parameters
        $url_components = parse_url($full_url);
        parse_str($url_components['query'], $params);

        $debug_info['final_params'] = $params;

        // For debugging purposes, let's also check what's in the database
        global $wpdb;
        $short_link_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}mec_short_links WHERE short_link = %s",
            $hash
        ));
        $debug_info['database_record'] = $short_link_data;

        // Return both parameters and debug info
        return [
            'params' => $params,
            'debug_info' => $debug_info
        ];
    }

    /**
     * QR Scan API - Handles both short URLs and full URLs
     */
    public static function api_qr_scan($request)
    {
        try {
            // Get parameters from request
            $invoice_id = (int) $request->get_param('invoiceID');
            $email = \sanitize_email($request->get_param('checkIn'));
            $place = (int) $request->get_param('place');
            $key_checkin = (int) $request->get_param('key_checkin');
            $hash = $request->get_param('Hash');
            $all_checked = $request->get_param('all_checked');
            $short_url = $request->get_param('short_url');
            $qr_hash = $request->get_param('qr_hash');
            $doCheckin = $request->get_param('doCheckin');
            $makePreview = $request->get_param('makePreview');

            // Debug: Log initial parameters
            $debug_info = [
                'initial_invoice_id' => $invoice_id,
                'initial_email' => $email,
                'initial_place' => $place,
                'short_url' => $short_url,
                'qr_hash' => $qr_hash,
                'doCheckin' => $doCheckin,
                'makePreview' => $makePreview
            ];

            // If short URL or QR hash is provided, extract parameters
            if ($short_url || $qr_hash) {
                $extracted_result = self::extract_qr_parameters($short_url ?: $qr_hash);
                $debug_info['extraction_debug'] = $extracted_result['debug_info'] ?? null;

                if ($extracted_result && isset($extracted_result['params'])) {
                    $extracted_params = $extracted_result['params'];
                    $debug_info['extracted_params'] = $extracted_params;

                    // Directly assign extracted parameters, overriding any existing values
                    if (isset($extracted_params['invoiceID'])) {
                        $invoice_id = (int) $extracted_params['invoiceID'];
                    }
                    if (isset($extracted_params['checkIn'])) {
                        $email = \sanitize_email($extracted_params['checkIn']);
                    }
                    if (isset($extracted_params['place'])) {
                        $place = (int) $extracted_params['place'];
                    }
                    if (isset($extracted_params['Hash'])) {
                        $hash = $extracted_params['Hash'];
                    }
                    if (isset($extracted_params['doCheckin'])) {
                        $doCheckin = $extracted_params['doCheckin'];
                    }
                    if (isset($extracted_params['makePreview'])) {
                        $makePreview = $extracted_params['makePreview'];
                    }
                } else {
                    return new \WP_REST_Response([
                        'status' => 404,
                        'status_scan' => -1,
                        'msg' => 'Invalid short URL or QR hash.',
                        'data' => null,
                        'debug' => $debug_info
                    ], 404);
                }
            }

            // Debug: Log final parameters
            $debug_info['final_invoice_id'] = $invoice_id;
            $debug_info['final_email'] = $email;
            $debug_info['final_place'] = $place;
            $debug_info['final_doCheckin'] = $doCheckin;
            $debug_info['final_makePreview'] = $makePreview;

            // Use place parameter, fallback to key_checkin for backward compatibility
            $place = $place ?: $key_checkin;

            // Hash validation removed for backward compatibility with mec-invoice
            // Original mec-invoice didn't validate Hash parameter

            // Get book_id from invoice
            $book_id = \get_post_meta($invoice_id, 'book_id', true);
            if (!$book_id) {
                return new \WP_REST_Response([
                    'status' => 404,
                    'status_scan' => -1,
                    'msg' => 'Invoice not found.',
                    'data' => null,
                    'debug' => $debug_info
                ], 404);
            }

            // Check if booking is verified
            $verified = \get_post_meta($book_id, 'mec_verified', true);
            if ($verified !== '1') {
                return new \WP_REST_Response([
                    'status' => 404,
                    'status_scan' => -1,
                    'msg' => 'Booking is not verified!',
                    'data' => null,
                    'debug' => $debug_info
                ], 404);
            }

            // --- RE-ORDERED LOGIC ---
            // Handle bulk check-in (doCheckin flow) - This should be checked BEFORE individual parameters
            if ($doCheckin) {
                // Hash validation removed for backward compatibility with mec-invoice
                // Original mec-invoice didn't validate doCheckin hash

                // Get all attendees and perform bulk check-in/out
                $attendees = \get_post_meta($book_id, 'mec_attendees', true);
                if (!$attendees) {
                    return new \WP_REST_Response([
                        'status' => 404,
                        'status_scan' => -1,
                        'msg' => 'No attendee found.',
                        'data' => null,
                        'debug' => $debug_info
                    ], 404);
                }

                $checkin_count = 0;
                $uncheck_count = 0;

                foreach ($attendees as $key => $attendee) {
                    // Skip non-numeric keys (e.g., 'attachments')
                    if (!is_numeric($key)) {
                        continue;
                    }

                    $place_number = (int)$key + 1;
                    if (!\MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $attendee['email'], $place_number)) {
                        \MEC_Invoice\Attendee::doCheckIn($invoice_id, $attendee['email'], $place_number, null, true);
                        $checkin_count++;
                    } else {
                        // Do not toggle to checkout. Only allow check-in.
                        $uncheck_count++;
                    }
                }

                if ($checkin_count > 0) {
                    $text = 'Successfully Checked!';
                    $status_scan = 1;
                } else {
                    $text = 'Alredy Checked!';
                    $status_scan = 1;
                }

                // Get event information for response
                $event_id = \get_post_meta($book_id, 'mec_event_id', true);
                $event_title = self::clean_title(\get_the_title($event_id));
                $event_start_date = \get_post_meta($event_id, 'mec_start_date', true);
                $event_end_date = \get_post_meta($event_id, 'mec_end_date', true);

                // Get all invoices for THIS EVENT (invoices have event_id directly)
                $event_invoices = \get_posts([
                    'post_type' => 'mec_invoice',
                    'numberposts' => -1,
                    'post_status' => 'any',
                    'fields' => 'ids',
                    'meta_query' => [
                        [
                            'key' => 'event_id',
                            'value' => $event_id,
                            'compare' => '='
                        ]
                    ]
                ]);

                // Calculate attendee statistics for THIS EVENT (all invoices)
                $total_event_attendees = 0;
                $checked_in_event_attendees = 0;

                foreach ($event_invoices as $event_invoice_id) {
                    $invoice_book_id = \get_post_meta($event_invoice_id, 'book_id', true);
                    if (!$invoice_book_id) continue;

                    $booking_attendees = \get_post_meta($invoice_book_id, 'mec_attendees', true);

                    if (is_array($booking_attendees)) {
                        foreach ($booking_attendees as $key => $attendee) {
                            // Skip non-numeric keys (e.g., 'attachments')
                            if (!is_numeric($key)) {
                                continue;
                            }

                            $total_event_attendees++;
                            $place_number = (int)$key + 1;

                            if (\MEC_Invoice\Attendee::hasCheckedIn($event_invoice_id, $attendee['email'], $place_number)) {
                                $checked_in_event_attendees++;
                            }
                        }
                    }
                }

                // Get total attendees across all events (query all invoices)
                $total_all_events_attendees = 0;
                $all_invoices = \get_posts([
                    'post_type' => 'mec_invoice',
                    'numberposts' => -1,
                    'post_status' => 'any',
                    'fields' => 'ids'
                ]);

                foreach ($all_invoices as $invoice_id) {
                    $invoice_book_id = \get_post_meta($invoice_id, 'book_id', true);
                    if (!$invoice_book_id) continue;

                    $booking_attendees = \get_post_meta($invoice_book_id, 'mec_attendees', true);
                    if (is_array($booking_attendees)) {
                        foreach ($booking_attendees as $key => $attendee) {
                            if (is_numeric($key)) {
                                $total_all_events_attendees++;
                            }
                        }
                    }
                }

                return new \WP_REST_Response([
                    'status' => 200,
                    'status_scan' => $status_scan,
                    'msg' => $text,
                    'data' => [
                        'status' => $status_scan,
                        'event_info' => [
                            'id' => $event_id,
                            'title' => $event_title,
                            'start_date' => $event_start_date,
                            'end_date' => $event_end_date,
                        ],
                        'attendee_stats' => [
                            'total_event_attendees' => $total_event_attendees,
                            'checked_in_event_attendees' => $checked_in_event_attendees,
                            'unchecked_event_attendees' => $total_event_attendees - $checked_in_event_attendees,
                            'total_all_events_attendees' => $total_all_events_attendees,
                        ],
                    ],
                    'debug' => $debug_info
                ], 200);
            }

            // Handle bulk check-in/out (all_checked === 'all')
            if ($all_checked === 'all') {
                $attendees = \get_post_meta($book_id, 'mec_attendees', true);
                if (!$attendees) {
                    return new \WP_REST_Response([
                        'status' => 404,
                        'status_scan' => -1,
                        'msg' => 'No attendee found.',
                        'data' => null,
                        'debug' => $debug_info
                    ], 404);
                }

                $checkin = 0;
                $uncheck = 0;
                $j = 1;

                foreach ($attendees as $attendee) {
                    if (!\MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $attendee['email'], $j)) {
                        \MEC_Invoice\Attendee::doCheckIn($invoice_id, $attendee['email'], $j, null, true);
                        $checkin++;
                    } else {
                        // Do not toggle to checkout. Only allow check-in.
                        $uncheck++;
                    }
                    $j++;
                }

                if ($checkin > 0) {
                    $text = 'Check-in Completed';
                    $status_scan = 1;
                } else {
                    $text = 'All Already Checked In!';
                    $status_scan = 1;
                }

                return new \WP_REST_Response([
                    'status' => 200,
                    'status_scan' => $status_scan,
                    'msg' => $text,
                    'data' => [
                        'status' => $status_scan,
                    ],
                    'debug' => $debug_info
                ], 200);
            }

            // Individual attendee - Only check this if not doing bulk operations
            if (!$doCheckin && (!$email || !$place)) {
                return new \WP_REST_Response([
                    'status' => 404,
                    'status_scan' => -1,
                    'msg' => 'Missing email or place parameter.',
                    'data' => null,
                    'debug' => $debug_info
                ], 404);
            }

            if (!\MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $email, $place)) {
                \MEC_Invoice\Attendee::doCheckIn($invoice_id, $email, $place, null, true);
                $text = 'Checkin';
                $status_scan = 1;
            } else {
                // Do not perform checkout. Only allow check-in.
                $text = 'Already Checked!';
                $status_scan = 1;
            }

            // Get event information for response
            $event_id = \get_post_meta($book_id, 'mec_event_id', true);
            $event_title = self::clean_title(\get_the_title($event_id));
            $event_start_date = \get_post_meta($event_id, 'mec_start_date', true);
            $event_end_date = \get_post_meta($event_id, 'mec_end_date', true);

            // Get all invoices for THIS EVENT (invoices have event_id directly)
            $event_invoices = \get_posts([
                'post_type' => 'mec_invoice',
                'numberposts' => -1,
                'post_status' => 'any',
                'fields' => 'ids',
                'meta_query' => [
                    [
                        'key' => 'event_id',
                        'value' => $event_id,
                        'compare' => '='
                    ]
                ]
            ]);

            // Calculate attendee statistics for THIS EVENT (all invoices)
            $total_event_attendees = 0;
            $checked_in_event_attendees = 0;

            foreach ($event_invoices as $event_invoice_id) {
                $invoice_book_id = \get_post_meta($event_invoice_id, 'book_id', true);
                if (!$invoice_book_id) continue;

                $booking_attendees = \get_post_meta($invoice_book_id, 'mec_attendees', true);

                if (is_array($booking_attendees)) {
                    foreach ($booking_attendees as $key => $attendee) {
                        // Skip non-numeric keys (e.g., 'attachments')
                        if (!is_numeric($key)) {
                            continue;
                        }

                        $total_event_attendees++;
                        $place_number = (int)$key + 1;

                        if (\MEC_Invoice\Attendee::hasCheckedIn($event_invoice_id, $attendee['email'], $place_number)) {
                            $checked_in_event_attendees++;
                        }
                    }
                }
            }

            // Get total attendees across all events (query all invoices)
            $total_all_events_attendees = 0;
            $all_invoices = \get_posts([
                'post_type' => 'mec_invoice',
                'numberposts' => -1,
                'post_status' => 'any',
                'fields' => 'ids'
            ]);

            foreach ($all_invoices as $invoice_id) {
                $invoice_book_id = \get_post_meta($invoice_id, 'book_id', true);
                if (!$invoice_book_id) continue;

                $booking_attendees = \get_post_meta($invoice_book_id, 'mec_attendees', true);
                if (is_array($booking_attendees)) {
                    foreach ($booking_attendees as $key => $attendee) {
                        if (is_numeric($key)) {
                            $total_all_events_attendees++;
                        }
                    }
                }
            }

            return new \WP_REST_Response([
                'status' => 200,
                'status_scan' => $status_scan,
                'msg' => $text,
                'data' => [
                    'status' => $status_scan,
                    'event_info' => [
                        'id' => $event_id,
                        'title' => $event_title,
                        'start_date' => $event_start_date,
                        'end_date' => $event_end_date,
                    ],
                    'attendee_stats' => [
                        'total_event_attendees' => $total_event_attendees,
                        'checked_in_event_attendees' => $checked_in_event_attendees,
                        'unchecked_event_attendees' => $total_event_attendees - $checked_in_event_attendees,
                        'total_all_events_attendees' => $total_all_events_attendees,
                    ],
                ],
                'debug' => $debug_info
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('qr_scan_error', 'Error processing QR scan: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * QR Code Generate endpoint - based on MEC Invoice InvoiceInformation::get_qr_code_link
     */
    public static function api_qr_generate($request)
    {
        try {
            $invoice_id = (int) $request->get_param('invoice_id');
            $email = \sanitize_email($request->get_param('email'));
            $place = (int) $request->get_param('place');

            // Validate required parameters
            if (!$invoice_id) {
                return new \WP_Error('missing_parameters', 'Missing invoice_id parameter.', ['status' => 400]);
            }

            // Verify invoice exists
            $invoice = \get_post($invoice_id);
            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            // Get invoice hash - same as controller.php
            $invoice_hash = \get_post_meta($invoice_id, 'invoiceID', true);
            if (!$invoice_hash) {
                return new \WP_Error('invoice_hash_not_found', 'Invoice hash not found.', ['status' => 404]);
            }

            // Generate QR code URL based on MEC Invoice InvoiceInformation::get_qr_code_link structure
            if ($email && $place) {
                // For specific attendee - same structure as InvoiceInformation::get_qr_code_link
                $qr_url = \get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $invoice_hash . '&attendee=' . $email . '&place=' . $place . '&Hash=' . $invoice_hash);
            } else {
                // For general invoice
                $qr_url = \get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $invoice_hash);
            }

            // Get short link if available - same as controller.php and InvoiceInformation
            if (class_exists('MEC_Invoice\\Helper') && method_exists('MEC_Invoice\\Helper', 'getShortLink')) {
                $short_url = \MEC_Invoice\Helper::getShortLink($qr_url);
                if ($short_url) {
                    $qr_url = $short_url;
                }
            }

            return new \WP_REST_Response([
                'status' => 200,
                'msg' => 'QR code generated successfully',
                'data' => [
                    'qr_url' => $qr_url,
                    'invoice_id' => $invoice_id,
                    'email' => $email,
                    'place' => $place,
                    'image_url' => \get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $invoice_hash . '&attendee=' . $email . '&place=' . $place . '&Hash=' . $invoice_hash)
                ]
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('qr_generate_error', 'Error generating QR code: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * QR Code Generate Bulk endpoint
     */
    public static function api_qr_generate_bulk($request)
    {
        try {
            $invoice_id = (int) $request->get_param('invoice_id');

            // Validate required parameters
            if (!$invoice_id) {
                return new \WP_Error('missing_parameters', 'Missing invoice_id parameter.', ['status' => 400]);
            }

            // Verify invoice exists
            $invoice = \get_post($invoice_id);
            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            // Get book_id from invoice
            $book_id = \get_post_meta($invoice_id, 'book_id', true);
            if (!$book_id) {
                return new \WP_Error('book_not_found', 'Book ID not found for this invoice.', ['status' => 404]);
            }

            // Get invoice hash
            $invoice_hash = \get_post_meta($invoice_id, 'invoiceID', true);
            if (!$invoice_hash) {
                return new \WP_Error('invoice_hash_not_found', 'Invoice hash not found.', ['status' => 404]);
            }

            // Get all attendees
            $attendees = \get_post_meta($book_id, 'mec_attendees', true);
            if (!$attendees) {
                return new \WP_Error('attendees_not_found', 'No attendees found for this booking.', ['status' => 404]);
            }

            // Generate QR codes for all attendees
            $qr_codes = [];
            foreach ($attendees as $key => $attendee) {
                $email = $attendee['email'] ?? '';
                $place = $key + 1;

                if ($email) {
                    $qr_url = \get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $invoice_hash . '&attendee=' . $email . '&place=' . $place . '&Hash=' . $invoice_hash);

                    // Get short link if available
                    if (class_exists('MEC_Invoice\\Helper') && method_exists('MEC_Invoice\\Helper', 'getShortLink')) {
                        $short_url = \MEC_Invoice\Helper::getShortLink($qr_url);
                        if ($short_url) {
                            $qr_url = $short_url;
                        }
                    }

                    $qr_codes[] = [
                        'email' => $email,
                        'place' => $place,
                        'name' => $attendee['name'] ?? '',
                        'qr_url' => $qr_url,
                        'image_url' => \get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $invoice_hash . '&attendee=' . $email . '&place=' . $place . '&Hash=' . $invoice_hash)
                    ];
                }
            }

            return new \WP_REST_Response([
                'status' => 200,
                'msg' => 'Bulk QR codes generated successfully',
                'data' => [
                    'invoice_id' => $invoice_id,
                    'book_id' => $book_id,
                    'total_attendees' => count($qr_codes),
                    'qr_codes' => $qr_codes
                ]
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('qr_generate_bulk_error', 'Error generating bulk QR codes: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * QR Code Image endpoint
     */
    public static function api_qr_image($request)
    {
        try {
            $invoice_id = (int) $request->get_param('invoice_id');
            $email = \sanitize_email($request->get_param('email'));
            $place = (int) $request->get_param('place');

            // Validate required parameters
            if (!$invoice_id) {
                return new \WP_Error('missing_parameters', 'Missing invoice_id parameter.', ['status' => 400]);
            }

            // Verify invoice exists
            $invoice = \get_post($invoice_id);
            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            // Get invoice hash
            $invoice_hash = \get_post_meta($invoice_id, 'invoiceID', true);
            if (!$invoice_hash) {
                return new \WP_Error('invoice_hash_not_found', 'Invoice hash not found.', ['status' => 404]);
            }

            // Generate QR code URL based on MEC Invoice structure
            if ($email && $place) {
                // For specific attendee
                $qr_url = \get_site_url(null, '?invoiceID=' . $invoice_id . '&checkIn=' . $email . '&place=' . $place . '&Hash=' . $invoice_hash);
            } else {
                // For general invoice
                $qr_url = \get_site_url(null, '?invoiceID=' . $invoice_id . '&makePreview=' . $invoice_hash);
            }

            // Get short link if available
            if (class_exists('MEC_Invoice\\Helper') && method_exists('MEC_Invoice\\Helper', 'getShortLink')) {
                $short_url = \MEC_Invoice\Helper::getShortLink($qr_url);
                if ($short_url) {
                    $qr_url = $short_url;
                }
            }

            // Check if QR library is available
            if (!class_exists('QRcode')) {
                $qr_lib_path = ABSPATH . 'wp-content/plugins/mec-invoice/libraries/phpqrcode/qrlib.php';
                if (file_exists($qr_lib_path)) {
                    include_once($qr_lib_path);
                }
            }

            if (class_exists('QRcode')) {
                // Generate QR code image
                \ob_start();
                \header('Content-Type: image/png');
                \header('Expires: 0');
                \header("Content-Disposition: inline; filename=\"{$invoice_id}-qrcode.png\"");

                \QRcode::png($qr_url);
                exit;
            } else {
                return new \WP_Error('qr_library_not_found', 'QR code library not available.', ['status' => 501]);
            }
        } catch (\Exception $e) {
            return new \WP_Error('qr_image_error', 'Error generating QR image: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get translations endpoint
     */
    public static function api_get_translations($request)
    {
        try {
            global $wpdb;

            // Get translation settings from database
            $translations = \get_option('mec_utility_translations', []);
            $active = \get_option('mec_utility_translations_active', '0');

            return new \WP_REST_Response([
                'status' => 200,
                'active' => $active,
                'translations' => $translations
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('translations_error', 'Error fetching translations: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Update translations endpoint
     */
    public static function api_update_translations($request)
    {
        try {
            $active = \sanitize_text_field($request->get_param('active'));
            $translate_string = \sanitize_text_field($request->get_param('translate_string'));

            // Validate JSON if provided
            if ($translate_string) {
                $decoded = json_decode($translate_string, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    return new \WP_Error('invalid_json', 'Invalid JSON in translate_string parameter.', ['status' => 400]);
                }
            }

            // Update settings
            if ($active !== null) {
                \update_option('mec_utility_translations_active', $active);
            }

            if ($translate_string !== null) {
                \update_option('mec_utility_translations', $translate_string);
            }

            return new \WP_REST_Response([
                'status' => 200,
                'message' => 'Translations updated successfully',
                'active' => \get_option('mec_utility_translations_active', '0'),
                'translations' => \get_option('mec_utility_translations', [])
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('translations_update_error', 'Error updating translations: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * API get taxonomy terms callback - Complete with pagination and search
     */
    public static function api_get_taxonomy_terms($request)
    {
        $taxonomy = $request->get_param('taxonomy');
        $per_page = $request->get_param('per_page') ?: 20;
        $page = $request->get_param('page') ?: 1;
        $search = $request->get_param('search') ?: '';

        // Valid MEC taxonomies including post_tag
        $valid_taxonomies = [
            'mec_category',
            'mec_location',
            'mec_organizer',
            'mec_speaker',
            'mec_sponsor',
            'mec_label',
            'post_tag'
        ];

        if (!in_array($taxonomy, $valid_taxonomies)) {
            return new \WP_Error('invalid_taxonomy', 'Invalid taxonomy. Valid options: ' . implode(', ', $valid_taxonomies), ['status' => 400]);
        }

        $args = [
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
            'number' => $per_page,
            'offset' => ($page - 1) * $per_page
        ];

        if (!empty($search)) {
            $args['search'] = $search;
        }

        $terms = \get_terms($args);

        if (\is_wp_error($terms)) {
            return new \WP_Error('taxonomy_error', $terms->get_error_message(), ['status' => 500]);
        }

        // Get total count for pagination
        $total_args = $args;
        unset($total_args['number'], $total_args['offset']);
        $total_terms = \get_terms($total_args);
        $total = is_array($total_terms) ? count($total_terms) : 0;

        $formatted_terms = [];
        foreach ($terms as $term) {
            $term_data = [
                'id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'count' => $term->count,
                'taxonomy' => $taxonomy
            ];

            // Add taxonomy-specific metadata
            if ($taxonomy === 'mec_category') {
                $term_data['icon'] = \get_term_meta($term->term_id, 'mec_cat_icon', true);
                $term_data['color'] = \get_term_meta($term->term_id, 'mec_cat_color', true);
            } elseif ($taxonomy === 'mec_location') {
                $term_data['address'] = \get_term_meta($term->term_id, 'address', true);
                $term_data['latitude'] = \get_term_meta($term->term_id, 'latitude', true);
                $term_data['longitude'] = \get_term_meta($term->term_id, 'longitude', true);
                $term_data['url'] = \get_term_meta($term->term_id, 'url', true);
                $term_data['tel'] = \get_term_meta($term->term_id, 'tel', true);
                $term_data['thumbnail'] = \get_term_meta($term->term_id, 'thumbnail', true);
            } elseif ($taxonomy === 'mec_organizer') {
                $term_data['email'] = \get_term_meta($term->term_id, 'email', true);
                $term_data['tel'] = \get_term_meta($term->term_id, 'tel', true);
                $term_data['url'] = \get_term_meta($term->term_id, 'url', true);
                $term_data['thumbnail'] = \get_term_meta($term->term_id, 'thumbnail', true);
            } elseif ($taxonomy === 'mec_speaker') {
                $term_data['job_title'] = \get_term_meta($term->term_id, 'job_title', true);
                $term_data['tel'] = \get_term_meta($term->term_id, 'tel', true);
                $term_data['email'] = \get_term_meta($term->term_id, 'email', true);
                $term_data['facebook'] = \get_term_meta($term->term_id, 'facebook', true);
                $term_data['twitter'] = \get_term_meta($term->term_id, 'twitter', true);
                $term_data['thumbnail'] = \get_term_meta($term->term_id, 'thumbnail', true);
            } elseif ($taxonomy === 'mec_sponsor') {
                $term_data['url'] = \get_term_meta($term->term_id, 'url', true);
                $term_data['logo'] = \get_term_meta($term->term_id, 'logo', true);
                $term_data['thumbnail'] = \get_term_meta($term->term_id, 'thumbnail', true);
            } elseif ($taxonomy === 'mec_label') {
                $term_data['color'] = \get_term_meta($term->term_id, 'color', true);
                $term_data['style'] = \get_term_meta($term->term_id, 'style', true);
            }

            $formatted_terms[] = $term_data;
        }

        $total_pages = ceil($total / $per_page);

        return \rest_ensure_response([
            'taxonomy' => $taxonomy,
            'terms' => $formatted_terms,
            'pagination' => [
                'total' => $total,
                'per_page' => $per_page,
                'current_page' => $page,
                'total_pages' => $total_pages,
                'has_more' => $page < $total_pages
            ]
        ]);
    }

    /**
     * API create taxonomy term callback - Complete with all taxonomy support
     */
    public static function api_create_taxonomy_term($request)
    {
        $taxonomy = $request->get_param('taxonomy');
        $name = \sanitize_text_field($request->get_param('name'));

        if (empty($name)) {
            return new \WP_Error('missing_name', 'Term name is required', ['status' => 400]);
        }

        // Valid MEC taxonomies including post_tag
        $valid_taxonomies = [
            'mec_category',
            'mec_location',
            'mec_organizer',
            'mec_speaker',
            'mec_sponsor',
            'mec_label',
            'post_tag'
        ];

        if (!in_array($taxonomy, $valid_taxonomies)) {
            return new \WP_Error('invalid_taxonomy', 'Invalid taxonomy. Valid options: ' . implode(', ', $valid_taxonomies), ['status' => 400]);
        }

        $args = [
            'description' => \sanitize_text_field($request->get_param('description')) ?: '',
            'slug' => \sanitize_title($request->get_param('slug')) ?: '',
        ];

        $result = \wp_insert_term($name, $taxonomy, $args);

        if (\is_wp_error($result)) {
            return new \WP_Error('term_creation_failed', $result->get_error_message(), ['status' => 500]);
        }

        $term_id = $result['term_id'];

        // Add taxonomy-specific metadata
        if ($taxonomy === 'mec_category') {
            $icon = \sanitize_text_field($request->get_param('icon'));
            $color = \sanitize_hex_color($request->get_param('color'));
            if ($icon) \update_term_meta($term_id, 'mec_cat_icon', $icon);
            if ($color) \update_term_meta($term_id, 'mec_cat_color', $color);
        } elseif ($taxonomy === 'mec_location') {
            $address = \sanitize_text_field($request->get_param('address'));
            $latitude = \sanitize_text_field($request->get_param('latitude'));
            $longitude = \sanitize_text_field($request->get_param('longitude'));
            $url = \esc_url_raw($request->get_param('url'));
            $tel = \sanitize_text_field($request->get_param('tel'));
            $thumbnail = \absint($request->get_param('thumbnail'));
            if ($address) \update_term_meta($term_id, 'address', $address);
            if ($latitude) \update_term_meta($term_id, 'latitude', $latitude);
            if ($longitude) \update_term_meta($term_id, 'longitude', $longitude);
            if ($url) \update_term_meta($term_id, 'url', $url);
            if ($tel) \update_term_meta($term_id, 'tel', $tel);
            if ($thumbnail) \update_term_meta($term_id, 'thumbnail', $thumbnail);
        } elseif ($taxonomy === 'mec_organizer') {
            $email = \sanitize_email($request->get_param('email'));
            $tel = \sanitize_text_field($request->get_param('tel'));
            $url = \esc_url_raw($request->get_param('url'));
            $thumbnail = \absint($request->get_param('thumbnail'));
            if ($email) \update_term_meta($term_id, 'email', $email);
            if ($tel) \update_term_meta($term_id, 'tel', $tel);
            if ($url) \update_term_meta($term_id, 'url', $url);
            if ($thumbnail) \update_term_meta($term_id, 'thumbnail', $thumbnail);
        } elseif ($taxonomy === 'mec_speaker') {
            $job_title = \sanitize_text_field($request->get_param('job_title'));
            $tel = \sanitize_text_field($request->get_param('tel'));
            $email = \sanitize_email($request->get_param('email'));
            $facebook = \esc_url_raw($request->get_param('facebook'));
            $twitter = \esc_url_raw($request->get_param('twitter'));
            $thumbnail = \absint($request->get_param('thumbnail'));
            if ($job_title) \update_term_meta($term_id, 'job_title', $job_title);
            if ($tel) \update_term_meta($term_id, 'tel', $tel);
            if ($email) \update_term_meta($term_id, 'email', $email);
            if ($facebook) \update_term_meta($term_id, 'facebook', $facebook);
            if ($twitter) \update_term_meta($term_id, 'twitter', $twitter);
            if ($thumbnail) \update_term_meta($term_id, 'thumbnail', $thumbnail);
        } elseif ($taxonomy === 'mec_sponsor') {
            $url = \esc_url_raw($request->get_param('url'));
            $logo = \absint($request->get_param('logo'));
            $thumbnail = \absint($request->get_param('thumbnail'));
            if ($url) \update_term_meta($term_id, 'url', $url);
            if ($logo) \update_term_meta($term_id, 'logo', $logo);
            if ($thumbnail) \update_term_meta($term_id, 'thumbnail', $thumbnail);
        } elseif ($taxonomy === 'mec_label') {
            $color = \sanitize_hex_color($request->get_param('color'));
            $style = \sanitize_text_field($request->get_param('style'));
            if ($color) \update_term_meta($term_id, 'color', $color);
            if ($style) \update_term_meta($term_id, 'style', $style);
        }

        $term = \get_term($term_id, $taxonomy);
        $term_data = [
            'id' => $term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
            'description' => $term->description,
            'count' => $term->count,
            'taxonomy' => $taxonomy
        ];

        return \rest_ensure_response([
            'success' => true,
            'message' => 'Term created successfully',
            'term' => $term_data
        ]);
    }

    /**
     * Handle event taxonomies - create new terms or assign existing ones
     */
    private static function handle_event_taxonomies($event_id, $taxonomies)
    {
        // Build taxonomy data from request
        $taxonomy_data = array();

        if (isset($taxonomies['mec_category'])) $taxonomy_data['mec_category'] = $taxonomies['mec_category'];
        if (isset($taxonomies['mec_label'])) $taxonomy_data['mec_label'] = $taxonomies['mec_label'];
        if (isset($taxonomies['mec_speaker'])) $taxonomy_data['mec_speaker'] = $taxonomies['mec_speaker'];
        if (isset($taxonomies['mec_sponsor'])) $taxonomy_data['mec_sponsor'] = $taxonomies['mec_sponsor'];
        if (isset($taxonomies['post_tag'])) $taxonomy_data['post_tag'] = $taxonomies['post_tag'];

        foreach ($taxonomy_data as $taxonomy => $terms) {
            if (empty($terms) || empty($taxonomy)) {
                continue;
            }

            // Ensure $terms is an array
            if (!is_array($terms)) {
                $terms = [$terms];
            }

            $term_ids = [];

            // Handle post_tag specially - it's the default WordPress tag taxonomy
            if ($taxonomy === 'post_tag') {
                foreach ($terms as $term) {
                    if (is_numeric($term)) {
                        // It's an ID, verify it exists
                        $existing_term = \get_term($term, 'post_tag');
                        if (!is_wp_error($existing_term)) {
                            $term_ids[] = (int) $term;
                        }
                    } else {
                        // It's a name, check if term exists or create new one
                        $existing_term = \get_term_by('name', $term, 'post_tag');
                        if ($existing_term) {
                            $term_ids[] = $existing_term->term_id;
                        } else {
                            // Create new term
                            $new_term = \wp_insert_term($term, 'post_tag');
                            if (!is_wp_error($new_term)) {
                                $term_ids[] = $new_term['term_id'];
                            }
                        }
                    }
                }
            } else {
                // Handle other MEC taxonomies
                foreach ($terms as $term) {
                    if (is_numeric($term)) {
                        // It's an ID, verify it exists
                        $existing_term = \get_term($term, $taxonomy);
                        if (!is_wp_error($existing_term)) {
                            $term_ids[] = (int) $term;
                        }
                    } else {
                        // It's a name, check if term exists or create new one
                        $existing_term = \get_term_by('name', $term, $taxonomy);
                        if ($existing_term) {
                            $term_ids[] = $existing_term->term_id;
                        } else {
                            // Create new term
                            $new_term = \wp_insert_term($term, $taxonomy);
                            if (!is_wp_error($new_term)) {
                                $term_ids[] = $new_term['term_id'];
                            }
                        }
                    }
                }
            }

            // Assign terms to event
            if (!empty($term_ids)) {
                $result = \wp_set_object_terms($event_id, $term_ids, $taxonomy);
            }
        }
    }

    /**
     * Create a new location
     */
    private static function create_location($location_data)
    {
        if (empty($location_data['name'])) {
            return '';
        }

        $location_term = \wp_insert_term($location_data['name'], 'mec_location');
        if (is_wp_error($location_term)) {
            return '';
        }

        $location_id = $location_term['term_id'];

        // Add location meta data
        if (!empty($location_data['address'])) {
            \update_term_meta($location_id, 'address', $location_data['address']);
        }
        if (!empty($location_data['latitude'])) {
            \update_term_meta($location_id, 'latitude', $location_data['latitude']);
        }
        if (!empty($location_data['longitude'])) {
            \update_term_meta($location_id, 'longitude', $location_data['longitude']);
        }
        if (!empty($location_data['url'])) {
            \update_term_meta($location_id, 'url', $location_data['url']);
        }
        if (!empty($location_data['tel'])) {
            \update_term_meta($location_id, 'tel', $location_data['tel']);
        }
        if (!empty($location_data['thumbnail'])) {
            \update_term_meta($location_id, 'thumbnail', $location_data['thumbnail']);
        }

        return $location_id;
    }

    /**
     * Create a new organizer
     */
    private static function create_organizer($organizer_data)
    {
        if (empty($organizer_data['name'])) {
            return '';
        }

        $organizer_term = \wp_insert_term($organizer_data['name'], 'mec_organizer');
        if (is_wp_error($organizer_term)) {
            return '';
        }

        $organizer_id = $organizer_term['term_id'];

        // Add organizer meta data
        if (!empty($organizer_data['email'])) {
            \update_term_meta($organizer_id, 'email', $organizer_data['email']);
        }
        if (!empty($organizer_data['tel'])) {
            \update_term_meta($organizer_id, 'tel', $organizer_data['tel']);
        }
        if (!empty($organizer_data['url'])) {
            \update_term_meta($organizer_id, 'url', $organizer_data['url']);
        }
        if (!empty($organizer_data['thumbnail'])) {
            \update_term_meta($organizer_id, 'thumbnail', $organizer_data['thumbnail']);
        }

        return $organizer_id;
    }

    /**
     * Convert time to seconds
     */
    private static function time_to_seconds($hour, $minutes, $ampm)
    {
        $hour = (int) $hour;
        $minutes = (int) $minutes;

        // Convert to 24-hour format
        if ($ampm === 'AM' && $hour === 12) {
            $hour = 0;
        } elseif ($ampm === 'PM' && $hour !== 12) {
            $hour += 12;
        }

        return ($hour * 3600) + ($minutes * 60);
    }

    /**
     * Get all invoices with filters
     */
    public static function api_invoices($request)
    {
        try {
            $per_page = $request->get_param('per_page') ?: 10;
            $page = $request->get_param('page') ?: 1;
            $offset = ($page - 1) * $per_page;

            // Use same approach as mec-invoice.php - get_posts with simple arguments
            $invoices = \get_posts([
                'post_type' => 'mec_invoice',
                'post_status' => 'any',  // Same as mec-invoice.php line 105
                'posts_per_page' => $per_page,
                'offset' => $offset,
                'orderby' => 'ID',
                'order' => 'DESC'
            ]);

            // Get total count for pagination
            $total_invoices = \get_posts([
                'post_type' => 'mec_invoice',
                'post_status' => 'any',
                'posts_per_page' => -1,
                'fields' => 'ids'
            ]);
            $total_count = count($total_invoices);

            // Process each invoice - same as mec-invoice.php structure
            $invoice_data = [];
            foreach ($invoices as $invoice) {
                $invoice_info = [
                    'invoice_id' => $invoice->ID,
                    'title' => self::clean_title($invoice->post_title),
                    'date' => $invoice->post_date,
                    'status' => $invoice->post_status,
                    'book_id' => \get_post_meta($invoice->ID, 'book_id', true),
                    'event_id' => \get_post_meta($invoice->ID, 'event_id', true),
                    'price' => \get_post_meta($invoice->ID, 'price', true),
                    'confirmed' => \get_post_meta($invoice->ID, 'confirmed', true),
                    'invoice_status' => \get_post_meta($invoice->ID, 'status', true),
                    'invoice_hash' => \get_post_meta($invoice->ID, 'invoiceID', true),
                    'transaction_id' => \get_post_meta($invoice->ID, 'transaction_id', true),
                ];

                // Add event details if available
                if ($invoice_info['event_id']) {
                    $event = \get_post($invoice_info['event_id']);
                    if ($event) {
                        $invoice_info['event_title'] = self::clean_title($event->post_title);
                    }
                }

                $invoice_data[] = $invoice_info;
            }

            // Calculate pagination
            $total_pages = ceil($total_count / $per_page);
            $response_data = [
                'invoices' => $invoice_data,
                'pagination' => [
                    'total' => $total_count,
                    'per_page' => $per_page,
                    'current_page' => $page,
                    'total_pages' => $total_pages,
                    'has_more' => $page < $total_pages
                ]
            ];

            return new \WP_REST_Response($response_data, 200);
        } catch (\Exception $e) {
            return new \WP_Error('invoices_error', 'Error fetching invoices: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get single invoice
     */
    public static function api_single_invoice($request)
    {
        try {
            // Check if MEC Invoice plugin is available
            if (!class_exists('MEC_Invoice\Helper\InvoiceInformation')) {
                return new \WP_Error('plugin_not_available', 'MEC Invoice plugin required for invoice functionality.', ['status' => 501]);
            }

            $invoice_id = (int) $request->get_param('invoice_id');
            $invoice = \get_post($invoice_id);

            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            $invoice_data = self::prepare_invoice_for_response($invoice, true);

            if (is_wp_error($invoice_data)) {
                return $invoice_data;
            }

            return new \WP_REST_Response($invoice_data, 200);
        } catch (\Exception $e) {
            return new \WP_Error('invoice_error', 'Error fetching invoice: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Update invoice
     */
    public static function api_update_invoice($request)
    {
        try {
            // Check if MEC Invoice plugin is available
            if (!class_exists('MEC_Invoice\Helper\InvoiceInformation')) {
                return new \WP_Error('plugin_not_available', 'MEC Invoice plugin required for invoice functionality.', ['status' => 501]);
            }

            $invoice_id = (int) $request->get_param('invoice_id');
            $invoice = \get_post($invoice_id);

            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            $body = $request->get_json_params();

            // Update available fields
            if (isset($body['status'])) {
                $status = in_array($body['status'], ['open', 'closed']) ? $body['status'] : 'open';
                \update_post_meta($invoice_id, 'status', $status);
            }

            if (isset($body['confirmed'])) {
                $confirmed = $body['confirmed'] ? '1' : '0';
                \update_post_meta($invoice_id, 'confirmed', $confirmed);
            }

            if (isset($body['notes'])) {
                $notes = \sanitize_textarea_field($body['notes']);
                \update_post_meta($invoice_id, 'notes', $notes);
            }

            // Get updated invoice data
            $invoice_data = self::prepare_invoice_for_response(\get_post($invoice_id), true);

            if (is_wp_error($invoice_data)) {
                return $invoice_data;
            }

            return new \WP_REST_Response($invoice_data, 200);
        } catch (\Exception $e) {
            return new \WP_Error('invoice_update_error', 'Error updating invoice: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get invoice PDF
     */
    public static function api_invoice_pdf($request)
    {
        try {
            // Check if MEC Invoice plugin is available
            if (!class_exists('MEC_Invoice\PDF')) {
                return new \WP_Error('plugin_not_available', 'MEC Invoice plugin required for PDF functionality.', ['status' => 501]);
            }

            $invoice_id = (int) $request->get_param('invoice_id');
            $invoice = \get_post($invoice_id);

            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            $invoice_hash = \get_post_meta($invoice_id, 'invoiceID', true);
            $pdf_url = \get_site_url(null, '?invoiceID=' . $invoice_id . '&makePreview=' . $invoice_hash . '&showPDF=true');

            return new \WP_REST_Response([
                'pdf_url' => $pdf_url,
                'invoice_id' => $invoice_id,
                'invoice_hash' => $invoice_hash
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('invoice_pdf_error', 'Error generating PDF: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get invoice QR codes
     */
    public static function api_invoice_qr_codes($request)
    {
        try {
            // Check if MEC Invoice plugin is available
            if (!class_exists('MEC_Invoice\Helper\InvoiceInformation')) {
                return new \WP_Error('plugin_not_available', 'MEC Invoice plugin required for QR functionality.', ['status' => 501]);
            }

            $invoice_id = (int) $request->get_param('invoice_id');
            $invoice = \get_post($invoice_id);

            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            $book_id = \get_post_meta($invoice_id, 'book_id', true);
            if (!$book_id) {
                return new \WP_Error('booking_not_found', 'Related booking not found.', ['status' => 404]);
            }

            // Get attendees for this booking
            $attendees = \get_post_meta($book_id, 'mec_attendees', true);
            if (!$attendees) $attendees = [];

            $qr_codes = [];
            $invoice_hash = \get_post_meta($invoice_id, 'invoiceID', true);
            $checkin_hash = \get_post_meta($invoice_id, 'CheckinHash', true);

            if (!empty($attendees)) {
                foreach ($attendees as $key => $attendee) {
                    $qr_codes[] = [
                        'attendee_key' => $key,
                        'attendee_name' => $attendee['name'] ?? '',
                        'attendee_email' => $attendee['email'] ?? '',
                        'qr_code_url' => \get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $checkin_hash . '&attendee=' . ($attendee['email'] ?? '') . '&place=' . ($key + 1) . '&Hash=' . $checkin_hash),
                        'qr_image_url' => \get_site_url(null, '/wp-json/mec-utility/v1/qr/image?invoice_id=' . $invoice_id . '&email=' . ($attendee['email'] ?? '') . '&place=' . ($key + 1))
                    ];
                }
            } else {
                // Single attendee (main booking)
                $user_email = \get_post_meta($book_id, 'mec_email', true);
                $qr_codes[] = [
                    'attendee_key' => 0,
                    'attendee_name' => \get_post_meta($book_id, 'mec_name', true) ?: '',
                    'attendee_email' => $user_email,
                    'qr_code_url' => \get_site_url(null, '?invoiceID=' . $invoice_id . '&makeQRCode=' . $checkin_hash . '&attendee=' . $user_email . '&place=1&Hash=' . $checkin_hash),
                    'qr_image_url' => \get_site_url(null, '/wp-json/mec-utility/v1/qr/image?invoice_id=' . $invoice_id . '&email=' . $user_email . '&place=1')
                ];
            }

            return new \WP_REST_Response([
                'invoice_id' => $invoice_id,
                'qr_codes' => $qr_codes,
                'total_attendees' => count($qr_codes)
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('invoice_qr_error', 'Error generating QR codes: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * List attendees for a specific invoice (based on book_id -> mec_attendees)
     */
    public static function api_invoice_attendees($request)
    {
        try {
            $invoice_id = (int) $request->get_param('invoice_id');
            $invoice = \get_post($invoice_id);
            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            $book_id = \get_post_meta($invoice_id, 'book_id', true);
            if (!$book_id) {
                return new \WP_Error('booking_not_found', 'Related booking not found.', ['status' => 404]);
            }

            $attendees = \get_post_meta($book_id, 'mec_attendees', true);
            if (!is_array($attendees)) $attendees = [];

            // Enrich with check-in status if class exists
            $enriched = [];
            foreach ($attendees as $key => $attendee) {
                if ($key === 'attachments') continue;
                if (isset($attendee[0]['MEC_TYPE_OF_DATA'])) continue;
                $checked = null;
                if (class_exists('MEC_Invoice\\Attendee')) {
                    $checked = \MEC_Invoice\Attendee::hasCheckedIn($invoice_id, $attendee['email'] ?? '', $key + 1);
                }
                $enriched[] = [
                    'attendee_key' => $key + 1,
                    'name' => $attendee['name'] ?? '',
                    'email' => $attendee['email'] ?? '',
                    'ticket_id' => isset($attendee['id']) ? (string)$attendee['id'] : '',
                    'checkin_status' => (bool)$checked,
                ];
            }

            return new \WP_REST_Response([
                'invoice_id' => $invoice_id,
                'booking_id' => (int) $book_id,
                'attendees' => $enriched,
                'count' => count($enriched)
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('invoice_attendees_error', 'Error fetching invoice attendees: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Manual check-in/out for invoice attendee
     * Body: { email: string, attendee_key: number, action: "checkin"|"checkout", occurrence_timestamp?: number }
     */
    public static function api_invoice_attendee_check($request)
    {
        try {
            if (!class_exists('MEC_Invoice\\Attendee')) {
                return new \WP_Error('plugin_not_available', 'MEC Invoice plugin required for check-in.', ['status' => 501]);
            }

            $invoice_id = (int) $request->get_param('invoice_id');
            $invoice = \get_post($invoice_id);
            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            $body = $request->get_json_params();
            $email = isset($body['email']) ? sanitize_email($body['email']) : '';
            $attendee_key = isset($body['attendee_key']) ? (int)$body['attendee_key'] : 0;
            $action = isset($body['action']) ? sanitize_text_field($body['action']) : 'checkin';
            $timestamp = isset($body['occurrence_timestamp']) ? (int)$body['occurrence_timestamp'] : null;

            if (!$email || !$attendee_key) {
                return new \WP_Error('invalid_params', 'email and attendee_key are required.', ['status' => 400]);
            }

            if ($action === 'checkout') {
                \MEC_Invoice\Attendee::doCheckOut($invoice_id, $email, $attendee_key, $timestamp, true);
                $status = false;
            } else {
                \MEC_Invoice\Attendee::doCheckIn($invoice_id, $email, $attendee_key, $timestamp, true);
                $status = true;
            }

            return new \WP_REST_Response([
                'invoice_id' => $invoice_id,
                'email' => $email,
                'attendee_key' => $attendee_key,
                'checked_in' => $status
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('invoice_attendee_check_error', 'Error updating attendee check status: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Prepare invoice data for API response
     */
    private static function prepare_invoice_for_response($invoice, $detailed = false)
    {
        try {
            $invoice_id = $invoice->ID;
            $book_id = \get_post_meta($invoice_id, 'book_id', true);
            $event_id = \get_post_meta($invoice_id, 'event_id', true);
            $transaction_id = \get_post_meta($invoice_id, 'transaction_id', true);
            $price = \get_post_meta($invoice_id, 'price', true);
            $confirmed = \get_post_meta($invoice_id, 'confirmed', true);
            $status = \get_post_meta($invoice_id, 'status', true);
            $invoice_hash = \get_post_meta($invoice_id, 'invoiceID', true);
            $checkin_hash = \get_post_meta($invoice_id, 'CheckinHash', true);

            // Get invoice number
            $invoice_number = '';
            if (class_exists('MEC_Invoice\Helper\Invoice')) {
                $invoice_number = \MEC_Invoice\Helper\Invoice::get_invoice_number($invoice_id);
            }

            // Basic invoice data
            $invoice_data = [
                'invoice_id' => $invoice_id,
                'invoice_number' => $invoice_number,
                'invoice_hash' => $invoice_hash,
                'checkin_hash' => $checkin_hash,
                'title' => self::clean_title($invoice->post_title),
                'date' => $invoice->post_date,
                'status' => $status ?: 'open',
                'confirmed' => $confirmed === '1',
                'price' => floatval($price),
                'formatted_price' => \MEC\Base::get_main()->render_price($price),
                'transaction_id' => $transaction_id,
                'booking_id' => $book_id,
                'event_id' => $event_id,
                'pdf_url' => \get_site_url(null, '?invoiceID=' . $invoice_id . '&makePreview=' . $invoice_hash . '&showPDF=true'),
            ];

            // Add detailed information if requested
            if ($detailed) {
                // Event information
                if ($event_id) {
                    $event = \get_post($event_id);
                    if ($event) {
                        $invoice_data['event'] = [
                            'id' => $event->ID,
                            'title' => self::clean_title($event->post_title),
                            'url' => \get_permalink($event->ID),
                            'start_date' => \get_post_meta($event->ID, 'mec_start_date', true),
                            'end_date' => \get_post_meta($event->ID, 'mec_end_date', true),
                        ];
                    }
                }

                // Booking information
                if ($book_id) {
                    $booking = \get_post($book_id);
                    if ($booking) {
                        $attendees = \get_post_meta($book_id, 'mec_attendees', true);
                        $invoice_data['booking'] = [
                            'id' => $book_id,
                            'name' => \get_post_meta($book_id, 'mec_name', true),
                            'email' => \get_post_meta($book_id, 'mec_email', true),
                            'phone' => \get_post_meta($book_id, 'mec_phone', true),
                            'attendees_count' => is_array($attendees) ? count($attendees) : 1,
                            'attendees' => $attendees ?: [],
                            'booking_date' => $booking->post_date,
                        ];
                    }
                }

                // Additional meta fields
                $invoice_data['notes'] = \get_post_meta($invoice_id, 'notes', true);
                $invoice_data['date_submit'] = \get_post_meta($invoice_id, 'date_submit', true);
            }

            return $invoice_data;
        } catch (\Exception $e) {
            return new \WP_Error('invoice_preparation_error', 'Error preparing invoice data: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Export attendees for given invoices
     */
    public static function api_export_invoice_attendees($request)
    {
        try {
            $body = $request->get_json_params();
            $invoice_ids = $body['invoice_ids'] ?? $request->get_param('invoice_ids');
            $format = strtolower($body['format'] ?? $request->get_param('format') ?? 'json');

            if (is_string($invoice_ids)) {
                $invoice_ids = array_filter(array_map('intval', explode(',', $invoice_ids)));
            }
            if (!is_array($invoice_ids) || empty($invoice_ids)) {
                return new \WP_Error('invalid_invoice_ids', 'invoice_ids is required (array or CSV).', ['status' => 400]);
            }

            $rows = [];
            foreach ($invoice_ids as $invoice_id) {
                $invoice = get_post((int)$invoice_id);
                if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                    continue;
                }

                $book_id = get_post_meta($invoice_id, 'book_id', true);
                $event_id = get_post_meta($invoice_id, 'event_id', true);
                $transaction_id = get_post_meta($invoice_id, 'transaction_id', true);
                $attendees = get_post_meta($book_id, 'mec_attendees', true);
                if (!is_array($attendees)) $attendees = [];

                foreach ($attendees as $key => $a) {
                    if ($key === 'attachments') continue;
                    if (isset($a[0]['MEC_TYPE_OF_DATA'])) continue;
                    $rows[] = [
                        'invoice_id' => (int)$invoice_id,
                        'booking_id' => (int)$book_id,
                        'event_id' => (int)$event_id,
                        'transaction_id' => (string)$transaction_id,
                        'attendee_key' => is_numeric($key) ? (int)$key : $key,
                        'name' => $a['name'] ?? '',
                        'email' => $a['email'] ?? '',
                        'ticket_id' => isset($a['id']) ? (string)$a['id'] : '',
                        'phone' => $a['phone'] ?? '',
                        'reg' => isset($a['reg']) && is_array($a['reg']) ? $a['reg'] : [],
                    ];
                }
            }

            if ($format === 'csv') {
                $upload = wp_upload_dir();
                $filename = 'invoice-attendees-' . date('Ymd-His') . '.csv';
                $path = trailingslashit($upload['path']) . $filename;
                $fh = fopen($path, 'w');
                if ($fh) {
                    fputcsv($fh, ['invoice_id', 'booking_id', 'event_id', 'transaction_id', 'attendee_key', 'name', 'email', 'ticket_id', 'phone', 'reg_json']);
                    foreach ($rows as $r) {
                        fputcsv($fh, [
                            $r['invoice_id'],
                            $r['booking_id'],
                            $r['event_id'],
                            $r['transaction_id'],
                            $r['attendee_key'],
                            $r['name'],
                            $r['email'],
                            $r['ticket_id'],
                            $r['phone'],
                            wp_json_encode($r['reg'])
                        ]);
                    }
                    fclose($fh);
                }
                return new \WP_REST_Response([
                    'success' => true,
                    'count' => count($rows),
                    'file_url' => trailingslashit($upload['url']) . $filename,
                ], 200);
            }

            if ($format === 'pdf') {
                // Return available invoice PDF URLs for the given invoices (leveraging MEC Invoice)
                if (!class_exists('MEC_Invoice\\PDF')) {
                    return new \WP_Error('plugin_not_available', 'MEC Invoice PDF generator not available.', ['status' => 501]);
                }

                $pdfs = [];
                foreach ($invoice_ids as $invoice_id) {
                    $invoice = get_post((int)$invoice_id);
                    if (!$invoice || $invoice->post_type !== 'mec_invoice') continue;
                    $invoice_hash = get_post_meta($invoice_id, 'invoiceID', true);
                    $pdf_url = get_site_url(null, '?invoiceID=' . (int)$invoice_id . '&makePreview=' . $invoice_hash . '&showPDF=true');
                    $pdfs[] = [
                        'invoice_id' => (int)$invoice_id,
                        'pdf_url' => $pdf_url,
                    ];
                }

                return new \WP_REST_Response([
                    'success' => true,
                    'pdfs' => $pdfs,
                    'count' => count($pdfs),
                ], 200);
            }

            return new \WP_REST_Response([
                'success' => true,
                'count' => count($rows),
                'attendees' => $rows,
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('export_invoice_attendees_error', 'Error exporting invoice attendees: ' . $e->getMessage(), ['status' => 500]);
        }
    }
    /**
     * Export bookings CSV
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_export_bookings_csv($request)
    {
        if (!class_exists('MEC_feature_books')) {
            return new \WP_Error('plugin_not_available', 'MEC plugin not available', ['status' => 404]);
        }

        $booking_ids = $request->get_param('booking_ids');
        if (empty($booking_ids)) {
            return new \WP_Error('no_booking_ids', 'No booking IDs provided', ['status' => 400]);
        }

        // Validate booking IDs
        $validated_ids = [];
        foreach ($booking_ids as $id) {
            $booking = \get_post($id);
            if ($booking && $booking->post_type === 'mec-books') {
                $validated_ids[] = $id;
            }
        }

        if (empty($validated_ids)) {
            return new \WP_Error('no_valid_bookings', 'No valid booking IDs provided', ['status' => 400]);
        }

        try {
            // Get MEC books instance
            $books = new \MEC_feature_books();
            $rows = $books->csvexcel($validated_ids);

            if (empty($rows)) {
                return new \WP_Error('no_data', 'No data found for export', ['status' => 404]);
            }

            // Generate filename
            $filename = 'bookings-' . md5(time() . mt_rand(100, 999)) . '.csv';
            $upload_dir = \wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;

            // Create CSV file
            $output = fopen($file_path, 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            $delimiter = "\t";
            foreach ($rows as $row) {
                fputcsv($output, $row, $delimiter);
            }
            fclose($output);

            // Move file to uploads directory
            $upload_dir = wp_upload_dir();
            $final_file_path = $upload_dir['basedir'] . '/' . $filename;
            $final_file_url = $upload_dir['baseurl'] . '/' . $filename;

            if (rename($file_path, $final_file_path)) {
                // Create attachment in media library
                $attachment = array(
                    'post_mime_type' => 'text/csv',
                    'post_title' => 'Bookings Export CSV - ' . date('Y-m-d H:i:s'),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );

                $attachment_id = wp_insert_attachment($attachment, $final_file_path);

                if ($attachment_id) {
                    // Schedule file deletion after 1 hour
                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($final_file_path, $attachment_id));

                    return new \WP_REST_Response([
                        'success' => true,
                        'download_url' => $final_file_url,
                        'filename' => $filename,
                        'attachment_id' => $attachment_id,
                        'total_rows' => count($rows) - 1, // Exclude header
                        'booking_ids' => $validated_ids,
                        'expires_in' => '1 hour'
                    ], 200);
                }
            }

            // Fallback: clean up and return error
            @unlink($file_path);
            return new \WP_Error('file_upload_failed', 'Failed to upload CSV file to media library.', ['status' => 500]);
        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting CSV: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Export bookings Excel
     * Downloads invoice/PDF files and saves them to media library with 1-hour expiration
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_export_bookings_excel($request)
    {
        if (!class_exists('MEC_feature_books')) {
            return new \WP_Error('plugin_not_available', 'MEC plugin not available', ['status' => 404]);
        }

        $booking_ids = $request->get_param('booking_ids');
        if (empty($booking_ids)) {
            return new \WP_Error('no_booking_ids', 'No booking IDs provided', ['status' => 400]);
        }

        // Check if mec-invoice plugin is active (same check as used elsewhere in codebase)
        $mec_invoice_active = class_exists('MEC_Invoice\\Base') || 
                              class_exists('MEC_Invoice\\Helper\\Invoice') || 
                              class_exists('MEC_Invoice\\Helper\\InvoiceInformation');

        // Validate booking IDs and download invoice/PDF files
        $bookings_data = [];
        $book = new \MEC_book();
        
        foreach ($booking_ids as $id) {
            $booking = \get_post($id);
            if (!$booking || $booking->post_type !== 'mec-books') {
                continue;
            }

            $transaction_id = \get_post_meta($id, 'mec_transaction_id', true);
            if (!$transaction_id) {
                continue;
            }

            $booking_data = [
                'booking_id' => $id,
                'transaction_id' => $transaction_id,
            ];

            try {
                // Check mec-invoice plugin status (same logic as books.php meta_box_invoice)
                if ($mec_invoice_active) {
                    // mec-invoice is active: generate PDF file
                    $invoice_id = \get_post_meta($id, 'invoiceID', true);
                    if ($invoice_id && class_exists('MEC_Invoice\\PDF')) {
                        // Generate PDF file using mec-invoice
                        $pdf_file_path = \MEC_Invoice\PDF::createFromInvoice($invoice_id, true);
                        
                        if ($pdf_file_path && file_exists($pdf_file_path)) {
                            // Read PDF content
                            $pdf_content = file_get_contents($pdf_file_path);
                            
                            // Generate filename
                            $filename = 'invoice-' . $transaction_id . '-' . time() . '.pdf';
                            $upload_dir = \wp_upload_dir();
                            // Use 'path' which includes year/month subdirectory (e.g., /2025/12)
                            $file_path = $upload_dir['path'] . '/' . $filename;
                            
                            // Save to uploads directory
                            if (file_put_contents($file_path, $pdf_content)) {
                                // Create attachment in media library
                                $attachment = array(
                                    'post_mime_type' => 'application/pdf',
                                    'post_title' => 'Invoice - Booking #' . $id . ' - ' . date('Y-m-d H:i:s'),
                                    'post_content' => '',
                                    'post_status' => 'inherit'
                                );

                                $attachment_id = wp_insert_attachment($attachment, $file_path);
                                
                                if ($attachment_id) {
                                    // Generate attachment metadata (required for proper URL)
                                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                                    $attach_data = wp_generate_attachment_metadata($attachment_id, $file_path);
                                    wp_update_attachment_metadata($attachment_id, $attach_data);
                                    
                                    // Schedule file deletion after 1 hour
                                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($file_path, $attachment_id));
                                    
                                    // Get correct file URL using WordPress function (includes year/month)
                                    $file_url = wp_get_attachment_url($attachment_id);
                                    
                                    $booking_data['download_url'] = $file_url;
                                    $booking_data['filename'] = $filename;
                                    $booking_data['attachment_id'] = $attachment_id;
                                    $booking_data['type'] = 'invoice';
                                    $booking_data['expires_in'] = '1 hour';
                                }
                            }
                            
                            // Clean up temporary PDF file
                            @unlink($pdf_file_path);
                        }
                    }
                } else {
                    // mec-invoice is not active: generate PDF using MEC's build_booking_invoice_pdf method
                    $settings = $book->settings;
                    if (!isset($settings['booking_invoice']) || (isset($settings['booking_invoice']) && $settings['booking_invoice'])) {
                        // Get transaction to access invoice_key
                        $transaction = $book->get_transaction($transaction_id);
                        $invoice_key = isset($transaction['invoice_key']) ? $transaction['invoice_key'] : null;
                        
                        // Use MEC's build_booking_invoice_pdf method directly (same as MEC uses internally)
                        // This method generates PDF content without needing URL access
                        $main = $book->getMain();
                        $pdf_data = $main->build_booking_invoice_pdf($transaction_id, [
                            'book_id' => $id,
                            'require_confirmation' => false, // Don't require confirmation for API access
                            'enforce_key' => true,
                            'invoice_key' => $invoice_key,
                        ]);
                        
                        if (!is_wp_error($pdf_data) && !empty($pdf_data['content'])) {
                            // PDF content is in $pdf_data['content']
                            $pdf_content = $pdf_data['content'];
                            
                            // Generate filename
                            $filename = 'invoice-' . $transaction_id . '-' . time() . '.pdf';
                            $upload_dir = \wp_upload_dir();
                            // Use 'path' which includes year/month subdirectory (e.g., /2025/12)
                            $file_path = $upload_dir['path'] . '/' . $filename;
                            
                            // Save to uploads directory
                            if (file_put_contents($file_path, $pdf_content)) {
                                // Create attachment in media library
                                $attachment = array(
                                    'post_mime_type' => 'application/pdf',
                                    'post_title' => 'Invoice - Booking #' . $id . ' - ' . date('Y-m-d H:i:s'),
                                    'post_content' => '',
                                    'post_status' => 'inherit'
                                );

                                $attachment_id = wp_insert_attachment($attachment, $file_path);
                                
                                if ($attachment_id) {
                                    // Generate attachment metadata (required for proper URL)
                                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                                    $attach_data = wp_generate_attachment_metadata($attachment_id, $file_path);
                                    wp_update_attachment_metadata($attachment_id, $attach_data);
                                    
                                    // Schedule file deletion after 1 hour
                                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($file_path, $attachment_id));
                                    
                                    // Get correct file URL using WordPress function (includes year/month)
                                    $file_url = wp_get_attachment_url($attachment_id);
                                    
                                    $booking_data['download_url'] = $file_url;
                                    $booking_data['filename'] = $filename;
                                    $booking_data['attachment_id'] = $attachment_id;
                                    $booking_data['type'] = 'pdf';
                                    $booking_data['expires_in'] = '1 hour';
                                }
                            }
                        } else {
                            // Handle error
                            if (is_wp_error($pdf_data)) {
                                $booking_data['error'] = $pdf_data->get_error_message();
                            } else {
                                $booking_data['error'] = 'Failed to generate PDF invoice';
                            }
                        }
                    }
                }
            } catch (\Exception $e) {
                $booking_data['error'] = 'Failed to generate invoice: ' . $e->getMessage();
            }

            $bookings_data[] = $booking_data;
        }

        if (empty($bookings_data)) {
            return new \WP_Error('no_valid_bookings', 'No valid booking IDs provided', ['status' => 400]);
        }

        return new \WP_REST_Response([
            'success' => true,
            'mec_invoice_active' => $mec_invoice_active,
            'bookings' => $bookings_data,
            'total' => count($bookings_data)
        ], 200);
    }

    /**
     * Get RSVP list with advanced filters
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_rsvps($request)
    {
        global $wpdb;

        $page = $request->get_param('page') ?: 1;
        $per_page = $request->get_param('per_page') ?: 20;
        $search = $request->get_param('search') ?: '';
        $event_id = $request->get_param('event_id');
        $location = $request->get_param('location');
        $response = $request->get_param('response') ?: 'all';
        $confirmation = $request->get_param('confirmation') ?: 'all';
        $verification = $request->get_param('verification') ?: 'all';
        $date_filter = $request->get_param('date_filter') ?: 'all';
        $order_date = $request->get_param('order_date') ?: 'all';
        $type_creation = $request->get_param('type_creation') ?: 'all';
        $start_date = $request->get_param('start_date');
        $end_date = $request->get_param('end_date');
        $order_by = $request->get_param('order_by') ?: 'date';
        $order = $request->get_param('order') ?: 'desc';

        $offset = ($page - 1) * $per_page;

        // Base query for bookings (RSVPs are stored as bookings)
        $query = "
                SELECT DISTINCT p.ID, p.post_title, p.post_date, p.post_status,
                    pm_event.meta_value as event_id,
                    pm_date.meta_value as event_date,
                    pm_confirmed.meta_value as confirmed,
                    pm_verified.meta_value as verified,
                    pm_attendees.meta_value as attendees,
                    pm_transaction.meta_value as transaction_id,
                    pm_gateway.meta_value as gateway_label,
                    pm_time.meta_value as booking_time
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} pm_event ON p.ID = pm_event.post_id AND pm_event.meta_key = 'mec_event_id'
                LEFT JOIN {$wpdb->postmeta} pm_date ON p.ID = pm_date.post_id AND pm_date.meta_key = 'mec_date'
                LEFT JOIN {$wpdb->postmeta} pm_confirmed ON p.ID = pm_confirmed.post_id AND pm_confirmed.meta_key = 'mec_confirmed'
                LEFT JOIN {$wpdb->postmeta} pm_verified ON p.ID = pm_verified.post_id AND pm_verified.meta_key = 'mec_verified'
                LEFT JOIN {$wpdb->postmeta} pm_attendees ON p.ID = pm_attendees.post_id AND pm_attendees.meta_key = 'mec_attendees'
                LEFT JOIN {$wpdb->postmeta} pm_transaction ON p.ID = pm_transaction.post_id AND pm_transaction.meta_key = 'mec_transaction_id'
                LEFT JOIN {$wpdb->postmeta} pm_gateway ON p.ID = pm_gateway.post_id AND pm_gateway.meta_key = 'mec_gateway_label'
                LEFT JOIN {$wpdb->postmeta} pm_time ON p.ID = pm_time.post_id AND pm_time.meta_key = 'mec_booking_time'
                WHERE p.post_type = 'mec-books'
                AND p.post_status NOT IN ('trash', 'auto-draft')
            ";

        $where_conditions = [];
        $params = [];

        // Event filter
        if ($event_id) {
            $where_conditions[] = "pm_event.meta_value = %d";
            $params[] = $event_id;
        }

        // Search filter
        if ($search) {
            $where_conditions[] = "(p.post_title LIKE %s OR pm_attendees.meta_value LIKE %s)";
            $params[] = '%' . $search . '%';
            $params[] = '%' . $search . '%';
        }

        // Confirmation filter
        if ($confirmation !== 'all') {
            $confirmation_value = ($confirmation === 'confirmed') ? '1' : (($confirmation === 'rejected') ? '-1' : '0');
            $where_conditions[] = "pm_confirmed.meta_value = %s";
            $params[] = $confirmation_value;
        }

        // Verification filter
        if ($verification !== 'all') {
            $verification_value = ($verification === 'verified') ? '1' : (($verification === 'rejected') ? '-1' : '0');
            $where_conditions[] = "pm_verified.meta_value = %s";
            $params[] = $verification_value;
        }

        // Date filters
        $date_conditions = self::apply_date_filters([], $start_date, $end_date, $date_filter);
        if (!empty($date_conditions)) {
            // Apply date filters to event date
            $now = current_time('timestamp');
            switch ($date_filter) {
                case 'today':
                    $where_conditions[] = "pm_date.meta_value LIKE %s";
                    $params[] = date('Y-m-d', $now) . '%';
                    break;
                case 'tomorrow':
                    $where_conditions[] = "pm_date.meta_value LIKE %s";
                    $params[] = date('Y-m-d', $now + 86400) . '%';
                    break;
                case 'this_week':
                    $week_start = date('Y-m-d', strtotime('monday this week', $now));
                    $week_end = date('Y-m-d', strtotime('sunday this week', $now));
                    $where_conditions[] = "pm_date.meta_value >= %s AND pm_date.meta_value <= %s";
                    $params[] = $week_start;
                    $params[] = $week_end . ' 23:59:59';
                    break;
                case 'this_month':
                    $month_start = date('Y-m-01', $now);
                    $month_end = date('Y-m-t', $now);
                    $where_conditions[] = "pm_date.meta_value >= %s AND pm_date.meta_value <= %s";
                    $params[] = $month_start;
                    $params[] = $month_end . ' 23:59:59';
                    break;
            }
        }

        // Order date filter
        if ($order_date !== 'all') {
            $now = current_time('timestamp');
            switch ($order_date) {
                case 'today':
                    $where_conditions[] = "DATE(p.post_date) = %s";
                    $params[] = date('Y-m-d', $now);
                    break;
                case 'yesterday':
                    $where_conditions[] = "DATE(p.post_date) = %s";
                    $params[] = date('Y-m-d', $now - 86400);
                    break;
                case 'this_week':
                    $week_start = date('Y-m-d', strtotime('monday this week', $now));
                    $week_end = date('Y-m-d', strtotime('sunday this week', $now));
                    $where_conditions[] = "DATE(p.post_date) >= %s AND DATE(p.post_date) <= %s";
                    $params[] = $week_start;
                    $params[] = $week_end;
                    break;
                case 'this_month':
                    $month_start = date('Y-m-01', $now);
                    $month_end = date('Y-m-t', $now);
                    $where_conditions[] = "DATE(p.post_date) >= %s AND DATE(p.post_date) <= %s";
                    $params[] = $month_start;
                    $params[] = $month_end;
                    break;
            }
        }

        // Add where conditions
        if (!empty($where_conditions)) {
            $query .= " AND " . implode(' AND ', $where_conditions);
        }

        // Order by
        $order_field = 'p.post_date';
        switch ($order_by) {
            case 'event':
                $order_field = 'pm_event.meta_value';
                break;
            case 'name':
                $order_field = 'p.post_title';
                break;
            case 'confirmation':
                $order_field = 'pm_confirmed.meta_value';
                break;
            case 'verification':
                $order_field = 'pm_verified.meta_value';
                break;
            case 'date':
            default:
                $order_field = 'p.post_date';
                break;
        }

        $query .= " ORDER BY {$order_field} " . strtoupper($order);
        $query .= " LIMIT %d OFFSET %d";
        $params[] = $per_page;
        $params[] = $offset;

        // Execute query
        $prepared_query = $wpdb->prepare($query, $params);
        $results = $wpdb->get_results($prepared_query);

        // Get total count
        $count_query = str_replace('SELECT DISTINCT p.ID, p.post_title, p.post_date, p.post_status,
                    pm_event.meta_value as event_id,
                    pm_date.meta_value as event_date,
                    pm_confirmed.meta_value as confirmed,
                    pm_verified.meta_value as verified,
                    pm_attendees.meta_value as attendees,
                    pm_transaction.meta_value as transaction_id,
                    pm_gateway.meta_value as gateway_label,
                    pm_time.meta_value as booking_time', 'SELECT COUNT(DISTINCT p.ID)', $query);
        $count_query = preg_replace('/ORDER BY.*$/i', '', $count_query);
        $count_query = preg_replace('/LIMIT.*$/i', '', $count_query);

        $count_params = array_slice($params, 0, -2); // Remove LIMIT and OFFSET params
        $total_count = $wpdb->get_var($wpdb->prepare($count_query, $count_params));

        // Process results
        $rsvps = [];
        foreach ($results as $result) {
            $event_title = '';
            $event_location = '';

            if ($result->event_id) {
                $event_title = get_the_title($result->event_id);
                $location_id = get_post_meta($result->event_id, 'mec_location_id', true);
                if ($location_id) {
                    $location_term = get_term($location_id, 'mec_location');
                    if ($location_term && !is_wp_error($location_term)) {
                        $event_location = $location_term->name;
                    }
                }
            }

            $attendees = [];
            if ($result->attendees) {
                $attendees_data = maybe_unserialize($result->attendees);
                if (is_array($attendees_data)) {
                    foreach ($attendees_data as $key => $attendee) {
                        if ($key === 'attachments') continue;
                        $attendees[] = [
                            'id' => $attendee['id'] ?? '',
                            'name' => $attendee['name'] ?? '',
                            'email' => $attendee['email'] ?? '',
                            'phone' => $attendee['phone'] ?? '',
                            'ticket_id' => $attendee['id'] ?? '',
                            'reg_fields' => $attendee['reg'] ?? [],
                        ];
                    }
                }
            }

            $confirmation_label = '';
            switch ($result->confirmed) {
                case '1':
                    $confirmation_label = 'Confirmed';
                    break;
                case '-1':
                    $confirmation_label = 'Rejected';
                    break;
                default:
                    $confirmation_label = 'Pending';
                    break;
            }

            $verification_label = '';
            switch ($result->verified) {
                case '1':
                    $verification_label = 'Verified';
                    break;
                case '-1':
                    $verification_label = 'Rejected';
                    break;
                default:
                    $verification_label = 'Pending';
                    break;
            }

            $rsvps[] = [
                'id' => (int)$result->ID,
                'event_id' => (int)$result->event_id,
                'event_title' => self::clean_title($event_title),
                'event_date' => $result->event_date,
                'location' => $event_location,
                'booking_date' => $result->post_date,
                'booking_time' => $result->booking_time,
                'confirmation' => [
                    'status' => $result->confirmed,
                    'label' => $confirmation_label,
                ],
                'verification' => [
                    'status' => $result->verified,
                    'label' => $verification_label,
                ],
                'response' => 'accepted', // Default, can be customized based on your logic
                'attendees' => $attendees,
                'attendees_count' => count($attendees),
                'transaction_id' => $result->transaction_id,
                'gateway' => $result->gateway_label,
                'creation_type' => 'frontend', // Can be determined based on your logic
            ];
        }

        return new \WP_REST_Response([
            'success' => true,
            'rsvps' => $rsvps,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => (int)$total_count,
                'total_pages' => ceil($total_count / $per_page),
            ],
            'filters' => [
                'search' => $search,
                'event_id' => $event_id,
                'location' => $location,
                'response' => $response,
                'confirmation' => $confirmation,
                'verification' => $verification,
                'date_filter' => $date_filter,
                'order_date' => $order_date,
                'type_creation' => $type_creation,
                'order_by' => $order_by,
                'order' => $order,
            ],
        ], 200);
    }

    /**
     * Get single RSVP details
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_single_rsvp($request)
    {
        $rsvp_id = $request->get_param('rsvp_id');

        $booking = \get_post($rsvp_id);
        if (!$booking || $booking->post_type !== 'mec-books') {
            return new \WP_Error('rsvp_not_found', 'RSVP not found', ['status' => 404]);
        }

        $event_id = get_post_meta($rsvp_id, 'mec_event_id', true);
        $event_date = get_post_meta($rsvp_id, 'mec_date', true);
        $confirmed = get_post_meta($rsvp_id, 'mec_confirmed', true);
        $verified = get_post_meta($rsvp_id, 'mec_verified', true);
        $attendees_data = get_post_meta($rsvp_id, 'mec_attendees', true);
        $transaction_id = get_post_meta($rsvp_id, 'mec_transaction_id', true);
        $gateway_label = get_post_meta($rsvp_id, 'mec_gateway_label', true);
        $booking_time = get_post_meta($rsvp_id, 'mec_booking_time', true);

        // Get event details
        $event_title = '';
        $event_location = '';
        if ($event_id) {
            $event_title = get_the_title($event_id);
            $location_id = get_post_meta($event_id, 'mec_location_id', true);
            if ($location_id) {
                $location_term = get_term($location_id, 'mec_location');
                if ($location_term && !is_wp_error($location_term)) {
                    $event_location = $location_term->name;
                }
            }
        }

        // Process attendees
        $attendees = [];
        if ($attendees_data) {
            $attendees_data = maybe_unserialize($attendees_data);
            if (is_array($attendees_data)) {
                foreach ($attendees_data as $key => $attendee) {
                    if ($key === 'attachments') continue;
                    $attendees[] = [
                        'id' => $attendee['id'] ?? '',
                        'name' => $attendee['name'] ?? '',
                        'email' => $attendee['email'] ?? '',
                        'phone' => $attendee['phone'] ?? '',
                        'ticket_id' => $attendee['id'] ?? '',
                        'reg_fields' => $attendee['reg'] ?? [],
                        'variations' => $attendee['variations'] ?? [],
                    ];
                }
            }
        }

        $rsvp = [
            'id' => (int)$rsvp_id,
            'event_id' => (int)$event_id,
            'event_title' => self::clean_title($event_title),
            'event_date' => $event_date,
            'location' => $event_location,
            'booking_date' => $booking->post_date,
            'booking_time' => $booking_time,
            'confirmation' => [
                'status' => $confirmed,
                'label' => $confirmed == '1' ? 'Confirmed' : ($confirmed == '-1' ? 'Rejected' : 'Pending'),
            ],
            'verification' => [
                'status' => $verified,
                'label' => $verified == '1' ? 'Verified' : ($verified == '-1' ? 'Rejected' : 'Pending'),
            ],
            'response' => 'accepted', // Default
            'attendees' => $attendees,
            'attendees_count' => count($attendees),
            'transaction_id' => $transaction_id,
            'gateway' => $gateway_label,
            'creation_type' => 'frontend',
            'notes' => get_post_meta($rsvp_id, 'mec_booking_notes', true),
        ];

        return new \WP_REST_Response([
            'success' => true,
            'rsvp' => $rsvp,
        ], 200);
    }

    /**
     * Update RSVP (confirmation/verification)
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_update_rsvp($request)
    {
        $rsvp_id = $request->get_param('rsvp_id');
        $confirmation = $request->get_param('confirmation');
        $verification = $request->get_param('verification');
        $response = $request->get_param('response');
        $attendees = $request->get_param('attendees');
        $notes = $request->get_param('notes');

        $booking = \get_post($rsvp_id);
        if (!$booking || $booking->post_type !== 'mec-books') {
            return new \WP_Error('rsvp_not_found', 'RSVP not found', ['status' => 404]);
        }

        $updated_fields = [];

        // Update confirmation
        if ($confirmation !== null) {
            $confirmation_value = '';
            switch ($confirmation) {
                case 'confirmed':
                    $confirmation_value = '1';
                    break;
                case 'rejected':
                    $confirmation_value = '-1';
                    break;
                case 'pending':
                default:
                    $confirmation_value = '0';
                    break;
            }
            update_post_meta($rsvp_id, 'mec_confirmed', $confirmation_value);
            $updated_fields['confirmation'] = $confirmation;

            // Use MEC book class for proper confirmation handling
            if (class_exists('MEC_book')) {
                $book = new \MEC_book();
                if ($confirmation === 'confirmed') {
                    $book->confirm($rsvp_id);
                } elseif ($confirmation === 'rejected') {
                    $book->reject($rsvp_id);
                } else {
                    $book->pending($rsvp_id);
                }
            }
        }

        // Update verification
        if ($verification !== null) {
            $verification_value = '';
            switch ($verification) {
                case 'verified':
                    $verification_value = '1';
                    break;
                case 'rejected':
                    $verification_value = '-1';
                    break;
                case 'pending':
                default:
                    $verification_value = '0';
                    break;
            }
            update_post_meta($rsvp_id, 'mec_verified', $verification_value);
            $updated_fields['verification'] = $verification;

            // Use MEC book class for proper verification handling
            if (class_exists('MEC_book')) {
                $book = new \MEC_book();
                if ($verification === 'verified') {
                    $book->verify($rsvp_id);
                }
            }
        }

        // Update attendees
        if ($attendees !== null && is_array($attendees)) {
            $existing_attendees = get_post_meta($rsvp_id, 'mec_attendees', true);
            $existing_attendees = maybe_unserialize($existing_attendees);

            if (!is_array($existing_attendees)) {
                $existing_attendees = [];
            }

            // Handle both new attendees and updates to existing ones
            $updated_attendees = [];

            foreach ($attendees as $attendee_data) {
                $attendee_key = $attendee_data['key'] ?? null;

                // If key is provided, update existing attendee
                if ($attendee_key !== null && isset($existing_attendees[$attendee_key])) {
                    $updated_attendee = $existing_attendees[$attendee_key];

                    // Update attendee fields if provided
                    if (isset($attendee_data['name'])) {
                        $updated_attendee['name'] = sanitize_text_field($attendee_data['name']);
                    }
                    if (isset($attendee_data['email'])) {
                        $updated_attendee['email'] = sanitize_email($attendee_data['email']);
                    }
                    if (isset($attendee_data['phone'])) {
                        $updated_attendee['phone'] = sanitize_text_field($attendee_data['phone']);
                    }
                    if (isset($attendee_data['birth_date'])) {
                        $updated_attendee['birth_date'] = sanitize_text_field($attendee_data['birth_date']);
                    }
                    if (isset($attendee_data['note'])) {
                        $updated_attendee['note'] = sanitize_textarea_field($attendee_data['note']);
                    }
                    if (isset($attendee_data['reg']) && is_array($attendee_data['reg'])) {
                        $updated_attendee['reg'] = $attendee_data['reg'];
                    }
                    if (isset($attendee_data['variations']) && is_array($attendee_data['variations'])) {
                        $updated_attendee['variations'] = $attendee_data['variations'];
                    }
                    if (isset($attendee_data['ticket_id'])) {
                        $updated_attendee['id'] = (int) $attendee_data['ticket_id'];
                    }

                    // Preserve important MEC fields
                    if (!isset($updated_attendee['buyerip'])) {
                        $updated_attendee['buyerip'] = $_SERVER['REMOTE_ADDR'] ?? '';
                    }
                    if (!isset($updated_attendee['count'])) {
                        $updated_attendee['count'] = 1;
                    }

                    $updated_attendees[$attendee_key] = $updated_attendee;
                } else {
                    // New attendee
                    $new_attendee = [
                        'id' => $attendee_data['ticket_id'] ?? $attendee_data['id'] ?? '',
                        'name' => sanitize_text_field($attendee_data['name'] ?? ''),
                        'email' => sanitize_email($attendee_data['email'] ?? ''),
                        'phone' => sanitize_text_field($attendee_data['phone'] ?? ''),
                        'birth_date' => sanitize_text_field($attendee_data['birth_date'] ?? ''),
                        'note' => sanitize_textarea_field($attendee_data['note'] ?? ''),
                        'reg' => $attendee_data['reg'] ?? [],
                        'variations' => $attendee_data['variations'] ?? [],
                        'buyerip' => $_SERVER['REMOTE_ADDR'] ?? '',
                        'count' => 1,
                    ];

                    $new_key = $attendee_key !== null ? $attendee_key : count($updated_attendees);
                    $updated_attendees[$new_key] = $new_attendee;
                }
            }

            // Preserve attachments if they exist
            if (isset($existing_attendees['attachments'])) {
                $updated_attendees['attachments'] = $existing_attendees['attachments'];
            }

            update_post_meta($rsvp_id, 'mec_attendees', $updated_attendees);
            $updated_fields['attendees'] = count($updated_attendees);
        }

        // Update notes
        if ($notes !== null) {
            update_post_meta($rsvp_id, 'mec_booking_notes', sanitize_textarea_field($notes));
            $updated_fields['notes'] = $notes;
        }

        return new \WP_REST_Response([
            'success' => true,
            'message' => 'RSVP updated successfully',
            'rsvp_id' => $rsvp_id,
            'updated_fields' => $updated_fields,
        ], 200);
    }

    /**
     * Get RSVP statistics
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_rsvp_stats($request)
    {
        global $wpdb;

        $event_id = $request->get_param('event_id');
        $date_filter = $request->get_param('date_filter') ?: 'all';

        $query = "
                SELECT
                    COUNT(p.ID) as total_rsvps,
                    SUM(CASE WHEN pm_confirmed.meta_value = '1' THEN 1 ELSE 0 END) as confirmed,
                    SUM(CASE WHEN pm_confirmed.meta_value = '-1' THEN 1 ELSE 0 END) as rejected,
                    SUM(CASE WHEN pm_confirmed.meta_value = '0' OR pm_confirmed.meta_value IS NULL THEN 1 ELSE 0 END) as pending_confirmation,
                    SUM(CASE WHEN pm_verified.meta_value = '1' THEN 1 ELSE 0 END) as verified,
                    SUM(CASE WHEN pm_verified.meta_value = '-1' THEN 1 ELSE 0 END) as rejected_verification,
                    SUM(CASE WHEN pm_verified.meta_value = '0' OR pm_verified.meta_value IS NULL THEN 1 ELSE 0 END) as pending_verification
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} pm_event ON p.ID = pm_event.post_id AND pm_event.meta_key = 'mec_event_id'
                LEFT JOIN {$wpdb->postmeta} pm_confirmed ON p.ID = pm_confirmed.post_id AND pm_confirmed.meta_key = 'mec_confirmed'
                LEFT JOIN {$wpdb->postmeta} pm_verified ON p.ID = pm_verified.post_id AND pm_verified.meta_key = 'mec_verified'
                WHERE p.post_type = 'mec-books'
                AND p.post_status NOT IN ('trash', 'auto-draft')
            ";

        $params = [];

        if ($event_id) {
            $query .= " AND pm_event.meta_value = %d";
            $params[] = $event_id;
        }

        // Date filter
        if ($date_filter !== 'all') {
            $now = current_time('timestamp');
            switch ($date_filter) {
                case 'today':
                    $query .= " AND DATE(p.post_date) = %s";
                    $params[] = date('Y-m-d', $now);
                    break;
                case 'this_week':
                    $week_start = date('Y-m-d', strtotime('monday this week', $now));
                    $week_end = date('Y-m-d', strtotime('sunday this week', $now));
                    $query .= " AND DATE(p.post_date) >= %s AND DATE(p.post_date) <= %s";
                    $params[] = $week_start;
                    $params[] = $week_end;
                    break;
                case 'this_month':
                    $month_start = date('Y-m-01', $now);
                    $month_end = date('Y-m-t', $now);
                    $query .= " AND DATE(p.post_date) >= %s AND DATE(p.post_date) <= %s";
                    $params[] = $month_start;
                    $params[] = $month_end;
                    break;
            }
        }

        $result = $wpdb->get_row($wpdb->prepare($query, $params));

        $stats = [
            'total_rsvps' => (int)$result->total_rsvps,
            'confirmation' => [
                'confirmed' => (int)$result->confirmed,
                'rejected' => (int)$result->rejected,
                'pending' => (int)$result->pending_confirmation,
            ],
            'verification' => [
                'verified' => (int)$result->verified,
                'rejected' => (int)$result->rejected_verification,
                'pending' => (int)$result->pending_verification,
            ],
            'response' => [
                'accepted' => (int)$result->confirmed, // Assuming confirmed = accepted
                'declined' => (int)$result->rejected,
                'pending' => (int)$result->pending_confirmation,
            ],
        ];

        return new \WP_REST_Response([
            'success' => true,
            'stats' => $stats,
            'filters' => [
                'event_id' => $event_id,
                'date_filter' => $date_filter,
            ],
        ], 200);
    }

    /**
     * Export RSVPs CSV
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_export_rsvps_csv($request)
    {
        if (!class_exists('MEC_feature_books')) {
            return new \WP_Error('plugin_not_available', 'MEC plugin not available', ['status' => 404]);
        }

        $rsvp_ids = $request->get_param('rsvp_ids');
        if (empty($rsvp_ids)) {
            return new \WP_Error('no_rsvp_ids', 'No RSVP IDs provided', ['status' => 400]);
        }

        // Validate RSVP IDs
        $validated_ids = [];
        foreach ($rsvp_ids as $id) {
            $rsvp = \get_post($id);
            if ($rsvp && $rsvp->post_type === 'mec-books') {
                $validated_ids[] = $id;
            }
        }

        if (empty($validated_ids)) {
            return new \WP_Error('no_valid_rsvps', 'No valid RSVP IDs provided', ['status' => 400]);
        }

        try {
            // Get MEC books instance
            $books = new \MEC_feature_books();
            $rows = $books->csvexcel($validated_ids);

            if (empty($rows)) {
                return new \WP_Error('no_data', 'No data found for export', ['status' => 404]);
            }

            // Generate filename
            $filename = 'rsvps-' . md5(time() . mt_rand(100, 999)) . '.csv';
            $upload_dir = \wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;

            // Create CSV file
            $output = fopen($file_path, 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            $delimiter = "\t";
            foreach ($rows as $row) {
                fputcsv($output, $row, $delimiter);
            }
            fclose($output);

            // Get file contents and base64 encode
            $file_contents = file_get_contents($file_path);
            $base64_content = base64_encode($file_contents);

            // Clean up temporary file
            unlink($file_path);

            return new \WP_REST_Response([
                'success' => true,
                'filename' => $filename,
                'content' => $base64_content,
                'mime_type' => 'text/csv',
                'total_rows' => count($rows) - 1, // Exclude header
                'rsvp_ids' => $validated_ids
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting CSV: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Export RSVPs Excel
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_export_rsvps_excel($request)
    {
        if (!class_exists('MEC_feature_books')) {
            return new \WP_Error('plugin_not_available', 'MEC plugin not available', ['status' => 404]);
        }

        $rsvp_ids = $request->get_param('rsvp_ids');
        if (empty($rsvp_ids)) {
            return new \WP_Error('no_rsvp_ids', 'No RSVP IDs provided', ['status' => 400]);
        }

        // Validate RSVP IDs
        $validated_ids = [];
        foreach ($rsvp_ids as $id) {
            $rsvp = \get_post($id);
            if ($rsvp && $rsvp->post_type === 'mec-books') {
                $validated_ids[] = $id;
            }
        }

        if (empty($validated_ids)) {
            return new \WP_Error('no_valid_rsvps', 'No valid RSVP IDs provided', ['status' => 400]);
        }

        try {
            // Include XLSX library
            include_once \MEC_ABSPATH . 'app' . DIRECTORY_SEPARATOR . 'api' . DIRECTORY_SEPARATOR . 'XLSX' . DIRECTORY_SEPARATOR . 'xlsxwriter.class.php';

            // Get MEC books instance
            $books = new \MEC_feature_books();
            $rows = $books->csvexcel($validated_ids);

            if (empty($rows)) {
                return new \WP_Error('no_data', 'No data found for export', ['status' => 404]);
            }

            // Generate filename
            $filename = 'rsvps-' . md5(time() . mt_rand(100, 999)) . '.xlsx';
            $upload_dir = \wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;

            // Create Excel file
            $writer = new \MEC_XLSXWriter();
            $writer->writeSheet($rows);
            $writer->writeToFile($file_path);

            // Get file contents and base64 encode
            $file_contents = file_get_contents($file_path);
            $base64_content = base64_encode($file_contents);

            // Clean up temporary file
            unlink($file_path);

            return new \WP_REST_Response([
                'success' => true,
                'filename' => $filename,
                'content' => $base64_content,
                'mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'total_rows' => count($rows) - 1, // Exclude header
                'rsvp_ids' => $validated_ids
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting Excel: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get confirmation status label
     */
    private static function get_confirmation_label($status)
    {
        switch ((int) $status) {
            case 1:
                return 'Confirmed';
            case 0:
                return 'Pending';
            case -1:
                return 'Rejected';
            default:
                return 'Unknown';
        }
    }

    /**
     * Get verification status label
     */
    private static function get_verification_label($status)
    {
        switch ((int) $status) {
            case 1:
                return 'Verified';
            case 0:
                return 'Waiting';
            case -1:
                return 'Canceled';
            default:
                return 'Unknown';
        }
    }

    /**
     * Get event colors for specified month
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function api_event_colors($request)
    {
        try {
            global $wpdb;

            // Get date parameter from request
            $date_param = $request->get_param('date');
            $status = $request->get_param('status') ?: 'any'; // Support all post statuses by default

            // If no date provided, use current month
            if (empty($date_param)) {
                $date_param = date('Y-m');
            }

            // Validate date format (should be YYYY-MM or YYYY-MM-DD)
            if (!preg_match('/^\d{4}-\d{2}(-\d{2})?$/', $date_param)) {
                return new \WP_Error(
                    'invalid_date_format',
                    'Date parameter must be in YYYY-MM or YYYY-MM-DD format.',
                    array('status' => 400)
                );
            }

            // Determine if it's a month or specific date
            $is_month = strlen($date_param) === 7; // YYYY-MM format

            // Build status condition
            $status_condition = '';
            if ($status !== 'any') {
                $status_condition = $wpdb->prepare("AND p.post_status = %s", $status);
            } else {
                // For 'any', exclude only auto-draft
                $status_condition = "AND p.post_status != 'auto-draft'";
            }

            if ($is_month) {
                // Get events for specified month
                $start_of_month = $date_param . '-01';
                $end_of_month = date('Y-m-t', strtotime($start_of_month));

                $query = $wpdb->prepare(
                    "SELECT e.post_id, e.start, p.post_status
                        FROM {$wpdb->prefix}mec_events e
                        INNER JOIN {$wpdb->posts} p ON e.post_id = p.ID
                        WHERE e.start >= %s AND e.start <= %s
                        AND p.post_type = 'mec-events'
                        {$status_condition}
                        ORDER BY e.start ASC",
                    $start_of_month,
                    $end_of_month
                );
            } else {
                // Get events for specific date
                $specific_date = $date_param;

                $query = $wpdb->prepare(
                    "SELECT e.post_id, e.start, p.post_status
                        FROM {$wpdb->prefix}mec_events e
                        INNER JOIN {$wpdb->posts} p ON e.post_id = p.ID
                        WHERE DATE(e.start) = %s
                        AND p.post_type = 'mec-events'
                        {$status_condition}
                        ORDER BY e.start ASC",
                    $specific_date
                );
            }

            $events = $wpdb->get_results($query);

            // Group events by date and limit to 3 per day
            $events_by_date = array();
            foreach ($events as $event) {
                $start_date = $event->start;
                $color = get_post_meta($event->post_id, 'mec_color', true);

                // Format date for grouping
                $date_key = date('Y-m-d', strtotime($start_date));

                if (!isset($events_by_date[$date_key])) {
                    $events_by_date[$date_key] = array();
                }

                // Only add if we have less than 3 events for this date
                if (count($events_by_date[$date_key]) < 3) {
                    $events_by_date[$date_key][] = array(
                        'id' => $event->post_id,
                        'start_date' => $start_date,
                        'color' => $color ?: '#000000' // Default color if none set
                    );
                }
            }

            // Format response
            $response_data = array();
            foreach ($events_by_date as $date => $day_events) {
                $response_data[] = array(
                    'date' => $date,
                    'events' => $day_events
                );
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => $response_data,
                'requested_date' => $date_param,
                'is_month' => $is_month,
                'total_dates' => count($response_data)
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error(
                'mec_utility_event_colors_error',
                'Unable to retrieve event colors: ' . $e->getMessage(),
                array('status' => 500)
            );
        }
    }

    /**
     * Upload media file to WordPress media library
     */
    public static function api_upload_media($request)
    {
        try {
            // Check if file is uploaded
            if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
                return new \WP_Error('no_file', 'No file uploaded or upload error occurred.', ['status' => 400]);
            }

            $file = $_FILES['file'];
            $filename = sanitize_file_name($file['name']);
            $upload_dir = wp_upload_dir();

            // Validate file type
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $file_type = wp_check_filetype($filename);

            if (!in_array($file['type'], $allowed_types)) {
                return new \WP_Error('invalid_file_type', 'Only image files (JPEG, PNG, GIF, WebP) are allowed.', ['status' => 400]);
            }

            // Generate unique filename
            $filename = wp_unique_filename($upload_dir['path'], $filename);
            $file_path = $upload_dir['path'] . '/' . $filename;

            // Move uploaded file
            if (!move_uploaded_file($file['tmp_name'], $file_path)) {
                return new \WP_Error('upload_failed', 'Failed to move uploaded file.', ['status' => 500]);
            }

            // Create attachment
            $attachment = array(
                'post_mime_type' => $file['type'],
                'post_title' => sanitize_file_name($file['name']),
                'post_content' => '',
                'post_status' => 'inherit'
            );

            $attachment_id = wp_insert_attachment($attachment, $file_path);

            if (is_wp_error($attachment_id)) {
                return $attachment_id;
            }

            // Generate attachment metadata
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
            wp_update_attachment_metadata($attachment_id, $attachment_data);

            // Get attachment URL
            $attachment_url = wp_get_attachment_url($attachment_id);

            return new \WP_REST_Response([
                'success' => true,
                'attachment_id' => $attachment_id,
                'url' => $attachment_url,
                'filename' => $filename,
                'mime_type' => $file['type'],
                'size' => $file['size']
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error('upload_error', 'Upload error: ' . $e->getMessage(), ['status' => 500]);
        }
    }
}

