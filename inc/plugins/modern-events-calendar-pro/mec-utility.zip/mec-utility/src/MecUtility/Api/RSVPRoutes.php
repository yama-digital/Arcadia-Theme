<?php

/**
 * RSVP API Routes
 *
 * @package    MecUtility
 * @subpackage MecUtility/API
 * @since      1.0.0
 */

namespace MecUtility\Api;

use MecUtility\Auth\AuthHelper;
use MEC\Events\Event;
use MEC\Attendees\Attendees;

/**
 * RSVPRoutes class for managing RSVPs via REST API
 */
class RSVPRoutes
{
    /**
     * Register the API routes
     */
    public function register_routes()
    {
        // Get RSVPs list with filtering and search
        register_rest_route('mec-utility/v1', '/rsvps', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_rsvps'],
            'permission_callback' => AuthHelper::permission_callback('read_rsvp'),
            'args'                => $this->get_list_query_params(),
        ]);

        // Get, Update, Delete single RSVP
        register_rest_route('mec-utility/v1', '/rsvps/(?P<rsvp_id>\d+)', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_rsvp'],
                'permission_callback' => AuthHelper::permission_callback('read_rsvp'),
            ],
            [
                'methods'             => \WP_REST_Server::EDITABLE,
                'callback'            => [$this, 'update_rsvp'],
                'permission_callback' => AuthHelper::permission_callback('update_rsvp'),
                'args'                => $this->get_rsvp_update_schema(),
            ],
            [
                'methods'             => \WP_REST_Server::DELETABLE,
                'callback'            => [$this, 'delete_rsvp'],
                'permission_callback' => AuthHelper::permission_callback('delete_rsvp'),
                'args'                => [
                    'force' => [
                        'description' => 'Whether to permanently delete the RSVP (true) or move to trash (false, default)',
                        'type'        => 'boolean',
                        'default'     => false,
                    ],
                ],
            ],
        ]);

        // Update RSVP status (confirmation and verification)
        register_rest_route('mec-utility/v1', '/rsvps/(?P<rsvp_id>\d+)/status', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'update_rsvp_status'],
            'permission_callback' => AuthHelper::permission_callback('confirm_rsvp'),
            'args'                => $this->get_status_update_schema(),
        ]);

        // Get RSVP attendees
        register_rest_route('mec-utility/v1', '/rsvps/(?P<rsvp_id>\d+)/attendees', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_rsvp_attendees'],
            'permission_callback' => AuthHelper::permission_callback('read_rsvp'),
        ]);

        // Export RSVPs CSV
        register_rest_route('mec-utility/v1', '/rsvps/export/csv', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'export_rsvps_csv'],
            'permission_callback' => AuthHelper::permission_callback('export_rsvp'),
            'args'                => [
                'rsvp_ids' => [
                    'required' => true,
                    'type'     => 'array',
                    'items'    => ['type' => 'integer'],
                ],
            ],
        ]);

        // Export RSVPs Excel
        register_rest_route('mec-utility/v1', '/rsvps/export/excel', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'export_rsvps_excel'],
            'permission_callback' => AuthHelper::permission_callback('export_rsvp'),
            'args'                => [
                'rsvp_ids' => [
                    'required' => true,
                    'type'     => 'array',
                    'items'    => ['type' => 'integer'],
                ],
            ],
        ]);

        // RSVP Statistics
        register_rest_route('mec-utility/v1', '/rsvps/stats', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_rsvp_stats'],
            'permission_callback' => AuthHelper::permission_callback('read_rsvp'),
        ]);

        // RSVPs by Event ID
        register_rest_route('mec-utility/v1', '/events/(?P<event_id>\d+)/rsvps', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_event_rsvps'],
            'permission_callback' => AuthHelper::permission_callback('read_rsvp'),
            'args'                => [
                'event_id' => [
                    'description' => 'Event ID to get RSVPs for',
                    'type'        => 'integer',
                    'required'    => true,
                ],
            ],
        ]);

        // Bulk operations
        register_rest_route('mec-utility/v1', '/rsvps/bulk-status', [
            'methods'             => \WP_REST_Server::EDITABLE,
            'callback'            => [$this, 'bulk_update_status'],
            'permission_callback' => AuthHelper::permission_callback('bulk_rsvp'),
        ]);

        register_rest_route('mec-utility/v1', '/rsvps/bulk-delete', [
            'methods'             => \WP_REST_Server::DELETABLE,
            'callback'            => [$this, 'bulk_delete'],
            'permission_callback' => AuthHelper::permission_callback('bulk_rsvp'),
            'args'                => [
                'force' => [
                    'description' => 'Whether to permanently delete RSVPs (true) or move to trash (false, default)',
                    'type'        => 'boolean',
                    'default'     => false,
                ],
            ],
        ]);

        // RSVP Months (for frontend All dates dropdown)
        register_rest_route('mec-utility/v1', '/rsvp-months', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_rsvp_months'],
            'permission_callback' => AuthHelper::permission_callback('read_rsvp'),
            'args'                => [
                'event_id' => [
                    'description' => 'Optional event ID to limit months to a single event',
                    'type'        => 'integer',
                    'required'    => false,
                ],
            ],
        ]);

        // Debug endpoint for RSVP data
        register_rest_route('mec-utility/v1', '/rsvps/(?P<rsvp_id>\d+)/debug', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'debug_rsvp_data'],
            'permission_callback' => AuthHelper::permission_callback('read_rsvp'),
        ]);
    }

    /**
     * Get RSVPs for a specific event
     */
    public function get_event_rsvps(\WP_REST_Request $request)
    {
        try {
            // Authentication check
            $auth_result = AuthHelper::verify_authentication($request);
            if (is_wp_error($auth_result)) {
                return $auth_result;
            }

            // Permission check - allow any RSVP permission
            $has_permission = false;
            $rsvp_permissions = ['read_rsvp', 'manage_rsvp', 'mec_rsvp'];
            foreach ($rsvp_permissions as $permission) {
                $permission_check = AuthHelper::check_permission($auth_result, $permission);
                if (!is_wp_error($permission_check)) {
                    $has_permission = true;
                    break;
                }
            }
            if (!$has_permission) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Permission denied. Requires RSVP read access.',
                    'code' => 'no_permission'
                ], 403);
            }

            $event_id = (int) $request['event_id'];
            if ($event_id <= 0) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Invalid event_id',
                    'code' => 'invalid_event_id'
                ], 400);
            }

            // Ensure event exists (optional but helpful)
            $event_post = get_post($event_id);
            if (!$event_post) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Event not found',
                    'code' => 'event_not_found'
                ], 404);
            }

            // Query RSVPs for this event
            $query = new \WP_Query([
                'post_type' => 'mec_rsvp',
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'meta_query' => [
                    [
                        'key' => 'mec_event_id',
                        'value' => $event_id,
                        'compare' => '=',
                    ],
                ],
                'orderby' => 'date',
                'order' => 'DESC',
                'fields' => 'ids',
            ]);

            $rsvps = [];
            if ($query->have_posts()) {
                foreach ($query->posts as $rsvp_id) {
                    if (class_exists('MEC_RSVP\\RSVP\\RSVP')) {
                        $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
                        $rsvps[] = $this->format_rsvp_list_item($rsvp);
                    }
                }
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'event' => [
                        'id' => $event_id,
                        'title' => $this->clean_html_from_title(get_the_title($event_id)),
                        'permalink' => get_permalink($event_id),
                    ],
                    'rsvps' => $rsvps,
                    'count' => count($rsvps),
                ],
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve RSVPs for event: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get RSVPs list with filtering and search
     */
    public function get_rsvps(\WP_REST_Request $request)
    {
        try {
            // Authentication check
            $auth_result = AuthHelper::verify_authentication($request);
            if (is_wp_error($auth_result)) {
                return $auth_result;
            }

            // Permission check - allow any RSVP permission
            $has_permission = false;
            $rsvp_permissions = ['read_rsvp', 'manage_rsvp', 'mec_rsvp'];
            
            foreach ($rsvp_permissions as $permission) {
                $permission_check = AuthHelper::check_permission($auth_result, $permission);
                if (!is_wp_error($permission_check)) {
                    $has_permission = true;
                    break;
                }
            }
            
            if (!$has_permission) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Permission denied. Requires RSVP read access.',
                    'code' => 'no_permission'
                ], 403);
            }

            $params = $this->sanitize_list_params($request);
            
            $query_args = [
                'post_type' => 'mec_rsvp',
                'post_status' => 'publish',
                'posts_per_page' => -1, // Get all RSVPs
                'orderby' => $params['orderby'],
                'order' => $params['order'],
                'meta_query' => [],
                'date_query' => [],
            ];

            // Add search
            if (!empty($params['search'])) {
                $query_args['s'] = $params['search'];
            }

            // Filter by event
            if (!empty($params['event_id'])) {
                $query_args['meta_query'][] = [
                    'key' => 'mec_event_id',
                    'value' => $params['event_id'],
                    'compare' => '='
                ];
            }

            // Filter by response (answer)
            if (!empty($params['response'])) {
                $query_args['meta_query'][] = [
                    'key' => 'mec_answer',
                    'value' => $params['response'],
                    'compare' => '='
                ];
            }

            // Filter by confirmation status
            if (isset($params['confirmation']) && $params['confirmation'] !== '') {
                $query_args['meta_query'][] = [
                    'key' => 'mec_confirmed',
                    'value' => $params['confirmation'],
                    'compare' => '='
                ];
            }

            // Filter by verification status
            if (isset($params['verification']) && $params['verification'] !== '') {
                $query_args['meta_query'][] = [
                    'key' => 'mec_verified',
                    'value' => $params['verification'],
                    'compare' => '='
                ];
            }

            // Filter by location
            if (!empty($params['location'])) {
                // Get events with this location first
                $events_query = new \WP_Query([
                    'post_type' => 'mec-events',
                    'posts_per_page' => -1,
                    'fields' => 'ids',
                    'tax_query' => [
                        [
                            'taxonomy' => 'mec_location',
                            'field' => 'term_id',
                            'terms' => $params['location']
                        ]
                    ]
                ]);
                
                if ($events_query->posts) {
                    $query_args['meta_query'][] = [
                        'key' => 'mec_event_id',
                        'value' => $events_query->posts,
                        'compare' => 'IN'
                    ];
                } else {
                    // No events with this location, return empty
                    return new \WP_REST_Response([
                        'success' => true,
                        'data' => [
                            'rsvps' => [],
                            'response_counts' => [
                                'yes' => 0,
                                'no' => 0,
                                'maybe' => 0,
                                'total' => 0
                            ]
                        ]
                    ], 200);
                }
            }

            // Filter by creation type
            if (!empty($params['creation_type'])) {
                if ($params['creation_type'] === 'invite') {
                    $query_args['meta_query'][] = [
                        'key' => 'mec_creation_by_invite',
                        'compare' => 'EXISTS'
                    ];
                } else {
                    $query_args['meta_query'][] = [
                        'key' => 'mec_creation_by_invite',
                        'compare' => 'NOT EXISTS'
                    ];
                }
            }

            // Date filters
            if (!empty($params['date_from']) || !empty($params['date_to'])) {
                $date_query = [];
                
                if (!empty($params['date_from'])) {
                    $date_query['after'] = $params['date_from'];
                }
                
                if (!empty($params['date_to'])) {
                    $date_query['before'] = $params['date_to'];
                }
                
                if (!empty($date_query)) {
                    $query_args['date_query'][] = $date_query;
                }
            }

            // Set meta_query relation
            if (count($query_args['meta_query']) > 1) {
                $query_args['meta_query']['relation'] = 'AND';
            }

            $query = new \WP_Query($query_args);
            $rsvps = [];

            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $rsvp_id = get_the_ID();
                    
                    // Load RSVP class - check if exists first
                    if (class_exists('MEC_RSVP\RSVP\RSVP')) {
                        $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
                        $rsvps[] = $this->format_rsvp_list_item($rsvp);
                    }
                }
                wp_reset_postdata();
            }

            // Get response counts for all RSVPs (not just current page)
            $response_counts = $this->get_response_counts($params);

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'rsvps' => $rsvps,
                    'response_counts' => $response_counts,
                    'filters_applied' => array_filter([
                        'event_id' => $params['event_id'],
                        'response' => $params['response'],
                        'confirmation' => $params['confirmation'],
                        'verification' => $params['verification'],
                        'location' => $params['location'],
                        'creation_type' => $params['creation_type'],
                        'date_from' => $params['date_from'],
                        'date_to' => $params['date_to']
                    ])
                ]
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve RSVPs: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get single RSVP details
     */
    public function get_rsvp(\WP_REST_Request $request)
    {
        try {
            // Authentication check
            $auth_result = AuthHelper::verify_authentication($request);
            if (is_wp_error($auth_result)) {
                return $auth_result;
            }

            // Permission check - allow any RSVP permission
            $has_permission = false;
            $rsvp_permissions = ['read_rsvp', 'manage_rsvp', 'mec_rsvp'];
            
            foreach ($rsvp_permissions as $permission) {
                $permission_check = AuthHelper::check_permission($auth_result, $permission);
                if (!is_wp_error($permission_check)) {
                    $has_permission = true;
                    break;
                }
            }
            
            if (!$has_permission) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Permission denied. Requires RSVP read access.',
                    'code' => 'no_permission'
                ], 403);
            }

            $rsvp_id = (int) $request['rsvp_id'];
            
            // Check if RSVP exists
            $post = get_post($rsvp_id);
            if (!$post || $post->post_type !== 'mec_rsvp') {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP not found'
                ], 404);
            }

            // Load RSVP class
            if (!class_exists('MEC_RSVP\RSVP\RSVP')) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP class not available'
                ], 500);
            }

            $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
            $detailed_data = $this->format_rsvp_details($rsvp);

            return new \WP_REST_Response([
                'success' => true,
                'data' => $detailed_data,
                'message' => 'RSVP details retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve RSVP details: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update RSVP status (confirmation and verification)
     */
    public function update_rsvp_status(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'confirm_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            $rsvp_id = (int) $request['rsvp_id'];
            $params = $request->get_params();

            // Check if RSVP exists
            $post = get_post($rsvp_id);
            if (!$post || $post->post_type !== 'mec_rsvp') {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP not found'
                ], 404);
            }

            // Load RSVP class
            if (!class_exists('MEC_RSVP\RSVP\RSVP')) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP class not available'
                ], 500);
            }

            $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
            $updated_fields = [];

            // Debug: Log received parameters
            error_log('RSVP Update Debug - Received params: ' . print_r($params, true));

            // Update confirmation status
            if (isset($params['confirmation'])) {
                $confirmation = (int) $params['confirmation'];
                $rsvp->set_confirm_status($confirmation, 'manual');
                $updated_fields['confirmation'] = $confirmation;
            }

            // Update verification status
            if (isset($params['verification'])) {
                $verification = (int) $params['verification'];
                $rsvp->set_verification_status($verification, 'manual');
                $updated_fields['verification'] = $verification;
            }

            // Send verification email if requested
            if (isset($params['resend_verification']) && $params['resend_verification'] == 1) {
                // Trigger verification email resend
                do_action('mec_rsvp_resend_verification', $rsvp_id);
                $updated_fields['verification_email_sent'] = true;
            }

            // Send confirmation email if requested
            if (isset($params['resend_confirmation']) && $params['resend_confirmation'] == 1) {
                // Trigger confirmation email resend
                do_action('mec_rsvp_resend_confirmation', $rsvp_id);
                $updated_fields['confirmation_email_sent'] = true;
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'rsvp_id' => $rsvp_id,
                    'updated_fields' => $updated_fields,
                    'current_status' => [
                        'confirmation' => $rsvp->get_confirm_status(),
                        'verification' => $rsvp->get_verification_status()
                    ]
                ],
                'message' => 'RSVP status updated successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to update RSVP status: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update RSVP data (attendees and fixed fields)
     */
    public function update_rsvp(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'update_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            $rsvp_id = (int) $request['rsvp_id'];
            $params = $request->get_params();

            // Check if RSVP exists
            $post = get_post($rsvp_id);
            if (!$post || $post->post_type !== 'mec_rsvp') {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP not found'
                ], 404);
            }

            // Load RSVP class to get current data
            if (!class_exists('MEC_RSVP\RSVP\RSVP')) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP class not available'
                ], 500);
            }

            $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
            $updated_fields = [];
            $errors = [];

            // Update attendees if provided
            if (isset($params['attendees'])) {
                $attendees_result = $this->update_rsvp_attendees($rsvp, $params['attendees']);
                if ($attendees_result['success']) {
                    $updated_fields['attendees'] = $attendees_result['data'];
                } else {
                    $errors = array_merge($errors, $attendees_result['errors']);
                }
            }

            // Remove specific attendees if provided
            if (isset($params['remove_attendees']) && is_array($params['remove_attendees'])) {
                $remove_result = $this->remove_specific_attendees($rsvp, $params['remove_attendees']);
                if ($remove_result['success']) {
                    $updated_fields['removed_attendees'] = $remove_result['data'];
                } else {
                    $errors = array_merge($errors, $remove_result['errors']);
                }
            }

            // Update fixed fields if provided
            if (isset($params['fixed_fields'])) {
                $fixed_result = $this->update_rsvp_fixed_fields($rsvp, $params['fixed_fields']);
                if ($fixed_result['success']) {
                    $updated_fields['fixed_fields'] = $fixed_result['data'];
                } else {
                    $errors = array_merge($errors, $fixed_result['errors']);
                }
            }

            // Update answer if provided
            if (isset($params['answer'])) {
                $answer_result = $this->update_rsvp_answer($rsvp, $params['answer']);
                if ($answer_result['success']) {
                    $updated_fields['answer'] = $answer_result['data'];
                } else {
                    $errors = array_merge($errors, $answer_result['errors']);
                }
            }

            // Update event date if provided
            if (isset($params['event_date'])) {
                $date_result = $this->update_rsvp_event_date($rsvp, $params['event_date']);
                if ($date_result['success']) {
                    $updated_fields['event_date'] = $date_result['data'];
                } else {
                    $errors = array_merge($errors, $date_result['errors']);
                }
            }

            // Update title if provided or if attendees were updated
            if (isset($params['title']) || isset($updated_fields['attendees'])) {
                $title_result = $this->update_rsvp_title($rsvp, $params['title'] ?? null);
                if ($title_result['success']) {
                    $updated_fields['title'] = $title_result['data'];
                } else {
                    $errors = array_merge($errors, $title_result['errors']);
                }
            }

            // If there are errors, return them
            if (!empty($errors)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Some updates failed',
                    'errors' => $errors,
                    'updated_fields' => $updated_fields
                ], 400);
            }

            // Get updated RSVP data
            $updated_rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
            $detailed_data = $this->format_rsvp_details($updated_rsvp);

            return new \WP_REST_Response([
                'success' => true,
                'data' => $detailed_data,
                'updated_fields' => array_keys($updated_fields),
                'message' => 'RSVP updated successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to update RSVP: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete RSVP
     */
    public function delete_rsvp(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'delete_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            $rsvp_id = (int) $request['rsvp_id'];
            $force = (bool) $request->get_param('force'); // Get force parameter (default: false)

            // Check if RSVP exists
            $post = get_post($rsvp_id);
            if (!$post || $post->post_type !== 'mec_rsvp') {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP not found'
                ], 404);
            }

            // Delete the RSVP (trash or force delete based on parameter)
            if ($force) {
                $deleted = wp_delete_post($rsvp_id, true);
            } else {
                // Move to trash instead of permanent delete
                $deleted = wp_trash_post($rsvp_id);
            }

            if ($deleted) {
                return new \WP_REST_Response([
                    'success' => true,
                    'data' => [
                        'rsvp_id' => $rsvp_id,
                        'deleted' => $force,
                        'trashed' => !$force
                    ],
                    'message' => $force ? 'RSVP deleted permanently' : 'RSVP moved to trash'
                ], 200);
            } else {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Failed to delete RSVP'
                ], 500);
            }

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to delete RSVP: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get RSVP attendees
     */
    public function get_rsvp_attendees(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            $rsvp_id = (int) $request['rsvp_id'];

            // Check if RSVP exists
            $post = get_post($rsvp_id);
            if (!$post || $post->post_type !== 'mec_rsvp') {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP not found'
                ], 404);
            }

            // Load RSVP class
            if (!class_exists('MEC_RSVP\RSVP\RSVP')) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP class not available'
                ], 500);
            }

            $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
            $attendees = $rsvp->get_attendees();

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'rsvp_id' => $rsvp_id,
                    'attendees' => $attendees,
                    'attendees_count' => $rsvp->get_attendees_count()
                ],
                'message' => 'RSVP attendees retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve RSVP attendees: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Bulk update RSVP status
     */
    public function bulk_update_status(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'bulk_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            $params = $request->get_params();
            $rsvp_ids = isset($params['rsvp_ids']) ? $params['rsvp_ids'] : [];
            $status_updates = isset($params['status']) ? $params['status'] : [];

            if (empty($rsvp_ids) || empty($status_updates)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP IDs and status updates are required'
                ], 400);
            }

            $updated_count = 0;
            $failed_ids = [];

            foreach ($rsvp_ids as $rsvp_id) {
                try {
                    $rsvp_id = (int) $rsvp_id;
                    $post = get_post($rsvp_id);
                    
                    if (!$post || $post->post_type !== 'mec_rsvp') {
                        $failed_ids[] = $rsvp_id;
                        continue;
                    }

                    if (!class_exists('MEC_RSVP\RSVP\RSVP')) {
                        $failed_ids[] = $rsvp_id;
                        continue;
                    }

                    $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);

                    if (isset($status_updates['confirmation'])) {
                        $rsvp->set_confirm_status((int) $status_updates['confirmation'], 'manual');
                    }

                    if (isset($status_updates['verification'])) {
                        $rsvp->set_verification_status((int) $status_updates['verification'], 'manual');
                    }

                    $updated_count++;

                } catch (\Exception $e) {
                    $failed_ids[] = $rsvp_id;
                }
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'updated_count' => $updated_count,
                    'failed_count' => count($failed_ids),
                    'failed_ids' => $failed_ids,
                    'status_applied' => $status_updates
                ],
                'message' => "{$updated_count} RSVPs updated successfully"
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to bulk update RSVP status: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Bulk delete RSVPs
     */
    public function bulk_delete(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'bulk_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            $params = $request->get_params();
            $rsvp_ids = isset($params['rsvp_ids']) ? $params['rsvp_ids'] : [];
            $force = isset($params['force']) ? (bool) $params['force'] : false; // Get force parameter (default: false)

            if (empty($rsvp_ids)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP IDs are required'
                ], 400);
            }

            $deleted_count = 0;
            $trashed_count = 0;
            $failed_ids = [];

            foreach ($rsvp_ids as $rsvp_id) {
                try {
                    $rsvp_id = (int) $rsvp_id;
                    $post = get_post($rsvp_id);
                    
                    if (!$post || $post->post_type !== 'mec_rsvp') {
                        $failed_ids[] = $rsvp_id;
                        continue;
                    }

                    // Delete or trash based on force parameter
                    if ($force) {
                        $result = wp_delete_post($rsvp_id, true);
                        if ($result) {
                            $deleted_count++;
                        } else {
                            $failed_ids[] = $rsvp_id;
                        }
                    } else {
                        $result = wp_trash_post($rsvp_id);
                        if ($result) {
                            $trashed_count++;
                        } else {
                            $failed_ids[] = $rsvp_id;
                        }
                    }

                } catch (\Exception $e) {
                    $failed_ids[] = $rsvp_id;
                }
            }

            $success_count = $force ? $deleted_count : $trashed_count;
            $action = $force ? 'deleted permanently' : 'moved to trash';

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'deleted_count' => $deleted_count,
                    'trashed_count' => $trashed_count,
                    'failed_count' => count($failed_ids),
                    'failed_ids' => $failed_ids,
                    'force' => $force
                ],
                'message' => "{$success_count} RSVPs {$action}"
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to bulk delete RSVPs: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Export RSVPs to CSV
     */
    public function export_rsvps_csv(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'export_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            if (!class_exists('MEC_feature_books')) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'MEC plugin not available'
                ], 404);
            }

            $rsvp_ids = $request->get_param('rsvp_ids');
            if (empty($rsvp_ids)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'No RSVP IDs provided'
                ], 400);
            }

            // Validate RSVP IDs
            $validated_ids = [];
            foreach ($rsvp_ids as $id) {
                $rsvp = \get_post($id);
                if ($rsvp && $rsvp->post_type === 'mec-books') {
                    $validated_ids[] = $id;
                }
            }

            if (empty($validated_ids)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'No valid RSVP IDs provided'
                ], 400);
            }

            // Get MEC books instance
            $books = new \MEC_feature_books();
            $rows = $books->csvexcel($validated_ids);
            
            if (empty($rows)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'No data found for export'
                ], 404);
            }

            // Generate filename
            $filename = 'rsvps-' . md5(time() . mt_rand(100, 999)) . '.csv';
            $upload_dir = \wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;

            // Create CSV file
            $output = fopen($file_path, 'w');
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            $delimiter = "\t";
            foreach ($rows as $row) {
                fputcsv($output, $row, $delimiter);
            }
            fclose($output);

            // Get file contents and base64 encode
            $file_contents = file_get_contents($file_path);
            $base64_content = base64_encode($file_contents);

            // Clean up temporary file
            unlink($file_path);

            return new \WP_REST_Response([
                'success' => true,
                'filename' => $filename,
                'content' => $base64_content,
                'mime_type' => 'text/csv',
                'total_rows' => count($rows) - 1, // Exclude header
                'rsvp_ids' => $validated_ids
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Error exporting CSV: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Export RSVPs to Excel
     */
    public function export_rsvps_excel(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'export_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            if (!class_exists('MEC_feature_books')) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'MEC plugin not available'
                ], 404);
            }

            $rsvp_ids = $request->get_param('rsvp_ids');
            if (empty($rsvp_ids)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'No RSVP IDs provided'
                ], 400);
            }

            // Validate RSVP IDs
            $validated_ids = [];
            foreach ($rsvp_ids as $id) {
                $rsvp = \get_post($id);
                if ($rsvp && $rsvp->post_type === 'mec-books') {
                    $validated_ids[] = $id;
                }
            }

            if (empty($validated_ids)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'No valid RSVP IDs provided'
                ], 400);
            }

            // Include XLSX library
            include_once \MEC_ABSPATH . 'app' . DIRECTORY_SEPARATOR . 'api' . DIRECTORY_SEPARATOR . 'XLSX' . DIRECTORY_SEPARATOR . 'xlsxwriter.class.php';

            // Get MEC books instance
            $books = new \MEC_feature_books();
            $rows = $books->csvexcel($validated_ids);
            
            if (empty($rows)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'No data found for export'
                ], 404);
            }

            // Generate filename
            $filename = 'rsvps-' . md5(time() . mt_rand(100, 999)) . '.xlsx';
            $upload_dir = \wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $filename;

            // Create Excel file
            $writer = new \MEC_XLSXWriter();
            $writer->writeSheet($rows);
            $writer->writeToFile($file_path);

            // Get file contents and base64 encode
            $file_contents = file_get_contents($file_path);
            $base64_content = base64_encode($file_contents);

            // Clean up temporary file
            unlink($file_path);

            return new \WP_REST_Response([
                'success' => true,
                'filename' => $filename,
                'content' => $base64_content,
                'mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'total_rows' => count($rows) - 1, // Exclude header
                'rsvp_ids' => $validated_ids
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Error exporting Excel: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get RSVP Statistics
     */
    public function get_rsvp_stats(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_rsvp');
            if (is_wp_error($user_data)) {
                return $user_data;
            }

            global $wpdb;

            $event_id = $request->get_param('event_id');
            $date_filter = $request->get_param('date_filter');
            $start_date = $request->get_param('start_date');
            $end_date = $request->get_param('end_date');

            // Base query for statistics
            $where_conditions = [];
            $where_conditions[] = "p.post_type = 'mec-books'";
            $where_conditions[] = "p.post_status = 'publish'";

            if ($event_id) {
                $where_conditions[] = $wpdb->prepare("pm_event.meta_value = %d", $event_id);
            }

            // Date filtering
            if ($date_filter && $date_filter !== 'all') {
                $date_condition = $this->apply_date_filter_condition($date_filter);
                if ($date_condition) {
                    $where_conditions[] = $date_condition;
                }
            }

            if ($start_date && $end_date) {
                $where_conditions[] = $wpdb->prepare("DATE(p.post_date) BETWEEN %s AND %s", $start_date, $end_date);
            }

            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

            $query = "
                SELECT 
                    COUNT(p.ID) as total_rsvps,
                    SUM(CASE WHEN pm_confirmed.meta_value = '1' THEN 1 ELSE 0 END) as confirmed_rsvps,
                    SUM(CASE WHEN pm_confirmed.meta_value = '0' OR pm_confirmed.meta_value IS NULL THEN 1 ELSE 0 END) as pending_rsvps,
                    SUM(CASE WHEN pm_confirmed.meta_value = '-1' THEN 1 ELSE 0 END) as rejected_rsvps,
                    SUM(CASE WHEN pm_verified.meta_value = '1' THEN 1 ELSE 0 END) as verified_rsvps
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} pm_event ON p.ID = pm_event.post_id AND pm_event.meta_key = 'mec_event_id'
                LEFT JOIN {$wpdb->postmeta} pm_confirmed ON p.ID = pm_confirmed.post_id AND pm_confirmed.meta_key = 'mec_confirmed'
                LEFT JOIN {$wpdb->postmeta} pm_verified ON p.ID = pm_verified.post_id AND pm_verified.meta_key = 'mec_verified'
                {$where_clause}
            ";

            $result = $wpdb->get_row($query);

            return new \WP_REST_Response([
                'success' => true,
                'stats' => [
                    'total_rsvps' => (int)$result->total_rsvps,
                    'confirmed_rsvps' => (int)$result->confirmed_rsvps,
                    'pending_rsvps' => (int)$result->pending_rsvps,
                    'rejected_rsvps' => (int)$result->rejected_rsvps,
                    'verified_rsvps' => (int)$result->verified_rsvps,
                    'by_confirmation' => [
                        'confirmed' => (int)$result->confirmed_rsvps,
                        'pending' => (int)$result->pending_rsvps,
                        'rejected' => (int)$result->rejected_rsvps,
                    ],
                    'by_verification' => [
                        'verified' => (int)$result->verified_rsvps,
                        'pending' => (int)$result->total_rsvps - (int)$result->verified_rsvps,
                        'rejected' => 0, // Can be expanded later
                    ]
                ]
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Error getting RSVP statistics: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Apply date filter condition for statistics
     */
    private function apply_date_filter_condition($date_filter)
    {
        global $wpdb;
        
        switch ($date_filter) {
            case 'today':
                return "DATE(p.post_date) = CURDATE()";
            case 'this_week':
                return "YEARWEEK(p.post_date, 1) = YEARWEEK(CURDATE(), 1)";
            case 'this_month':
                return "YEAR(p.post_date) = YEAR(CURDATE()) AND MONTH(p.post_date) = MONTH(CURDATE())";
            default:
                return '';
        }
    }

    /**
     * Get response counts for RSVPs based on filters
     */
    private function get_response_counts($params)
    {
        global $wpdb;

        // Build the same query conditions as main query but without pagination
        $where_conditions = [];
        $where_conditions[] = "p.post_type = 'mec_rsvp'";
        $where_conditions[] = "p.post_status = 'publish'";

        // Apply same filters as main query
        if (!empty($params['event_id'])) {
            $where_conditions[] = $wpdb->prepare("pm_event.meta_value = %d", $params['event_id']);
        }

        if (!empty($params['response'])) {
            $where_conditions[] = $wpdb->prepare("pm_answer.meta_value = %s", $params['response']);
        }

        if (isset($params['confirmation']) && $params['confirmation'] !== '') {
            $where_conditions[] = $wpdb->prepare("pm_confirmed.meta_value = %d", $params['confirmation']);
        }

        if (isset($params['verification']) && $params['verification'] !== '') {
            $where_conditions[] = $wpdb->prepare("pm_verified.meta_value = %d", $params['verification']);
        }

        if (!empty($params['location'])) {
            // Get events with this location first
            $events_query = new \WP_Query([
                'post_type' => 'mec-events',
                'posts_per_page' => -1,
                'fields' => 'ids',
                'tax_query' => [
                    [
                        'taxonomy' => 'mec_location',
                        'field' => 'term_id',
                        'terms' => $params['location']
                    ]
                ]
            ]);
            
            if ($events_query->posts) {
                $event_ids = implode(',', array_map('intval', $events_query->posts));
                $where_conditions[] = "pm_event.meta_value IN ({$event_ids})";
            } else {
                // No events with this location, return zero counts
                return [
                    'yes' => 0,
                    'no' => 0,
                    'maybe' => 0,
                    'total' => 0
                ];
            }
        }

        if (!empty($params['creation_type'])) {
            if ($params['creation_type'] === 'invite') {
                $where_conditions[] = "pm_invite.meta_key = 'mec_creation_by_invite'";
            } else {
                $where_conditions[] = "pm_invite.meta_key IS NULL";
            }
        }

        // Date filters
        if (!empty($params['date_from']) || !empty($params['date_to'])) {
            if (!empty($params['date_from'])) {
                $where_conditions[] = $wpdb->prepare("DATE(p.post_date) >= %s", $params['date_from']);
            }
            
            if (!empty($params['date_to'])) {
                $where_conditions[] = $wpdb->prepare("DATE(p.post_date) <= %s", $params['date_to']);
            }
        }

        $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

        // Query to get response counts
        $query = "
            SELECT 
                COALESCE(pm_answer.meta_value, 'no_response') as response_type,
                COUNT(p.ID) as count
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm_event ON p.ID = pm_event.post_id AND pm_event.meta_key = 'mec_event_id'
            LEFT JOIN {$wpdb->postmeta} pm_answer ON p.ID = pm_answer.post_id AND pm_answer.meta_key = 'mec_answer'
            LEFT JOIN {$wpdb->postmeta} pm_confirmed ON p.ID = pm_confirmed.post_id AND pm_confirmed.meta_key = 'mec_confirmed'
            LEFT JOIN {$wpdb->postmeta} pm_verified ON p.ID = pm_verified.post_id AND pm_verified.meta_key = 'mec_verified'
            LEFT JOIN {$wpdb->postmeta} pm_invite ON p.ID = pm_invite.post_id AND pm_invite.meta_key = 'mec_creation_by_invite'
            {$where_clause}
            GROUP BY pm_answer.meta_value
        ";

        $results = $wpdb->get_results($query);

        // Initialize counts
        $counts = [
            'yes' => 0,
            'no' => 0,
            'maybe' => 0,
            'total' => 0
        ];

        // Process results
        foreach ($results as $result) {
            $response_type = $result->response_type;
            $count = (int) $result->count;
            
            if (in_array($response_type, ['yes', 'no', 'maybe'])) {
                $counts[$response_type] = $count;
            }
            $counts['total'] += $count;
        }

        return $counts;
    }

    /**
     * Get RSVP months list (YYYYMM + human label), optionally filtered by event
     */
    public function get_rsvp_months(\WP_REST_Request $request)
    {
        try {
            // Auth
            $auth_result = AuthHelper::verify_authentication($request);
            if (is_wp_error($auth_result)) {
                return $auth_result;
            }
            $perm = AuthHelper::check_permission($auth_result, 'read_rsvp');
            if (is_wp_error($perm)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Permission denied. Requires RSVP read access.',
                    'code' => 'no_permission'
                ], 403);
            }

            global $wpdb;
            $event_id = (int) ($request->get_param('event_id') ?: 0);

            if ($event_id > 0) {
                // Limit months to RSVPs of a specific event
                $sql = $wpdb->prepare(
                    "SELECT DATE_FORMAT(p.post_date, '%Y%m') AS ym,\n                            DATE_FORMAT(p.post_date, '%M %Y') AS month_label,\n                            COUNT(p.ID) AS items\n                     FROM {$wpdb->posts} p\n                     INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = 'mec_event_id'\n                     WHERE p.post_type = 'mec_rsvp' AND p.post_status = 'publish' AND pm.meta_value = %d\n                     GROUP BY ym, month_label\n                     ORDER BY ym DESC",
                    $event_id
                );
            } else {
                // All RSVPs across events
                $sql = "SELECT DATE_FORMAT(p.post_date, '%Y%m') AS ym,\n                               DATE_FORMAT(p.post_date, '%M %Y') AS month_label,\n                               COUNT(p.ID) AS items\n                        FROM {$wpdb->posts} p\n                        WHERE p.post_type = 'mec_rsvp' AND p.post_status = 'publish'\n                        GROUP BY ym, month_label\n                        ORDER BY ym DESC";
            }

            $rows = $wpdb->get_results($sql);

            $months = [];
            foreach ($rows as $row) {
                $months[] = [
                    'value' => $row->ym,          // e.g., 202506
                    'label' => $row->month_label, // e.g., June 2025
                    'count' => (int) $row->items,
                ];
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'months' => $months,
                ]
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve RSVP months: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Sanitize list parameters
     */
    private function sanitize_list_params(\WP_REST_Request $request)
    {
        $params = [
            'page' => max(1, (int) $request->get_param('page') ?: 1),
            'per_page' => min(100, max(1, (int) $request->get_param('per_page') ?: 20)),
            'orderby' => sanitize_text_field($request->get_param('orderby') ?: 'date'),
            'order' => strtoupper(sanitize_text_field($request->get_param('order') ?: 'DESC')),
            'search' => sanitize_text_field($request->get_param('search') ?: ''),
            'event_id' => (int) $request->get_param('event_id') ?: 0,
            'response' => sanitize_text_field($request->get_param('response') ?: ''),
            'confirmation' => $request->get_param('confirmation'),
            'verification' => $request->get_param('verification'),
            'location' => (int) $request->get_param('location') ?: 0,
            'creation_type' => sanitize_text_field($request->get_param('creation_type') ?: ''),
            'date_from' => sanitize_text_field($request->get_param('date_from') ?: ''),
            'date_to' => sanitize_text_field($request->get_param('date_to') ?: ''),
        ];

        // Validate order
        if (!in_array($params['order'], ['ASC', 'DESC'])) {
            $params['order'] = 'DESC';
        }

        // Validate orderby
        $valid_orderby = ['date', 'ID', 'title', 'event_id'];
        if (!in_array($params['orderby'], $valid_orderby)) {
            $params['orderby'] = 'date';
        }

        // Validate response
        if (!empty($params['response']) && !in_array($params['response'], ['yes', 'no', 'maybe'])) {
            $params['response'] = '';
        }

        return $params;
    }

    /**
     * Format RSVP for list display
     */
    private function format_rsvp_list_item($rsvp)
    {
        $event_id = $rsvp->get_event_id();
        $event_title = '';
        $event_location = '';
        
        if ($event_id) {
            $event_title = $this->clean_html_from_title(get_the_title($event_id));
            $location_terms = get_the_terms($event_id, 'mec_location');
            if ($location_terms && !is_wp_error($location_terms)) {
                $event_location = $location_terms[0]->name;
            }
        }

        return [
            'id' => $rsvp->get_id(),
            'title' => $rsvp->get_title(),
            'event' => [
                'id' => $event_id,
                'title' => $event_title,
                'location' => $event_location
            ],
            'response' => [
                'value' => $rsvp->get_answer(),
                'text' => $rsvp->get_answer_text()
            ],
            'attendees_count' => $rsvp->get_attendees_count(),
            'status' => [
                'confirmation' => $rsvp->get_confirm_status(),
                'verification' => $rsvp->get_verification_status()
            ],
            'creation_type' => $rsvp->get_creation_type(),
            'date_created' => $rsvp->get_create_datetime(),
            'primary_email' => $rsvp->get_creator_email(),
        ];
    }

    /**
     * Format RSVP details
     */
    private function format_rsvp_details($rsvp)
    {
        $event_id = $rsvp->get_event_id();
        $event_data = [];
        
        if ($event_id) {
            // Try multiple methods to get event title
            $event_title = '';
            
            // Method 1: Standard WordPress get_the_title
            $event_title = get_the_title($event_id);
            
            // Method 2: If empty, try direct database query with different post types
            if (empty($event_title)) {
                global $wpdb;
                $event_post = $wpdb->get_row($wpdb->prepare(
                    "SELECT post_title FROM {$wpdb->posts} WHERE ID = %d AND post_type IN ('mec-events', 'post', 'page')",
                    $event_id
                ));
                if ($event_post) {
                    $event_title = $event_post->post_title;
                }
            }
            
            // Method 3: Try MEC specific method if available
            if (empty($event_title) && function_exists('mec_get_event_title')) {
                $event_title = mec_get_event_title($event_id);
            }
            
            // Method 4: Try MEC meta data
            if (empty($event_title)) {
                $mec_title = get_post_meta($event_id, 'mec_title', true);
                if (!empty($mec_title)) {
                    $event_title = $mec_title;
                }
            }
            
            // Clean HTML entities from title
            $event_title = $this->clean_html_from_title($event_title);
            
            $event_data = [
                'id' => $event_id,
                'title' => $event_title ?: 'Event Title Not Available',
                'permalink' => get_permalink($event_id)
            ];
            
            $location_terms = get_the_terms($event_id, 'mec_location');
            if ($location_terms && !is_wp_error($location_terms)) {
                $event_data['location'] = [
                    'id' => $location_terms[0]->term_id,
                    'name' => $location_terms[0]->name
                ];
            }
        }

        // Get attendees with proper name formatting
        $attendees = $rsvp->get_attendees();
        $formatted_attendees = [];
        
        if (is_array($attendees)) {
            foreach ($attendees as $attendee_id => $attendee_data) {
                // Get attendee name from database if not available
                if (empty($attendee_data['first_name']) || empty($attendee_data['last_name'])) {
                    global $wpdb;
                    
                    // Try MEC users table first
                    $user_data = $wpdb->get_row($wpdb->prepare(
                        "SELECT first_name, last_name FROM {$wpdb->prefix}mec_users WHERE id = %d",
                        $attendee_id
                    ));
                    
                    // If not found in MEC users, try WordPress users table
                    if (!$user_data) {
                        $user_data = $wpdb->get_row($wpdb->prepare(
                            "SELECT display_name, user_email FROM {$wpdb->users} WHERE ID = %d",
                            $attendee_id
                        ));
                        
                        if ($user_data) {
                            // Try to extract first and last name from display_name
                            $name_parts = explode(' ', $user_data->display_name);
                            $attendee_data['first_name'] = $name_parts[0] ?? '';
                            $attendee_data['last_name'] = isset($name_parts[1]) ? implode(' ', array_slice($name_parts, 1)) : '';
                            $attendee_data['name'] = $user_data->display_name;
                        }
                    } else {
                        $attendee_data['first_name'] = $user_data->first_name ?: '';
                        $attendee_data['last_name'] = $user_data->last_name ?: '';
                        $attendee_data['name'] = trim($user_data->first_name . ' ' . $user_data->last_name) ?: ' ';
                    }
                    
                    // If still no name, try to extract from email
                    if (empty($attendee_data['name']) || $attendee_data['name'] === ' ') {
                        $email = $attendee_data['email'] ?? '';
                        if ($email) {
                            $email_parts = explode('@', $email);
                            $name_from_email = str_replace(['.', '_', '-'], ' ', $email_parts[0]);
                            $attendee_data['name'] = ucwords($name_from_email);
                            $attendee_data['first_name'] = explode(' ', $name_from_email)[0] ?? '';
                            $attendee_data['last_name'] = isset(explode(' ', $name_from_email)[1]) ? implode(' ', array_slice(explode(' ', $name_from_email), 1)) : '';
                        }
                    }
                }
                
                $formatted_attendees[$attendee_id] = $attendee_data;
            }
        } else {
            // If attendees array is empty, try to get from RSVP meta data
            global $wpdb;
            $primary_email = get_post_meta($rsvp->get_id(), 'mec_primary_attendee_email', true);
            if ($primary_email) {
                // Create a virtual attendee from primary email
                $email_parts = explode('@', $primary_email);
                $name_from_email = str_replace(['.', '_', '-'], ' ', $email_parts[0]);
                $formatted_attendees['primary'] = [
                    'post_id' => $rsvp->get_id(),
                    'attendee_id' => 'primary',
                    'first_name' => explode(' ', $name_from_email)[0] ?? '',
                    'last_name' => isset(explode(' ', $name_from_email)[1]) ? implode(' ', array_slice(explode(' ', $name_from_email), 1)) : '',
                    'name' => ucwords($name_from_email),
                    'email' => $primary_email,
                    'count' => '1',
                    'verification' => get_post_meta($rsvp->get_id(), 'mec_verified', true) ?: '0',
                    'confirmation' => get_post_meta($rsvp->get_id(), 'mec_confirmed', true) ?: '0',
                    'reg' => []
                ];
            }
        }

        // Get status with text labels
        $confirmation_status = $rsvp->get_confirm_status();
        $verification_status = $rsvp->get_verification_status();
        
        $status_labels = [
            'confirmation' => [
                '0' => 'Pending',
                '1' => 'Confirmed',
                '-1' => 'Rejected'
            ],
            'verification' => [
                '0' => 'Waiting',
                '1' => 'Verified',
                '-1' => 'Canceled'
            ]
        ];

        return [
            'id' => $rsvp->get_id(),
            'title' => $rsvp->get_title(),
            'event' => $event_data,
            'response' => [
                'value' => $rsvp->get_answer(),
                'text' => $rsvp->get_answer_text()
            ],
            'attendees' => $formatted_attendees,
            'attendees_count' => $rsvp->get_attendees_count(),
            'fixed_fields' => $rsvp->get_fixed_fields(),
            'status' => [
                'confirmation' => $confirmation_status,
                'confirmation_text' => $status_labels['confirmation'][$confirmation_status] ?? 'Unknown',
                'verification' => $verification_status,
                'verification_text' => $status_labels['verification'][$verification_status] ?? 'Unknown'
            ],
            'creation_type' => [
                'value' => $rsvp->get_creation_type(),
                'text' => $rsvp->get_creation_type_text()
            ],
            'date_created' => $rsvp->get_create_datetime(),
            'event_times' => [
                'start' => $rsvp->get_event_times('start'),
                'end' => $rsvp->get_event_times('end'),
                'full' => $rsvp->get_event_times()
            ],
            'primary_email' => $rsvp->get_creator_email(),
            'first_for_all' => $rsvp->get_attendee_first_for_all(),
        ];
    }

    /**
     * Debug RSVP data to understand database structure
     */
    public function debug_rsvp_data(\WP_REST_Request $request)
    {
        try {
            $auth_result = AuthHelper::verify_authentication($request);
            if (is_wp_error($auth_result)) {
                return $auth_result;
            }

            $rsvp_id = (int) $request['rsvp_id'];
            
            // Check if RSVP exists
            $post = get_post($rsvp_id);
            if (!$post || $post->post_type !== 'mec_rsvp') {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'RSVP not found'
                ], 404);
            }

            global $wpdb;
            
            // Get RSVP post data
            $rsvp_post = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->posts} WHERE ID = %d",
                $rsvp_id
            ));
            
            // Get RSVP meta data
            $rsvp_meta = $wpdb->get_results($wpdb->prepare(
                "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d",
                $rsvp_id
            ));
            
            // Get event data
            $event_id = get_post_meta($rsvp_id, 'mec_event_id', true);
            $event_post = null;
            $event_meta = [];
            if ($event_id) {
                $event_post = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->posts} WHERE ID = %d",
                    $event_id
                ));
                
                // Get event meta data
                $event_meta = $wpdb->get_results($wpdb->prepare(
                    "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d",
                    $event_id
                ));
            }
            
            // Get attendees data
            $attendees_meta = $wpdb->get_results($wpdb->prepare(
                "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE 'mec_attendees_%'",
                $rsvp_id
            ));
            
            // Get MEC users data
            $mec_users = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}mec_users LIMIT 5");
            
            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'rsvp_post' => $rsvp_post,
                    'rsvp_meta' => $rsvp_meta,
                    'event_id' => $event_id,
                    'event_post' => $event_post,
                    'event_meta' => $event_meta,
                    'attendees_meta' => $attendees_meta,
                    'mec_users_sample' => $mec_users,
                    'wpdb_prefix' => $wpdb->prefix,
                    'all_post_types' => $wpdb->get_results("SELECT DISTINCT post_type FROM {$wpdb->posts} WHERE post_type LIKE '%mec%' OR post_type LIKE '%event%'")
                ]
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Debug failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update RSVP attendees with full CRUD operations
     */
    private function update_rsvp_attendees($rsvp, $attendees_data)
    {
        try {
            if (!is_array($attendees_data)) {
                return [
                    'success' => false,
                    'errors' => ['attendees' => 'Attendees data must be an array']
                ];
            }

            $rsvp_id = $rsvp->get_id();
            $current_attendees = $rsvp->get_attendees();
            $updated_attendees = [];
            $errors = [];

            // Find the highest existing attendee ID (same logic as MetaBoxDetail.php)
            $max_attendee_id = 0;
            if (!empty($current_attendees) && is_array($current_attendees)) {
                foreach ($current_attendees as $key => $attendee) {
                    if ($key === 'attachments') continue;
                    if (isset($attendee[0]['MEC_TYPE_OF_DATA'])) continue;
                    $max_attendee_id = max($max_attendee_id, (int)$key);
                }
            }

            // Process each attendee
            foreach ($attendees_data as $attendee_id => $attendee_data) {
                if (!is_array($attendee_data)) {
                    $errors[] = "Attendee {$attendee_id} data must be an array";
                    continue;
                }

                // Validate required fields
                $validation_result = $this->validate_attendee_data($attendee_data);
                if (!$validation_result['valid']) {
                    $errors[] = "Attendee {$attendee_id}: " . implode(', ', $validation_result['errors']);
                    continue;
                }

                // Sanitize attendee data
                $sanitized_attendee = $this->sanitize_attendee_data($attendee_data);
                
                // Generate full name if not provided
                if (empty($sanitized_attendee['name']) && 
                    (!empty($sanitized_attendee['first_name']) || !empty($sanitized_attendee['last_name']))) {
                    $sanitized_attendee['name'] = trim(
                        ($sanitized_attendee['first_name'] ?? '') . ' ' . 
                        ($sanitized_attendee['last_name'] ?? '')
                    );
                }

                // If attendee_id is 'new' or empty, generate a new ID
                if ($attendee_id === 'new' || empty($attendee_id)) {
                    $max_attendee_id++;
                    $attendee_id = (string)$max_attendee_id;
                }

                $updated_attendees[$attendee_id] = $sanitized_attendee;
            }

            if (!empty($errors)) {
                return [
                    'success' => false,
                    'errors' => $errors
                ];
            }

            // Update attendees in database using MEC Attendees class
            $result = $this->save_attendees_to_database($rsvp_id, $updated_attendees);
            
            if (!$result) {
                return [
                    'success' => false,
                    'errors' => ['attendees' => 'Failed to save attendees to database']
                ];
            }

            return [
                'success' => true,
                'data' => $updated_attendees
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'errors' => ['attendees' => 'Failed to update attendees: ' . $e->getMessage()]
            ];
        }
    }

    /**
     * Remove specific attendees by their IDs
     */
    private function remove_specific_attendees($rsvp, $attendee_ids_to_remove)
    {
        try {
            if (!is_array($attendee_ids_to_remove)) {
                return [
                    'success' => false,
                    'errors' => ['remove_attendees' => 'Remove attendees must be an array of attendee IDs']
                ];
            }

            $rsvp_id = $rsvp->get_id();
            $event_id = $rsvp->get_event_id();
            $occurrence = $rsvp->get_event_times('start');
            
            if (!$event_id || !$occurrence) {
                return [
                    'success' => false,
                    'errors' => ['remove_attendees' => 'Invalid RSVP data - missing event_id or occurrence']
                ];
            }

            $current_attendees = $rsvp->get_attendees();
            $remaining_attendees = [];
            $removed_attendees = [];

            // Filter out attendees that should be removed
            foreach ($current_attendees as $attendee_id => $attendee_data) {
                if (in_array($attendee_id, $attendee_ids_to_remove)) {
                    $removed_attendees[] = $attendee_id;
                } else {
                    $remaining_attendees[$attendee_id] = $attendee_data;
                }
            }

            // Convert remaining attendees to the format expected by MEC Attendees class
            $formatted_attendees = [];
            foreach ($remaining_attendees as $attendee_id => $attendee_data) {
                $formatted_attendees[] = [
                    'post_id' => $rsvp_id,
                    'event_id' => $event_id,
                    'occurrence' => $occurrence,
                    'email' => $attendee_data['email'],
                    'first_name' => $attendee_data['first_name'],
                    'last_name' => $attendee_data['last_name'],
                    'count' => $attendee_data['count'] ?? '1',
                    'verification' => $attendee_data['verification'] ?? '0',
                    'confirmation' => $attendee_data['confirmation'] ?? '0',
                    'data' => $attendee_data['reg'] ?? []
                ];
            }

            // Use MEC Attendees class to update attendees
            if (class_exists('\MEC\Attendees\Attendees')) {
                // First remove all attendees for this RSVP
                $this->remove_all_attendees_for_rsvp($rsvp_id, $event_id, $occurrence);
                
                // Then add back only the remaining attendees
                if (!empty($formatted_attendees)) {
                    $result = \MEC\Attendees\Attendees::getInstance()->add_or_update(
                        $rsvp_id,
                        $event_id,
                        $occurrence,
                        $formatted_attendees
                    );
                    
                    if (!$result) {
                        return [
                            'success' => false,
                            'errors' => ['remove_attendees' => 'Failed to update remaining attendees']
                        ];
                    }
                }
            } else {
                return [
                    'success' => false,
                    'errors' => ['remove_attendees' => 'MEC Attendees class not available']
                ];
            }

            return [
                'success' => true,
                'data' => [
                    'removed_ids' => $removed_attendees,
                    'remaining_count' => count($remaining_attendees)
                ]
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'errors' => ['remove_attendees' => 'Failed to remove attendees: ' . $e->getMessage()]
            ];
        }
    }

    /**
     * Remove all attendees for a specific RSVP
     */
    private function remove_all_attendees_for_rsvp($rsvp_id, $event_id, $occurrence)
    {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mec_attendees';
        
        $result = $wpdb->delete(
            $table_name,
            [
                'post_id' => $rsvp_id,
                'event_id' => $event_id,
                'occurrence' => $occurrence
            ],
            ['%d', '%d', '%d']
        );
        
        return $result !== false;
    }

    /**
     * Update RSVP fixed fields
     */
    private function update_rsvp_fixed_fields($rsvp, $fixed_fields_data)
    {
        try {
            if (!is_array($fixed_fields_data)) {
                return [
                    'success' => false,
                    'errors' => ['fixed_fields' => 'Fixed fields data must be an array']
                ];
            }

            $rsvp_id = $rsvp->get_id();
            $sanitized_fields = $this->sanitize_fixed_fields_data($fixed_fields_data);

            // Update fixed fields in database
            update_post_meta($rsvp_id, 'mec_fixed', $sanitized_fields);

            return [
                'success' => true,
                'data' => $sanitized_fields
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'errors' => ['fixed_fields' => 'Failed to update fixed fields: ' . $e->getMessage()]
            ];
        }
    }

    /**
     * Update RSVP answer
     */
    private function update_rsvp_answer($rsvp, $answer)
    {
        try {
            $valid_answers = ['yes', 'no', 'maybe'];
            if (!in_array($answer, $valid_answers)) {
                return [
                    'success' => false,
                    'errors' => ['answer' => 'Answer must be one of: ' . implode(', ', $valid_answers)]
                ];
            }

            $rsvp_id = $rsvp->get_id();
            update_post_meta($rsvp_id, 'mec_answer', sanitize_text_field($answer));

            return [
                'success' => true,
                'data' => $answer
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'errors' => ['answer' => 'Failed to update answer: ' . $e->getMessage()]
            ];
        }
    }

    /**
     * Update RSVP event date
     */
    private function update_rsvp_event_date($rsvp, $event_date)
    {
        try {
            if (empty($event_date)) {
                return [
                    'success' => false,
                    'errors' => ['event_date' => 'Event date is required']
                ];
            }

            $rsvp_id = $rsvp->get_id();
            update_post_meta($rsvp_id, 'mec_event_date', sanitize_text_field($event_date));

            return [
                'success' => true,
                'data' => $event_date
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'errors' => ['event_date' => 'Failed to update event date: ' . $e->getMessage()]
            ];
        }
    }

    /**
     * Update RSVP title
     */
    private function update_rsvp_title($rsvp, $title = null)
    {
        try {
            $rsvp_id = $rsvp->get_id();
            
            // If title is provided, use it; otherwise generate from attendees
            if ($title !== null) {
                $new_title = sanitize_text_field($title);
            } else {
                $new_title = $this->generate_rsvp_title_from_attendees($rsvp);
            }

            if (empty($new_title)) {
                return [
                    'success' => false,
                    'errors' => ['title' => 'Title cannot be empty']
                ];
            }

            // Update post title
            wp_update_post([
                'ID' => $rsvp_id,
                'post_title' => $new_title
            ]);

            return [
                'success' => true,
                'data' => $new_title
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'errors' => ['title' => 'Failed to update title: ' . $e->getMessage()]
            ];
        }
    }

    /**
     * Validate attendee data
     */
    private function validate_attendee_data($attendee_data)
    {
        $errors = [];

        // Check required fields
        if (empty($attendee_data['email'])) {
            $errors[] = 'Email is required';
        } elseif (!is_email($attendee_data['email'])) {
            $errors[] = 'Email must be valid';
        }

        if (empty($attendee_data['first_name']) && empty($attendee_data['last_name']) && empty($attendee_data['name'])) {
            $errors[] = 'At least one name field (first_name, last_name, or name) is required';
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * Sanitize single attendee data
     */
    private function sanitize_attendee_data($attendee_data)
    {
        return [
            'first_name' => sanitize_text_field($attendee_data['first_name'] ?? ''),
            'last_name' => sanitize_text_field($attendee_data['last_name'] ?? ''),
            'name' => sanitize_text_field($attendee_data['name'] ?? ''),
            'email' => sanitize_email($attendee_data['email'] ?? ''),
            'mec_email' => sanitize_email($attendee_data['mec_email'] ?? $attendee_data['email'] ?? ''),
            'count' => sanitize_text_field($attendee_data['count'] ?? '1'),
            'verification' => sanitize_text_field($attendee_data['verification'] ?? '0'),
            'confirmation' => sanitize_text_field($attendee_data['confirmation'] ?? '0'),
            'reg' => is_array($attendee_data['reg'] ?? null) ? $attendee_data['reg'] : []
        ];
    }

    /**
     * Save attendees to database
     */
    private function save_attendees_to_database($rsvp_id, $attendees)
    {
        try {
            // Get RSVP data to get event_id and occurrence
            $rsvp = new \MEC_RSVP\RSVP\RSVP($rsvp_id);
            $event_id = $rsvp->get_event_id();
            $occurrence = $rsvp->get_event_times('start');
            
            // If occurrence is empty, try to get from event_date meta
            if (empty($occurrence)) {
                $event_date = get_post_meta($rsvp_id, 'mec_event_date', true);
                if (!empty($event_date)) {
                    $occurrence = $event_date;
                    error_log("RSVP Debug - Using event_date as occurrence: $occurrence");
                }
            }
            
            // Debug logging
            error_log("RSVP Debug - rsvp_id: $rsvp_id, event_id: $event_id, occurrence: $occurrence");
            error_log("RSVP Debug - attendees: " . print_r($attendees, true));
            
            if (!$event_id || !$occurrence) {
                error_log("RSVP Debug - Missing event_id or occurrence");
                return false;
            }

            // Convert attendees array to the format expected by MEC Attendees class
            $formatted_attendees = [];
            foreach ($attendees as $attendee_id => $attendee_data) {
                $formatted_attendees[] = [
                    'post_id' => $rsvp_id,
                    'event_id' => $event_id,
                    'occurrence' => $occurrence,
                    'email' => $attendee_data['email'],
                    'first_name' => $attendee_data['first_name'],
                    'last_name' => $attendee_data['last_name'],
                    'count' => isset($attendee_data['count']) ? (int)$attendee_data['count'] : 1,
                    'verification' => isset($attendee_data['verification']) ? (int)$attendee_data['verification'] : 0,
                    'confirmation' => isset($attendee_data['confirmation']) ? (int)$attendee_data['confirmation'] : 0,
                    'data' => $attendee_data['reg'] ?? []
                ];
            }

            error_log("RSVP Debug - formatted_attendees: " . print_r($formatted_attendees, true));

            // Use MEC Attendees class to update attendees
            if (class_exists('\MEC\Attendees\Attendees')) {
                // Try add_or_update first
                $result = \MEC\Attendees\Attendees::getInstance()->add_or_update(
                    $rsvp_id,
                    $event_id,
                    $occurrence,
                    $formatted_attendees
                );
                
                error_log("RSVP Debug - add_or_update result: " . ($result ? 'true' : 'false'));
                
                // If add_or_update fails, try direct database insert
                if (!$result) {
                    error_log("RSVP Debug - add_or_update failed, trying direct database insert");
                    
                    global $wpdb;
                    $table_name = $wpdb->prefix . 'mec_attendees';
                    
                    foreach ($formatted_attendees as $attendee) {
                        $insert_data = [
                            'post_id' => (int)$attendee['post_id'],
                            'event_id' => (int)$attendee['event_id'],
                            'occurrence' => (int)$attendee['occurrence'],
                            'email' => $attendee['email'],
                            'first_name' => $attendee['first_name'],
                            'last_name' => $attendee['last_name'],
                            'data' => serialize($attendee['data']),
                            'count' => (int)$attendee['count'],
                            'verification' => (int)$attendee['verification'],
                            'confirmation' => (int)$attendee['confirmation'],
                        ];
                        
                        $insert_result = $wpdb->insert($table_name, $insert_data, [
                            '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%d', '%d'
                        ]);
                        
                        error_log("RSVP Debug - direct insert result: " . ($insert_result ? 'true' : 'false'));
                        if (!$insert_result) {
                            error_log("RSVP Debug - insert error: " . $wpdb->last_error);
                        }
                    }
                    
                    // Clear cache after direct insert
                    \MEC\Attendees\Attendees::getInstance()->clear_cache($rsvp_id, $event_id, $occurrence);
                    $result = true;
                }
                
                return $result;
            } else {
                error_log("RSVP Debug - MEC Attendees class not found");
                return false;
            }

        } catch (\Exception $e) {
            error_log("RSVP Debug - Exception: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Generate RSVP title from attendees
     */
    private function generate_rsvp_title_from_attendees($rsvp)
    {
        $attendees = $rsvp->get_attendees();
        
        if (empty($attendees) || !is_array($attendees)) {
            return $rsvp->get_title(); // Return current title if no attendees
        }

        $names = [];
        $emails = [];

        foreach ($attendees as $attendee) {
            if (isset($attendee['name']) && !empty($attendee['name'])) {
                $names[] = $attendee['name'];
            } elseif ((isset($attendee['first_name']) && !empty($attendee['first_name'])) || 
                     (isset($attendee['last_name']) && !empty($attendee['last_name']))) {
                $names[] = trim(($attendee['first_name'] ?? '') . ' ' . ($attendee['last_name'] ?? ''));
            }

            if (isset($attendee['email']) && !empty($attendee['email'])) {
                $emails[] = $attendee['email'];
            }
        }

        // Create title from names and emails
        $title_parts = [];
        if (!empty($names)) {
            $title_parts[] = implode(', ', array_slice($names, 0, 3)); // Max 3 names
            if (count($names) > 3) {
                $title_parts[0] .= ' +' . (count($names) - 3) . ' more';
            }
        }
        
        if (!empty($emails)) {
            $title_parts[] = $emails[0]; // Primary email
        }

        return implode(' ', $title_parts);
    }

    /**
     * Sanitize attendees data
     */
    private function sanitize_attendees_data($attendees)
    {
        if (!is_array($attendees)) {
            return [];
        }

        $sanitized = [];
        foreach ($attendees as $key => $attendee) {
            if (!is_array($attendee)) {
                continue;
            }

            $sanitized[$key] = [
                'first_name' => sanitize_text_field($attendee['first_name'] ?? ''),
                'last_name' => sanitize_text_field($attendee['last_name'] ?? ''),
                'email' => sanitize_email($attendee['email'] ?? ''),
                'mec_email' => sanitize_email($attendee['mec_email'] ?? $attendee['email'] ?? ''),
                'reg' => is_array($attendee['reg'] ?? null) ? $attendee['reg'] : []
            ];
        }

        return $sanitized;
    }

    /**
     * Sanitize fixed fields data
     */
    private function sanitize_fixed_fields_data($fixed_fields)
    {
        if (!is_array($fixed_fields)) {
            return [];
        }

        $sanitized = [];
        foreach ($fixed_fields as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = array_map('sanitize_text_field', $value);
            } else {
                $sanitized[$key] = sanitize_text_field($value);
            }
        }

        return $sanitized;
    }

    /**
     * Get list query parameters schema
     */
    private function get_list_query_params()
    {
        return [
            'page' => [
                'description' => 'Page number for pagination',
                'type' => 'integer',
                'default' => 1,
                'minimum' => 1,
            ],
            'per_page' => [
                'description' => 'Number of items per page',
                'type' => 'integer',
                'default' => 20,
                'minimum' => 1,
                'maximum' => 100,
            ],
            'search' => [
                'description' => 'Search query',
                'type' => 'string',
            ],
            'orderby' => [
                'description' => 'Sort field',
                'type' => 'string',
                'enum' => ['date', 'ID', 'title', 'event_id'],
                'default' => 'date',
            ],
            'order' => [
                'description' => 'Sort order',
                'type' => 'string',
                'enum' => ['ASC', 'DESC'],
                'default' => 'DESC',
            ],
            'event_id' => [
                'description' => 'Filter by event ID',
                'type' => 'integer',
            ],
            'response' => [
                'description' => 'Filter by response type',
                'type' => 'string',
                'enum' => ['yes', 'no', 'maybe'],
            ],
            'confirmation' => [
                'description' => 'Filter by confirmation status',
                'type' => 'integer',
                'enum' => [0, 1],
            ],
            'verification' => [
                'description' => 'Filter by verification status',
                'type' => 'integer',
                'enum' => [0, 1],
            ],
            'location' => [
                'description' => 'Filter by location ID',
                'type' => 'integer',
            ],
            'creation_type' => [
                'description' => 'Filter by creation type',
                'type' => 'string',
                'enum' => ['invite', 'normal'],
            ],
            'date_from' => [
                'description' => 'Filter from date (Y-m-d format)',
                'type' => 'string',
                'format' => 'date',
            ],
            'date_to' => [
                'description' => 'Filter to date (Y-m-d format)',
                'type' => 'string',
                'format' => 'date',
            ],
        ];
    }

    /**
     * Get status update schema
     */
    private function get_status_update_schema()
    {
        return [
            'confirmation' => [
                'description' => 'Confirmation status',
                'type' => 'integer',
                'sanitize_callback' => function($value) {
                    // Convert to integer
                    return (int) $value;
                },
                'validate_callback' => function($value) {
                    // Accept integer values
                    return in_array((int) $value, [1, 0, -1], true);
                },
            ],
            'verification' => [
                'description' => 'Verification status',
                'type' => 'integer',
                'sanitize_callback' => function($value) {
                    // Convert to integer
                    return (int) $value;
                },
                'validate_callback' => function($value) {
                    // Accept integer values
                    return in_array((int) $value, [1, 0, -1], true);
                },
            ],
            'resend_verification' => [
                'description' => 'Resend verification email',
                'type' => 'integer',
                'default' => 0,
                'sanitize_callback' => function($value) {
                    return (int) $value;
                },
                'validate_callback' => function($value) {
                    return in_array((int) $value, [0, 1], true);
                },
            ],
            'resend_confirmation' => [
                'description' => 'Resend confirmation email',
                'type' => 'integer',
                'default' => 0,
                'sanitize_callback' => function($value) {
                    return (int) $value;
                },
                'validate_callback' => function($value) {
                    return in_array((int) $value, [0, 1], true);
                },
            ],
        ];
    }

    /**
     * Get RSVP update schema
     */
    private function get_rsvp_update_schema()
    {
        return [
            'attendees' => [
                'description' => 'Attendees data with full CRUD operations (add, edit, remove)',
                'type' => 'object',
                'additionalProperties' => [
                    'type' => 'object',
                    'properties' => [
                        'post_id' => ['type' => 'string'],
                        'attendee_id' => ['type' => 'string'],
                        'first_name' => ['type' => 'string'],
                        'last_name' => ['type' => 'string'],
                        'name' => ['type' => 'string'],
                        'email' => ['type' => 'string', 'format' => 'email'],
                        'mec_email' => ['type' => 'string', 'format' => 'email'],
                        'count' => ['type' => 'string'],
                        'verification' => ['type' => 'string'],
                        'confirmation' => ['type' => 'string'],
                        'reg' => ['type' => 'object'],
                    ],
                    'required' => ['email'],
                ],
            ],
            'fixed_fields' => [
                'description' => 'Fixed fields data',
                'type' => 'object',
            ],
            'answer' => [
                'description' => 'RSVP answer',
                'type' => 'string',
                'enum' => ['yes', 'no', 'maybe'],
            ],
            'event_date' => [
                'description' => 'Event date timestamp',
                'type' => 'string',
            ],
            'title' => [
                'description' => 'RSVP title (optional, will be auto-generated from attendees if not provided)',
                'type' => 'string',
            ],
            'remove_attendees' => [
                'description' => 'Array of attendee IDs to remove from RSVP',
                'type' => 'array',
                'items' => [
                    'type' => 'string',
                ],
            ],
        ];
    }

    /**
     * Clean HTML entities and tags from event title
     *
     * @param string $title The title to clean.
     * @return string Clean title without HTML tags and entities.
     */
    private function clean_html_from_title($title)
    {
        if (empty($title)) {
            return $title;
        }

        // First decode HTML entities
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Remove HTML tags
        $title = strip_tags($title);

        // Clean up any remaining HTML entities
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Trim whitespace
        $title = trim($title);

        return $title;
    }
} 