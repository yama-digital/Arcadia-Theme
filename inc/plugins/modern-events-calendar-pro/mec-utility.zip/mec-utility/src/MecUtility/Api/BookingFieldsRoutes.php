<?php

/**
 * Booking Fields API Routes
 *
 * @package    MecUtility
 * @subpackage MecUtility/API
 * @since      1.0.0
 */

namespace MecUtility\Api;

use MecUtility\Auth\AuthHelper;

/**
 * BookingFieldsRoutes class for managing booking form fields via REST API
 */
class BookingFieldsRoutes
{
    /**
     * Register the API routes
     */
    public function register_routes()
    {
        // Per Attendee Fields routes
        register_rest_route('mec-utility/v1', '/booking-fields/attendee', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_attendee_fields'],
                'permission_callback' => AuthHelper::permission_callback('read_booking_fields'),
            ],
            [
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'create_attendee_field'],
                'permission_callback' => AuthHelper::permission_callback('create_booking_fields'),
                'args'                => $this->get_field_schema(),
            ],
        ]);

        register_rest_route('mec-utility/v1', '/booking-fields/attendee/(?P<field_id>\d+)', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_attendee_field'],
                'permission_callback' => AuthHelper::permission_callback('read_booking_fields'),
            ],
            [
                'methods'             => \WP_REST_Server::EDITABLE,
                'callback'            => [$this, 'update_attendee_field'],
                'permission_callback' => AuthHelper::permission_callback('update_booking_fields'),
                'args'                => $this->get_field_schema(),
            ],
            [
                'methods'             => \WP_REST_Server::DELETABLE,
                'callback'            => [$this, 'delete_attendee_field'],
                'permission_callback' => AuthHelper::permission_callback('delete_booking_fields'),
            ],
        ]);

        // Fixed Fields routes
        register_rest_route('mec-utility/v1', '/booking-fields/fixed', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_fixed_fields'],
                'permission_callback' => AuthHelper::permission_callback('read_booking_fields'),
            ],
            [
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'create_fixed_field'],
                'permission_callback' => AuthHelper::permission_callback('create_booking_fields'),
                'args'                => $this->get_field_schema(),
            ],
        ]);

        register_rest_route('mec-utility/v1', '/booking-fields/fixed/(?P<field_id>\d+)', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_fixed_field'],
                'permission_callback' => AuthHelper::permission_callback('read_booking_fields'),
            ],
            [
                'methods'             => \WP_REST_Server::EDITABLE,
                'callback'            => [$this, 'update_fixed_field'],
                'permission_callback' => AuthHelper::permission_callback('update_booking_fields'),
                'args'                => $this->get_field_schema(),
            ],
            [
                'methods'             => \WP_REST_Server::DELETABLE,
                'callback'            => [$this, 'delete_fixed_field'],
                'permission_callback' => AuthHelper::permission_callback('delete_booking_fields'),
            ],
        ]);

        // Field types and schema routes
        register_rest_route('mec-utility/v1', '/booking-fields/types', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_field_types'],
            'permission_callback' => AuthHelper::permission_callback('read_booking_fields'),
        ]);

        register_rest_route('mec-utility/v1', '/booking-fields/schema', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_fields_schema'],
            'permission_callback' => AuthHelper::permission_callback('read_booking_fields'),
        ]);

        // Bulk operations
        register_rest_route('mec-utility/v1', '/booking-fields/attendee/bulk', [
            'methods'             => \WP_REST_Server::EDITABLE,
            'callback'            => [$this, 'bulk_update_attendee_fields'],
            'permission_callback' => AuthHelper::permission_callback('update_booking_fields'),
        ]);

        register_rest_route('mec-utility/v1', '/booking-fields/fixed/bulk', [
            'methods'             => \WP_REST_Server::EDITABLE,
            'callback'            => [$this, 'bulk_update_fixed_fields'],
            'permission_callback' => AuthHelper::permission_callback('update_booking_fields'),
        ]);
    }

    /**
     * Get all attendee fields
     */
    public function get_attendee_fields(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $mec_main = \MEC::getInstance('app.libraries.main');
            $reg_fields = $mec_main->get_reg_fields();

            $formatted_fields = [];
            foreach ($reg_fields as $field_id => $field_data) {
                if (!is_numeric($field_id)) continue;
                
                $formatted_fields[] = $this->format_field_response($field_id, $field_data, 'attendee');
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'fields' => $formatted_fields,
                    'total_count' => count($formatted_fields),
                    'field_types' => $this->get_available_field_types(),
                ],
                'message' => 'Attendee fields retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve attendee fields: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get single attendee field
     */
    public function get_attendee_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_id = (int) $request['field_id'];
            $mec_main = \MEC::getInstance('app.libraries.main');
            $reg_fields = $mec_main->get_reg_fields();

            if (!isset($reg_fields[$field_id])) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Attendee field not found'
                ], 404);
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => $this->format_field_response($field_id, $reg_fields[$field_id], 'attendee'),
                'message' => 'Attendee field retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve attendee field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Create new attendee field
     */
    public function create_attendee_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'create_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_data = $this->prepare_field_data($request);
            $validation = $this->validate_field_data($field_data);
            
            if (\is_wp_error($validation)) {
                return $validation;
            }

            $mec_main = \MEC::getInstance('app.libraries.main');
            $reg_fields = $mec_main->get_reg_fields();

            // Get next field ID
            $field_id = $this->get_next_field_id($reg_fields);

            // Add new field
            $reg_fields[$field_id] = $field_data;

            // Save to options
            $options = $mec_main->get_options();
            $options['reg_fields'] = $reg_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => $this->format_field_response($field_id, $field_data, 'attendee'),
                'message' => 'Attendee field created successfully'
            ], 201);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to create attendee field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update attendee field
     */
    public function update_attendee_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'update_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_id = (int) $request['field_id'];
            $mec_main = \MEC::getInstance('app.libraries.main');
            $reg_fields = $mec_main->get_reg_fields();

            if (!isset($reg_fields[$field_id])) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Attendee field not found'
                ], 404);
            }

            $field_data = $this->prepare_field_data($request, $reg_fields[$field_id]);
            $validation = $this->validate_field_data($field_data);
            
            if (\is_wp_error($validation)) {
                return $validation;
            }

            // Update field
            $reg_fields[$field_id] = $field_data;

            // Save to options
            $options = $mec_main->get_options();
            $options['reg_fields'] = $reg_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => $this->format_field_response($field_id, $field_data, 'attendee'),
                'message' => 'Attendee field updated successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to update attendee field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete attendee field
     */
    public function delete_attendee_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'delete_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_id = (int) $request['field_id'];
            $mec_main = \MEC::getInstance('app.libraries.main');
            $reg_fields = $mec_main->get_reg_fields();

            if (!isset($reg_fields[$field_id])) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Attendee field not found'
                ], 404);
            }

            // Check if field is protected (name, email)
            $field_type = $reg_fields[$field_id]['type'] ?? '';
            if (in_array($field_type, ['name', 'mec_email'])) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Cannot delete protected field: ' . $field_type
                ], 400);
            }

            $deleted_field = $reg_fields[$field_id];
            unset($reg_fields[$field_id]);

            // Save to options
            $options = $mec_main->get_options();
            $options['reg_fields'] = $reg_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'deleted_field' => $this->format_field_response($field_id, $deleted_field, 'attendee')
                ],
                'message' => 'Attendee field deleted successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to delete attendee field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get all fixed fields
     */
    public function get_fixed_fields(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $mec_main = \MEC::getInstance('app.libraries.main');
            $bfixed_fields = $mec_main->get_bfixed_fields();

            $formatted_fields = [];
            foreach ($bfixed_fields as $field_id => $field_data) {
                if (!is_numeric($field_id)) continue;
                
                $formatted_fields[] = $this->format_field_response($field_id, $field_data, 'fixed');
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'fields' => $formatted_fields,
                    'total_count' => count($formatted_fields),
                    'field_types' => $this->get_available_field_types(),
                ],
                'message' => 'Fixed fields retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve fixed fields: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get single fixed field
     */
    public function get_fixed_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_id = (int) $request['field_id'];
            $mec_main = \MEC::getInstance('app.libraries.main');
            $bfixed_fields = $mec_main->get_bfixed_fields();

            if (!isset($bfixed_fields[$field_id])) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Fixed field not found'
                ], 404);
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => $this->format_field_response($field_id, $bfixed_fields[$field_id], 'fixed'),
                'message' => 'Fixed field retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve fixed field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Create new fixed field
     */
    public function create_fixed_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'create_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_data = $this->prepare_field_data($request);
            $validation = $this->validate_field_data($field_data);
            
            if (\is_wp_error($validation)) {
                return $validation;
            }

            $mec_main = \MEC::getInstance('app.libraries.main');
            $bfixed_fields = $mec_main->get_bfixed_fields();

            // Get next field ID
            $field_id = $this->get_next_field_id($bfixed_fields);

            // Add new field
            $bfixed_fields[$field_id] = $field_data;

            // Save to options
            $options = $mec_main->get_options();
            $options['bfixed_fields'] = $bfixed_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => $this->format_field_response($field_id, $field_data, 'fixed'),
                'message' => 'Fixed field created successfully'
            ], 201);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to create fixed field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update fixed field
     */
    public function update_fixed_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'update_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_id = (int) $request['field_id'];
            $mec_main = \MEC::getInstance('app.libraries.main');
            $bfixed_fields = $mec_main->get_bfixed_fields();

            if (!isset($bfixed_fields[$field_id])) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Fixed field not found'
                ], 404);
            }

            $field_data = $this->prepare_field_data($request, $bfixed_fields[$field_id]);
            $validation = $this->validate_field_data($field_data);
            
            if (\is_wp_error($validation)) {
                return $validation;
            }

            // Update field
            $bfixed_fields[$field_id] = $field_data;

            // Save to options
            $options = $mec_main->get_options();
            $options['bfixed_fields'] = $bfixed_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => $this->format_field_response($field_id, $field_data, 'fixed'),
                'message' => 'Fixed field updated successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to update fixed field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete fixed field
     */
    public function delete_fixed_field(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'delete_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $field_id = (int) $request['field_id'];
            $mec_main = \MEC::getInstance('app.libraries.main');
            $bfixed_fields = $mec_main->get_bfixed_fields();

            if (!isset($bfixed_fields[$field_id])) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Fixed field not found'
                ], 404);
            }

            $deleted_field = $bfixed_fields[$field_id];
            unset($bfixed_fields[$field_id]);

            // Save to options
            $options = $mec_main->get_options();
            $options['bfixed_fields'] = $bfixed_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'deleted_field' => $this->format_field_response($field_id, $deleted_field, 'fixed')
                ],
                'message' => 'Fixed field deleted successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to delete fixed field: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get available field types
     */
    public function get_field_types(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'field_types' => $this->get_available_field_types(),
                    'field_schemas' => $this->get_field_type_schemas(),
                ],
                'message' => 'Field types retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve field types: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get fields schema
     */
    public function get_fields_schema(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'read_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'field_schema' => $this->get_field_schema(),
                    'field_types' => $this->get_available_field_types(),
                    'field_type_schemas' => $this->get_field_type_schemas(),
                ],
                'message' => 'Fields schema retrieved successfully'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to retrieve fields schema: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Bulk update attendee fields
     */
    public function bulk_update_attendee_fields(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'update_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $fields_data = $request->get_param('fields');
            if (!is_array($fields_data)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Fields data must be an array'
                ], 400);
            }

            $mec_main = \MEC::getInstance('app.libraries.main');
            $reg_fields = $mec_main->get_reg_fields();

            $updated_fields = [];
            $errors = [];

            foreach ($fields_data as $field_id => $field_data) {
                if (!is_numeric($field_id) || !isset($reg_fields[$field_id])) {
                    $errors[] = "Field ID {$field_id} not found";
                    continue;
                }

                $prepared_data = $this->prepare_field_data_from_array($field_data, $reg_fields[$field_id]);
                $validation = $this->validate_field_data($prepared_data);
                
                if (\is_wp_error($validation)) {
                    $errors[] = "Field ID {$field_id}: " . $validation->get_error_message();
                    continue;
                }

                $reg_fields[$field_id] = $prepared_data;
                $updated_fields[] = $this->format_field_response($field_id, $prepared_data, 'attendee');
            }

            // Save to options
            $options = $mec_main->get_options();
            $options['reg_fields'] = $reg_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'updated_fields' => $updated_fields,
                    'updated_count' => count($updated_fields),
                    'errors' => $errors,
                ],
                'message' => 'Bulk update completed'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to bulk update attendee fields: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Bulk update fixed fields
     */
    public function bulk_update_fixed_fields(\WP_REST_Request $request)
    {
        try {
            $user_data = AuthHelper::verify_with_permission($request, 'update_booking_fields');
            if (\is_wp_error($user_data)) {
                return $user_data;
            }

            $fields_data = $request->get_param('fields');
            if (!is_array($fields_data)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'Fields data must be an array'
                ], 400);
            }

            $mec_main = \MEC::getInstance('app.libraries.main');
            $bfixed_fields = $mec_main->get_bfixed_fields();

            $updated_fields = [];
            $errors = [];

            foreach ($fields_data as $field_id => $field_data) {
                if (!is_numeric($field_id) || !isset($bfixed_fields[$field_id])) {
                    $errors[] = "Field ID {$field_id} not found";
                    continue;
                }

                $prepared_data = $this->prepare_field_data_from_array($field_data, $bfixed_fields[$field_id]);
                $validation = $this->validate_field_data($prepared_data);
                
                if (\is_wp_error($validation)) {
                    $errors[] = "Field ID {$field_id}: " . $validation->get_error_message();
                    continue;
                }

                $bfixed_fields[$field_id] = $prepared_data;
                $updated_fields[] = $this->format_field_response($field_id, $prepared_data, 'fixed');
            }

            // Save to options
            $options = $mec_main->get_options();
            $options['bfixed_fields'] = $bfixed_fields;
            update_option('mec_options', $options);

            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'updated_fields' => $updated_fields,
                    'updated_count' => count($updated_fields),
                    'errors' => $errors,
                ],
                'message' => 'Bulk update completed'
            ], 200);

        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Failed to bulk update fixed fields: ' . $e->getMessage()
            ], 500);
        }
    }

    // Helper methods

    /**
     * Format field response
     */
    private function format_field_response($field_id, $field_data, $type)
    {
        return [
            'id' => (int) $field_id,
            'type' => $field_data['type'] ?? '',
            'label' => $field_data['label'] ?? '',
            'mandatory' => $field_data['mandatory'] ?? '0',
            'options' => $field_data['options'] ?? [],
            'placeholder' => $field_data['placeholder'] ?? '',
            'description' => $field_data['description'] ?? '',
            'default_value' => $field_data['default_value'] ?? '',
            'max_length' => isset($field_data['max_length']) ? (int) $field_data['max_length'] : null,
            'validation_rules' => $field_data['validation_rules'] ?? [],
            'field_category' => $type, // attendee or fixed
            'created_at' => $field_data['created_at'] ?? null,
            'updated_at' => current_time('mysql'),
        ];
    }

    /**
     * Prepare field data from request
     */
    private function prepare_field_data(\WP_REST_Request $request, $existing_data = [])
    {
        $field_data = array_merge($existing_data, [
            'type' => sanitize_text_field($request->get_param('type') ?? $existing_data['type'] ?? ''),
            'label' => sanitize_text_field($request->get_param('label') ?? $existing_data['label'] ?? ''),
            'mandatory' => sanitize_text_field($request->get_param('mandatory') ?? $existing_data['mandatory'] ?? '0'),
            'placeholder' => sanitize_text_field($request->get_param('placeholder') ?? $existing_data['placeholder'] ?? ''),
            'description' => sanitize_textarea_field($request->get_param('description') ?? $existing_data['description'] ?? ''),
            'default_value' => sanitize_text_field($request->get_param('default_value') ?? $existing_data['default_value'] ?? ''),
        ]);

        // Handle options for select, checkbox, radio fields
        $options = $request->get_param('options');
        if ($options !== null) {
            $field_data['options'] = is_array($options) ? array_map('sanitize_text_field', $options) : [];
        }

        // Handle max_length for text fields
        $max_length = $request->get_param('max_length');
        if ($max_length !== null) {
            $field_data['max_length'] = (int) $max_length;
        }

        // Handle validation rules
        $validation_rules = $request->get_param('validation_rules');
        if ($validation_rules !== null) {
            $field_data['validation_rules'] = is_array($validation_rules) ? $validation_rules : [];
        }

        // Set timestamps
        if (empty($existing_data)) {
            $field_data['created_at'] = current_time('mysql');
        }
        $field_data['updated_at'] = current_time('mysql');

        return $field_data;
    }

    /**
     * Prepare field data from array (for bulk operations)
     */
    private function prepare_field_data_from_array($data, $existing_data = [])
    {
        $field_data = array_merge($existing_data, [
            'type' => sanitize_text_field($data['type'] ?? $existing_data['type'] ?? ''),
            'label' => sanitize_text_field($data['label'] ?? $existing_data['label'] ?? ''),
            'mandatory' => sanitize_text_field($data['mandatory'] ?? $existing_data['mandatory'] ?? '0'),
            'placeholder' => sanitize_text_field($data['placeholder'] ?? $existing_data['placeholder'] ?? ''),
            'description' => sanitize_textarea_field($data['description'] ?? $existing_data['description'] ?? ''),
            'default_value' => sanitize_text_field($data['default_value'] ?? $existing_data['default_value'] ?? ''),
        ]);

        // Handle options
        if (isset($data['options'])) {
            $field_data['options'] = is_array($data['options']) ? array_map('sanitize_text_field', $data['options']) : [];
        }

        // Handle max_length
        if (isset($data['max_length'])) {
            $field_data['max_length'] = (int) $data['max_length'];
        }

        // Handle validation rules
        if (isset($data['validation_rules'])) {
            $field_data['validation_rules'] = is_array($data['validation_rules']) ? $data['validation_rules'] : [];
        }

        $field_data['updated_at'] = current_time('mysql');

        return $field_data;
    }

    /**
     * Validate field data
     */
    private function validate_field_data($field_data)
    {
        if (empty($field_data['type'])) {
            return new \WP_Error('missing_type', 'Field type is required', ['status' => 400]);
        }

        if (empty($field_data['label'])) {
            return new \WP_Error('missing_label', 'Field label is required', ['status' => 400]);
        }

        $valid_types = array_keys($this->get_available_field_types());
        if (!in_array($field_data['type'], $valid_types)) {
            return new \WP_Error('invalid_type', 'Invalid field type', ['status' => 400]);
        }

        // Validate options for fields that need them
        $types_with_options = ['select', 'checkbox', 'radio'];
        if (in_array($field_data['type'], $types_with_options)) {
            if (empty($field_data['options']) || !is_array($field_data['options'])) {
                return new \WP_Error('missing_options', 'Options are required for this field type', ['status' => 400]);
            }
        }

        return true;
    }

    /**
     * Get next available field ID
     */
    private function get_next_field_id($fields)
    {
        $max_id = 0;
        foreach ($fields as $field_id => $field_data) {
            if (is_numeric($field_id)) {
                $max_id = max($max_id, (int) $field_id);
            }
        }
        return $max_id + 1;
    }

    /**
     * Get available field types
     */
    private function get_available_field_types()
    {
        return [
            'text' => 'Text Input',
            'name' => 'Name Field (Special)',
            'mec_email' => 'MEC Email Field (Special)',
            'email' => 'Email Input',
            'tel' => 'Phone Number',
            'date' => 'Date Picker',
            'textarea' => 'Text Area',
            'select' => 'Dropdown/Select',
            'checkbox' => 'Checkboxes',
            'radio' => 'Radio Buttons',
            'file' => 'File Upload',
            'agreement' => 'Agreement/Terms',
            'p' => 'Paragraph/Text Display',
        ];
    }

    /**
     * Get field type schemas
     */
    private function get_field_type_schemas()
    {
        return [
            'text' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['placeholder', 'max_length', 'default_value', 'validation_rules'],
                'supports_options' => false,
            ],
            'name' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['placeholder', 'validation_rules'],
                'supports_options' => false,
                'special' => true,
            ],
            'mec_email' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['placeholder', 'validation_rules'],
                'supports_options' => false,
                'special' => true,
            ],
            'email' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['placeholder', 'default_value', 'validation_rules'],
                'supports_options' => false,
            ],
            'tel' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['placeholder', 'default_value', 'validation_rules'],
                'supports_options' => false,
            ],
            'date' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['default_value', 'validation_rules'],
                'supports_options' => false,
            ],
            'textarea' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['placeholder', 'default_value', 'max_length', 'validation_rules'],
                'supports_options' => false,
            ],
            'select' => [
                'required_fields' => ['type', 'label', 'options'],
                'optional_fields' => ['default_value', 'validation_rules'],
                'supports_options' => true,
            ],
            'checkbox' => [
                'required_fields' => ['type', 'label', 'options'],
                'optional_fields' => ['default_value', 'validation_rules'],
                'supports_options' => true,
            ],
            'radio' => [
                'required_fields' => ['type', 'label', 'options'],
                'optional_fields' => ['default_value', 'validation_rules'],
                'supports_options' => true,
            ],
            'file' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['validation_rules'],
                'supports_options' => false,
            ],
            'agreement' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['description'],
                'supports_options' => false,
            ],
            'p' => [
                'required_fields' => ['type', 'label'],
                'optional_fields' => ['description'],
                'supports_options' => false,
                'display_only' => true,
            ],
        ];
    }

    /**
     * Get field schema for validation
     */
    private function get_field_schema()
    {
        return [
            'type' => [
                'description' => 'The field type',
                'type' => 'string',
                'required' => true,
                'enum' => array_keys($this->get_available_field_types()),
            ],
            'label' => [
                'description' => 'The field label displayed to users',
                'type' => 'string',
                'required' => true,
            ],
            'mandatory' => [
                'description' => 'Whether the field is required (1) or optional (0)',
                'type' => 'string',
                'enum' => ['0', '1'],
                'default' => '0',
            ],
            'placeholder' => [
                'description' => 'Placeholder text for input fields',
                'type' => 'string',
            ],
            'description' => [
                'description' => 'Additional description or help text',
                'type' => 'string',
            ],
            'default_value' => [
                'description' => 'Default value for the field',
                'type' => 'string',
            ],
            'options' => [
                'description' => 'Options for select, checkbox, and radio fields',
                'type' => 'array',
                'items' => [
                    'type' => 'string',
                ],
            ],
            'max_length' => [
                'description' => 'Maximum length for text inputs',
                'type' => 'integer',
                'minimum' => 1,
            ],
            'validation_rules' => [
                'description' => 'Additional validation rules',
                'type' => 'array',
            ],
        ];
    }
} 
