<?php

/**
 * Events API Controller
 *
 * @package    MecUtility
 * @subpackage MecUtility/Api/Controllers
 * @since      1.0.0
 */

namespace MecUtility\Api\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use WP_Error;
use WP_Query;
use Exception;
use MecUtility\Auth\AuthHelper;
use MecUtility\Api\AttendeesController;

/**
 * Events Controller class
 */
class EventsController
{

    /**
     * The namespace for this controller's routes.
     *
     * @var string
     */
    protected $namespace = 'mec-utility/v1';

    /**
     * The base of this controller's routes.
     *
     * @var string
     */
    protected $rest_base = 'events';

    /**
     * Register the routes for the objects of the controller.
     */
    public function register_routes()
    {
        // Register cleanup hook for temporary export files
        add_action('mec_utility_delete_temp_file', array(__CLASS__, 'delete_temp_file'), 10, 2);
        
        $namespace = 'mec-utility/v1';

        // Get events collection
        register_rest_route(
            $namespace,
            '/events',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_events'),
                'permission_callback' => '__return_true',
                'args'                => $this->get_collection_params(),
            )
        );

        // Get single event
        register_rest_route(
            $namespace,
            '/events/(?P<id>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event'),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                ),
            )
        );

        // Get event occurrences
        register_rest_route(
            $namespace,
            '/events/(?P<id>[\d]+)/occurrences',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event_occurrences_endpoint'),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'start_date' => array(
                        'type' => 'string',
                        'format' => 'date',
                        'description' => __('Start date filter (YYYY-MM-DD)', 'mec-utility'),
                    ),
                    'limit' => array(
                        'type' => 'integer',
                        'default' => 50,
                        'minimum' => 1,
                        'maximum' => 200,
                        'description' => __('Maximum number of occurrences to return', 'mec-utility'),
                    ),
                ),
            )
        );

        // Get event occurrence attendees
        register_rest_route(
            $namespace,
            '/events/(?P<event_id>[\d]+)/occurrences/(?P<occurrence_timestamp>[\d]+)/attendees',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_occurrence_attendees'),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'event_id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'occurrence_timestamp' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'include_details' => array(
                        'type' => 'boolean',
                        'default' => false,
                        'description' => __('Include detailed attendee information', 'mec-utility'),
                    ),
                ),
            )
        );

        // Get event occurrence attendees check-in status (lightweight)
        register_rest_route(
            $namespace,
            '/events/(?P<event_id>[\d]+)/occurrences/(?P<occurrence_timestamp>[\d]+)/attendees/status',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_occurrence_attendees_status'),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'event_id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'occurrence_timestamp' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                ),
            )
        );

        // Export event occurrence attendees (CSV/Excel) - Returns download URL
        register_rest_route(
            $namespace,
            '/events/(?P<event_id>[\d]+)/occurrences/(?P<occurrence_timestamp>[\d]+)/attendees/export',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'export_occurrence_attendees'),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'event_id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'occurrence_timestamp' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'format' => array(
                        'type' => 'string',
                        'default' => 'csv',
                        'enum' => array('csv', 'excel', 'xlsx'),
                        'description' => __('Export format: csv or excel/xlsx', 'mec-utility'),
                    ),
                    'download' => array(
                        'type' => 'boolean',
                        'default' => false,
                        'description' => __('Force download file instead of returning URL', 'mec-utility'),
                    ),
                ),
            )
        );

        // Download event occurrence attendees (CSV/Excel) - Direct download
        register_rest_route(
            $namespace,
            '/events/(?P<event_id>[\d]+)/occurrences/(?P<occurrence_timestamp>[\d]+)/attendees/download',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'download_occurrence_attendees'),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'event_id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'occurrence_timestamp' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        }
                    ),
                    'format' => array(
                        'type' => 'string',
                        'default' => 'csv',
                        'enum' => array('csv', 'excel', 'xlsx'),
                        'description' => __('Export format: csv or excel/xlsx', 'mec-utility'),
                    ),
                ),
            )
        );

        // Get event colors (new endpoint)
        \register_rest_route(
            $namespace,
            '/event-colors',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event_colors'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'date' => array(
                        'description' => \__('Date parameter in YYYY-MM or YYYY-MM-DD format. If not provided, current month will be used.', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => false,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // Create new event
        \register_rest_route(
            $namespace,
            '/' . $this->rest_base,
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'create_event'),
                'permission_callback' => AuthHelper::permission_callback('create_events'),
                'args'                => $this->get_endpoint_args_for_item_schema('POST'),
            )
        );

        // Get single event
        \register_rest_route(
            $namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'id' => array(
                        'description' => \__('Unique identifier for the event.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => true,
                        'validate_callback' => 'rest_validate_request_arg',
                    ),
                ),
            )
        );

        // Update event
        \register_rest_route(
            $namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            array(
                'methods'             => 'PUT,PATCH',
                'callback'            => array($this, 'update_event'),
                'permission_callback' => AuthHelper::permission_callback('update_events'),
                'args'                => $this->get_endpoint_args_for_item_schema('PUT'),
            )
        );

        // Delete event
        \register_rest_route(
            $namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            array(
                'methods'             => 'DELETE',
                'callback'            => array($this, 'delete_event'),
                'permission_callback' => AuthHelper::permission_callback('delete_events'),
                'args'                => array(
                    'id' => array(
                        'description' => \__('Unique identifier for the event.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => true,
                    ),
                    'force' => array(
                        'description' => \__('Whether to bypass trash and force deletion.', 'mec-utility'),
                        'type'        => 'boolean',
                        'default'     => false,
                    ),
                ),
            )
        );

        // Search events
        \register_rest_route(
            $namespace,
            '/' . $this->rest_base . '/search',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'search_events'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'query' => array(
                        'description' => \__('Search query string.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'start_date' => array(
                        'description' => \__('Start date filter (Y-m-d format).', 'mec-utility'),
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'end_date' => array(
                        'description' => \__('End date filter (Y-m-d format).', 'mec-utility'),
                        'type'        => 'string',
                        'format'      => 'date',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'date_filter' => array(
                        'description' => \__('Date filter type: upcoming, past, expired, today, this_week, this_month.', 'mec-utility'),
                        'type'        => 'string',
                        'enum'        => array('upcoming', 'past', 'expired', 'today', 'this_week', 'this_month'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'status' => array(
                        'description' => \__('Event status: publish, draft, private, future, pending.', 'mec-utility'),
                        'type'        => 'string',
                        'enum'        => array('publish', 'draft', 'private', 'future', 'pending'),
                        'default'     => 'publish',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'category' => array(
                        'description' => \__('Event category ID(s) or slug(s). Can be single value or comma-separated.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'label' => array(
                        'description' => \__('Event label ID(s) or slug(s). Can be single value or comma-separated.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'location' => array(
                        'description' => \__('Event location ID(s). Can be single value or comma-separated.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'organizer' => array(
                        'description' => \__('Event organizer ID(s). Can be single value or comma-separated.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'speaker' => array(
                        'description' => \__('Event speaker ID(s) or slug(s). Can be single value or comma-separated.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'sponsor' => array(
                        'description' => \__('Event sponsor ID(s) or slug(s). Can be single value or comma-separated.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'tag' => array(
                        'description' => \__('Event tag ID(s) or slug(s). Can be single value or comma-separated.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'cost_min' => array(
                        'description' => \__('Minimum event cost.', 'mec-utility'),
                        'type'        => 'number',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'cost_max' => array(
                        'description' => \__('Maximum event cost.', 'mec-utility'),
                        'type'        => 'number',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'featured' => array(
                        'description' => \__('Filter by featured events only.', 'mec-utility'),
                        'type'        => 'boolean',
                        'default'     => false,
                    ),
                    'per_page' => array(
                        'description' => \__('Maximum number of items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 10,
                        'minimum'     => 1,
                        'maximum'     => 100,
                    ),
                    'page' => array(
                        'description' => \__('Current page of the collection.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 1,
                        'minimum'     => 1,
                    ),
                    'orderby' => array(
                        'description' => \__('Sort collection by object attribute.', 'mec-utility'),
                        'type'        => 'string',
                        'default'     => 'date',
                        'enum'        => array('date', 'title', 'start_date', 'end_date', 'cost', 'menu_order'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'order' => array(
                        'description' => \__('Order sort attribute ascending or descending.', 'mec-utility'),
                        'type'        => 'string',
                        'default'     => 'asc',
                        'enum'        => array('asc', 'desc'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // Locations list
        \register_rest_route(
            $namespace,
            '/locations',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_locations'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'search' => array(
                        'description' => \__('Search by name/slug.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'per_page' => array(
                        'description' => \__('Max items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 20,
                        'sanitize_callback' => 'absint',
                    ),
                    'page' => array(
                        'description' => \__('Page number.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 1,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // Organizers list
        \register_rest_route(
            $namespace,
            '/organizers',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_organizers'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'search' => array(
                        'description' => \__('Search by name/slug.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'per_page' => array(
                        'description' => \__('Max items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 20,
                        'sanitize_callback' => 'absint',
                    ),
                    'page' => array(
                        'description' => \__('Page number.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 1,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // MEC tags list
        \register_rest_route(
            $namespace,
            '/tags',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_tags'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'search' => array(
                        'description' => \__('Search by tag name/slug.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'per_page' => array(
                        'description' => \__('Max items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 20,
                        'sanitize_callback' => 'absint',
                    ),
                    'page' => array(
                        'description' => \__('Page number.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 1,
                        'sanitize_callback' => 'absint',
                    ),
                    'orderby' => array(
                        'description' => \__('Order by field.', 'mec-utility'),
                        'type'        => 'string',
                        'default'     => 'count',
                        'enum'        => array('count', 'name', 'slug'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'order' => array(
                        'description' => \__('Order direction.', 'mec-utility'),
                        'type'        => 'string',
                        'default'     => 'desc',
                        'enum'        => array('asc', 'desc'),
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // MEC popular tags ("most used")
        \register_rest_route(
            $namespace,
            '/tags/popular',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_popular_tags'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'per_page' => array(
                        'description' => \__('Max items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 20,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // Create MEC tag
        \register_rest_route(
            $namespace,
            '/tags',
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'create_tag'),
                'permission_callback' => AuthHelper::permission_callback('create_events'),
                'args'                => array(
                    'name' => array(
                        'description' => \__('Tag name (title).', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => false,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'title' => array(
                        'description' => \__('Alias for name.', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => false,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'slug' => array(
                        'description' => \__('Optional slug.', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => false,
                        'sanitize_callback' => 'sanitize_title',
                    ),
                ),
            )
        );

        // MEC categories list
        \register_rest_route(
            $namespace,
            '/categories',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_categories'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'search' => array(
                        'description' => \__('Search by name/slug.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'per_page' => array(
                        'description' => \__('Max items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 50,
                        'sanitize_callback' => 'absint',
                    ),
                    'page' => array(
                        'description' => \__('Page number.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 1,
                        'sanitize_callback' => 'absint',
                    ),
                    'hide_empty' => array(
                        'description' => \__('Hide terms not assigned to any posts.', 'mec-utility'),
                        'type'        => 'boolean',
                        'default'     => false,
                    ),
                    'parent' => array(
                        'description' => \__('Filter by parent term ID.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => false,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // Create MEC category
        \register_rest_route(
            $namespace,
            '/categories',
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'create_category'),
                'permission_callback' => AuthHelper::permission_callback('create_events'),
                'args'                => array(
                    'name' => array(
                        'description' => \__('Category name (title).', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'slug' => array(
                        'description' => \__('Optional slug.', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => false,
                        'sanitize_callback' => 'sanitize_title',
                    ),
                    'parent' => array(
                        'description' => \__('Optional parent term ID.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => false,
                        'sanitize_callback' => 'absint',
                    ),
                    'meta' => array(
                        'description' => \__('Optional meta {color, icon, thumbnail}.', 'mec-utility'),
                        'type'        => 'object',
                        'required'    => false,
                    ),
                ),
            )
        );

        // MEC speakers list
        \register_rest_route(
            $namespace,
            '/speakers',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_speakers'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'search' => array(
                        'description' => \__('Search by name/slug.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'per_page' => array(
                        'description' => \__('Max items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 50,
                        'sanitize_callback' => 'absint',
                    ),
                    'page' => array(
                        'description' => \__('Page number.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 1,
                        'sanitize_callback' => 'absint',
                    ),
                    'hide_empty' => array(
                        'description' => \__('Hide terms not assigned to any posts.', 'mec-utility'),
                        'type'        => 'boolean',
                        'default'     => false,
                    ),
                    'parent' => array(
                        'description' => \__('Filter by parent term ID.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => false,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // Create MEC speaker
        \register_rest_route(
            $namespace,
            '/speakers',
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'create_speaker'),
                'permission_callback' => AuthHelper::permission_callback('create_events'),
                'args'                => array(
                    'name' => array(
                        'description' => \__('Speaker name (title).', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'slug' => array(
                        'description' => \__('Optional slug.', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => false,
                        'sanitize_callback' => 'sanitize_title',
                    ),
                    'parent' => array(
                        'description' => \__('Optional parent term ID.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => false,
                        'sanitize_callback' => 'absint',
                    ),
                    'meta' => array(
                        'description' => \__('Optional meta (e.g., thumbnail, job_title, company, url, email, tel).', 'mec-utility'),
                        'type'        => 'object',
                        'required'    => false,
                    ),
                ),
            )
        );

        // MEC labels list
        \register_rest_route(
            $namespace,
            '/labels',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_labels'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
                'args'                => array(
                    'search' => array(
                        'description' => \__('Search by name/slug.', 'mec-utility'),
                        'type'        => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'per_page' => array(
                        'description' => \__('Max items to return.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 50,
                        'sanitize_callback' => 'absint',
                    ),
                    'page' => array(
                        'description' => \__('Page number.', 'mec-utility'),
                        'type'        => 'integer',
                        'default'     => 1,
                        'sanitize_callback' => 'absint',
                    ),
                    'hide_empty' => array(
                        'description' => \__('Hide terms not assigned to any posts.', 'mec-utility'),
                        'type'        => 'boolean',
                        'default'     => false,
                    ),
                    'parent' => array(
                        'description' => \__('Filter by parent term ID.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => false,
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        // Create MEC label
        \register_rest_route(
            $namespace,
            '/labels',
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'create_label'),
                'permission_callback' => AuthHelper::permission_callback('create_events'),
                'args'                => array(
                    'name' => array(
                        'description' => \__('Label name (title).', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'slug' => array(
                        'description' => \__('Optional slug.', 'mec-utility'),
                        'type'        => 'string',
                        'required'    => false,
                        'sanitize_callback' => 'sanitize_title',
                    ),
                    'parent' => array(
                        'description' => \__('Optional parent term ID.', 'mec-utility'),
                        'type'        => 'integer',
                        'required'    => false,
                        'sanitize_callback' => 'absint',
                    ),
                    'meta' => array(
                        'description' => \__('Optional meta (e.g., color, icon, thumbnail).', 'mec-utility'),
                        'type'        => 'object',
                        'required'    => false,
                    ),
                ),
            )
        );

        // Plugin status endpoint
        \register_rest_route(
            $namespace,
            '/plugin-status',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_plugin_status'),
                'permission_callback' => AuthHelper::permission_callback('read_events'),
            )
        );
    }

    /**
     * Get all events
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_events($request)
    {
        try {
            $search   = $request->get_param('search') ?: '';
            $status   = $request->get_param('status') ?: 'any'; // Changed from 'publish' to 'any' to get all statuses
            $orderby  = $request->get_param('orderby') ?: 'date';
            $order    = $request->get_param('order') ?: 'asc';

            // Date filters
            $start_date = $request->get_param('start_date');
            $end_date = $request->get_param('end_date');
            $date_filter = $request->get_param('date_filter');

            // Other filters
            $category = $request->get_param('category');
            $location = $request->get_param('location');
            $organizer = $request->get_param('organizer');

            $args = array(
                'post_type'      => 'mec-events',
                'post_status'    => $status,
                'posts_per_page' => -1, // Get all events
                'meta_query'     => array(
                    array(
                        'key'     => 'mec_start_date',
                        'compare' => 'EXISTS',
                    ),
                ),
            );

            // Add search query
            if (! empty($search)) {
                $args['s'] = $search;
            }

            // Add date filters using mec_events table
            $args = $this->apply_date_filters($args, $start_date, $end_date, $date_filter);

            // Add taxonomy filters
            if (! empty($category)) {
                $args['tax_query'][] = array(
                    'taxonomy' => 'mec_category',
                    'field'    => is_numeric($category) ? 'term_id' : 'slug',
                    'terms'    => $category,
                );
            }

            // Add meta filters for location and organizer
            if (! empty($location)) {
                $args['meta_query'][] = array(
                    'key'     => 'mec_location_id',
                    'value'   => $location,
                    'compare' => '=',
                );
            }

            if (! empty($organizer)) {
                $args['meta_query'][] = array(
                    'key'     => 'mec_organizer_id',
                    'value'   => $organizer,
                    'compare' => '=',
                );
            }

            // Set ordering
            if ($orderby === 'start_date') {
                $args['meta_key'] = 'mec_start_date';
                $args['orderby'] = 'meta_value';
                $args['order'] = strtoupper($order);
            } else {
                $args['orderby'] = $orderby;
                $args['order'] = strtoupper($order);
            }

            $query = new WP_Query($args);
            $events = array();

            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $event_data = $this->prepare_event_for_response(\get_post(), $request);
                    if (! \is_wp_error($event_data)) {
                        $events[] = $event_data;
                    }
                }
                \wp_reset_postdata();
            }

            $response_data = [
                'events' => $events,
                'total' => count($events)
            ];

            return \rest_ensure_response($response_data);
        } catch (Exception $e) {
            return new WP_Error(
                'mec_utility_events_error',
                __('Unable to retrieve events.', 'mec-utility'),
                array('status' => 500)
            );
        }
    }

    /**
     * Get single event
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_event($request)
    {
        $event_id = $request->get_param('id');
        $event    = get_post($event_id);

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new WP_Error(
                'mec_utility_event_not_found',
                __('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Do not expose trashed events as existing resources
        if ('trash' === $event->post_status) {
            return new WP_Error(
                'mec_utility_event_not_found',
                __('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        $event_data = $this->prepare_event_for_response($event, $request);

        if (is_wp_error($event_data)) {
            return $event_data;
        }

        return rest_ensure_response($event_data);
    }

    /**
     * Create a new event
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function create_event($request)
    {
        global $wpdb;

        try {
            $prepared_post = $this->prepare_item_for_database($request);

            if (\is_wp_error($prepared_post)) {
                return $prepared_post;
            }

            // Get API user info directly from request headers
            $api_user = null;
            $auth_result = AuthHelper::verify_authentication($request);
            if (!\is_wp_error($auth_result) && is_array($auth_result)) {
                $api_user = $auth_result;
            }

            // Set post_author based on API key user
            if ($api_user && isset($api_user['user_id']) && $api_user['user_id'] > 0) {
                $prepared_post['post_author'] = (int) $api_user['user_id'];
            } elseif (!isset($prepared_post['post_author'])) {
                // Fallback to current user if available
                $current_user_id = \get_current_user_id();
                if ($current_user_id > 0) {
                    $prepared_post['post_author'] = $current_user_id;
                }
            }

            $post_id = \wp_insert_post($prepared_post, true);

            if (\is_wp_error($post_id)) {
                return $post_id;
            }

            $event = \get_post($post_id);

            // Save API key metadata if event was created via API
            if ($api_user && is_array($api_user) && isset($api_user['name']) && !empty($api_user['name'])) {
                \update_post_meta($post_id, 'mec_utility_api_author_name', \sanitize_text_field($api_user['name']));
                if (isset($api_user['api_key_id']) && $api_user['api_key_id'] > 0) {
                    \update_post_meta($post_id, 'mec_utility_api_key_id', (int) $api_user['api_key_id']);
                }
            }

        $this->update_event_meta($event->ID, $request);

        $this->save_mec_event_data($event->ID, $request);

        // Regenerate MEC occurrences (mec_dates) so frontend shows correct dates
        $this->reschedule_event($event->ID);

        // Regenerate MEC occurrences (mec_dates) so frontend shows correct dates
        $this->reschedule_event($event->ID);

            // Handle taxonomies
            $this->handle_event_taxonomies($event->ID, $request);

            $response = $this->prepare_event_for_response($event, $request);

            return \rest_ensure_response($response);
        } catch (Exception $e) {
            return new WP_Error(
                'mec_utility_create_error',
                __('Unable to create event.', 'mec-utility'),
                array('status' => 500)
            );
        }
    }

    /**
     * Update an event
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function update_event($request)
    {
        $event_id = $request->get_param('id');
        $event    = \get_post($event_id);

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new WP_Error(
                'mec_utility_event_not_found',
                __('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        try {
            $prepared_post = $this->prepare_item_for_database($request);
            $prepared_post['ID'] = $event_id;

            if (\is_wp_error($prepared_post)) {
                return $prepared_post;
            }

            $post_id = \wp_update_post($prepared_post, true);

            if (\is_wp_error($post_id)) {
                return $post_id;
            }

            $updated_event = \get_post($post_id);

        $this->update_event_meta($updated_event->ID, $request);

        $this->save_mec_event_data($updated_event->ID, $request);

        // Regenerate MEC occurrences (mec_dates) so frontend shows correct dates
        $this->reschedule_event($updated_event->ID);

        // Regenerate MEC occurrences (mec_dates) so frontend shows correct dates
        $this->reschedule_event($updated_event->ID);

            $response = $this->prepare_event_for_response($updated_event, $request);

            return \rest_ensure_response($response);
        } catch (Exception $e) {
            return new WP_Error(
                'mec_utility_update_error',
                __('Unable to update event.', 'mec-utility'),
                array('status' => 500)
            );
        }
    }

    /**
     * Delete an event
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function delete_event($request)
    {
        $event_id = $request->get_param('id');
        $force    = $request->get_param('force');
        $event    = \get_post($event_id);

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new WP_Error(
                'mec_utility_event_not_found',
                __('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        try {
            $previous = $this->prepare_event_for_response($event, $request);
            $result   = false;

            if ($force) {
                $result = \wp_delete_post($event_id, true);
            } else {
                if ('trash' === $event->post_status) {
                    return new WP_Error(
                        'mec_utility_already_trashed',
                        __('The event has already been deleted.', 'mec-utility'),
                        array('status' => 410)
                    );
                }

                $result = \wp_trash_post($event_id);
            }

            if (! $result) {
                return new WP_Error(
                    'mec_utility_cannot_delete',
                    __('The event cannot be deleted.', 'mec-utility'),
                    array('status' => 500)
                );
            }

            $response = new WP_REST_Response();
            $response->set_data(
                array(
                    'deleted'  => true,
                    'previous' => $previous,
                )
            );

            return $response;
        } catch (Exception $e) {
            return new WP_Error(
                'mec_utility_delete_error',
                __('Unable to delete event.', 'mec-utility'),
                array('status' => 500)
            );
        }
    }

    /**
     * Search events
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function search_events($request)
    {
        try {
            // Basic parameters
            $query    = $request->get_param('query') ?: '';
            $per_page = $request->get_param('per_page') ?: 10;
            $page     = $request->get_param('page') ?: 1;
            $orderby  = $request->get_param('orderby') ?: 'date';
            $order    = $request->get_param('order') ?: 'asc';
            $status   = $request->get_param('status') ?: 'publish';

            // Date filters
            $start_date = $request->get_param('start_date');
            $end_date = $request->get_param('end_date');
            $date_filter = $request->get_param('date_filter');

            // Taxonomy filters (can be comma-separated)
            $category = $request->get_param('category');
            $label = $request->get_param('label');
            $location = $request->get_param('location');
            $organizer = $request->get_param('organizer');
            $speaker = $request->get_param('speaker');
            $sponsor = $request->get_param('sponsor');
            $tag = $request->get_param('tag');

            // Cost filters
            $cost_min = $request->get_param('cost_min');
            $cost_max = $request->get_param('cost_max');
            $featured = $request->get_param('featured');

            $args = array(
                'post_type'      => 'mec-events',
                'post_status'    => $status,
                'posts_per_page' => $per_page,
                'paged'          => $page,
                'meta_query'     => array(
                    array(
                        'key'     => 'mec_start_date',
                        'compare' => 'EXISTS',
                    ),
                ),
                'tax_query'      => array(),
            );

            // Add search query
            if (! empty($query)) {
                $args['s'] = $query;
            }

            // Add date filters using mec_events table
            $args = $this->apply_date_filters($args, $start_date, $end_date, $date_filter);

            // Add taxonomy filters with array support
            if (! empty($category)) {
                $category_values = array_map('trim', explode(',', $category));
                $args['tax_query'][] = array(
                    'taxonomy' => 'mec_category',
                    'field'    => $this->is_numeric_array($category_values) ? 'term_id' : 'slug',
                    'terms'    => $category_values,
                    'operator' => 'IN',
                );
            }

            if (! empty($label)) {
                $label_values = array_map('trim', explode(',', $label));
                $args['tax_query'][] = array(
                    'taxonomy' => 'mec_label',
                    'field'    => $this->is_numeric_array($label_values) ? 'term_id' : 'slug',
                    'terms'    => $label_values,
                    'operator' => 'IN',
                );
            }

            if (! empty($speaker)) {
                $speaker_values = array_map('trim', explode(',', $speaker));
                $args['tax_query'][] = array(
                    'taxonomy' => 'mec_speaker',
                    'field'    => $this->is_numeric_array($speaker_values) ? 'term_id' : 'slug',
                    'terms'    => $speaker_values,
                    'operator' => 'IN',
                );
            }

            if (! empty($sponsor)) {
                $sponsor_values = array_map('trim', explode(',', $sponsor));
                $args['tax_query'][] = array(
                    'taxonomy' => 'mec_sponsor',
                    'field'    => $this->is_numeric_array($sponsor_values) ? 'term_id' : 'slug',
                    'terms'    => $sponsor_values,
                    'operator' => 'IN',
                );
            }

            if (! empty($tag)) {
                $tag_values = array_map('trim', explode(',', $tag));
                $args['tax_query'][] = array(
                    'taxonomy' => 'mec_tag',
                    'field'    => $this->is_numeric_array($tag_values) ? 'term_id' : 'slug',
                    'terms'    => $tag_values,
                    'operator' => 'IN',
                );
            }

            // Add meta filters for location and organizer with array support
            if (! empty($location)) {
                $location_values = array_map('intval', array_map('trim', explode(',', $location)));
                if (count($location_values) > 1) {
                    $args['meta_query'][] = array(
                        'key'     => 'mec_location_id',
                        'value'   => $location_values,
                        'compare' => 'IN',
                    );
                } else {
                    $args['meta_query'][] = array(
                        'key'     => 'mec_location_id',
                        'value'   => $location_values[0],
                        'compare' => '=',
                    );
                }
            }

            if (! empty($organizer)) {
                $organizer_values = array_map('intval', array_map('trim', explode(',', $organizer)));
                if (count($organizer_values) > 1) {
                    $args['meta_query'][] = array(
                        'key'     => 'mec_organizer_id',
                        'value'   => $organizer_values,
                        'compare' => 'IN',
                    );
                } else {
                    $args['meta_query'][] = array(
                        'key'     => 'mec_organizer_id',
                        'value'   => $organizer_values[0],
                        'compare' => '=',
                    );
                }
            }

            // Add cost filters
            if (! empty($cost_min) || ! empty($cost_max)) {
                $cost_query = array('relation' => 'AND');

                if (! empty($cost_min)) {
                    $cost_query[] = array(
                        'key'     => 'mec_cost',
                        'value'   => floatval($cost_min),
                        'compare' => '>=',
                        'type'    => 'NUMERIC',
                    );
                }

                if (! empty($cost_max)) {
                    $cost_query[] = array(
                        'key'     => 'mec_cost',
                        'value'   => floatval($cost_max),
                        'compare' => '<=',
                        'type'    => 'NUMERIC',
                    );
                }

                $args['meta_query'][] = $cost_query;
            }

            // Add featured filter
            if ($featured) {
                $args['meta_query'][] = array(
                    'key'     => 'mec_featured',
                    'value'   => '1',
                    'compare' => '=',
                );
            }

            // Set tax_query relation if multiple taxonomies
            if (count($args['tax_query']) > 1) {
                $args['tax_query']['relation'] = 'AND';
            }

            // Set meta_query relation if multiple meta queries
            if (count($args['meta_query']) > 1) {
                $args['meta_query']['relation'] = 'AND';
            }

            // Set ordering
            if ($orderby === 'start_date') {
                $args['meta_key'] = 'mec_start_date';
                $args['orderby'] = 'meta_value';
                $args['order'] = strtoupper($order);
            } elseif ($orderby === 'end_date') {
                $args['meta_key'] = 'mec_end_date';
                $args['orderby'] = 'meta_value';
                $args['order'] = strtoupper($order);
            } elseif ($orderby === 'cost') {
                $args['meta_key'] = 'mec_cost';
                $args['orderby'] = 'meta_value_num';
                $args['order'] = strtoupper($order);
            } else {
                $args['orderby'] = $orderby;
                $args['order'] = strtoupper($order);
            }

            $search_query = new WP_Query($args);
            $events = array();

            if ($search_query->have_posts()) {
                while ($search_query->have_posts()) {
                    $search_query->the_post();
                    $event_data = $this->prepare_event_for_response(\get_post(), $request);
                    if (! \is_wp_error($event_data)) {
                        $events[] = $event_data;
                    }
                }
                \wp_reset_postdata();
            }

            // Calculate pagination info
            $total_items = $search_query->found_posts;
            $total_pages = $search_query->max_num_pages;

            $response_data = [
                'events' => $events,
                'pagination' => [
                    'total' => $total_items,
                    'per_page' => $per_page,
                    'current_page' => $page,
                    'total_pages' => $total_pages,
                    'has_more' => $page < $total_pages
                ],
                'filters_applied' => [
                    'query' => $query,
                    'date_filter' => $date_filter,
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'status' => $status,
                    'category' => $category,
                    'label' => $label,
                    'location' => $location,
                    'organizer' => $organizer,
                    'speaker' => $speaker,
                    'sponsor' => $sponsor,
                    'tag' => $tag,
                    'cost_min' => $cost_min,
                    'cost_max' => $cost_max,
                    'featured' => $featured,
                ]
            ];

            $response = \rest_ensure_response($response_data);

            // Add pagination and filter info headers
            $response->header('X-WP-Total', $total_items);
            $response->header('X-WP-TotalPages', $total_pages);

            return $response;
        } catch (Exception $e) {
            return new WP_Error(
                'mec_utility_search_error',
                __('Unable to search events: ' . $e->getMessage(), 'mec-utility'),
                array('status' => 500)
            );
        }
    }

    /**
     * Check if a given request has access to create events
     */
    public function create_event_permissions_check($request)
    {
        if (! \current_user_can('edit_posts')) {
            return new WP_Error(
                'mec_utility_cannot_create',
                __('Sorry, you are not allowed to create events.', 'mec-utility'),
                array('status' => \rest_authorization_required_code())
            );
        }

        return true;
    }

    /**
     * Check if a given request has access to update an event
     */
    public function update_event_permissions_check($request)
    {
        $event = \get_post($request->get_param('id'));

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new WP_Error(
                'mec_utility_event_not_found',
                __('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        if (! \current_user_can('edit_post', $event->ID)) {
            return new WP_Error(
                'mec_utility_cannot_edit',
                __('Sorry, you are not allowed to edit this event.', 'mec-utility'),
                array('status' => \rest_authorization_required_code())
            );
        }

        return true;
    }

    /**
     * Check if a given request has access to delete an event
     */
    public function delete_event_permissions_check($request)
    {
        $event = \get_post($request->get_param('id'));

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new WP_Error(
                'mec_utility_event_not_found',
                __('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        if (! \current_user_can('delete_post', $event->ID)) {
            return new WP_Error(
                'mec_utility_cannot_delete',
                __('Sorry, you are not allowed to delete this event.', 'mec-utility'),
                array('status' => \rest_authorization_required_code())
            );
        }

        return true;
    }

    /**
     * Prepare complete event data for API response (like RSVP API format)
     *
     * @param \WP_Post $event Event post object.
     * @param WP_REST_Request $request Request object.
     * @return array|WP_Error Complete prepared event data or error.
     */
    protected function prepare_event_for_response($event, $request)
    {
        global $wpdb;

        try {
            // Get all meta data
            $meta = \get_post_meta($event->ID);
            $formatted_meta = [];
            foreach ($meta as $key => $value) {
                $formatted_meta[$key] = is_array($value) && count($value) === 1 ? $value[0] : $value;
            }

            // Get taxonomies with complete information
            $categories = \wp_get_post_terms($event->ID, 'mec_category', ['fields' => 'all']);
            $speakers = \wp_get_post_terms($event->ID, 'mec_speaker', ['fields' => 'all']);
            $sponsors = \wp_get_post_terms($event->ID, 'mec_sponsor', ['fields' => 'all']);
            $labels = \wp_get_post_terms($event->ID, 'mec_label', ['fields' => 'all']);
            // Use MEC's taxonomy tag filter (defaults to 'post_tag' if no custom taxonomy is set)
            $tag_taxonomy = apply_filters('mec_taxonomy_tag', 'post_tag');
            $tags = \wp_get_post_terms($event->ID, $tag_taxonomy, ['fields' => 'all']);

            // Format taxonomies with WP_Error safety
            $format_terms = function ($terms) {
                if (is_wp_error($terms) || empty($terms)) {
                    return [];
                }
                if (!is_array($terms)) {
                    $terms = (array) $terms;
                }
                $terms = array_filter($terms, function ($term) {
                    return is_object($term) && isset($term->term_id);
                });
                return array_map(function ($term) {
                    return [
                        'id' => (int) $term->term_id,
                        'name' => $term->name,
                        'slug' => $term->slug,
                        'description' => $term->description,
                        'count' => (int) $term->count,
                    ];
                }, $terms);
            };

            // Get MEC event data from database
            $mec_data = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}mec_events WHERE post_id = %d",
                $event->ID
            ));

            // Format dates and times
            $start_date = $formatted_meta['mec_start_date'] ?? '';
            $end_date = $formatted_meta['mec_end_date'] ?? '';
            $start_time_hour = $formatted_meta['mec_start_time_hour'] ?? '8';
            $start_time_minutes = $formatted_meta['mec_start_time_minutes'] ?? '0';
            $start_time_ampm = $formatted_meta['mec_start_time_ampm'] ?? 'AM';
            $end_time_hour = $formatted_meta['mec_end_time_hour'] ?? '6';
            $end_time_minutes = $formatted_meta['mec_end_time_minutes'] ?? '0';
            $end_time_ampm = $formatted_meta['mec_end_time_ampm'] ?? 'PM';

            $start_time_formatted = sprintf('%02d:%02d %s', $start_time_hour, $start_time_minutes, $start_time_ampm);
            $end_time_formatted = sprintf('%02d:%02d %s', $end_time_hour, $end_time_minutes, $end_time_ampm);

            // Convert to seconds for time_start and time_end
            $start_time_seconds = $this->time_to_seconds($start_time_hour, $start_time_minutes, $start_time_ampm);
            $end_time_seconds = $this->time_to_seconds($end_time_hour, $end_time_minutes, $end_time_ampm);

            // Get location details
            $location_id = $formatted_meta['mec_location_id'] ?? '';
            $location_details = [];
            if ($location_id) {
                $location_term = \get_term($location_id, 'mec_location');
                if ($location_term && !is_wp_error($location_term)) {
                    $location_meta = \get_term_meta($location_id);
                    $location_details = [
                        'id' => (int) $location_term->term_id,
                        'name' => $location_term->name,
                        'slug' => $location_term->slug,
                        'description' => $location_term->description,
                        'address' => $location_meta['address'][0] ?? '',
                        'latitude' => $location_meta['latitude'][0] ?? '',
                        'longitude' => $location_meta['longitude'][0] ?? '',
                        'url' => $location_meta['url'][0] ?? '',
                        'tel' => $location_meta['tel'][0] ?? '',
                        'thumbnail' => $location_meta['thumbnail'][0] ?? '',
                    ];
                }
            }

            // Get organizer details
            $organizer_id = $formatted_meta['mec_organizer_id'] ?? '';
            $organizer_details = [];
            if ($organizer_id) {
                $organizer_term = \get_term($organizer_id, 'mec_organizer');
                if ($organizer_term && !is_wp_error($organizer_term)) {
                    $organizer_meta = \get_term_meta($organizer_id);
                    $organizer_details = [
                        'id' => (int) $organizer_term->term_id,
                        'name' => $organizer_term->name,
                        'slug' => $organizer_term->slug,
                        'description' => $organizer_term->description,
                        'email' => $organizer_meta['email'][0] ?? '',
                        'tel' => $organizer_meta['tel'][0] ?? '',
                        'url' => $organizer_meta['url'][0] ?? '',
                        'thumbnail' => $organizer_meta['thumbnail'][0] ?? '',
                    ];
                }
            }

            // Get additional locations (Other Locations)
            $additional_locations = [];
            if (isset($formatted_meta['mec_additional_location_ids'])) {
                $raw_additional = maybe_unserialize($formatted_meta['mec_additional_location_ids']);
                if (is_array($raw_additional)) {
                    foreach ($raw_additional as $loc_id) {
                        $loc_id = intval($loc_id);
                        if (!$loc_id) {
                            continue;
                        }
                        $term = \get_term($loc_id, 'mec_location');
                        if ($term && !is_wp_error($term)) {
                            $lm = \get_term_meta($loc_id);
                            $additional_locations[] = [
                                'id' => (int) $term->term_id,
                                'name' => $term->name,
                                'slug' => $term->slug,
                                'description' => $term->description,
                                'address' => $lm['address'][0] ?? '',
                                'latitude' => $lm['latitude'][0] ?? '',
                                'longitude' => $lm['longitude'][0] ?? '',
                                'url' => $lm['url'][0] ?? '',
                                'tel' => $lm['tel'][0] ?? '',
                                'thumbnail' => $lm['thumbnail'][0] ?? '',
                            ];
                        }
                    }
                }
            }

            // Get author details
            $author_id = $event->post_author;
            $author_details = [];
            if ($author_id) {
                $author = \get_userdata($author_id);
                if ($author) {
                    $author_details = [
                        'id' => (int) $author->ID,
                        'username' => $author->user_login,
                        'email' => $author->user_email,
                        'display_name' => $author->display_name,
                        'first_name' => $author->first_name,
                        'last_name' => $author->last_name,
                        'avatar' => \get_avatar_url($author->ID),
                    ];
                }
            }

            // Get featured image details
            $featured_image_id = \get_post_thumbnail_id($event->ID);
            $featured_image_details = [];
            if ($featured_image_id) {
                $featured_image_details = [
                    'id' => (int) $featured_image_id,
                    'url' => \wp_get_attachment_url($featured_image_id),
                    'thumbnail' => \wp_get_attachment_image_url($featured_image_id, 'thumbnail'),
                    'medium' => \wp_get_attachment_image_url($featured_image_id, 'medium'),
                    'large' => \wp_get_attachment_image_url($featured_image_id, 'large'),
                    'full' => \wp_get_attachment_image_url($featured_image_id, 'full'),
                    'alt' => \get_post_meta($featured_image_id, '_wp_attachment_image_alt', true),
                    'caption' => \wp_get_attachment_caption($featured_image_id),
                ];
            }

            // Build gallery images from MEC meta
            $images = [];
            $extract_gallery_ids = function ($formatted_meta) {
                $candidates = [];
                if (isset($formatted_meta['mec_gallery'])) {
                    $candidates[] = $formatted_meta['mec_gallery'];
                }
                if (isset($formatted_meta['mec_gallery_images'])) {
                    $candidates[] = $formatted_meta['mec_gallery_images'];
                }
                if (isset($formatted_meta['mec_images'])) {
                    $candidates[] = $formatted_meta['mec_images'];
                }
                // Modern Events Calendar commonly uses this key for event gallery
                if (isset($formatted_meta['mec_event_gallery'])) {
                    $candidates[] = $formatted_meta['mec_event_gallery'];
                }

                $ids = [];
                foreach ($candidates as $raw) {
                    $val = maybe_unserialize($raw);
                    if (is_array($val)) {
                        foreach ($val as $item) {
                            if (is_numeric($item)) {
                                $ids[] = (int)$item;
                            } elseif (is_array($item)) {
                                if (isset($item['id']) && is_numeric($item['id'])) {
                                    $ids[] = (int)$item['id'];
                                } elseif (isset($item['attachment_id']) && is_numeric($item['attachment_id'])) {
                                    $ids[] = (int)$item['attachment_id'];
                                }
                            } elseif (is_string($item) && preg_match('/^\d+(,\d+)*$/', $item)) {
                                $ids = array_merge($ids, array_map('intval', explode(',', $item)));
                            }
                        }
                    } elseif (is_string($val) && preg_match('/^\d+(,\d+)*$/', $val)) {
                        $ids = array_merge($ids, array_map('intval', explode(',', $val)));
                    } elseif (is_numeric($val)) {
                        $ids[] = (int)$val;
                    }
                }
                $ids = array_values(array_unique(array_filter($ids)));
                return $ids;
            };

            $gallery_ids = $extract_gallery_ids($formatted_meta);
            foreach ($gallery_ids as $att_id) {
                $file_url = \wp_get_attachment_url($att_id);
                if (!$file_url) {
                    continue;
                }
                $file_path = \get_attached_file($att_id);
                $size_bytes = ($file_path && file_exists($file_path)) ? filesize($file_path) : null;
                $images[] = [
                    'id' => (int)$att_id,
                    'name' => \get_the_title($att_id),
                    'size' => $size_bytes !== null ? $size_bytes : null,
                    'url' => $file_url,
                    'thumbnail' => \wp_get_attachment_image_url($att_id, 'thumbnail') ?: $file_url,
                    'medium' => \wp_get_attachment_image_url($att_id, 'medium') ?: $file_url,
                    'large' => \wp_get_attachment_image_url($att_id, 'large') ?: $file_url,
                    'full' => \wp_get_attachment_image_url($att_id, 'full') ?: $file_url,
                    'alt' => \get_post_meta($att_id, '_wp_attachment_image_alt', true) ?: '',
                    'caption' => \wp_get_attachment_caption($att_id) ?: '',
                ];
            }

            // Get tickets info
            $tickets_info = [];
            if (isset($formatted_meta['mec_tickets'])) {
                $tickets_data = maybe_unserialize($formatted_meta['mec_tickets']);
                if (is_array($tickets_data)) {
                    foreach ($tickets_data as $ticket_id => $ticket) {
                        $tickets_info[] = [
                            'id' => $ticket_id,
                            'name' => $ticket['name'] ?? '',
                            'price' => $ticket['price'] ?? '0',
                            'price_label' => $ticket['price_label'] ?? '',
                            'description' => $ticket['description'] ?? '',
                            'limit' => $ticket['limit'] ?? '0',
                            'minimum_ticket' => $ticket['minimum_ticket'] ?? '1',
                        ];
                    }
                }
            }

            // Get booking settings
            $booking_settings = [];
            if (isset($formatted_meta['mec_booking'])) {
                $booking_data = maybe_unserialize($formatted_meta['mec_booking']);
                if (is_array($booking_data)) {
                    $booking_settings = [
                        'enabled' => $booking_data['bookings_enabled'] ?? '0',
                        'limit' => $booking_data['bookings_limit'] ?? '0',
                        'limit_for_users' => $booking_data['bookings_limit_for_users'] ?? '0',
                        'user_limit' => $booking_data['bookings_user_limit'] ?? '0',
                        'form_id' => $booking_data['bookings_form_id'] ?? '',
                        'auto_confirm' => $booking_data['bookings_auto_confirm'] ?? '0',
                        'auto_verify' => $booking_data['bookings_auto_verify'] ?? '0',
                        'all_data' => $booking_data
                    ];
                }
            }

            // Get attendee count (only count valid attendees, exclude deleted/empty ones)
            $attendee_count = 0;
            if (class_exists('MecUtility\\Api\\AttendeesController')) {
                $attendees_controller = new AttendeesController();
                $bookings = $attendees_controller->get_event_bookings($event->ID);
                foreach ($bookings as $booking) {
                    $attendees = get_post_meta($booking->ID, 'mec_attendees', true);
                    if (is_array($attendees)) {
                        foreach ($attendees as $k => $attendee) {
                            // Only count numeric keys (exclude 'attachments' etc.) and validate attendee is not empty/deleted
                            if (is_numeric($k) && self::is_valid_attendee($attendee)) {
                                $attendee_count++;
                            }
                        }
                    }
                }
            }

            // Check if event is recurring
            $repeat_status = $formatted_meta['mec_repeat_status'] ?? '0';
            $is_recurring = ($repeat_status === '1');

            // Get repeat-related fields
            $repeat_type = $formatted_meta['mec_repeat_type'] ?? '';

            // Get advanced days
            $advanced_days = [];
            if ($repeat_type === 'advanced') {
                $advanced_days_meta = get_post_meta($event->ID, 'mec_advanced_days', true);
                if (is_array($advanced_days_meta)) {
                    $advanced_days = $advanced_days_meta;
                }
            }

            // Get certain weekdays
            $certain_weekdays = [];
            if ($repeat_type === 'certain_weekdays') {
                $certain_weekdays_meta = get_post_meta($event->ID, 'mec_certain_weekdays', true);
                if (is_array($certain_weekdays_meta)) {
                    $certain_weekdays = $certain_weekdays_meta;
                }
            }

            // Get custom days
            $custom_days = [];
            if ($repeat_type === 'custom_days') {
                $custom_days_meta = get_post_meta($event->ID, 'mec_in_days', true);
                if (!empty($custom_days_meta)) {
                    if (is_string($custom_days_meta)) {
                        $custom_days = array_filter(explode(',', $custom_days_meta));
                    } elseif (is_array($custom_days_meta)) {
                        $custom_days = $custom_days_meta;
                    }
                }
            }

            // Detect multi-day (continuous span) events (not recurring)
            $is_multiday = false;
            if (!empty($start_date) && !empty($end_date)) {
                $is_multiday = ($end_date > $start_date);
            }

            // Build occurrences array for either recurring or multi-day single event
            $occurrences = [];
            $start_date_param = $request->get_param('start_date');
            $occurrences_limit = $request->get_param('occurrences_limit') ?: 50;
            if ($is_recurring) {
                $occurrences = $this->get_event_occurrences($event->ID, $start_date_param, $occurrences_limit);
            } elseif ($is_multiday || (!empty($start_date) && !empty($end_date))) {
                // For non-recurring events, still provide a single/day-by-day occurrence list
                $occurrences = $this->get_multiday_occurrences($event->ID, $start_date_param, $occurrences_limit);
            }

            // Parse Custom Days meta (mec_in_days) into structured array and fallback occurrences
            $custom_days = [];
            $in_days_raw = isset($formatted_meta['mec_in_days']) ? (string)$formatted_meta['mec_in_days'] : '';
            if (!empty($in_days_raw)) {
                $segments = array_filter(array_map('trim', explode(',', $in_days_raw)));
                $parse_time_label = function ($label) {
                    // format like 04-00-AM
                    $parts = explode('-', $label);
                    if (count($parts) !== 3) {
                        return null;
                    }
                    $h = (int)$parts[0];
                    $m = (int)$parts[1];
                    $ampm = strtoupper($parts[2]) === 'PM' ? 'PM' : 'AM';
                    $h24 = ($ampm === 'PM' && $h != 12) ? $h + 12 : (($ampm === 'AM' && $h == 12) ? 0 : $h);
                    return [
                        'hour' => sprintf('%02d', $h),
                        'minute' => sprintf('%02d', $m),
                        'ampm' => $ampm,
                        'time_24' => sprintf('%02d:%02d:00', $h24, $m),
                    ];
                };
                foreach ($segments as $seg) {
                    $parts = explode(':', $seg);
                    if (count($parts) >= 2) {
                        $sd = $parts[0];
                        $ed = $parts[1];
                        $st = isset($parts[2]) ? $parse_time_label($parts[2]) : null;
                        $et = isset($parts[3]) ? $parse_time_label($parts[3]) : null;
                        $custom_days[] = [
                            'startDate' => $sd,
                            'endDate' => $ed,
                            'startTime' => $st ? ['hour' => $st['hour'], 'minute' => $st['minute'], 'ampm' => $st['ampm']] : null,
                            'endTime' => $et ? ['hour' => $et['hour'], 'minute' => $et['minute'], 'ampm' => $et['ampm']] : null,
                        ];
                        // If DB occurrences not generated, synthesize one for this range
                        if (empty($occurrences)) {
                            $st_ts = strtotime($sd . ' ' . ($st ? $st['time_24'] : '00:00:00'));
                            $et_ts = strtotime($ed . ' ' . ($et ? $et['time_24'] : '23:59:59'));
                            if ($st_ts && $et_ts) {
                                $current_time_ts = current_time('timestamp');
                                $occurrences[] = [
                                    'start_timestamp' => (string)$st_ts,
                                    'end_timestamp' => (string)$et_ts,
                                    'start_date' => date('Y-m-d', $st_ts),
                                    'end_date' => date('Y-m-d', $et_ts),
                                    'start_time' => date('H:i:s', $st_ts),
                                    'end_time' => date('H:i:s', $et_ts),
                                    'start_datetime' => date('Y-m-d H:i:s', $st_ts),
                                    'end_datetime' => date('Y-m-d H:i:s', $et_ts),
                                    'is_past' => $et_ts < $current_time_ts,
                                    'is_today' => date('Y-m-d', $st_ts) === date('Y-m-d', $current_time_ts),
                                    'is_upcoming' => $st_ts > $current_time_ts,
                                    'occurrence_id' => $event->ID . '_' . $st_ts,
                                    'params' => [],
                                    'title' => $this->clean_html_from_title(\get_the_title($event->ID)),
                                    'cost' => $formatted_meta['mec_cost'] ?? '',
                                    'location_id' => $formatted_meta['mec_location_id'] ?? '',
                                    'organizer_id' => $formatted_meta['mec_organizer_id'] ?? '',
                                    'event_status' => $formatted_meta['mec_event_status'] ?? 'EventScheduled',
                                    'bookings_limit' => '',
                                    'cancelled_reason' => '',
                                    'moved_online_link' => '',
                                    'attendees' => [
                                        'total_attendees' => 0,
                                        'attendees' => [],
                                        'booking_count' => 0,
                                    ],
                                ];
                            }
                        }
                    }
                }
            }

            // Complete event data response
            return array(
                'id' => $event->ID,
                'title' => $this->clean_html_from_title(\get_the_title($event->ID)),
                'content' => $event->post_content,
                'excerpt' => \get_the_excerpt($event->ID),
                'status' => $event->post_status,
                'visibility' => (function () use ($event) {
                    if ($event->post_status === 'private') {
                        return 'Private';
                    }
                    $pwd = isset($event->post_password) ? $event->post_password : '';
                    if (!empty($pwd)) {
                        return 'Password protected';
                    }
                    return 'Public';
                })(),
                'permalink' => \get_permalink($event->ID),
                'featured_image' => $featured_image_details ?: false,
                'images' => $images,
                'date_created' => $event->post_date,
                'date_modified' => $event->post_modified,
                'author' => $author_details,
                'location' => $location_details,
                'additional_locations' => $additional_locations,
                'organizer' => $organizer_details,
                'mec_data' => array(
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'start_time' => $start_time_seconds,
                    'end_time' => $end_time_seconds,
                    'start_time_formatted' => $start_time_formatted,
                    'end_time_formatted' => $end_time_formatted,
                    'start_time_hour' => $start_time_hour,
                    'start_time_minutes' => $start_time_minutes,
                    'start_time_ampm' => $start_time_ampm,
                    'end_time_hour' => $end_time_hour,
                    'end_time_minutes' => $end_time_minutes,
                    'end_time_ampm' => $end_time_ampm,
                    'allday' => $formatted_meta['mec_allday'] ?? '0',
                    'hide_time' => $formatted_meta['mec_hide_time'] ?? '0',
                    'hide_end_time' => $formatted_meta['mec_hide_end_time'] ?? '0',
                    // Reflect whether cost should auto-calculate from tickets (FES option)
                    'cost_auto_calculate' => (function () use ($formatted_meta) {
                        $val = isset($formatted_meta['mec_cost_auto_calculate']) ? $formatted_meta['mec_cost_auto_calculate'] : '0';
                        if (is_array($val)) {
                            $val = reset($val);
                        }
                        return ($val === '1' || $val === 1 || $val === true) ? '1' : '0';
                    })(),
                    // Return exact stored value as "0" or "1" for map visibility
                    'dont_show_map' => (function () use ($event, $formatted_meta) {
                        $val = \get_post_meta($event->ID, 'mec_dont_show_map', true);
                        if ($val === '' || $val === null) {
                            $val = isset($formatted_meta['dont_show_map']) ? $formatted_meta['dont_show_map'] : '0';
                        }
                        return ($val === '1' || $val === 1) ? '1' : '0';
                    })(),
                    'hide_location' => $formatted_meta['mec_hide_location'] ?? '0',
                    'timezone' => $formatted_meta['mec_timezone'] ?? 'global',
                    'comment' => $formatted_meta['mec_comment'] ?? '',
                    // MEC Visibility metabox fields
                    'public' => (function () use ($formatted_meta) {
                        $val = isset($formatted_meta['mec_public']) ? $formatted_meta['mec_public'] : true;
                        if (is_array($val)) {
                            $val = reset($val);
                        }
                        $bool = ($val === '1' || $val === 1 || $val === true || $val === 'true');
                        return $bool ? '1' : '0';
                    })(),
                    // Aliases to match UI wording
                    'visibility' => (function () use ($formatted_meta) {
                        $val = isset($formatted_meta['mec_public']) ? $formatted_meta['mec_public'] : true;
                        if (is_array($val)) {
                            $val = reset($val);
                        }
                        return ($val === '1' || $val === 1 || $val === true || $val === 'true');
                    })(),
                    'visibility_label' => (function () use ($formatted_meta) {
                        $val = isset($formatted_meta['mec_public']) ? $formatted_meta['mec_public'] : true;
                        if (is_array($val)) {
                            $val = reset($val);
                        }
                        $is_public = ($val === '1' || $val === 1 || $val === true || $val === 'true');
                        return $is_public ? 'Show on Shortcodes' : 'Hide on Shortcodes';
                    })(),
                    'style_per_event' => (function () use ($formatted_meta) {
                        $val = isset($formatted_meta['mec_style_per_event']) ? $formatted_meta['mec_style_per_event'] : 'global';
                        if (is_array($val)) {
                            $val = reset($val);
                        }
                        return (string)$val;
                    })(),
                    'details_page_style' => (function () use ($formatted_meta) {
                        $val = isset($formatted_meta['mec_style_per_event']) ? $formatted_meta['mec_style_per_event'] : 'global';
                        if (is_array($val)) {
                            $val = reset($val);
                        }
                        return (string)$val;
                    })(),
                    'repeat_status' => $repeat_status,
                    'repeat_type' => $formatted_meta['mec_repeat_type'] ?? '',
                    'repeat_interval' => $formatted_meta['mec_repeat_interval'] ?? null,
                    'repeat_end' => $formatted_meta['mec_repeat_end'] ?? 'never',
                    'repeat_end_at_date' => $formatted_meta['mec_repeat_end_at_date'] ?? '',
                    // MEC stores internally as -1, add +1 for display (UI expects displayed value)
                    'repeat_end_at_occurrences' => isset($formatted_meta['mec_repeat_end_at_occurrences']) ? (intval($formatted_meta['mec_repeat_end_at_occurrences']) + 1) : 10,
                    'cost' => $formatted_meta['mec_cost'] ?? '',
                    'location_id' => $formatted_meta['mec_location_id'] ?? '',
                    'organizer_id' => $formatted_meta['mec_organizer_id'] ?? '',
                    'event_status' => $formatted_meta['mec_event_status'] ?? 'EventScheduled',
                    'cancelled_reason' => $formatted_meta['mec_cancelled_reason'] ?? '',
                    'display_cancellation_reason_in_single_page' => isset($formatted_meta['mec_display_cancellation_reason_in_single_page']) && $formatted_meta['mec_display_cancellation_reason_in_single_page'] == '1',
                    'moved_online_link' => $formatted_meta['mec_moved_online_link'] ?? '',
                    'is_recurring' => $is_recurring,
                    'is_multiday' => $is_multiday,
                    'show_only_one_occurrence' => (!empty($formatted_meta['mec_show_only_one_occurrence']) && $formatted_meta['mec_show_only_one_occurrence'] == '1') || (!empty($formatted_meta['one_occurrence']) && $formatted_meta['one_occurrence'] == '1'),
                    'custom_days' => $custom_days,
                    'advanced_days' => $advanced_days,
                    'certain_weekdays' => $certain_weekdays,
                ),
                'hourly_schedules' => (function () use ($formatted_meta) {
                    $hourly_schedules_raw = isset($formatted_meta['mec_hourly_schedules']) ? maybe_unserialize($formatted_meta['mec_hourly_schedules']) : [];
                    if (!is_array($hourly_schedules_raw)) {
                        return [];
                    }
                    return $hourly_schedules_raw;
                })(),
                'booking' => $booking_settings,
                'tickets' => $tickets_info,
                'categories' => $format_terms($categories ?: []),
                'speakers' => $format_terms($speakers ?: []),
                'sponsors' => $format_terms($sponsors ?: []),
                'labels' => $format_terms($labels ?: []),
                'tags' => $format_terms($tags ?: []),
                'occurrences' => $occurrences,
                'occurrences_count' => count($occurrences),
                'formatted_dates' => array(
                    'start_date_formatted' => $start_date . ' ' . sprintf(
                        '%02d:%02d:%02d',
                        ($start_time_ampm === 'PM' && $start_time_hour != 12) ? $start_time_hour + 12 : (($start_time_ampm === 'AM' && $start_time_hour == 12) ? 0 : $start_time_hour),
                        $start_time_minutes,
                        0
                    ),
                    'end_date_formatted' => $end_date . ' ' . sprintf(
                        '%02d:%02d:%02d',
                        ($end_time_ampm === 'PM' && $end_time_hour != 12) ? $end_time_hour + 12 : (($end_time_ampm === 'AM' && $end_time_hour == 12) ? 0 : $end_time_hour),
                        $end_time_minutes,
                        0
                    ),
                ),
                'zoom' => $this->get_zoom_meta($event->ID),
                'virtual_event' => $this->get_virtual_event_meta($event->ID),
                'entity_type' => $this->get_entity_type_meta($event->ID),
                'appointments' => $this->get_appointments_meta($event->ID),
                'meta' => $formatted_meta,
                'raw_mec_data' => $mec_data,
                'attendee_count' => $attendee_count,
            );
        } catch (Exception $e) {
            return new WP_Error(
                'mec_utility_event_prepare_error',
                __('Unable to prepare event data.', 'mec-utility'),
                array('status' => 500)
            );
        }
    }

    /**
     * Prepare item for database
     */
    protected function prepare_item_for_database($request)
    {
        $prepared_post = array();

        if (isset($request['title'])) {
            $prepared_post['post_title'] = \sanitize_text_field($request['title']);
        }

        // Support both 'content' and README's 'description'
        if (isset($request['content'])) {
            $prepared_post['post_content'] = \wp_kses_post($request['content']);
        } elseif (isset($request['description'])) {
            $prepared_post['post_content'] = \wp_kses_post($request['description']);
        }

        if (isset($request['excerpt'])) {
            $prepared_post['post_excerpt'] = \sanitize_textarea_field($request['excerpt']);
        }

        // Map README's status/visibility to WP post_status
        if (isset($request['status'])) {
            $status = $request['status'];
            if ($status === 'Published') {
                $prepared_post['post_status'] = 'publish';
            } elseif ($status === 'Draft') {
                $prepared_post['post_status'] = 'draft';
            } elseif ($status === 'Pending Review' || $status === 'pending') {
                $prepared_post['post_status'] = 'pending';
            } else {
                $prepared_post['post_status'] = \sanitize_key($status);
            }
        }

        // Visibility mapping: Public | Private | Password protected
        if (isset($request['visibility'])) {
            $visibility = $request['visibility'];
            if ($visibility === 'Private') {
                $prepared_post['post_status'] = 'private';
            } elseif ($visibility === 'Password protected') {
                $prepared_post['post_status'] = 'publish'; // WP uses publish with password for protection
                if (isset($request['post_password'])) {
                    $prepared_post['post_password'] = (string)$request['post_password'];
                }
            } else {
                // Public
                $prepared_post['post_password'] = '';
            }
        }

        $prepared_post['post_type'] = 'mec-events';

        return $prepared_post;
    }

    /**
     * Update event meta
     */
    protected function update_event_meta($event_id, $request)
    {
        // Helper to read nested values like advancedSettings.*
        $get_nested = function ($array, $path, $default = null) {
            $cursor = $array;
            foreach ($path as $key) {
                if (!is_array($cursor) || !array_key_exists($key, $cursor)) {
                    return $default;
                }
                $cursor = $cursor[$key];
            }
            return $cursor;
        };

        // Handle time fields: support README's HH:mm and isAllDay
        $is_all_day = isset($request['isAllDay']) ? (bool)$request['isAllDay'] : (isset($request['allday']) ? (bool)$request['allday'] : false);

        // Defaults if nothing provided
        $start_time_hour = 8;
        $start_time_minutes = 0;
        $start_time_ampm = 'AM';
        $end_time_hour = 6;
        $end_time_minutes = 0;
        $end_time_ampm = 'PM';

        if (isset($request['startTime']) && is_string($request['startTime'])) {
            // Expect HH:mm 24h
            $parts = explode(':', $request['startTime']);
            if (count($parts) === 2) {
                $h24 = (int)$parts[0];
                $m = (int)$parts[1];
                $start_time_ampm = $h24 >= 12 ? 'PM' : 'AM';
                $start_time_hour = $h24 % 12;
                if ($start_time_hour === 0) {
                    $start_time_hour = 12;
                }
                $start_time_minutes = $m;
            }
        } elseif (isset($request['start_time_hour'])) {
            $start_time_hour = intval($request['start_time_hour']);
            $start_time_minutes = isset($request['start_time_minutes']) ? intval($request['start_time_minutes']) : 0;
            $start_time_ampm = isset($request['start_time_ampm']) ? strtoupper($request['start_time_ampm']) : 'AM';
        }

        if (isset($request['endTime']) && is_string($request['endTime'])) {
            $parts = explode(':', $request['endTime']);
            if (count($parts) === 2) {
                $h24 = (int)$parts[0];
                $m = (int)$parts[1];
                $end_time_ampm = $h24 >= 12 ? 'PM' : 'AM';
                $end_time_hour = $h24 % 12;
                if ($end_time_hour === 0) {
                    $end_time_hour = 12;
                }
                $end_time_minutes = $m;
            }
        } elseif (isset($request['end_time_hour'])) {
            $end_time_hour = intval($request['end_time_hour']);
            $end_time_minutes = isset($request['end_time_minutes']) ? intval($request['end_time_minutes']) : 0;
            $end_time_ampm = isset($request['end_time_ampm']) ? strtoupper($request['end_time_ampm']) : 'PM';
        }

        if ($is_all_day) {
            // Normalize to full-day defaults
            $start_time_hour = 12;
            $start_time_minutes = 0;
            $start_time_ampm = 'AM';
            $end_time_hour = 11;
            $end_time_minutes = 59;
            $end_time_ampm = 'PM';
        }

        $day_start_seconds = $this->time_to_seconds($start_time_hour, $start_time_minutes, $start_time_ampm);
        $day_end_seconds = $this->time_to_seconds($end_time_hour, $end_time_minutes, $end_time_ampm);

        // Create MEC date array
        // Support README's startDate/endDate in addition to existing keys
        $start_date = isset($request['start_date']) ? \sanitize_text_field($request['start_date']) : (isset($request['startDate']) ? \sanitize_text_field($request['startDate']) : \date('Y-m-d'));
        $end_date = isset($request['end_date']) ? \sanitize_text_field($request['end_date']) : (isset($request['endDate']) ? \sanitize_text_field($request['endDate']) : $start_date);

        $date_array = array(
            'start' => array(
                'date' => $start_date,
                'hour' => $start_time_hour,
                'minutes' => $start_time_minutes,
                'ampm' => $start_time_ampm,
            ),
            'end' => array(
                'date' => $end_date,
                'hour' => $end_time_hour,
                'minutes' => $end_time_minutes,
                'ampm' => $end_time_ampm,
            ),
            'allday' => $is_all_day,
            // Map advancedSettings.hideEventTime / hideEventEndTime, fall back to existing keys
            'hide_time' => $get_nested($request, array('advancedSettings', 'hideEventTime'), isset($request['hide_time']) ? (bool)$request['hide_time'] : false) ? true : false,
            'hide_end_time' => $get_nested($request, array('advancedSettings', 'hideEventEndTime'), isset($request['hide_end_time']) ? (bool)$request['hide_end_time'] : false) ? true : false,
            // Map advancedSettings.timeNotes to comment
            'comment' => $get_nested($request, array('advancedSettings', 'timeNotes'), isset($request['comment']) ? \sanitize_text_field($request['comment']) : ''),
        );

        // Basic event meta
        \update_post_meta($event_id, 'mec_location_id', isset($request['location_id']) ? intval($request['location_id']) : '');
        \update_post_meta($event_id, 'mec_organizer_id', isset($request['organizer_id']) ? intval($request['organizer_id']) : '');
        \update_post_meta($event_id, 'mec_cost', isset($request['cost']) ? \sanitize_text_field($request['cost']) : '');
        // Cost auto calculate flag (Show the minimum price based on tickets)
        $cost_auto_calc = $get_nested($request, array('advancedSettings', 'costAutoCalculate'), isset($request['cost_auto_calculate']) ? (bool)$request['cost_auto_calculate'] : null);
        if ($cost_auto_calc !== null) {
            \update_post_meta($event_id, 'mec_cost_auto_calculate', (bool)$cost_auto_calc ? '1' : '0');
        } else if (isset($request['show_minimum_price'])) {
            \update_post_meta($event_id, 'mec_cost_auto_calculate', (bool)$request['show_minimum_price'] ? '1' : '0');
        } else if (isset($request['mec_data']['show_minimum_price'])) {
            \update_post_meta($event_id, 'mec_cost_auto_calculate', (bool)$request['mec_data']['show_minimum_price'] ? '1' : '0');
        }
        // Event Status Schema
        // Read from REST request JSON/body safely
        if ($request instanceof WP_REST_Request) {
            $raw_event_status = $request->get_param('event_status');
        } else {
            $raw_event_status = isset($request['event_status']) ? $request['event_status'] : null;
        }
        $event_status = $raw_event_status ? \sanitize_text_field($raw_event_status) : 'EventScheduled';
        $valid_statuses = array('EventScheduled', 'EventRescheduled', 'EventPostponed', 'EventCancelled', 'EventMovedOnline');
        if (!in_array($event_status, $valid_statuses)) {
            $event_status = 'EventScheduled';
        }
        \update_post_meta($event_id, 'mec_event_status', $event_status);

        // Cancelled Reason (for EventCancelled status)
        if ($event_status === 'EventCancelled') {
            if ($request instanceof WP_REST_Request) {
                $raw_cancelled_reason = $request->get_param('cancelled_reason');
                $raw_display_cancellation = $request->get_param('display_cancellation_reason_in_single_page');
            } else {
                $raw_cancelled_reason = isset($request['cancelled_reason']) ? $request['cancelled_reason'] : null;
                $raw_display_cancellation = isset($request['display_cancellation_reason_in_single_page']) ? $request['display_cancellation_reason_in_single_page'] : null;
            }

            $cancelled_reason = $raw_cancelled_reason ? \sanitize_text_field($raw_cancelled_reason) : '';
            \update_post_meta($event_id, 'mec_cancelled_reason', $cancelled_reason);

            $display_cancellation_in_single = $raw_display_cancellation !== null ? (bool)$raw_display_cancellation : false;
            \update_post_meta($event_id, 'mec_display_cancellation_reason_in_single_page', $display_cancellation_in_single ? '1' : '0');
        } else {
            // Clear cancelled data if status is not cancelled
            \delete_post_meta($event_id, 'mec_cancelled_reason');
            \delete_post_meta($event_id, 'mec_display_cancellation_reason_in_single_page');
        }

        // Moved Online Link (for EventMovedOnline status)
        if ($event_status === 'EventMovedOnline') {
            if ($request instanceof WP_REST_Request) {
                $raw_moved_online_link = $request->get_param('moved_online_link');
            } else {
                $raw_moved_online_link = isset($request['moved_online_link']) ? $request['moved_online_link'] : null;
            }
            $moved_online_link = $raw_moved_online_link ? \sanitize_url($raw_moved_online_link) : '';
            \update_post_meta($event_id, 'mec_moved_online_link', $moved_online_link);
        } else {
            // Clear moved online link if status is not moved online
            \delete_post_meta($event_id, 'mec_moved_online_link');
        }

        // Date and time meta
        \update_post_meta($event_id, 'mec_date', $date_array);
        // Persist all-day flag for downstream consumers
        \update_post_meta($event_id, 'mec_allday', $is_all_day ? '1' : '0');
        \update_post_meta($event_id, 'mec_start_date', $start_date);
        \update_post_meta($event_id, 'mec_end_date', $end_date);
        \update_post_meta($event_id, 'mec_start_time_hour', $start_time_hour);
        \update_post_meta($event_id, 'mec_start_time_minutes', $start_time_minutes);
        \update_post_meta($event_id, 'mec_start_time_ampm', $start_time_ampm);
        \update_post_meta($event_id, 'mec_start_day_seconds', $day_start_seconds);
        \update_post_meta($event_id, 'mec_end_time_hour', $end_time_hour);
        \update_post_meta($event_id, 'mec_end_time_minutes', $end_time_minutes);
        \update_post_meta($event_id, 'mec_end_time_ampm', $end_time_ampm);
        \update_post_meta($event_id, 'mec_end_day_seconds', $day_end_seconds);

        // Time visibility options
        $hide_time = isset($request['hide_time']) ? (bool)$request['hide_time'] : false;
        $hide_end_time = isset($request['hide_end_time']) ? (bool)$request['hide_end_time'] : false;
        $comment = isset($request['comment']) ? \sanitize_text_field($request['comment']) : '';
        
        \update_post_meta($event_id, 'mec_hide_time', $hide_time ? '1' : '0');
        \update_post_meta($event_id, 'mec_hide_end_time', $hide_end_time ? '1' : '0');
        \update_post_meta($event_id, 'mec_comment', $comment);

        // Ensure primary location/organizer taxonomy terms reflect provided IDs
        if (isset($request['location_id'])) {
            $__loc_id = intval($request['location_id']);
            if ($__loc_id) {
                \wp_set_object_terms($event_id, (int)$__loc_id, 'mec_location');
            }
        }
        if (isset($request['organizer_id'])) {
            $__org_id = intval($request['organizer_id']);
            if ($__org_id) {
                \wp_set_object_terms($event_id, (int)$__org_id, 'mec_organizer');
            }
        }

        // Event color (advancedSettings.eventColor)
        $event_color = $get_nested($request, array('advancedSettings', 'eventColor'), isset($request['color']) ? $request['color'] : '');
        \update_post_meta($event_id, 'mec_color', $event_color ? \sanitize_text_field($event_color) : '');

        // Links section mapping from advancedSettings
        $event_link = $get_nested($request, array('advancedSettings', 'eventLink'), isset($request['read_more']) ? $request['read_more'] : '');
        $more_info = $get_nested($request, array('advancedSettings', 'moreInfoLink'), isset($request['more_info']) ? $request['more_info'] : '');
        $link_target_label = $get_nested($request, array('advancedSettings', 'linkTarget'), isset($request['more_info_target']) ? $request['more_info_target'] : '');
        \update_post_meta($event_id, 'mec_read_more', $event_link ? \sanitize_text_field($event_link) : '');
        \update_post_meta($event_id, 'mec_more_info', $more_info ? \sanitize_text_field($more_info) : '');
        \update_post_meta($event_id, 'mec_more_info_title', isset($request['more_info_title']) ? \sanitize_text_field($request['more_info_title']) : '');
        if ($link_target_label) {
            // Normalize human-readable labels like "Current Window" / "New Window"
            $normalized_target = $this->normalize_more_info_target($link_target_label);
            \update_post_meta($event_id, 'mec_more_info_target', $normalized_target);
        }

        // Direct Event Link support
        if (isset($request['event_link'])) {
            \update_post_meta($event_id, 'mec_read_more', \sanitize_text_field($request['event_link']));
        }

        // Additional settings
        \update_post_meta($event_id, 'mec_timezone', isset($request['timezone']) ? \sanitize_text_field($request['timezone']) : '');
        \update_post_meta($event_id, 'mec_trailer_url', isset($request['trailer_url']) ? \sanitize_text_field($request['trailer_url']) : '');
        \update_post_meta($event_id, 'mec_trailer_title', isset($request['trailer_title']) ? \sanitize_text_field($request['trailer_title']) : '');
        // Visibility from README (Public | Private) -> also save mec_public boolean for downstream usage
        $visibility = isset($request['visibility']) ? $request['visibility'] : null;
        $public_value = true; // default
        if ($visibility) {
            $public_value = ($visibility === 'Public');
        } else if (isset($request['public'])) {
            $public_value = (bool)$request['public'];
        } else if (isset($request['show_on_shortcodes'])) {
            $public_value = (bool)$request['show_on_shortcodes'];
        } else if (isset($request['mec_data']['visibility'])) {
            $public_value = (bool)$request['mec_data']['visibility'];
        } else if (isset($request['advancedSettings']['visibility']['showOnShortcodes'])) {
            $public_value = (bool)$request['advancedSettings']['visibility']['showOnShortcodes'];
        } else if (isset($request['hide_on_shortcodes'])) {
            $public_value = !(bool)$request['hide_on_shortcodes'];
        }
        \update_post_meta($event_id, 'mec_public', $public_value);
        \update_post_meta($event_id, 'mec_note', isset($request['note']) ? \sanitize_text_field($request['note']) : '');
        \update_post_meta($event_id, 'mec_countdown_method', isset($request['countdown_method']) ? \sanitize_text_field($request['countdown_method']) : '');
        // Map advancedSettings.visibility.detailsPageStyle
        $details_page_style = $get_nested($request, array('advancedSettings', 'visibility', 'detailsPageStyle'), isset($request['style_per_event']) ? $request['style_per_event'] : '');
        \update_post_meta($event_id, 'mec_style_per_event', $details_page_style ? \sanitize_text_field($details_page_style) : '');
        \update_post_meta($event_id, 'mec_dl_file', isset($request['downloadable_file']) ? \sanitize_text_field($request['downloadable_file']) : '');

        // Don't show map in single event page
        $dont_show_map = $get_nested($request, array('advancedSettings', 'dontShowMap'), null);
        if ($dont_show_map !== null) {
            \update_post_meta($event_id, 'mec_dont_show_map', (bool)$dont_show_map ? '1' : '0');
        } else if (isset($request['dont_show_map'])) {
            \update_post_meta($event_id, 'mec_dont_show_map', (bool)$request['dont_show_map'] ? '1' : '0');
        }

        // Hide Location flag (UI: advancedSettings.hideLocation)
        $hide_location = $get_nested($request, array('advancedSettings', 'hideLocation'), null);
        if ($hide_location !== null) {
            \update_post_meta($event_id, 'mec_hide_location', (bool)$hide_location ? '1' : '0');
        } else if (isset($request['hide_location'])) {
            \update_post_meta($event_id, 'mec_hide_location', (bool)$request['hide_location'] ? '1' : '0');
        }

        // Map showOnlyOneOccurrence
        $show_one = $get_nested($request, array('advancedSettings', 'showOnlyOneOccurrence'), null);
        if ($show_one !== null) {
            \update_post_meta($event_id, 'mec_show_only_one_occurrence', (bool)$show_one);
        }

        // Handle Repeat Options
        $this->handle_repeat_options($event_id, $request);

        // Handle featured image (mec_image) - accepts both URL and attachment ID
        $featured_image = $get_nested($request, array('advancedSettings', 'mec_image'), isset($request['featured_image']) ? $request['featured_image'] : '');
        if ($featured_image) {
            $attachment_id = null;
            
            // Check if it's a numeric ID
            if (is_numeric($featured_image)) {
                $attachment_id = (int)$featured_image;
                $image_url = \wp_get_attachment_url($attachment_id);
                if ($image_url) {
                    \update_post_meta($event_id, 'mec_image', $image_url);
                    \set_post_thumbnail($event_id, $attachment_id);
                }
            } 
            // Check if it's a URL
            elseif (is_string($featured_image) && filter_var($featured_image, FILTER_VALIDATE_URL)) {
                \update_post_meta($event_id, 'mec_image', \sanitize_text_field($featured_image));
                $attachment_id = \attachment_url_to_postid($featured_image);
                if ($attachment_id) {
                    \set_post_thumbnail($event_id, $attachment_id);
                }
            }
        }

        // Handle gallery images (mec_event_gallery) - accepts both URLs and attachment IDs
        $gallery_images = $get_nested($request, array('advancedSettings', 'mec_gallery'), isset($request['images']) ? $request['images'] : null);
        if ($gallery_images && is_array($gallery_images)) {
            // Convert URLs and IDs to attachment IDs
            $gallery_ids = [];
            foreach ($gallery_images as $image) {
                // If it's already a numeric ID
                if (is_numeric($image)) {
                    $id = (int)$image;
                    // Verify it's a valid attachment
                    if (\wp_get_attachment_url($id)) {
                        $gallery_ids[] = $id;
                    }
                } 
                // If it's a URL
                elseif (is_string($image) && filter_var($image, FILTER_VALIDATE_URL)) {
                    $attachment_id = \attachment_url_to_postid($image);
                    if ($attachment_id) {
                        $gallery_ids[] = $attachment_id;
                    }
                }
            }

            if (!empty($gallery_ids)) {
                // MEC uses mec_event_gallery for gallery images
                \update_post_meta($event_id, 'mec_event_gallery', $gallery_ids);
                // Also update mec_gallery for backward compatibility
                \update_post_meta($event_id, 'mec_gallery', $gallery_ids);
            }
        }

        // Taxonomies: tags, categories, speakers - handle both direct and nested formats
        // Use MEC's taxonomy tag filter (defaults to 'post_tag' if no custom taxonomy is set)
        $tag_taxonomy = apply_filters('mec_taxonomy_tag', 'post_tag');
        
        $tags = $get_nested($request, array('advancedSettings', 'tags'), null);
        if (is_array($tags)) {
            // Handle mixed array of IDs and names for tags
            $tag_ids = [];
            foreach ($tags as $tag) {
                if (is_numeric($tag)) {
                    $tag_ids[] = (int)$tag;
                } else if (is_string($tag) && !empty(trim($tag))) {
                    $tag_name = trim($tag);
                    $existing_tag = \get_term_by('name', $tag_name, $tag_taxonomy);
                    if ($existing_tag && !is_wp_error($existing_tag)) {
                        $tag_ids[] = $existing_tag->term_id;
                    } else {
                        // Create new tag
                        $new_tag = \wp_insert_term($tag_name, $tag_taxonomy);
                        if (!is_wp_error($new_tag)) {
                            $tag_ids[] = $new_tag['term_id'];
                        }
                    }
                }
            }
            if (!empty($tag_ids)) {
                \wp_set_object_terms($event_id, $tag_ids, $tag_taxonomy);
            }
        } else if (isset($request['mec_tag']) && is_array($request['mec_tag'])) {
            // Handle mixed array of IDs and names for tags
            $tag_ids = [];
            foreach ($request['mec_tag'] as $tag) {
                if (is_numeric($tag)) {
                    $tag_ids[] = (int)$tag;
                } else if (is_string($tag) && !empty(trim($tag))) {
                    $tag_name = trim($tag);
                    $existing_tag = \get_term_by('name', $tag_name, $tag_taxonomy);
                    if ($existing_tag && !is_wp_error($existing_tag)) {
                        $tag_ids[] = $existing_tag->term_id;
                    } else {
                        // Create new tag
                        $new_tag = \wp_insert_term($tag_name, $tag_taxonomy);
                        if (!is_wp_error($new_tag)) {
                            $tag_ids[] = $new_tag['term_id'];
                        }
                    }
                }
            }
            if (!empty($tag_ids)) {
                \wp_set_object_terms($event_id, $tag_ids, $tag_taxonomy);
            }
        } else if (isset($request['tags']) && is_array($request['tags'])) {
            // Handle 'tags' alias for 'mec_tag'
            $tag_ids = [];
            foreach ($request['tags'] as $tag) {
                if (is_numeric($tag)) {
                    $tag_ids[] = (int)$tag;
                } else if (is_string($tag) && !empty(trim($tag))) {
                    $tag_name = trim($tag);
                    $existing_tag = \get_term_by('name', $tag_name, $tag_taxonomy);
                    if ($existing_tag && !is_wp_error($existing_tag)) {
                        $tag_ids[] = $existing_tag->term_id;
                    } else {
                        // Create new tag
                        $new_tag = \wp_insert_term($tag_name, $tag_taxonomy);
                        if (!is_wp_error($new_tag)) {
                            $tag_ids[] = $new_tag['term_id'];
                        }
                    }
                }
            }
            if (!empty($tag_ids)) {
                \wp_set_object_terms($event_id, $tag_ids, $tag_taxonomy);
            }
        }

        $categories = $get_nested($request, array('advancedSettings', 'categories'), null);
        if (is_array($categories)) {
            \wp_set_object_terms($event_id, array_map('sanitize_text_field', $categories), 'mec_category');
        } else if (isset($request['mec_category']) && is_array($request['mec_category'])) {
            \wp_set_object_terms($event_id, array_map('intval', $request['mec_category']), 'mec_category');
        }

        $speakers = $get_nested($request, array('advancedSettings', 'speakers'), null);
        if (is_array($speakers)) {
            \wp_set_object_terms($event_id, array_map('sanitize_text_field', $speakers), 'mec_speaker');
        } else if (isset($request['mec_speaker']) && is_array($request['mec_speaker'])) {
            \wp_set_object_terms($event_id, array_map('intval', $request['mec_speaker']), 'mec_speaker');
        }

        $labels = $get_nested($request, array('advancedSettings', 'eventLabels'), null);
        if (is_array($labels)) {
            \wp_set_object_terms($event_id, array_map('intval', $labels), 'mec_label');
        } else if (isset($request['event_labels']) && is_array($request['event_labels'])) {
            \wp_set_object_terms($event_id, array_map('intval', $request['event_labels']), 'mec_label');
        } else if (isset($request['mec_label']) && is_array($request['mec_label'])) {
            \wp_set_object_terms($event_id, array_map('intval', $request['mec_label']), 'mec_label');
        } else {
            // If no labels provided, clear all labels
            \wp_set_object_terms($event_id, [], 'mec_label');
        }

        // Additional Locations (Other Locations): accept array of IDs
        $other_locations = $get_nested($request, array('advancedSettings', 'otherLocations'), null);
        if (is_array($other_locations)) {
            $ids = array_values(array_unique(array_filter(array_map('intval', $other_locations))));
            \update_post_meta($event_id, 'mec_additional_location_ids', $ids);
        } else if (isset($request['otherLocations']) && is_array($request['otherLocations'])) {
            $ids = array_values(array_unique(array_filter(array_map('intval', $request['otherLocations']))));
            \update_post_meta($event_id, 'mec_additional_location_ids', $ids);
        } else if (isset($request['otherLocationIds']) && is_array($request['otherLocationIds'])) {
            $ids = array_values(array_unique(array_filter(array_map('intval', $request['otherLocationIds']))));
            \update_post_meta($event_id, 'mec_additional_location_ids', $ids);
        }

        // Repeats mapping (Recurring) - Support both nested structure and direct advancedSettings
        $repeats = $get_nested($request, array('advancedSettings', 'repeats'), null);
        $repeat_enabled = false;

        // Check for direct repeat settings in advancedSettings first
        $repeat_status = $get_nested($request, array('advancedSettings', 'mec_repeat_status'), null);
        $repeat_type = $get_nested($request, array('advancedSettings', 'mec_repeat_type'), null);
        $repeat_interval = $get_nested($request, array('advancedSettings', 'mec_repeat_interval'), null);
        $repeat_end = $get_nested($request, array('advancedSettings', 'mec_repeat_end'), null);
        $repeat_end_at_date = $get_nested($request, array('advancedSettings', 'mec_repeat_end_at_date'), null);
        $repeat_end_at_occurrences = $get_nested($request, array('advancedSettings', 'mec_repeat_end_at_occurrences'), null);
        $advanced_days = $get_nested($request, array('advancedSettings', 'mec_advanced_days'), null);
        $certain_weekdays = $get_nested($request, array('advancedSettings', 'mec_repeat_days'), null);
        $custom_days = $get_nested($request, array('advancedSettings', 'mec_custom_days'), null);

        // Also check mec_data for repeat settings
        if ($repeat_status === null && isset($request['mec_data']) && is_array($request['mec_data'])) {
            $mec_data = $request['mec_data'];
            $repeat_status = $mec_data['repeat_status'] ?? null;
            $repeat_type = $mec_data['repeat_type'] ?? null;
            $repeat_interval = $mec_data['repeat_interval'] ?? null;
            $repeat_end = $mec_data['repeat_end'] ?? null;
            $repeat_end_at_date = $mec_data['repeat_end_at_date'] ?? null;
            $repeat_end_at_occurrences = $mec_data['repeat_end_at_occurrences'] ?? null;
            $custom_days = $mec_data['custom_days'] ?? null;
            $advanced_days = $mec_data['advanced_days'] ?? null;
            $certain_weekdays = $mec_data['repeat_days'] ?? null;
        }

        if ($repeat_status !== null) {
            $repeat_enabled = ($repeat_status === '1' || $repeat_status === 1);
            \update_post_meta($event_id, 'mec_repeat_status', $repeat_enabled ? '1' : '0');

            if ($repeat_enabled) {
                // Direct repeat type
                if ($repeat_type) {
                    \update_post_meta($event_id, 'mec_repeat_type', \sanitize_text_field($repeat_type));
                }

                // Direct repeat interval
                if ($repeat_interval) {
                    $interval = (int)$repeat_interval;
                    if ($repeat_type === 'weekly') {
                        $interval = max(1, $interval) * 7;
                    }
                    \update_post_meta($event_id, 'mec_repeat_interval', $interval);
                }

                // Direct certain weekdays
                if ($repeat_type === 'certain_weekdays' && is_array($certain_weekdays)) {
                    $days_nums = array_map('intval', $certain_weekdays);
                    \update_post_meta($event_id, 'mec_certain_weekdays', $days_nums);
                }

                // Direct custom days
                if ($repeat_type === 'custom_days' && is_array($custom_days)) {
                    \update_post_meta($event_id, 'mec_in_days', $custom_days);
                }

                // Direct advanced days
                if ($repeat_type === 'advanced' && is_array($advanced_days)) {
                    $advanced_str = implode(',', $advanced_days);
                    \update_post_meta($event_id, 'mec_advanced_days', $advanced_days);
                    \update_post_meta($event_id, 'mec_repeat_advanced', $advanced_str);
                }

                // Direct repeat end settings
                if ($repeat_end) {
                    \update_post_meta($event_id, 'mec_repeat_end', \sanitize_text_field($repeat_end));
                }
                if ($repeat_end_at_date !== null) {
                    \update_post_meta($event_id, 'mec_repeat_end_at_date', \sanitize_text_field($repeat_end_at_date));
                }
                if ($repeat_end_at_occurrences !== null) {
                    // MEC stores occurrences as (user_input - 1) internally
                    \update_post_meta($event_id, 'mec_repeat_end_at_occurrences', max(0, intval($repeat_end_at_occurrences) - 1));
                }
            }
        } elseif (is_array($repeats)) {
            $repeat_enabled = !empty($repeats['enabled']);
            \update_post_meta($event_id, 'mec_repeat_status', $repeat_enabled ? '1' : '0');

            if ($repeat_enabled) {
                // Frequency/type mapping
                $freq_map = array(
                    'Daily' => 'daily',
                    'Every Weekday' => 'weekday',
                    'Every Weekend' => 'weekend',
                    'Certain Weekdays' => 'certain_weekdays',
                    'Weekly' => 'weekly',
                    'Monthly' => 'monthly',
                    'Yearly' => 'yearly',
                    'Custom Days' => 'custom_days',
                    'Advanced' => 'advanced',
                );
                $repeat_type = isset($repeats['frequency']) && isset($freq_map[$repeats['frequency']]) ? $freq_map[$repeats['frequency']] : null;
                if ($repeat_type) {
                    \update_post_meta($event_id, 'mec_repeat_type', $repeat_type);
                }

                // Interval: MEC stores weekly as days (7 * interval), others as provided
                if (isset($repeats['interval']) && is_numeric($repeats['interval'])) {
                    $interval = (int)$repeats['interval'];
                    if ($repeat_type === 'weekly') {
                        $interval = max(1, $interval) * 7;
                    }
                    \update_post_meta($event_id, 'mec_repeat_interval', $interval);
                }

                // Certain weekdays mapping
                if ($repeat_type === 'certain_weekdays' && isset($repeats['weekdays']) && is_array($repeats['weekdays'])) {
                    $weekday_map = array(
                        'monday' => 1,
                        'tuesday' => 2,
                        'wednesday' => 3,
                        'thursday' => 4,
                        'friday' => 5,
                        'saturday' => 6,
                        'sunday' => 7,
                        'mon' => 1,
                        'tue' => 2,
                        'wed' => 3,
                        'thu' => 4,
                        'fri' => 5,
                        'sat' => 6,
                        'sun' => 7,
                    );
                    $days_nums = array();
                    foreach ($repeats['weekdays'] as $day_key) {
                        $key = strtolower(trim($day_key));
                        if (isset($weekday_map[$key])) {
                            $days_nums[] = $weekday_map[$key];
                        }
                    }
                    $days_nums = array_values(array_unique($days_nums));
                    \update_post_meta($event_id, 'mec_repeat_certain_weekdays', $days_nums);
                }

                // Custom Days -> mec_in_days
                if ($repeat_type === 'custom_days' && isset($repeats['customDays']) && is_array($repeats['customDays'])) {
                    $in_days = array();
                    foreach ($repeats['customDays'] as $cd) {
                        if (empty($cd['startDate']) || empty($cd['endDate'])) {
                            continue;
                        }
                        $start = \sanitize_text_field($cd['startDate']);
                        $end = \sanitize_text_field($cd['endDate']);
                        $seg = $start . ':' . $end;
                        $fmt_time = function ($t) {
                            if (!is_array($t)) return '';
                            $hour = isset($t['hour']) ? (string)$t['hour'] : '';
                            $minute = isset($t['minute']) ? (string)$t['minute'] : '';
                            $ampm = isset($t['ampm']) ? strtoupper($t['ampm']) : '';
                            if ($hour === '' || $minute === '' || $ampm === '') return '';
                            return sprintf('%02d-%02d-%s', (int)$hour, (int)$minute, $ampm);
                        };
                        $st = $fmt_time(isset($cd['startTime']) ? $cd['startTime'] : null);
                        $et = $fmt_time(isset($cd['endTime']) ? $cd['endTime'] : null);
                        if ($st !== '') {
                            $seg .= ':' . $st;
                        }
                        if ($et !== '') {
                            $seg .= ':' . $et;
                        }
                        $in_days[] = $seg;
                    }
                    \update_post_meta($event_id, 'mec_in_days', $in_days);
                }

                // Advanced repeats -> mec_repeat_advanced string
                if ($repeat_type === 'advanced' && isset($repeats['advanced']) && is_array($repeats['advanced'])) {
                    $weeks = isset($repeats['advanced']['weeks']) && is_array($repeats['advanced']['weeks']) ? $repeats['advanced']['weeks'] : array();
                    $week_to_key = array('first' => '1', 'second' => '2', 'third' => '3', 'fourth' => '4', 'last' => 'l');
                    $weekday_keys = isset($repeats['advanced']['weekdays']) && is_array($repeats['advanced']['weekdays']) ? $repeats['advanced']['weekdays'] : array();
                    $dayname_map = array(
                        'mon' => 'Monday',
                        'tue' => 'Tuesday',
                        'wed' => 'Wednesday',
                        'thu' => 'Thursday',
                        'fri' => 'Friday',
                        'sat' => 'Saturday',
                        'sun' => 'Sunday',
                        'monday' => 'Monday',
                        'tuesday' => 'Tuesday',
                        'wednesday' => 'Wednesday',
                        'thursday' => 'Thursday',
                        'friday' => 'Friday',
                        'saturday' => 'Saturday',
                        'sunday' => 'Sunday',
                    );
                    $tokens = array();
                    foreach ($weeks as $w) {
                        $wk = isset($week_to_key[$w]) ? $week_to_key[$w] : null;
                        if (!$wk) continue;
                        $wd_list = isset($weekday_keys[$w]) && is_array($weekday_keys[$w]) ? $weekday_keys[$w] : array();
                        foreach ($wd_list as $wd) {
                            $dn = isset($dayname_map[strtolower($wd)]) ? $dayname_map[strtolower($wd)] : null;
                            if ($dn) {
                                $tokens[] = $dn . '.' . $wk . '-';
                            }
                        }
                    }
                    $advanced_str = implode(',', $tokens);
                    \update_post_meta($event_id, 'mec_repeat_advanced', $advanced_str);
                }

                // End Repeat mapping
                $endRepeat = $get_nested($request, array('advancedSettings', 'endRepeat'), null);
                if (is_array($endRepeat)) {
                    $type = isset($endRepeat['type']) ? $endRepeat['type'] : 'Never';
                    if ($type === 'Never') {
                        \update_post_meta($event_id, 'mec_repeat_end', 'never');
                        \update_post_meta($event_id, 'mec_repeat_end_at_date', '');
                        \update_post_meta($event_id, 'mec_repeat_end_at_occurrences', '0');
                    } elseif ($type === 'On') {
                        \update_post_meta($event_id, 'mec_repeat_end', 'date');
                        if (!empty($endRepeat['date'])) {
                            \update_post_meta($event_id, 'mec_repeat_end_at_date', \sanitize_text_field($endRepeat['date']));
                        }
                    } elseif ($type === 'After') {
                        \update_post_meta($event_id, 'mec_repeat_end', 'occurrences');
                        if (isset($endRepeat['occurrences']) && is_numeric($endRepeat['occurrences'])) {
                            $occ = max(0, (int)$endRepeat['occurrences'] - 1); // MEC stores displayed N as N-1
                            \update_post_meta($event_id, 'mec_repeat_end_at_occurrences', (string)$occ);
                        }
                    }
                }
            }
        }

        // Ensure mec_events table 'repeat' column reflects current setting
        if (method_exists($request, 'set_param')) {
            $request->set_param('repeat_status', $repeat_enabled ? 1 : 0);
        }

        // Update mec_events table with repeat data
        if ($repeat_enabled) {
            $final_repeat_type = $repeat_type ?: \get_post_meta($event_id, 'mec_repeat_type', true);
            $final_repeat_interval = $repeat_interval ?: \get_post_meta($event_id, 'mec_repeat_interval', true);

            // Get current event data for mec_events table update
            $start_date = \get_post_meta($event_id, 'mec_start_date', true);
            $end_date = \get_post_meta($event_id, 'mec_end_date', true);
            $start_time_seconds = \get_post_meta($event_id, 'mec_start_day_seconds', true);
            $end_time_seconds = \get_post_meta($event_id, 'mec_end_day_seconds', true);

            if ($start_date && $end_date) {
                $this->save_mec_event_data($event_id, array(
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'start_time_seconds' => $start_time_seconds ?: 0,
                    'end_time_seconds' => $end_time_seconds ?: 0,
                    'repeat_status' => 1,
                    'repeat_interval' => $final_repeat_interval ?: 1,
                    'repeat_type' => $final_repeat_type ?: 'daily'
                ));
            }
        }

        // FAQ handling - correct structure: title/body not question/answer
        if (isset($request['faq']) && is_array($request['faq'])) {
            $faq_data = array();
            foreach ($request['faq'] as $index => $faq_item) {
                $faq_data[$index] = array(
                    'title' => isset($faq_item['title']) ? \sanitize_text_field($faq_item['title']) : (isset($faq_item['question']) ? \sanitize_text_field($faq_item['question']) : ''),
                    'body' => isset($faq_item['body']) ? \sanitize_text_field($faq_item['body']) : (isset($faq_item['answer']) ? \sanitize_text_field($faq_item['answer']) : ''),
                );
            }
            \update_post_meta($event_id, 'mec_faq', $faq_data);
        }

        // Event Banner handling
        if (isset($request['banner']) && is_array($request['banner'])) {
            $banner_data = array(
                'status' => isset($request['banner']['status']) ? (bool)$request['banner']['status'] : false,
                'color' => isset($request['banner']['color']) ? \sanitize_text_field($request['banner']['color']) : '',
                'image' => isset($request['banner']['image']) ? \sanitize_text_field($request['banner']['image']) : '',
                'use_featured_image' => isset($request['banner']['use_featured_image']) ? (bool)$request['banner']['use_featured_image'] : false,
            );
            \update_post_meta($event_id, 'mec_banner', $banner_data);
        }

        // Exceptional Days (Exclude Dates) handling
        if (isset($request['not_in_days']) && is_array($request['not_in_days'])) {
            $not_in_days = implode(',', array_map('sanitize_text_field', $request['not_in_days']));
            \update_post_meta($event_id, 'mec_not_in_days', $not_in_days);
        }

        // Location creation handling
        if (isset($request['location']) && is_array($request['location']) && isset($request['location']['name'])) {
            $location_data = array(
                'name' => \sanitize_text_field($request['location']['name']),
                'address' => isset($request['location']['address']) ? \sanitize_text_field($request['location']['address']) : '',
                'latitude' => isset($request['location']['latitude']) ? \sanitize_text_field($request['location']['latitude']) : '',
                'longitude' => isset($request['location']['longitude']) ? \sanitize_text_field($request['location']['longitude']) : '',
                'url' => isset($request['location']['url']) ? \sanitize_url($request['location']['url']) : '',
                'tel' => isset($request['location']['tel']) ? \sanitize_text_field($request['location']['tel']) : '',
                'opening_hour' => isset($request['location']['opening_hour']) ? \sanitize_text_field($request['location']['opening_hour']) : '',
                'thumbnail' => isset($request['location']['thumbnail']) ? \sanitize_text_field($request['location']['thumbnail']) : '',
            );

            // Create new location term
            $location_term = wp_insert_term($location_data['name'], 'mec_location');
            if (!is_wp_error($location_term)) {
                $location_id = $location_term['term_id'];

                // Save location meta data
                foreach ($location_data as $key => $value) {
                    if ($key !== 'name' && $value) {
                        update_term_meta($location_id, $key, $value);
                    }
                }

                // Set location ID for event
                \update_post_meta($event_id, 'mec_location_id', $location_id);
                wp_set_object_terms($event_id, (int)$location_id, 'mec_location');
            }
        }

        // Organizer creation handling
        if (isset($request['organizer']) && is_array($request['organizer']) && isset($request['organizer']['name'])) {
            $organizer_data = array(
                'name' => \sanitize_text_field($request['organizer']['name']),
                'tel' => isset($request['organizer']['tel']) ? \sanitize_text_field($request['organizer']['tel']) : '',
                'email' => isset($request['organizer']['email']) ? \sanitize_email($request['organizer']['email']) : '',
                'url' => isset($request['organizer']['url']) ? \sanitize_url($request['organizer']['url']) : '',
                'page_label' => isset($request['organizer']['page_label']) ? \sanitize_text_field($request['organizer']['page_label']) : '',
                'thumbnail' => isset($request['organizer']['thumbnail']) ? \sanitize_text_field($request['organizer']['thumbnail']) : '',
            );

            // Create new organizer term
            $organizer_term = wp_insert_term($organizer_data['name'], 'mec_organizer');
            if (!is_wp_error($organizer_term)) {
                $organizer_id = $organizer_term['term_id'];

                // Save organizer meta data
                foreach ($organizer_data as $key => $value) {
                    if ($key !== 'name' && $value) {
                        update_term_meta($organizer_id, $key, $value);
                    }
                }

                // Set organizer ID for event
                \update_post_meta($event_id, 'mec_organizer_id', $organizer_id);
                wp_set_object_terms($event_id, (int)$organizer_id, 'mec_organizer');
            }
        }

        // Custom fields (mec_fields)
        if (isset($request['fields']) && is_array($request['fields'])) {
            \update_post_meta($event_id, 'mec_fields', $request['fields']);

            // Save fields one by one
            foreach ($request['fields'] as $field_id => $values) {
                if (is_array($values)) {
                    $values = array_unique($values);
                    $values = implode(',', $values);
                }
                \update_post_meta($event_id, 'mec_fields_' . $field_id, \sanitize_text_field($values));
            }
        }

        // Booking settings
        if (isset($request['booking']) && is_array($request['booking'])) {
            \update_post_meta($event_id, 'mec_booking', $request['booking']);
        }

        // Hourly schedules
        if (isset($request['hourly_schedules']) && is_array($request['hourly_schedules'])) {
            \update_post_meta($event_id, 'mec_hourly_schedules', $request['hourly_schedules']);
        }

        // Handle tickets
        if (isset($request['tickets']) && is_array($request['tickets'])) {
            $tickets = array();
            foreach ($request['tickets'] as $index => $ticket_data) {
                $ticket = array(
                    'id' => $index + 1,
                    'name' => isset($ticket_data['name']) ? \sanitize_text_field($ticket_data['name']) : '',
                    'price' => isset($ticket_data['price']) ? \sanitize_text_field($ticket_data['price']) : '',
                    'price_label' => isset($ticket_data['price_label']) ? \sanitize_text_field($ticket_data['price_label']) : '',
                    'limit' => isset($ticket_data['limit']) ? intval($ticket_data['limit']) : '',
                    'description' => isset($ticket_data['description']) ? \sanitize_text_field($ticket_data['description']) : '',
                    'minimum_ticket' => isset($ticket_data['minimum_ticket']) ? intval($ticket_data['minimum_ticket']) : 1,
                );
                $tickets[] = $ticket;
            }
            \update_post_meta($event_id, 'mec_tickets', $tickets);
        }

        // Zoom meta
        $zoom_payload = null;
        if ($request instanceof WP_REST_Request) {
            $zoom_payload = $request->get_param('zoom');
            if ($zoom_payload === null) {
                $json_body = $request->get_json_params();
                if (is_array($json_body) && isset($json_body['zoom'])) {
                    $zoom_payload = $json_body['zoom'];
                }
            }
        } elseif (is_array($request) && isset($request['zoom'])) {
            $zoom_payload = $request['zoom'];
        }
        if (is_array($zoom_payload)) {
            $this->applyZoomMeta($event_id, $zoom_payload);
        }

        // Virtual event meta
        $virtual_payload = null;
        if ($request instanceof WP_REST_Request) {
            $virtual_payload = $request->get_param('virtual_event');
            if ($virtual_payload === null) {
                $json_body = $request->get_json_params();
                if (is_array($json_body) && isset($json_body['virtual_event'])) {
                    $virtual_payload = $json_body['virtual_event'];
                }
            }
        } elseif (is_array($request) && isset($request['virtual_event'])) {
            $virtual_payload = $request['virtual_event'];
        }
        if (is_array($virtual_payload)) {
            $this->applyVirtualEventMeta($event_id, $virtual_payload);
        }

        // Entity type / appointments meta
        $entity_type_param = null;
        if ($request instanceof WP_REST_Request) {
            $entity_type_param = $request->get_param('entity_type');
            if ($entity_type_param === null) {
                $json_body = $request->get_json_params();
                if (is_array($json_body) && array_key_exists('entity_type', $json_body)) {
                    $entity_type_param = $json_body['entity_type'];
                }
            }
        } elseif (is_array($request) && array_key_exists('entity_type', $request)) {
            $entity_type_param = $request['entity_type'];
        }

        $entity_type = null;
        if ($entity_type_param !== null) {
            $entity_type_param = is_string($entity_type_param) ? strtolower((string) $entity_type_param) : $entity_type_param;
            $entity_type = in_array($entity_type_param, array('event', 'appointment'), true) ? $entity_type_param : 'event';
            \update_post_meta($event_id, 'mec_entity_type', $entity_type);
        }

        $appointments_payload = null;
        if ($request instanceof WP_REST_Request) {
            $appointments_payload = $request->get_param('appointments');
            if ($appointments_payload === null) {
                $json_body = $request->get_json_params();
                if (is_array($json_body) && array_key_exists('appointments', $json_body)) {
                    $appointments_payload = $json_body['appointments'];
                }
            }
        } elseif (is_array($request) && array_key_exists('appointments', $request)) {
            $appointments_payload = $request['appointments'];
        }

        $appointments_payload = is_array($appointments_payload) ? $appointments_payload : null;
        $current_entity_type = $entity_type ?? (string) \get_post_meta($event_id, 'mec_entity_type', true);
        if (!in_array($current_entity_type, array('event', 'appointment'), true)) {
            $current_entity_type = 'event';
        }

        if ($appointments_payload !== null && $current_entity_type !== 'appointment') {
            $current_entity_type = 'appointment';
            \update_post_meta($event_id, 'mec_entity_type', $current_entity_type);
        }

        $should_apply_appointments = ($appointments_payload !== null) || ($entity_type === 'event');

        if ($should_apply_appointments) {
            if ($appointments_payload !== null && !isset($appointments_payload['saved'])) {
                $appointments_payload['saved'] = 1;
            }

            if (!class_exists('\MEC_appointments') && defined('MEC_ABSPATH')) {
                $appointments_library_path = MEC_ABSPATH . 'app' . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'appointments.php';
                if (file_exists($appointments_library_path)) {
                    require_once $appointments_library_path;
                }
            }

            if (class_exists('\MEC_appointments')) {
                $appointments_library = new \MEC_appointments();
                $appointments_library->save($event_id, array(
                    'entity_type' => $current_entity_type,
                    'appointments' => $appointments_payload ?? array(),
                ));
            } else {
                if ($current_entity_type === 'event') {
                    \delete_post_meta($event_id, 'mec_appointments');
                } elseif ($appointments_payload !== null) {
                    \update_post_meta($event_id, 'mec_appointments', $appointments_payload);
                }
            }
        }

        // Handle repeat
        if (isset($request['repeat_status']) && $request['repeat_status']) {
            $repeat_array = array(
                'status' => 1,
                'type' => isset($request['repeat_type']) ? \sanitize_text_field($request['repeat_type']) : 'daily',
                'interval' => isset($request['repeat_interval']) ? intval($request['repeat_interval']) : 1,
                'end' => isset($request['repeat_end']) ? \sanitize_text_field($request['repeat_end']) : 'never',
                'end_at_date' => isset($request['repeat_end_at_date']) ? \sanitize_text_field($request['repeat_end_at_date']) : '',
                'end_at_occurrences' => isset($request['repeat_end_at_occurrences']) ? intval($request['repeat_end_at_occurrences']) : 10,
            );
            \update_post_meta($event_id, 'mec_repeat', $repeat_array);
            \update_post_meta($event_id, 'mec_repeat_status', 1);
        }
    }

    /**
     * Save MEC event data to database
     */
    protected function save_mec_event_data($event_id, $request)
    {
        global $wpdb;

        // Dates: prefer request, then stored meta
        $start_date = isset($request['start_date']) ? \sanitize_text_field($request['start_date'])
            : (isset($request['startDate']) ? \sanitize_text_field($request['startDate'])
                : (string) get_post_meta($event_id, 'mec_start_date', true));
        if (empty($start_date)) {
            $start_date = \date('Y-m-d');
        }

        $end_date = isset($request['end_date']) ? \sanitize_text_field($request['end_date'])
            : (isset($request['endDate']) ? \sanitize_text_field($request['endDate'])
                : (string) get_post_meta($event_id, 'mec_end_date', true));
        if (empty($end_date)) {
            $end_date = $start_date;
        }

        // Calculate proper time seconds
        // Times: prefer request numeric parts, then parse 24h strings, then stored meta
        $start_time_hour = isset($request['start_time_hour']) ? intval($request['start_time_hour']) : null;
        $start_time_minutes = isset($request['start_time_minutes']) ? intval($request['start_time_minutes']) : null;
        $start_time_ampm = isset($request['start_time_ampm']) ? strtoupper($request['start_time_ampm']) : null;

        if (($start_time_hour === null || $start_time_minutes === null || $start_time_ampm === null) && isset($request['startTime']) && is_string($request['startTime'])) {
            $parts = explode(':', $request['startTime']);
            if (count($parts) === 2) {
                $h24 = (int) $parts[0];
                $m = (int) $parts[1];
                $start_time_ampm = $h24 >= 12 ? 'PM' : 'AM';
                $start_time_hour = $h24 % 12;
                if ($start_time_hour === 0) {
                    $start_time_hour = 12;
                }
                $start_time_minutes = $m;
            }
        }
        if ($start_time_hour === null) {
            $start_time_hour = (int) get_post_meta($event_id, 'mec_start_time_hour', true) ?: 8;
        }
        if ($start_time_minutes === null) {
            $start_time_minutes = (int) get_post_meta($event_id, 'mec_start_time_minutes', true) ?: 0;
        }
        if ($start_time_ampm === null) {
            $start_time_ampm = strtoupper((string) get_post_meta($event_id, 'mec_start_time_ampm', true) ?: 'AM');
        }

        $end_time_hour = isset($request['end_time_hour']) ? intval($request['end_time_hour']) : null;
        $end_time_minutes = isset($request['end_time_minutes']) ? intval($request['end_time_minutes']) : null;
        $end_time_ampm = isset($request['end_time_ampm']) ? strtoupper($request['end_time_ampm']) : null;

        if (($end_time_hour === null || $end_time_minutes === null || $end_time_ampm === null) && isset($request['endTime']) && is_string($request['endTime'])) {
            $parts = explode(':', $request['endTime']);
            if (count($parts) === 2) {
                $h24 = (int) $parts[0];
                $m = (int) $parts[1];
                $end_time_ampm = $h24 >= 12 ? 'PM' : 'AM';
                $end_time_hour = $h24 % 12;
                if ($end_time_hour === 0) {
                    $end_time_hour = 12;
                }
                $end_time_minutes = $m;
            }
        }
        if ($end_time_hour === null) {
            $end_time_hour = (int) get_post_meta($event_id, 'mec_end_time_hour', true) ?: 6;
        }
        if ($end_time_minutes === null) {
            $end_time_minutes = (int) get_post_meta($event_id, 'mec_end_time_minutes', true) ?: 0;
        }
        if ($end_time_ampm === null) {
            $end_time_ampm = strtoupper((string) get_post_meta($event_id, 'mec_end_time_ampm', true) ?: 'PM');
        }

        // All-day normalization for mec_events table
        $is_all_day = null;
        if (isset($request['isAllDay'])) {
            $is_all_day = (bool) $request['isAllDay'];
        }
        if ($is_all_day === null) {
            $is_all_day = (string) get_post_meta($event_id, 'mec_allday', true) === '1';
        }

        if ($is_all_day) {
            $day_start_seconds = 0;
            $day_end_seconds = 86399;
        } else {
            $day_start_seconds = $this->time_to_seconds($start_time_hour, $start_time_minutes, $start_time_ampm);
            $day_end_seconds = $this->time_to_seconds($end_time_hour, $end_time_minutes, $end_time_ampm);
        }

        $repeat_status = isset($request['repeat_status']) && $request['repeat_status'] ? 1 : 0;

        // Get repeat type and interval from request or meta
        $repeat_type = isset($request['repeat_type']) ? $request['repeat_type'] : get_post_meta($event_id, 'mec_repeat_type', true);
        $repeat_interval = isset($request['repeat_interval']) ? intval($request['repeat_interval']) : intval(get_post_meta($event_id, 'mec_repeat_interval', true));

        // Get advanced days and weekdays for mec_events table
        $advanced_days_str = '';
        $weekdays_str = '';

        if ($repeat_type === 'advanced') {
            $advanced_days_meta = get_post_meta($event_id, 'mec_advanced_days', true);
            if (is_array($advanced_days_meta)) {
                $advanced_days_str = implode(',', $advanced_days_meta);
            }
        } elseif ($repeat_type === 'certain_weekdays') {
            $weekdays_meta = get_post_meta($event_id, 'mec_certain_weekdays', true);
            if (is_array($weekdays_meta)) {
                $weekdays_str = implode(',', $weekdays_meta);
            }
        } elseif ($repeat_type === 'weekday') {
            // For weekday repeat, set weekdays to weekdays (Monday-Friday)
            $weekdays_str = '1,2,3,4,5';
        } elseif ($repeat_type === 'weekend') {
            // For weekend repeat, set weekdays to weekends (Saturday-Sunday)
            $weekdays_str = '6,0';
        }

        // Get custom days for mec_events table
        $custom_days_str = '';
        $custom_days_meta = get_post_meta($event_id, 'mec_in_days', true);
        error_log('Custom days meta from database: ' . print_r($custom_days_meta, true));
        error_log('Custom days meta type: ' . gettype($custom_days_meta));
        
        if (is_array($custom_days_meta)) {
            // Convert array format to string format
            $custom_days_strings = [];
            foreach ($custom_days_meta as $day) {
                if (is_array($day) && isset($day['startDate'], $day['endDate'], $day['startTime'], $day['endTime'])) {
                    // Format time properly with leading zeros
                    $start_hour = str_pad($day['startTime']['hour'], 2, '0', STR_PAD_LEFT);
                    $start_minute = str_pad($day['startTime']['minute'], 2, '0', STR_PAD_LEFT);
                    $end_hour = str_pad($day['endTime']['hour'], 2, '0', STR_PAD_LEFT);
                    $end_minute = str_pad($day['endTime']['minute'], 2, '0', STR_PAD_LEFT);
                    
                    $start_time = $start_hour . '-' . $start_minute . '-' . $day['startTime']['ampm'];
                    $end_time = $end_hour . '-' . $end_minute . '-' . $day['endTime']['ampm'];
                    
                    $custom_days_strings[] = $day['startDate'] . ':' . $day['endDate'] . ':' . $start_time . ':' . $end_time;
                }
            }
            $custom_days_str = implode(',', $custom_days_strings);
        } elseif (is_string($custom_days_meta)) {
            $custom_days_str = $custom_days_meta;
        } else {
            // Ensure it's always a string
            $custom_days_str = '';
        }
        
        error_log('Final custom_days_str for database: ' . $custom_days_str);

        // Detect mec_events schema to avoid inserting unknown columns (compat with MEC Lite/Pro versions)
        $columns = $wpdb->get_col("SHOW COLUMNS FROM {$wpdb->prefix}mec_events", 0);
        $has_days = in_array('days', (array) $columns, true);
        $has_weekdays = in_array('weekdays', (array) $columns, true);
        $has_advanced_days = in_array('advanced_days', (array) $columns, true);

        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}mec_events WHERE post_id = %d",
                $event_id
            )
        );

        // Build dynamic data arrays according to available columns
        $data = array(
            'start'      => $start_date,
            'end'        => $end_date,
            'time_start' => $day_start_seconds,
            'time_end'   => $day_end_seconds,
            'repeat'     => $repeat_status,
            'rinterval'  => $repeat_interval,
        );
        $formats = array('%s', '%s', '%d', '%d', '%d', '%d');
        if ($has_days) {
            $data['days'] = $custom_days_str;
            $formats[] = '%s';
        }
        if ($has_weekdays) {
            $data['weekdays'] = $weekdays_str;
            $formats[] = '%s';
        }
        if ($has_advanced_days) {
            $data['advanced_days'] = $advanced_days_str;
            $formats[] = '%s';
        }

        if ($existing) {
            $wpdb->update(
                $wpdb->prefix . 'mec_events',
                $data,
                array('post_id' => $event_id),
                $formats,
                array('%d')
            );
        } else {
            $insert_data = array('post_id' => $event_id) + $data;
            $insert_formats = array('%d');
            $insert_formats = array_merge($insert_formats, $formats);
            $wpdb->insert(
                $wpdb->prefix . 'mec_events',
                $insert_data,
                $insert_formats
            );
        }
    }

    /**
     * Get collection parameters
     *
     * @return array Collection parameters.
     */
    public function get_collection_params()
    {
        return array(
            'per_page' => array(
                'description'       => __('Maximum number of items to return.', 'mec-utility'),
                'type'              => 'integer',
                'default'           => 10,
                'minimum'           => 1,
                'maximum'           => 100,
                'sanitize_callback' => 'absint',
            ),
            'page' => array(
                'description'       => __('Current page of the collection.', 'mec-utility'),
                'type'              => 'integer',
                'default'           => 1,
                'minimum'           => 1,
                'sanitize_callback' => 'absint',
            ),
            'search' => array(
                'description'       => __('Limit results to those matching a string.', 'mec-utility'),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'status' => array(
                'description' => __('Filter by post status. Use "any" for all statuses, or specify: publish, draft, pending, private, trash, future.', 'mec-utility'),
                'type'        => 'string',
                'default'     => 'any',
                'enum'        => array('any', 'publish', 'draft', 'pending', 'private', 'trash', 'future'),
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'start_date' => array(
                'description' => __('Start date filter (Y-m-d format).', 'mec-utility'),
                'type'        => 'string',
                'format'      => 'date',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'end_date' => array(
                'description' => __('End date filter (Y-m-d format).', 'mec-utility'),
                'type'        => 'string',
                'format'      => 'date',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'date_filter' => array(
                'description' => __('Date filter type: upcoming, past, today, this_week, this_month.', 'mec-utility'),
                'type'        => 'string',
                'enum'        => array('upcoming', 'past', 'today', 'this_week', 'this_month'),
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'category' => array(
                'description' => __('Event category ID or slug.', 'mec-utility'),
                'type'        => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'location' => array(
                'description' => __('Event location ID.', 'mec-utility'),
                'type'        => 'integer',
                'sanitize_callback' => 'absint',
            ),
            'organizer' => array(
                'description' => __('Event organizer ID.', 'mec-utility'),
                'type'        => 'integer',
                'sanitize_callback' => 'absint',
            ),
            'orderby' => array(
                'description' => __('Sort collection by object attribute.', 'mec-utility'),
                'type'        => 'string',
                'default'     => 'date',
                'enum'        => array('date', 'title', 'start_date'),
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'order' => array(
                'description' => __('Order sort attribute ascending or descending.', 'mec-utility'),
                'type'        => 'string',
                'default'     => 'asc',
                'enum'        => array('asc', 'desc'),
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'occurrences_limit' => array(
                'description' => __('Maximum number of occurrences to return for recurring events.', 'mec-utility'),
                'type'        => 'integer',
                'default'     => 50,
                'minimum'     => 1,
                'maximum'     => 200,
                'sanitize_callback' => 'absint',
            ),
        );
    }

    /**
     * Get MEC locations (taxonomy mec_location) with meta
     */
    public function get_locations($request)
    {
        $search = $request->get_param('search');
        $per_page = $request->get_param('per_page') ?: 20;
        $page = $request->get_param('page') ?: 1;

        $args = array(
            'taxonomy' => 'mec_location',
            'hide_empty' => false,
            'number' => $per_page,
            'offset' => ($page - 1) * $per_page,
        );
        if (!empty($search)) {
            $args['search'] = $search;
        }

        $terms = \get_terms($args);
        if (\is_wp_error($terms)) {
            return $terms;
        }

        $items = array();
        foreach ($terms as $term) {
            $meta = \get_term_meta($term->term_id);
            $items[] = array(
                'id' => (int)$term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'count' => (int)$term->count,
                'meta' => array(
                    'address' => isset($meta['address'][0]) ? $meta['address'][0] : '',
                    'latitude' => isset($meta['latitude'][0]) ? $meta['latitude'][0] : '',
                    'longitude' => isset($meta['longitude'][0]) ? $meta['longitude'][0] : '',
                    'url' => isset($meta['url'][0]) ? $meta['url'][0] : '',
                    'tel' => isset($meta['tel'][0]) ? $meta['tel'][0] : '',
                    'opening_hour' => isset($meta['opening_hour'][0]) ? $meta['opening_hour'][0] : '',
                    'thumbnail' => isset($meta['thumbnail'][0]) ? $meta['thumbnail'][0] : '',
                ),
            );
        }

        return \rest_ensure_response(array(
            'items' => $items,
            'page' => (int)$page,
            'per_page' => (int)$per_page,
            'total' => (int)\wp_count_terms(array('taxonomy' => 'mec_location', 'hide_empty' => false)),
        ));
    }

    /**
     * Get MEC tags (taxonomy post_tag by default, or custom via mec_taxonomy_tag filter) with pagination and search
     */
    public function get_tags($request)
    {
        $search = $request->get_param('search');
        $per_page = $request->get_param('per_page') ?: 20;
        $page = $request->get_param('page') ?: 1;
        $orderby = $request->get_param('orderby') ?: 'count';
        $order = strtoupper($request->get_param('order') ?: 'DESC');

        // Use MEC's taxonomy tag filter (defaults to 'post_tag' if no custom taxonomy is set)
        $tag_taxonomy = apply_filters('mec_taxonomy_tag', 'post_tag');

        $args = array(
            'taxonomy' => $tag_taxonomy,
            'hide_empty' => false,
            'number' => $per_page,
            'offset' => ($page - 1) * $per_page,
            'orderby' => $orderby,
            'order' => $order,
        );
        if (!empty($search)) {
            $args['search'] = $search;
        }

        $terms = \get_terms($args);
        if (\is_wp_error($terms)) {
            return $terms;
        }

        $items = array();
        foreach ($terms as $term) {
            $items[] = array(
                'id' => (int)$term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'count' => (int)$term->count,
            );
        }

        return \rest_ensure_response(array(
            'items' => $items,
            'page' => (int)$page,
            'per_page' => (int)$per_page,
            'total' => (int)\wp_count_terms(array('taxonomy' => $tag_taxonomy, 'hide_empty' => false)),
        ));
    }

    /**
     * Get MEC popular tags (most used) - mirrors WP meta box "Choose from the most used tags"
     */
    public function get_popular_tags($request)
    {
        $per_page = $request->get_param('per_page') ?: 20;

        // Use MEC's taxonomy tag filter (defaults to 'post_tag' if no custom taxonomy is set)
        $tag_taxonomy = apply_filters('mec_taxonomy_tag', 'post_tag');

        $terms = \get_terms(array(
            'taxonomy' => $tag_taxonomy,
            'orderby' => 'count',
            'order' => 'DESC',
            'number' => $per_page,
            'hide_empty' => false,
        ));

        if (\is_wp_error($terms)) {
            return $terms;
        }

        $items = array();
        foreach ($terms as $term) {
            $items[] = array(
                'id' => (int)$term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'count' => (int)$term->count,
            );
        }

        return \rest_ensure_response(array(
            'items' => $items,
            'total' => count($items),
        ));
    }

    /**
     * Create a new MEC tag
     */
    public function create_tag($request)
    {
        $name = $request->get_param('name');
        if (!$name) {
            $name = $request->get_param('title');
        }
        $slug = $request->get_param('slug');

        if (empty($name)) {
            return new \WP_Error(
                'invalid_tag_name',
                __('Tag name is required.', 'mec-utility'),
                array('status' => 400)
            );
        }

        // Use MEC's taxonomy tag filter (defaults to 'post_tag' if no custom taxonomy is set)
        $tag_taxonomy = apply_filters('mec_taxonomy_tag', 'post_tag');

        $args = array();
        if (!empty($slug)) {
            $args['slug'] = $slug;
        }

        $insert = \wp_insert_term($name, $tag_taxonomy, $args);
        if (\is_wp_error($insert)) {
            // If term exists, return existing term data
            if ($insert->get_error_code() === 'term_exists') {
                $term_id = (int)$insert->get_error_data('term_exists');
                $term = \get_term($term_id, $tag_taxonomy);
                if (!\is_wp_error($term) && $term) {
                    return \rest_ensure_response(array(
                        'id' => (int)$term->term_id,
                        'name' => $term->name,
                        'slug' => $term->slug,
                        'description' => $term->description,
                        'count' => (int)$term->count,
                        'created' => false,
                    ));
                }
            }
            return $insert;
        }

        $term_id = (int)$insert['term_id'];
        $term = \get_term($term_id, $tag_taxonomy);

        return \rest_ensure_response(array(
            'id' => (int)$term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
            'description' => $term->description,
            'count' => (int)$term->count,
            'created' => true,
        ));
    }

    /**
     * Get MEC organizers (taxonomy mec_organizer) with meta
     */
    public function get_organizers($request)
    {
        $search = $request->get_param('search');
        $per_page = $request->get_param('per_page') ?: 20;
        $page = $request->get_param('page') ?: 1;

        $args = array(
            'taxonomy' => 'mec_organizer',
            'hide_empty' => false,
            'number' => $per_page,
            'offset' => ($page - 1) * $per_page,
        );
        if (!empty($search)) {
            $args['search'] = $search;
        }

        $terms = \get_terms($args);
        if (\is_wp_error($terms)) {
            return $terms;
        }

        $items = array();
        foreach ($terms as $term) {
            $meta = \get_term_meta($term->term_id);
            $items[] = array(
                'id' => (int)$term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'count' => (int)$term->count,
                'meta' => array(
                    'email' => isset($meta['email'][0]) ? $meta['email'][0] : '',
                    'tel' => isset($meta['tel'][0]) ? $meta['tel'][0] : '',
                    'url' => isset($meta['url'][0]) ? $meta['url'][0] : '',
                    'page_label' => isset($meta['page_label'][0]) ? $meta['page_label'][0] : '',
                    'thumbnail' => isset($meta['thumbnail'][0]) ? $meta['thumbnail'][0] : '',
                ),
            );
        }

        return \rest_ensure_response(array(
            'items' => $items,
            'page' => (int)$page,
            'per_page' => (int)$per_page,
            'total' => (int)\wp_count_terms(array('taxonomy' => 'mec_organizer', 'hide_empty' => false)),
        ));
    }

    /**
     * Get MEC categories (taxonomy mec_category) with meta
     */
    public function get_categories($request)
    {
        $search = $request->get_param('search');
        $per_page = $request->get_param('per_page') ?: 50;
        $page = $request->get_param('page') ?: 1;
        $hide_empty = (bool) $request->get_param('hide_empty');
        $parent = $request->get_param('parent');

        $args = array(
            'taxonomy' => 'mec_category',
            'hide_empty' => $hide_empty,
            'number' => $per_page,
            'offset' => ($page - 1) * $per_page,
        );
        if (!empty($search)) {
            $args['search'] = $search;
        }
        if (!empty($parent)) {
            $args['parent'] = (int) $parent;
        }

        $terms = \get_terms($args);
        if (\is_wp_error($terms)) {
            return $terms;
        }

        $items = array();
        foreach ($terms as $term) {
            $meta = \get_term_meta($term->term_id);
            $items[] = array(
                'id' => (int)$term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'count' => (int)$term->count,
                'parent' => (int)$term->parent,
                'meta' => array(
                    'color' => isset($meta['color'][0]) ? $meta['color'][0] : '',
                    'icon' => isset($meta['icon'][0]) ? $meta['icon'][0] : '',
                    'thumbnail' => isset($meta['thumbnail'][0]) ? $meta['thumbnail'][0] : '',
                ),
            );
        }

        return \rest_ensure_response(array(
            'items' => $items,
            'page' => (int)$page,
            'per_page' => (int)$per_page,
            'total' => (int)\wp_count_terms(array('taxonomy' => 'mec_category', 'hide_empty' => $hide_empty)),
        ));
    }

    /**
     * Create a new MEC category
     */
    public function create_category($request)
    {
        $name = $request->get_param('name');
        $slug = $request->get_param('slug');
        $parent = $request->get_param('parent');
        $meta = $request->get_param('meta');

        if (empty($name)) {
            return new \WP_Error(
                'invalid_category_name',
                __('Category name is required.', 'mec-utility'),
                array('status' => 400)
            );
        }

        $args = array();
        if (!empty($slug)) {
            $args['slug'] = $slug;
        }
        if (!empty($parent)) {
            $args['parent'] = (int)$parent;
        }

        $insert = \wp_insert_term($name, 'mec_category', $args);
        if (\is_wp_error($insert)) {
            if ($insert->get_error_code() === 'term_exists') {
                $term_id = (int)$insert->get_error_data('term_exists');
                $term = \get_term($term_id, 'mec_category');
                if (!\is_wp_error($term) && $term) {
                    // Update meta if provided
                    if (is_array($meta)) {
                        foreach (array('color', 'icon', 'thumbnail') as $mkey) {
                            if (isset($meta[$mkey])) {
                                \update_term_meta($term_id, $mkey, $meta[$mkey]);
                            }
                        }
                    }
                    return \rest_ensure_response(array(
                        'id' => (int)$term->term_id,
                        'name' => $term->name,
                        'slug' => $term->slug,
                        'description' => $term->description,
                        'count' => (int)$term->count,
                        'parent' => (int)$term->parent,
                        'created' => false,
                    ));
                }
            }
            return $insert;
        }

        $term_id = (int)$insert['term_id'];

        // Save meta if provided
        if (is_array($meta)) {
            foreach (array('color', 'icon', 'thumbnail') as $mkey) {
                if (isset($meta[$mkey])) {
                    \update_term_meta($term_id, $mkey, $meta[$mkey]);
                }
            }
        }

        $term = \get_term($term_id, 'mec_category');
        return \rest_ensure_response(array(
            'id' => (int)$term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
            'description' => $term->description,
            'count' => (int)$term->count,
            'parent' => (int)$term->parent,
            'created' => true,
        ));
    }

    /**
     * Get MEC speakers (taxonomy mec_speaker)
     */
    public function get_speakers($request)
    {
        $search = $request->get_param('search');
        $per_page = $request->get_param('per_page') ?: 50;
        $page = $request->get_param('page') ?: 1;
        $hide_empty = (bool) $request->get_param('hide_empty');
        $parent = $request->get_param('parent');

        $args = array(
            'taxonomy' => 'mec_speaker',
            'hide_empty' => $hide_empty,
            'number' => $per_page,
            'offset' => ($page - 1) * $per_page,
        );
        if (!empty($search)) {
            $args['search'] = $search;
        }
        if (!empty($parent)) {
            $args['parent'] = (int) $parent;
        }

        $terms = \get_terms($args);
        if (\is_wp_error($terms)) {
            return $terms;
        }

        $items = array();
        foreach ($terms as $term) {
            $meta = \get_term_meta($term->term_id);
            $items[] = array(
                'id' => (int)$term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'parent' => (int)$term->parent,
                'meta' => array(
                    'thumbnail' => isset($meta['thumbnail'][0]) ? $meta['thumbnail'][0] : '',
                    'job_title' => isset($meta['job_title'][0]) ? $meta['job_title'][0] : '',
                    'company' => isset($meta['company'][0]) ? $meta['company'][0] : '',
                    'url' => isset($meta['url'][0]) ? $meta['url'][0] : '',
                    'email' => isset($meta['email'][0]) ? $meta['email'][0] : '',
                    'tel' => isset($meta['tel'][0]) ? $meta['tel'][0] : '',
                ),
            );
        }

        return \rest_ensure_response(array(
            'items' => $items,
            'page' => (int)$page,
            'per_page' => (int)$per_page,
        ));
    }

    /**
     * Create a new MEC speaker
     */
    public function create_speaker($request)
    {
        $name = $request->get_param('name');
        $slug = $request->get_param('slug');
        $parent = $request->get_param('parent');
        $meta = $request->get_param('meta');

        if (empty($name)) {
            return new \WP_Error(
                'invalid_speaker_name',
                __('Speaker name is required.', 'mec-utility'),
                array('status' => 400)
            );
        }

        $args = array();
        if (!empty($slug)) {
            $args['slug'] = $slug;
        }
        if (!empty($parent)) {
            $args['parent'] = (int)$parent;
        }

        $insert = \wp_insert_term($name, 'mec_speaker', $args);
        if (\is_wp_error($insert)) {
            if ($insert->get_error_code() === 'term_exists') {
                $term_id = (int)$insert->get_error_data('term_exists');
                $term = \get_term($term_id, 'mec_speaker');
                if (!\is_wp_error($term) && $term) {
                    if (is_array($meta)) {
                        foreach (array('thumbnail', 'job_title', 'company', 'url', 'email', 'tel') as $mkey) {
                            if (isset($meta[$mkey])) {
                                \update_term_meta($term_id, $mkey, $meta[$mkey]);
                            }
                        }
                    }
                    return \rest_ensure_response(array(
                        'id' => (int)$term->term_id,
                        'name' => $term->name,
                        'slug' => $term->slug,
                        'description' => $term->description,
                        'parent' => (int)$term->parent,
                        'created' => false,
                    ));
                }
            }
            return $insert;
        }

        $term_id = (int)$insert['term_id'];

        if (is_array($meta)) {
            foreach (array('thumbnail', 'job_title', 'company', 'url', 'email', 'tel') as $mkey) {
                if (isset($meta[$mkey])) {
                    \update_term_meta($term_id, $mkey, $meta[$mkey]);
                }
            }
        }

        $term = \get_term($term_id, 'mec_speaker');
        return \rest_ensure_response(array(
            'id' => (int)$term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
            'description' => $term->description,
            'parent' => (int)$term->parent,
            'created' => true,
        ));
    }

    /**
     * Get MEC labels (taxonomy mec_label)
     */
    public function get_labels($request)
    {
        $search = $request->get_param('search');
        $per_page = $request->get_param('per_page') ?: 50;
        $page = $request->get_param('page') ?: 1;
        $hide_empty = (bool) $request->get_param('hide_empty');
        $parent = $request->get_param('parent');

        $args = array(
            'taxonomy' => 'mec_label',
            'hide_empty' => $hide_empty,
            'number' => $per_page,
            'offset' => ($page - 1) * $per_page,
        );
        if (!empty($search)) {
            $args['search'] = $search;
        }
        if (!empty($parent)) {
            $args['parent'] = (int) $parent;
        }

        $terms = \get_terms($args);
        if (\is_wp_error($terms)) {
            return $terms;
        }

        $items = array();
        foreach ($terms as $term) {
            $meta = \get_term_meta($term->term_id);
            $items[] = array(
                'id' => (int)$term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'parent' => (int)$term->parent,
                'meta' => array(
                    'color' => isset($meta['color'][0]) ? $meta['color'][0] : '',
                    'icon' => isset($meta['icon'][0]) ? $meta['icon'][0] : '',
                    'thumbnail' => isset($meta['thumbnail'][0]) ? $meta['thumbnail'][0] : '',
                ),
            );
        }

        return \rest_ensure_response(array(
            'items' => $items,
            'page' => (int)$page,
            'per_page' => (int)$per_page,
        ));
    }

    /**
     * Create a new MEC label
     */
    public function create_label($request)
    {
        $name = $request->get_param('name');
        $slug = $request->get_param('slug');
        $parent = $request->get_param('parent');
        $meta = $request->get_param('meta');

        if (empty($name)) {
            return new \WP_Error(
                'invalid_label_name',
                __('Label name is required.', 'mec-utility'),
                array('status' => 400)
            );
        }

        $args = array();
        if (!empty($slug)) {
            $args['slug'] = $slug;
        }
        if (!empty($parent)) {
            $args['parent'] = (int)$parent;
        }

        $insert = \wp_insert_term($name, 'mec_label', $args);
        if (\is_wp_error($insert)) {
            if ($insert->get_error_code() === 'term_exists') {
                $term_id = (int)$insert->get_error_data('term_exists');
                $term = \get_term($term_id, 'mec_label');
                if (!\is_wp_error($term) && $term) {
                    if (is_array($meta)) {
                        foreach (array('color', 'icon', 'thumbnail') as $mkey) {
                            if (isset($meta[$mkey])) {
                                \update_term_meta($term_id, $mkey, $meta[$mkey]);
                            }
                        }
                    }
                    return \rest_ensure_response(array(
                        'id' => (int)$term->term_id,
                        'name' => $term->name,
                        'slug' => $term->slug,
                        'description' => $term->description,
                        'parent' => (int)$term->parent,
                        'created' => false,
                    ));
                }
            }
            return $insert;
        }

        $term_id = (int)$insert['term_id'];

        if (is_array($meta)) {
            foreach (array('color', 'icon', 'thumbnail') as $mkey) {
                if (isset($meta[$mkey])) {
                    \update_term_meta($term_id, $mkey, $meta[$mkey]);
                }
            }
        }

        $term = \get_term($term_id, 'mec_label');
        return \rest_ensure_response(array(
            'id' => (int)$term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
            'description' => $term->description,
            'parent' => (int)$term->parent,
            'created' => true,
        ));
    }

    /**
     * Get the event schema for REST API
     */
    public function get_endpoint_args_for_item_schema($method = 'GET')
    {
        $args = array();

        if ('POST' === $method || 'PUT' === $method) {
            $args['title'] = array(
                'description'       => __('The title for the event.', 'mec-utility'),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => 'rest_validate_request_arg',
            );

            $args['content'] = array(
                'description'       => __('The content for the event.', 'mec-utility'),
                'type'              => 'string',
                'sanitize_callback' => 'wp_kses_post',
                'validate_callback' => 'rest_validate_request_arg',
            );

            $args['excerpt'] = array(
                'description'       => __('The excerpt for the event.', 'mec-utility'),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_textarea_field',
            );

            $args['status'] = array(
                'description' => __('A named status for the event.', 'mec-utility'),
                'type'        => 'string',
                'enum'        => array('publish', 'draft', 'private', 'pending'),
                'default'     => 'publish',
                'sanitize_callback' => array($this, 'sanitize_status_param'),
            );

            $args['visibility'] = array(
                'description' => __('Post visibility: Public, Private, Password protected', 'mec-utility'),
                'type'        => 'string',
                'enum'        => array('Public', 'Private', 'Password protected'),
            );

            $args['post_password'] = array(
                'description' => __('Password for password-protected visibility', 'mec-utility'),
                'type'        => 'string',
            );

            $args['start_date'] = array(
                'description' => __('Event start date.', 'mec-utility'),
                'type'        => 'string',
                'format'      => 'date',
            );

            $args['end_date'] = array(
                'description' => __('Event end date.', 'mec-utility'),
                'type'        => 'string',
                'format'      => 'date',
            );

            $args['start_time'] = array(
                'description' => __('Event start time (timestamp).', 'mec-utility'),
                'type'        => 'integer',
            );

            $args['end_time'] = array(
                'description' => __('Event end time (timestamp).', 'mec-utility'),
                'type'        => 'integer',
            );

            // Extended accepted fields for full edit UI parity
            $args['isAllDay'] = array(
                'description' => __('All-day event flag.', 'mec-utility'),
                'type'        => 'boolean',
            );
            $args['startTime'] = array(
                'description' => __('Start time in 24h format HH:mm.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['endTime'] = array(
                'description' => __('End time in 24h format HH:mm.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['location_id'] = array(
                'description' => __('Event main location term ID.', 'mec-utility'),
                'type'        => 'integer',
            );
            $args['organizer_id'] = array(
                'description' => __('Event main organizer term ID.', 'mec-utility'),
                'type'        => 'integer',
            );
            $args['advancedSettings'] = array(
                'description' => __('Advanced settings object for multiple fields.', 'mec-utility'),
                'type'        => 'object',
            );
            $args['featured_image'] = array(
                'description' => __('Featured image URL for the event.', 'mec-utility'),
                'type'        => 'string',
                'format'      => 'uri',
            );
            $args['images'] = array(
                'description' => __('Gallery images array (URLs or attachment IDs).', 'mec-utility'),
                'type'        => 'array',
                'items'       => array(
                    'type' => 'string',
                ),
            );
            $args['cost'] = array(
                'description' => __('Event cost.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['color'] = array(
                'description' => __('Event color hex.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['public'] = array(
                'description' => __('Visibility boolean for shortcodes.', 'mec-utility'),
                'type'        => 'boolean',
            );
            $args['entity_type'] = array(
                'description' => __('Entity type for the event (event or appointment).', 'mec-utility'),
                'type'        => 'string',
                'enum'        => array('event', 'appointment'),
            );
            $args['appointments'] = array(
                'description' => __('Appointments configuration (only when entity_type is appointment).', 'mec-utility'),
                'type'        => 'object',
            );
            $args['style_per_event'] = array(
                'description' => __('Details Page Style per event.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['mec_category'] = array(
                'description' => __('Category IDs array.', 'mec-utility'),
                'type'        => 'array',
            );
            $args['mec_label'] = array(
                'description' => __('Label IDs array.', 'mec-utility'),
                'type'        => 'array',
            );
            $args['mec_speaker'] = array(
                'description' => __('Speaker IDs array.', 'mec-utility'),
                'type'        => 'array',
            );
            $args['mec_sponsor'] = array(
                'description' => __('Sponsor IDs array.', 'mec-utility'),
                'type'        => 'array',
            );
            $args['mec_tag'] = array(
                'description' => __('Tag IDs or names array. Can mix IDs (integers) and names (strings). New tags will be auto-created.', 'mec-utility'),
                'type'        => 'array',
            );
            $args['tags'] = array(
                'description' => __('Alias for mec_tag. Tag IDs or names array.', 'mec-utility'),
                'type'        => 'array',
            );
            $args['otherLocations'] = array(
                'description' => __('Other location IDs array.', 'mec-utility'),
                'type'        => 'array',
            );
            $args['read_more'] = array(
                'description' => __('Event Link (Read more).', 'mec-utility'),
                'type'        => 'string',
            );
            $args['more_info'] = array(
                'description' => __('More info URL.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['more_info_title'] = array(
                'description' => __('More info title.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['more_info_target'] = array(
                'description' => __('More info target (_blank|_self).', 'mec-utility'),
                'type'        => 'string',
            );
            $args['timezone'] = array(
                'description' => __('Event timezone.', 'mec-utility'),
                'type'        => 'string',
            );
            $args['event_status'] = array(
                'description' => __('Event status for SEO schema (EventScheduled, EventRescheduled, EventPostponed, EventCancelled, EventMovedOnline).', 'mec-utility'),
                'type'        => 'string',
                'enum'        => array('EventScheduled', 'EventRescheduled', 'EventPostponed', 'EventCancelled', 'EventMovedOnline'),
                'default'     => 'EventScheduled',
            );
            $args['cancelled_reason'] = array(
                'description' => __('Reason for cancellation (required if event_status is EventCancelled).', 'mec-utility'),
                'type'        => 'string',
            );
            $args['display_cancellation_reason_in_single_page'] = array(
                'description' => __('Display cancellation reason in single event page.', 'mec-utility'),
                'type'        => 'boolean',
            );
            $args['moved_online_link'] = array(
                'description' => __('Online event link (required if event_status is EventMovedOnline).', 'mec-utility'),
                'type'        => 'string',
                'format'      => 'uri',
            );
            $args['hourly_schedules'] = array(
                'description' => __('Hourly schedule for multi-day events. Array of days with schedules.', 'mec-utility'),
                'type'        => 'array',
                'items'       => array(
                    'type' => 'object',
                    'properties' => array(
                        'title' => array(
                            'type' => 'string',
                            'description' => __('Day title (e.g., "Day 1", "Monday").', 'mec-utility'),
                        ),
                        'schedules' => array(
                            'type' => 'array',
                            'description' => __('Array of time slots for this day.', 'mec-utility'),
                            'items' => array(
                                'type' => 'object',
                                'properties' => array(
                                    'from' => array(
                                        'type' => 'string',
                                        'description' => __('Start time (e.g., "8:15").', 'mec-utility'),
                                    ),
                                    'to' => array(
                                        'type' => 'string',
                                        'description' => __('End time (e.g., "9:30").', 'mec-utility'),
                                    ),
                                    'title' => array(
                                        'type' => 'string',
                                        'description' => __('Schedule title (e.g., "Opening Keynote").', 'mec-utility'),
                                    ),
                                    'description' => array(
                                        'type' => 'string',
                                        'description' => __('Schedule description.', 'mec-utility'),
                                    ),
                                    'speakers' => array(
                                        'type' => 'array',
                                        'description' => __('Speaker term IDs for this schedule.', 'mec-utility'),
                                        'items' => array(
                                            'type' => 'integer',
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            );
            $args['hide_time'] = array(
                'description' => __('Hide event time on event display.', 'mec-utility'),
                'type'        => 'boolean',
                'default'     => false,
            );
            $args['hide_end_time'] = array(
                'description' => __('Hide event end time on event display.', 'mec-utility'),
                'type'        => 'boolean',
                'default'     => false,
            );
            $args['comment'] = array(
                'description'       => __('Notes on the time (e.g., timezone information). Appears next to event time on single event page.', 'mec-utility'),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            );
        }

        return $args;
    }

    /**
     * Sanitize incoming status param from UI-friendly values
     */
    public function sanitize_status_param($value, $request, $param)
    {
        if (is_string($value)) {
            $map = array(
                'Published' => 'publish',
                'Draft' => 'draft',
                'Private' => 'private',
            );
            if (isset($map[$value])) {
                return $map[$value];
            }
        }
        return $value;
    }

    /**
     * Apply date filters to WP_Query using JOIN with mec_events table
     *
     * @param array $args WP_Query arguments
     * @param string $start_date Start date filter
     * @param string $end_date End date filter
     * @param string $date_filter Predefined date filter
     * @return array Modified WP_Query arguments
     */
    private function apply_date_filters($args, $start_date = null, $end_date = null, $date_filter = null)
    {
        global $wpdb;

        // Initialize where arrays
        $date_where = array();
        $occurrence_where = array();

        // Handle predefined date filters
        if (!empty($date_filter)) {
            $today = current_time('Y-m-d');

            switch ($date_filter) {
                case 'today':
                    // Events occurring today: span includes today OR occurrence on today
                    $start_date = $today;
                    $end_date = $today;
                    break;
                case 'upcoming':
                    $start_date = $today;
                    $end_date = null; // No end limit
                    break;
                case 'past':
                    $start_date = null; // No start limit
                    $end_date = date('Y-m-d', strtotime($today . ' -1 day'));
                    break;
                case 'expired':
                    $start_date = null; // No start limit
                    $end_date = date('Y-m-d', strtotime($today . ' -1 day'));
                    break;
                case 'this_week':
                    $start_date = date('Y-m-d', strtotime('monday this week'));
                    $end_date = date('Y-m-d', strtotime('sunday this week'));
                    break;
                case 'this_month':
                    $start_date = date('Y-m-01');
                    $end_date = date('Y-m-t');
                    break;
            }
        }

        // Validate dates
        if (!empty($start_date) && !$this->is_valid_date($start_date)) {
            $start_date = null;
        }
        if (!empty($end_date) && !$this->is_valid_date($end_date)) {
            $end_date = null;
        }

        // If we have date filters, we need to modify the query
        if (!empty($start_date) || !empty($end_date)) {
            // Get post IDs that match date criteria from both mec_events and mec_dates tables
            $matching_post_ids = array();

            // Main events table: select events whose span overlaps requested window
            $date_where = array();
            if (!empty($start_date) && !empty($end_date)) {
                // Overlap: event.start <= end_date AND event.end >= start_date
                $date_where[] = $wpdb->prepare("start <= %s", $end_date);
                $date_where[] = $wpdb->prepare("end >= %s", $start_date);
            } elseif (!empty($start_date)) {
                // Events occurring on specific date: event.start <= date AND event.end >= date
                $date_where[] = $wpdb->prepare("start <= %s", $start_date);
                $date_where[] = $wpdb->prepare("end >= %s", $start_date);
            } elseif (!empty($end_date)) {
                // Fallback: any event ending by end_date
                $date_where[] = $wpdb->prepare("end <= %s", $end_date);
            }
            if (!empty($date_where)) {
                $date_query = "SELECT post_id FROM {$wpdb->prefix}mec_events WHERE " . implode(' AND ', $date_where);
                $main_event_ids = $wpdb->get_col($date_query);
                if (is_array($main_event_ids)) {
                    $matching_post_ids = array_merge($matching_post_ids, $main_event_ids);
                }
            }

            // Occurrences table: days inside window
            $occurrence_where = array();
            if (!empty($start_date) && !empty($end_date)) {
                $occurrence_where[] = $wpdb->prepare("dstart >= %s", $start_date);
                $occurrence_where[] = $wpdb->prepare("dstart <= %s", $end_date);
            } elseif (!empty($start_date)) {
                $occurrence_where[] = $wpdb->prepare("dstart = %s", $start_date);
            } elseif (!empty($end_date)) {
                $occurrence_where[] = $wpdb->prepare("dstart <= %s", $end_date);
            }
            if (!empty($occurrence_where)) {
                $occurrence_query = "SELECT DISTINCT post_id FROM {$wpdb->prefix}mec_dates WHERE " . implode(' AND ', $occurrence_where);
                $occurrence_event_ids = $wpdb->get_col($occurrence_query);
                if (is_array($occurrence_event_ids)) {
                    $matching_post_ids = array_merge($matching_post_ids, $occurrence_event_ids);
                }
            }

            // Remove duplicates and ensure we have valid IDs
            $matching_post_ids = array_unique(array_filter($matching_post_ids));

            if (empty($matching_post_ids)) {
                $args['post__in'] = array(0); // No results
            } else {
                if (isset($args['post__in'])) {
                    $args['post__in'] = array_intersect($args['post__in'], $matching_post_ids);
                } else {
                    $args['post__in'] = $matching_post_ids;
                }
            }
        }

        return $args;
    }

    /**
     * Check if an attendee is valid (not deleted/empty)
     */
    private static function is_valid_attendee($attendee)
    {
        if (!is_array($attendee)) {
            return false;
        }
        
        // An attendee is valid if it has at least name or email (basic validation)
        // Empty arrays or null values are considered invalid
        $has_name = !empty($attendee['name']) && trim($attendee['name']) !== '';
        $has_email = !empty($attendee['email']) && trim($attendee['email']) !== '';
        
        return $has_name || $has_email;
    }

    /**
     * Validate date format
     *
     * @param string $date Date string to validate
     * @return bool True if valid date
     */
    private function is_valid_date($date)
    {
        $d = \DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    /**
     * Convert time to seconds
     */
    private function time_to_seconds($hour, $minutes, $ampm)
    {
        $hour = (int) $hour;
        $minutes = (int) $minutes;

        // Convert to 24-hour format
        if ($ampm === 'AM' && $hour === 12) {
            $hour = 0;
        } elseif ($ampm === 'PM' && $hour !== 12) {
            $hour += 12;
        }

        return ($hour * 3600) + ($minutes * 60);
    }

    /**
     * Handle event taxonomies - ONLY accept existing IDs (no creation)
     */
    protected function handle_event_taxonomies($event_id, $request)
    {
        // Use MEC's taxonomy tag filter (defaults to 'post_tag' if no custom taxonomy is set)
        $tag_taxonomy = apply_filters('mec_taxonomy_tag', 'post_tag');

        // Build taxonomy data from request - ONLY IDs accepted
        $taxonomy_data = array();

        if (isset($request['mec_category'])) $taxonomy_data['mec_category'] = $request['mec_category'];
        if (isset($request['mec_label'])) $taxonomy_data['mec_label'] = $request['mec_label'];
        if (isset($request['mec_speaker'])) $taxonomy_data['mec_speaker'] = $request['mec_speaker'];
        if (isset($request['mec_sponsor'])) $taxonomy_data['mec_sponsor'] = $request['mec_sponsor'];
        if (isset($request['mec_tag'])) $taxonomy_data[$tag_taxonomy] = $request['mec_tag'];


        foreach ($taxonomy_data as $taxonomy => $terms) {

            if (empty($terms) || empty($taxonomy)) {
                continue;
            }

            // Ensure $terms is an array
            if (!is_array($terms)) {
                $terms = [$terms];
            }

            $term_ids = [];

            foreach ($terms as $term) {
                if (is_numeric($term)) {
                    // Handle numeric IDs
                    $term_id = (int) $term;
                    $existing_term = \get_term($term_id, $taxonomy);
                    if (!is_wp_error($existing_term) && $existing_term) {
                        $term_ids[] = $term_id;
                    }
                } else if (is_string($term) && !empty(trim($term))) {
                    // Handle string names - create new terms for tags only
                    $tag_taxonomy_check = apply_filters('mec_taxonomy_tag', 'post_tag');
                    if ($taxonomy === 'mec_tag' || $taxonomy === $tag_taxonomy_check || $taxonomy === 'post_tag') {
                        $term_name = trim($term);
                        $existing_term = \get_term_by('name', $term_name, $taxonomy);
                        if ($existing_term && !is_wp_error($existing_term)) {
                            $term_ids[] = $existing_term->term_id;
                        } else {
                            // Create new tag
                            $new_term = \wp_insert_term($term_name, $taxonomy);
                            if (!is_wp_error($new_term)) {
                                $term_ids[] = $new_term['term_id'];
                            }
                        }
                    }
                }
            }

            // Assign valid term IDs to event
            if (!empty($term_ids)) {
                $result = \wp_set_object_terms($event_id, $term_ids, $taxonomy);
            } else {
            }
        }
    }

    /**
     * Check if an array is numeric (all elements are integers)
     *
     * @param array $array The array to check.
     * @return bool True if all elements are integers, false otherwise.
     */
    private function is_numeric_array($array)
    {
        foreach ($array as $item) {
            if (!is_numeric($item)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Clean HTML tags from event title
     *
     * @param string $title The title to clean.
     * @return string Clean title without HTML tags.
     */
    private function clean_html_from_title($title)
    {
        if (empty($title)) {
            return $title;
        }

        // First decode HTML entities
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Remove HTML tags
        $title = strip_tags($title);

        // Clean up any remaining HTML entities
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Trim whitespace
        $title = trim($title);

        return $title;
    }



    /**
     * Get event colors for specified month or date
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function get_event_colors($request)
    {
        try {
            global $wpdb;

            // Get date parameter from request
            $date_param = $request->get_param('date');

            // If no date provided, use current month
            if (empty($date_param)) {
                $date_param = date('Y-m');
            }

            // Validate date format (should be YYYY-MM or YYYY-MM-DD)
            if (!preg_match('/^\d{4}-\d{2}(-\d{2})?$/', $date_param)) {
                return new \WP_Error(
                    'invalid_date_format',
                    __('Date parameter must be in YYYY-MM or YYYY-MM-DD format.', 'mec-utility'),
                    array('status' => 400)
                );
            }

            // Determine if it's a month or specific date
            $is_month = strlen($date_param) === 7; // YYYY-MM format

            if ($is_month) {
                // Get occurrences for specified month from mec_dates table
                $start_of_month = $date_param . '-01';
                $end_of_month = date('Y-m-t', strtotime($start_of_month));
                $start_timestamp = strtotime($start_of_month);
                $end_timestamp = strtotime($end_of_month . ' 23:59:59');

                $query = $wpdb->prepare(
                    "SELECT d.post_id, d.tstart, d.dstart, p.post_status 
                     FROM {$wpdb->prefix}mec_dates d 
                     INNER JOIN {$wpdb->posts} p ON d.post_id = p.ID 
                     WHERE d.tstart >= %d AND d.tstart <= %d 
                     AND p.post_type = 'mec-events' 
                     AND p.post_status = 'publish' 
                     AND d.public = 1
                     ORDER BY d.tstart ASC",
                    $start_timestamp,
                    $end_timestamp
                );
            } else {
                // Get occurrences for specific date
                $specific_date = $date_param;
                $start_timestamp = strtotime($specific_date);
                $end_timestamp = strtotime($specific_date . ' 23:59:59');

                $query = $wpdb->prepare(
                    "SELECT d.post_id, d.tstart, d.dstart, p.post_status 
                     FROM {$wpdb->prefix}mec_dates d 
                     INNER JOIN {$wpdb->posts} p ON d.post_id = p.ID 
                     WHERE d.tstart >= %d AND d.tstart <= %d 
                     AND p.post_type = 'mec-events' 
                     AND p.post_status = 'publish' 
                     AND d.public = 1
                     ORDER BY d.tstart ASC",
                    $start_timestamp,
                    $end_timestamp
                );
            }

            $occurrences = $wpdb->get_results($query);

            // Group occurrences by date and limit to 3 per day
            $events_by_date = array();
            foreach ($occurrences as $occurrence) {
                $start_timestamp = (int) $occurrence->tstart;
                $start_date = $occurrence->dstart;

                $occurrence_color = '';
                $labels = \wp_get_post_terms($occurrence->post_id, 'mec_label', ['fields' => 'all']);
                if (!\is_wp_error($labels) && !empty($labels)) {
                    $occurrence_color = \get_term_meta($labels[0]->term_id, 'color', true);
                }
                if (empty($occurrence_color)) {
                    $occurrence_color = get_post_meta($occurrence->post_id, 'mec_color', true);
                }
                if (empty($occurrence_color)) {
                    $occurrence_color = '#ff5733';
                }

                $date_key = date('Y-m-d', $start_timestamp);

                if (!isset($events_by_date[$date_key])) {
                    $events_by_date[$date_key] = array();
                }

                // Avoid duplicates per day
                $duplicate = false;
                foreach ($events_by_date[$date_key] as $ev) {
                    if ((int) $ev['id'] === (int) $occurrence->post_id) {
                        $duplicate = true;
                        break;
                    }
                }

                if (!$duplicate) {
                    $events_by_date[$date_key][] = array(
                        'id' => (int) $occurrence->post_id,
                        'start_date' => $start_date,
                        'color' => $occurrence_color,
                        'month' => (int) date('n', $start_timestamp),
                        'month_name' => date('F', $start_timestamp)
                    );
                }
            }

            // Also include non-recurring multi-day (and single-day) events by expanding spans from mec_events
            $window_start_date = $is_month ? $start_of_month : $specific_date;
            $window_end_date = $is_month ? $end_of_month : $specific_date;

            $events_sql = $wpdb->prepare(
                "SELECT e.post_id, e.start, e.end 
                 FROM {$wpdb->prefix}mec_events e 
                 INNER JOIN {$wpdb->posts} p ON e.post_id = p.ID 
                 WHERE p.post_type = 'mec-events' 
                   AND p.post_status = 'publish' 
                   AND e.start <= %s 
                   AND e.end >= %s",
                $window_end_date,
                $window_start_date
            );

            $spanning_events = $wpdb->get_results($events_sql);

            if (is_array($spanning_events)) {
                foreach ($spanning_events as $evt) {
                    $post_id = (int) $evt->post_id;
                    if (empty($post_id)) continue;

                    // Clip event span to window
                    $evt_start_ts = strtotime($evt->start ?: $window_start_date);
                    $evt_end_ts = strtotime($evt->end ?: $evt->start ?: $window_end_date);
                    $win_start_ts = strtotime($window_start_date);
                    $win_end_ts = strtotime($window_end_date);

                    if ($evt_end_ts < $win_start_ts || $evt_start_ts > $win_end_ts) {
                        continue;
                    }

                    $span_start = max($evt_start_ts, $win_start_ts);
                    $span_end = min($evt_end_ts, $win_end_ts);

                    // Expand per day
                    for ($day_ts = $span_start; $day_ts <= $span_end; $day_ts = strtotime('+1 day', $day_ts)) {
                        $date_key = date('Y-m-d', $day_ts);
                        if (!isset($events_by_date[$date_key])) {
                            $events_by_date[$date_key] = array();
                        }

                        // Deduplicate if already present (e.g., from mec_dates for recurring)
                        $duplicate = false;
                        foreach ($events_by_date[$date_key] as $ev) {
                            if ((int) $ev['id'] === $post_id) {
                                $duplicate = true;
                                break;
                            }
                        }

                        if ($duplicate) {
                            continue;
                        }

                        $event_color = '';
                        $labels = \wp_get_post_terms($post_id, 'mec_label', ['fields' => 'all']);
                        if (!\is_wp_error($labels) && !empty($labels)) {
                            $event_color = \get_term_meta($labels[0]->term_id, 'color', true);
                        }
                        if (empty($event_color)) {
                            $event_color = get_post_meta($post_id, 'mec_color', true);
                        }
                        if (empty($event_color)) {
                            $event_color = '#ff5733';
                        }

                        $events_by_date[$date_key][] = array(
                            'id' => $post_id,
                            'start_date' => $date_key,
                            'color' => $event_color,
                            'month' => (int) date('n', $day_ts),
                            'month_name' => date('F', $day_ts)
                        );
                    }
                }
            }

            // Format response
            $response_data = array();
            foreach ($events_by_date as $date => $day_events) {
                $response_data[] = array(
                    'date' => $date,
                    'events' => $day_events
                );
            }

            return new \WP_REST_Response([
                'success' => true,
                'data' => $response_data,
                'requested_date' => $date_param,
                'is_month' => $is_month,
                'total_dates' => count($response_data)
            ], 200);
        } catch (\Exception $e) {
            return new \WP_Error(
                'mec_utility_event_colors_error',
                __('Unable to retrieve event colors: ', 'mec-utility') . $e->getMessage(),
                array('status' => 500)
            );
        }
    }

    /**
     * Get recurring event occurrences
     *
     * @param int $event_id Event ID
     * @param string $start_date Start date for occurrences (optional)
     * @param int $limit Maximum number of occurrences to return
     * @return array Array of occurrence data
     */
    protected function get_event_occurrences($event_id, $start_date = null, $limit = 50)
    {
        global $wpdb;

        // Build query to get occurrences
        $where_conditions = ["`post_id` = %d", "`public` = 1"];
        $query_params = [$event_id];

        if ($start_date) {
            $start_timestamp = strtotime($start_date);
            $where_conditions[] = "`tstart` >= %d";
            $query_params[] = $start_timestamp;
        }

        $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

        $sql = "SELECT `id`, `post_id`, `dstart`, `dend`, `tstart`, `tend`, `public` 
                FROM `{$wpdb->prefix}mec_dates` 
                {$where_clause} 
                ORDER BY `tstart` ASC 
                LIMIT %d";

        $query_params[] = $limit;

        $occurrences = $wpdb->get_results($wpdb->prepare($sql, $query_params));

        if (empty($occurrences)) {
            return [];
        }

        $formatted_occurrences = [];
        $current_time = current_time('timestamp');

        foreach ($occurrences as $occurrence) {
            $start_timestamp = (int) $occurrence->tstart;
            $end_timestamp = (int) $occurrence->tend;

            // Format dates and times
            $start_date = date('Y-m-d', $start_timestamp);
            $end_date = date('Y-m-d', $end_timestamp);
            $start_time = date('H:i:s', $start_timestamp);
            $end_time = date('H:i:s', $end_timestamp);
            $start_datetime = date('Y-m-d H:i:s', $start_timestamp);
            $end_datetime = date('Y-m-d H:i:s', $end_timestamp);

            // Determine status
            $is_past = $end_timestamp < $current_time;
            $is_today = date('Y-m-d', $start_timestamp) === date('Y-m-d', $current_time);
            $is_upcoming = $start_timestamp > $current_time;

            // Get occurrence-specific parameters
            $occurrence_params = [];
            $title = $this->clean_html_from_title(get_the_title($event_id));
            $cost = get_post_meta($event_id, 'mec_cost', true);
            $location_id = get_post_meta($event_id, 'mec_location_id', true);
            $organizer_id = get_post_meta($event_id, 'mec_organizer_id', true);
            $event_status = get_post_meta($event_id, 'mec_event_status', true);
            $bookings_limit = get_post_meta($event_id, 'mec_bookings_limit', true);
            $cancelled_reason = get_post_meta($event_id, 'mec_cancelled_reason', true);
            $moved_online_link = get_post_meta($event_id, 'mec_moved_online_link', true);

            // Try to get occurrence-specific overrides
            if (class_exists('MEC_feature_occurrences')) {
                $occurrence_params = \MEC_feature_occurrences::param($event_id, $start_timestamp, '*', []);

                if (!empty($occurrence_params)) {
                    $title = isset($occurrence_params['title']) && !empty($occurrence_params['title']) ? $occurrence_params['title'] : $title;
                    $cost = isset($occurrence_params['cost']) && !empty($occurrence_params['cost']) ? $occurrence_params['cost'] : $cost;
                    $location_id = isset($occurrence_params['location_id']) && !empty($occurrence_params['location_id']) ? $occurrence_params['location_id'] : $location_id;
                    $organizer_id = isset($occurrence_params['organizer_id']) && !empty($occurrence_params['organizer_id']) ? $occurrence_params['organizer_id'] : $organizer_id;
                    $event_status = isset($occurrence_params['event_status']) && !empty($occurrence_params['event_status']) ? $occurrence_params['event_status'] : $event_status;
                    $bookings_limit = isset($occurrence_params['bookings_limit']) && !empty($occurrence_params['bookings_limit']) ? $occurrence_params['bookings_limit'] : $bookings_limit;
                    $cancelled_reason = isset($occurrence_params['cancelled_reason']) && !empty($occurrence_params['cancelled_reason']) ? $occurrence_params['cancelled_reason'] : $cancelled_reason;
                    $moved_online_link = isset($occurrence_params['moved_online_link']) && !empty($occurrence_params['moved_online_link']) ? $occurrence_params['moved_online_link'] : $moved_online_link;
                }
            }

            // Get attendee information for this occurrence
            $attendee_info = $this->get_occurrence_attendee_info($event_id, $start_timestamp);

            $formatted_occurrences[] = [
                'start_timestamp' => (string) $start_timestamp,
                'end_timestamp' => (string) $end_timestamp,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'start_time' => $start_time,
                'end_time' => $end_time,
                'start_datetime' => $start_datetime,
                'end_datetime' => $end_datetime,
                'is_past' => $is_past,
                'is_today' => $is_today,
                'is_upcoming' => $is_upcoming,
                'occurrence_id' => $event_id . '_' . $start_timestamp,
                'params' => $occurrence_params,
                'title' => $this->clean_html_from_title($title),
                'cost' => $cost,
                'location_id' => $location_id,
                'organizer_id' => $organizer_id,
                'event_status' => $event_status,
                'bookings_limit' => $bookings_limit,
                'cancelled_reason' => $cancelled_reason,
                'moved_online_link' => $moved_online_link,
                'attendees' => $attendee_info
            ];
        }

        return $formatted_occurrences;
    }

    /**
     * Build day-by-day occurrences for a non-recurring multi-day event
     *
     * @param int $event_id
     * @param string|null $start_date Optional filter to start from a given date (Y-m-d)
     * @param int $limit Maximum number of daily entries to return
     * @return array
     */
    protected function get_multiday_occurrences($event_id, $start_date = null, $limit = 50)
    {
        // Determine start and end dates from meta
        $start = get_post_meta($event_id, 'mec_start_date', true);
        $end = get_post_meta($event_id, 'mec_end_date', true);

        if (empty($start)) {
            return [];
        }
        if (empty($end)) {
            $end = $start;
        }

        // Normalize filter start date
        if (!empty($start_date) && !$this->is_valid_date($start_date)) {
            $start_date = null;
        }

        // Event time settings
        $allday = get_post_meta($event_id, 'mec_allday', true);
        $start_time_hour = intval(get_post_meta($event_id, 'mec_start_time_hour', true));
        $start_time_minutes = intval(get_post_meta($event_id, 'mec_start_time_minutes', true));
        $start_time_ampm = strtoupper(get_post_meta($event_id, 'mec_start_time_ampm', true));
        $end_time_hour = intval(get_post_meta($event_id, 'mec_end_time_hour', true));
        $end_time_minutes = intval(get_post_meta($event_id, 'mec_end_time_minutes', true));
        $end_time_ampm = strtoupper(get_post_meta($event_id, 'mec_end_time_ampm', true));

        $start_seconds = $this->time_to_seconds($start_time_hour ?: 8, $start_time_minutes ?: 0, $start_time_ampm ?: 'AM');
        $end_seconds = $this->time_to_seconds($end_time_hour ?: 6, $end_time_minutes ?: 0, $end_time_ampm ?: 'PM');

        // Build daily periods
        $days = [];
        $current = strtotime($start);
        $end_ts = strtotime($end);
        $today_ts = current_time('timestamp');

        // If filter provided, advance current to filter start
        if (!empty($start_date)) {
            $filter_ts = strtotime($start_date);
            if ($filter_ts > $current) {
                $current = $filter_ts;
            }
        }

        while ($current <= $end_ts && count($days) < (int) $limit) {
            $day_str = date('Y-m-d', $current);

            if ($allday == '1') {
                $day_start_ts = strtotime($day_str . ' 00:00:00');
                $day_end_ts = strtotime($day_str . ' 23:59:59');
            } else {
                $day_start_ts = strtotime($day_str . ' 00:00:00') + $start_seconds;
                $day_end_ts = strtotime($day_str . ' 00:00:00') + $end_seconds;
            }

            // In case end time is earlier than start time, push end to next day
            if ($day_end_ts <= $day_start_ts) {
                $day_end_ts = strtotime($day_str . ' 00:00:00') + 24 * 3600 + max(0, $end_seconds);
            }

            // Basic details
            $title = $this->clean_html_from_title(get_the_title($event_id));
            $cost = get_post_meta($event_id, 'mec_cost', true);
            $location_id = get_post_meta($event_id, 'mec_location_id', true);
            $organizer_id = get_post_meta($event_id, 'mec_organizer_id', true);
            $event_status = get_post_meta($event_id, 'mec_event_status', true);
            $bookings_limit = get_post_meta($event_id, 'mec_bookings_limit', true);
            $cancelled_reason = get_post_meta($event_id, 'mec_cancelled_reason', true);
            $moved_online_link = get_post_meta($event_id, 'mec_moved_online_link', true);

            $attendee_info = $this->get_occurrence_attendee_info($event_id, $day_start_ts);

            $days[] = [
                'start_timestamp' => (string) $day_start_ts,
                'end_timestamp' => (string) $day_end_ts,
                'start_date' => date('Y-m-d', $day_start_ts),
                'end_date' => date('Y-m-d', $day_end_ts),
                'start_time' => date('H:i:s', $day_start_ts),
                'end_time' => date('H:i:s', $day_end_ts),
                'start_datetime' => date('Y-m-d H:i:s', $day_start_ts),
                'end_datetime' => date('Y-m-d H:i:s', $day_end_ts),
                'is_past' => $day_end_ts < $today_ts,
                'is_today' => date('Y-m-d', $day_start_ts) === date('Y-m-d', $today_ts),
                'is_upcoming' => $day_start_ts > $today_ts,
                'occurrence_id' => $event_id . '_' . $day_start_ts,
                'params' => [],
                'title' => $this->clean_html_from_title($title),
                'cost' => $cost,
                'location_id' => $location_id,
                'organizer_id' => $organizer_id,
                'event_status' => $event_status,
                'bookings_limit' => $bookings_limit,
                'cancelled_reason' => $cancelled_reason,
                'moved_online_link' => $moved_online_link,
                'attendees' => $attendee_info
            ];

            // next day
            $current = strtotime('+1 day', $current);
        }

        return $days;
    }

    /**
     * Get attendee information for a specific occurrence
     */
    private function get_occurrence_attendee_info($event_id, $occurrence_timestamp)
    {
        global $wpdb;

        // Try to get bookings from mec_bookings table first
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}mec_bookings'");
        
        $bookings = [];
        $debug_info = [
            'event_id' => $event_id,
            'occurrence_timestamp' => $occurrence_timestamp,
            'table_exists' => !empty($table_exists),
            'method' => ''
        ];

        if ($table_exists) {
            // Method 1: Use mec_bookings custom table
            // First, get ALL bookings for this event to debug
            $all_bookings_sql = "SELECT `id`, `booking_id`, `event_id`, `ticket_ids`, `status`, `confirmed`, `verified`, `all_occurrences`, `date`, `timestamp` 
                                FROM `{$wpdb->prefix}mec_bookings` 
                                WHERE `event_id` = %d";
            $all_bookings_for_event = $wpdb->get_results($wpdb->prepare($all_bookings_sql, $event_id));
            
            $debug_info['all_bookings_for_event'] = count($all_bookings_for_event);
            $debug_info['all_bookings_details'] = [];
            foreach ($all_bookings_for_event as $b) {
                $debug_info['all_bookings_details'][] = [
                    'booking_id' => $b->booking_id,
                    'timestamp' => $b->timestamp,
                    'all_occurrences' => $b->all_occurrences ?? 0
                ];
            }
            
            // Get bookings for specific occurrence OR all occurrences
            $bookings_sql = "SELECT `id`, `booking_id`, `event_id`, `ticket_ids`, `status`, `confirmed`, `verified`, `all_occurrences`, `date`, `timestamp` 
                            FROM `{$wpdb->prefix}mec_bookings` 
                            WHERE `event_id` = %d AND (`timestamp` = %d OR `all_occurrences` = 1 OR `timestamp` = 0)";

            $bookings = $wpdb->get_results($wpdb->prepare($bookings_sql, $event_id, $occurrence_timestamp));
            $debug_info['method'] = 'custom_table';
            $debug_info['bookings_found'] = count($bookings);
            
            // Debug: Show which bookings matched
            foreach ($bookings as $b) {
                $debug_info['matched_bookings'][] = [
                    'booking_id' => $b->booking_id,
                    'timestamp' => $b->timestamp,
                    'all_occurrences' => $b->all_occurrences ?? 0
                ];
            }
        }
        
        // Fallback: If no table or no bookings, use wp_posts method
        if (empty($bookings)) {
            $debug_info['method'] = 'wp_posts_fallback';
            
            // Get all bookings for this event from wp_posts
            $booking_posts = get_posts([
                'post_type' => 'mec_bookings',
                'numberposts' => -1,
                'post_status' => 'any',
                'meta_query' => [
                    [
                        'key' => 'mec_event_id',
                        'value' => $event_id,
                        'compare' => '='
                    ]
                ]
            ]);
            
            $debug_info['booking_posts_found'] = count($booking_posts);
            
            // Convert wp_posts bookings to same structure
            foreach ($booking_posts as $booking_post) {
                // Check if this booking is for the specific occurrence
                $booking_timestamp = get_post_meta($booking_post->ID, 'mec_booking_timestamp', true);
                $all_occurrences = get_post_meta($booking_post->ID, 'mec_all_occurrences', true);
                
                $debug_info['booking_' . $booking_post->ID . '_timestamp'] = $booking_timestamp;
                $debug_info['booking_' . $booking_post->ID . '_all_occurrences'] = $all_occurrences;
                
                // Include if: matches timestamp OR all_occurrences OR no timestamp
                $should_include = false;
                if (empty($booking_timestamp) || $booking_timestamp == 0) {
                    $should_include = true; // No timestamp means for all occurrences
                } elseif ($booking_timestamp == $occurrence_timestamp) {
                    $should_include = true; // Specific occurrence
                } elseif ($all_occurrences == 1) {
                    $should_include = true; // All occurrences
                }
                
                if (!$should_include) {
                    continue;
                }
                
                // Create pseudo booking object matching custom table structure
                $bookings[] = (object)[
                    'booking_id' => $booking_post->ID,
                    'event_id' => $event_id,
                    'status' => $booking_post->post_status,
                    'confirmed' => get_post_meta($booking_post->ID, 'mec_confirmed', true),
                    'verified' => get_post_meta($booking_post->ID, 'mec_verified', true),
                    'timestamp' => $occurrence_timestamp,
                    'all_occurrences' => $all_occurrences
                ];
            }
            
            $debug_info['filtered_bookings'] = count($bookings);
        }

        $total_attendees = 0;
        $attendee_details = [];

        foreach ($bookings as $booking) {
            $booking_id = isset($booking->booking_id) ? $booking->booking_id : $booking->ID;

            // Get attendees from booking post meta
            $attendees = get_post_meta($booking_id, 'mec_attendees', true);

            if (is_array($attendees)) {
                foreach ($attendees as $key => $attendee) {
                    if (!is_numeric($key)) continue; // Skip non-numeric keys

                    $total_attendees++;

                    // Add avatar
                    $avatar = '';
                    if (isset($attendee['email']) && !empty($attendee['email'])) {
                        $user = get_user_by('email', $attendee['email']);
                        if ($user) {
                            $avatar = get_avatar_url($user->ID, ['size' => 96]);
                        } else {
                            $avatar = get_avatar_url($attendee['email'], ['size' => 96]);
                        }
                    }

                    // Add check-in status
                    $checkin_status = null;
                    $checkin_available = false;
                    if (class_exists('MEC_Invoice\\Attendee')) {
                        $checkin_available = true;
                        $invoice_id = $this->get_invoice_id_by_booking($booking_id);
                        if ($invoice_id) {
                            $attendee_class = 'MEC_Invoice\\Attendee';
                            $checkin_status = $attendee_class::hasCheckedIn(
                                $invoice_id,
                                $attendee['email'] ?? '',
                                $key + 1,
                                $occurrence_timestamp
                            );
                        }
                    }

                    // Get invoice ID for this booking
                    $invoice_id = get_post_meta($booking_id, 'invoiceID', true);
                    
                    // Add basic attendee info with enhanced details
                    $attendee_details[] = [
                        'booking_id' => $booking_id,
                        'invoice_id' => $invoice_id ? (int) $invoice_id : null,
                        'attendee_key' => $key + 1,
                        'first_name' => isset($attendee['first_name']) ? $attendee['first_name'] : '',
                        'last_name' => isset($attendee['last_name']) ? $attendee['last_name'] : '',
                        'name' => isset($attendee['name']) ? $attendee['name'] : '',
                        'email' => isset($attendee['email']) ? $attendee['email'] : '',
                        'avatar' => $avatar,
                        'ticket_id' => isset($attendee['id']) ? $attendee['id'] : '',
                        'ticket_name' => isset($attendee['ticket_name']) ? $attendee['ticket_name'] : '',
                        'booking_status' => $booking->status,
                        'booking_confirmed' => (bool) $booking->confirmed,
                        'booking_verified' => (bool) $booking->verified,
                        'reg' => isset($attendee['reg']) ? $attendee['reg'] : [],
                        'checkin_status' => $checkin_status,
                        'checkin_available' => $checkin_available
                    ];
                }
            }
        }

        return [
            'total_attendees' => $total_attendees,
            'attendees' => $attendee_details,
            'booking_count' => count($bookings),
            'debug' => $debug_info
        ];
    }

    /**
     * Get event occurrences endpoint
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_event_occurrences_endpoint($request)
    {
        $event_id = $request->get_param('id');
        $event    = get_post($event_id);

        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new WP_Error(
                'mec_utility_event_not_found',
                __('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        $start_date = $request->get_param('start_date');
        $limit = $request->get_param('limit') ?: 50;

        // Determine event type
        $repeat_status = get_post_meta($event_id, 'mec_repeat_status', true);
        $is_recurring = ($repeat_status === '1');

        $start = get_post_meta($event_id, 'mec_start_date', true);
        $end = get_post_meta($event_id, 'mec_end_date', true);
        $is_multiday = (!empty($start) && !empty($end) && $end > $start);

        if ($is_recurring) {
            $occurrences = $this->get_event_occurrences($event_id, $start_date, $limit);
        } else {
            // For non-recurring events, return multi-day daily entries (or single-day occurrence)
            $occurrences = $this->get_multiday_occurrences($event_id, $start_date, $limit);
        }

        $response_data = [
            'event_id' => $event_id,
            'event_title' => $this->clean_html_from_title(get_the_title($event_id)),
            'occurrences' => $occurrences,
            'total_occurrences' => count($occurrences),
            'is_recurring' => (bool) $is_recurring,
            'is_multiday' => (bool) $is_multiday,
        ];

        return rest_ensure_response($response_data);
    }

    /**
     * Get attendees for a specific occurrence
     */
    public function get_occurrence_attendees($request)
    {
        try {
            $event_id = (int) $request['event_id'];
            $occurrence_timestamp = (int) $request['occurrence_timestamp'];
            $include_details = (bool) $request['include_details'];

            // Validate event exists
            $event = get_post($event_id);
            if (!$event || get_post_type($event_id) !== 'mec-events') {
                return new WP_Error(
                    'event_not_found',
                    'Event not found.',
                    ['status' => 404]
                );
            }

            // Validate occurrence exists
            global $wpdb;
            $occurrence_exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM `{$wpdb->prefix}mec_dates` 
                 WHERE `post_id` = %d AND `tstart` = %d AND `public` = 1",
                $event_id,
                $occurrence_timestamp
            ));

            if (!$occurrence_exists) {
                return new WP_Error(
                    'occurrence_not_found',
                    'Occurrence not found.',
                    ['status' => 404]
                );
            }

            // Get attendee information for this occurrence
            $attendee_info = $this->get_occurrence_attendee_info($event_id, $occurrence_timestamp);

            // Format response
            $response_data = [
                'event_id' => $event_id,
                'event_title' => $this->clean_html_from_title(get_the_title($event_id)),
                'occurrence_timestamp' => $occurrence_timestamp,
                'occurrence_date' => date('Y-m-d', $occurrence_timestamp),
                'occurrence_time' => date('H:i:s', $occurrence_timestamp),
                'occurrence_datetime' => date('Y-m-d H:i:s', $occurrence_timestamp),
                'total_attendees' => $attendee_info['total_attendees'],
                'booking_count' => $attendee_info['booking_count'],
                'attendees' => $attendee_info['attendees']
            ];

            // Include detailed attendee information if requested
            if ($include_details) {
                $response_data['detailed_attendees'] = $this->get_detailed_attendee_info($event_id, $occurrence_timestamp);
            }

            return new WP_REST_Response($response_data, 200);
        } catch (\Exception $e) {
            return new WP_Error(
                'occurrence_attendees_error',
                'Unable to retrieve occurrence attendees: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }

    /**
     * Get attendees check-in status only (lightweight endpoint for quick status checks)
     */
    public function get_occurrence_attendees_status($request)
    {
        try {
            $event_id = (int) $request['event_id'];
            $occurrence_timestamp = (int) $request['occurrence_timestamp'];

            // Validate event exists
            $event = get_post($event_id);
            if (!$event || get_post_type($event_id) !== 'mec-events') {
                return new WP_Error(
                    'event_not_found',
                    'Event not found.',
                    ['status' => 404]
                );
            }

            // Get attendee information (reuse existing method)
            $attendee_info = $this->get_occurrence_attendee_info($event_id, $occurrence_timestamp);

            // Extract only essential status information
            $status_list = [];
            foreach ($attendee_info['attendees'] as $attendee) {
                $status_list[] = [
                    'booking_id' => $attendee['booking_id'],
                    'invoice_id' => $attendee['invoice_id'],
                    'attendee_key' => $attendee['attendee_key'],
                    'email' => $attendee['email'],
                    'name' => $attendee['name'],
                    'checkin_status' => $attendee['checkin_status'],
                    'checkin_available' => $attendee['checkin_available']
                ];
            }

            // Format response
            $response_data = [
                'event_id' => $event_id,
                'occurrence_timestamp' => $occurrence_timestamp,
                'occurrence_date' => date('Y-m-d', $occurrence_timestamp),
                'total_attendees' => $attendee_info['total_attendees'],
                'checked_in_count' => count(array_filter($status_list, fn($a) => $a['checkin_status'] === true)),
                'checked_out_count' => count(array_filter($status_list, fn($a) => $a['checkin_status'] === false)),
                'attendees_status' => $status_list,
                'last_updated' => current_time('mysql')
            ];

            return new WP_REST_Response($response_data, 200);
        } catch (\Exception $e) {
            return new WP_Error(
                'occurrence_status_error',
                'Unable to retrieve attendees status: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }

    /**
     * Export occurrence attendees to CSV or Excel file
     */
    public function export_occurrence_attendees($request)
    {
        try {
            $event_id = (int) $request['event_id'];
            $occurrence_timestamp = (int) $request['occurrence_timestamp'];
            $format = strtolower($request->get_param('format') ?? 'csv');
            $force_download = (bool) $request->get_param('download');

            // Validate event exists
            $event = get_post($event_id);
            if (!$event || get_post_type($event_id) !== 'mec-events') {
                return new WP_Error(
                    'event_not_found',
                    'Event not found.',
                    ['status' => 404]
                );
            }

            // Get attendee information
            $attendee_info = $this->get_occurrence_attendee_info($event_id, $occurrence_timestamp);

            if (empty($attendee_info['attendees'])) {
                return new WP_Error(
                    'no_attendees',
                    'No attendees found for this occurrence.',
                    ['status' => 404]
                );
            }

            // Prepare data rows
            $rows = [];
            $headers = [
                'invoice_id',
                'booking_id',
                'event_id',
                'attendee_key',
                'name',
                'email',
                'phone',
                'ticket_name',
                'ticket_id',
                'checkin_status',
                'checkin_time',
                'checkout_time',
                'transaction_id'
            ];

            foreach ($attendee_info['attendees'] as $attendee) {
                $rows[] = [
                    'invoice_id' => $attendee['invoice_id'],
                    'booking_id' => $attendee['booking_id'],
                    'event_id' => $event_id,
                    'attendee_key' => $attendee['attendee_key'],
                    'name' => $attendee['name'],
                    'email' => $attendee['email'],
                    'phone' => $attendee['phone'] ?? '',
                    'ticket_name' => $attendee['ticket_name'] ?? '',
                    'ticket_id' => $attendee['ticket_id'] ?? '',
                    'checkin_status' => $attendee['checkin_status'] ? 'Checked In' : 'Not Checked',
                    'checkin_time' => $attendee['checkin_time'] ?? '',
                    'checkout_time' => $attendee['checkout_time'] ?? '',
                    'transaction_id' => $attendee['transaction_id'] ?? ''
                ];
            }

            // Get upload directory
            $upload_dir = wp_upload_dir();
            $event_slug = sanitize_title($event->post_title);
            $occurrence_date = date('Y-m-d', $occurrence_timestamp);

            // Generate file based on format
            if ($format === 'excel' || $format === 'xlsx') {
                // Excel export
                $filename = 'attendees-' . $event_slug . '-' . $occurrence_date . '-' . date('Ymd-His') . '.xlsx';
                $file_path = trailingslashit($upload_dir['basedir']) . $filename;
                $file_url = trailingslashit($upload_dir['baseurl']) . $filename;

                // Check if PhpSpreadsheet is available
                if (class_exists('\PhpOffice\PhpSpreadsheet\Spreadsheet')) {
                    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
                    $sheet = $spreadsheet->getActiveSheet();
                    
                    // Set headers
                    $col = 1;
                    foreach ($headers as $header) {
                        $sheet->setCellValueByColumnAndRow($col, 1, ucwords(str_replace('_', ' ', $header)));
                        $col++;
                    }
                    
                    // Style header row
                    $sheet->getStyle('A1:' . $sheet->getCellByColumnAndRow($col - 1, 1)->getCoordinate())
                          ->getFont()->setBold(true);
                    
                    // Add data rows
                    $row_num = 2;
                    foreach ($rows as $row) {
                        $col = 1;
                        foreach ($headers as $header) {
                            $sheet->setCellValueByColumnAndRow($col, $row_num, $row[$header] ?? '');
                            $col++;
                        }
                        $row_num++;
                    }
                    
                    // Auto-size columns
                    foreach (range(1, count($headers)) as $col) {
                        $sheet->getColumnDimensionByColumn($col)->setAutoSize(true);
                    }
                    
                    // Save file
                    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
                    $writer->save($file_path);
                } else {
                    return new WP_Error(
                        'excel_library_not_found',
                        'Excel library (PhpSpreadsheet) not available. Please install it or use CSV format.',
                        ['status' => 500]
                    );
                }
            } else {
                // CSV export (default)
                $filename = 'attendees-' . $event_slug . '-' . $occurrence_date . '-' . date('Ymd-His') . '.csv';
                $file_path = trailingslashit($upload_dir['basedir']) . $filename;
                $file_url = trailingslashit($upload_dir['baseurl']) . $filename;

                $fh = fopen($file_path, 'w');
                if (!$fh) {
                    return new WP_Error(
                        'file_creation_failed',
                        'Failed to create CSV file.',
                        ['status' => 500]
                    );
                }

                // Write headers
                fputcsv($fh, $headers);

                // Write data rows
                foreach ($rows as $row) {
                    $csv_row = [];
                    foreach ($headers as $header) {
                        $csv_row[] = $row[$header] ?? '';
                    }
                    fputcsv($fh, $csv_row);
                }

                fclose($fh);
            }

            // Create attachment in media library
            $mime_type = ($format === 'excel' || $format === 'xlsx') 
                ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
                : 'text/csv';

            $attachment = array(
                'post_mime_type' => $mime_type,
                'post_title' => 'Occurrence Attendees Export - ' . $event->post_title . ' - ' . $occurrence_date,
                'post_content' => '',
                'post_status' => 'inherit'
            );

            $attachment_id = wp_insert_attachment($attachment, $file_path);

            // Schedule file deletion after 24 hours
            if ($attachment_id && function_exists('wp_schedule_single_event')) {
                wp_schedule_single_event(time() + (24 * 3600), 'mec_utility_delete_temp_file', array($file_path, $attachment_id));
            }

            // If force download is requested, stream the file directly
            if ($force_download) {
                // Clear any previous output
                if (ob_get_level()) {
                    ob_end_clean();
                }

                // Set headers for file download
                header('Content-Type: ' . $mime_type);
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Content-Length: ' . filesize($file_path));
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Pragma: public');
                header('Expires: 0');

                // Read and output file
                readfile($file_path);
                exit;
            }

            // Return download URL if not forcing download
            return new WP_REST_Response([
                'success' => true,
                'download_url' => $file_url,
                'filename' => $filename,
                'attachment_id' => $attachment_id,
                'format' => $format,
                'rows_count' => count($rows),
                'event_id' => $event_id,
                'occurrence_timestamp' => $occurrence_timestamp,
                'occurrence_date' => $occurrence_date,
                'expires_in' => '24 hours'
            ], 200);

        } catch (\Exception $e) {
            return new WP_Error(
                'export_error',
                'Error exporting attendees: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }

    /**
     * Download occurrence attendees file directly (force download)
     */
    public function download_occurrence_attendees($request)
    {
        // Set download parameter to true and call export method
        $request->set_param('download', true);
        return $this->export_occurrence_attendees($request);
    }

    /**
     * Get detailed attendee information for an occurrence
     */
    private function get_detailed_attendee_info($event_id, $occurrence_timestamp)
    {
        global $wpdb;

        // Try to get bookings from mec_bookings table first
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}mec_bookings'");
        
        $bookings = [];

        if ($table_exists) {
            // Method 1: Use mec_bookings custom table
            // Get bookings for specific occurrence OR all occurrences
            $bookings_sql = "SELECT `id`, `booking_id`, `event_id`, `ticket_ids`, `status`, `confirmed`, `verified`, `all_occurrences`, `date`, `timestamp` 
                            FROM `{$wpdb->prefix}mec_bookings` 
                            WHERE `event_id` = %d AND (`timestamp` = %d OR `all_occurrences` = 1 OR `timestamp` = 0)";

            $bookings = $wpdb->get_results($wpdb->prepare($bookings_sql, $event_id, $occurrence_timestamp));
        }
        
        // Fallback: If no table or no bookings, use wp_posts method
        if (empty($bookings)) {
            // Get all bookings for this event from wp_posts
            $booking_posts = get_posts([
                'post_type' => 'mec_bookings',
                'numberposts' => -1,
                'post_status' => 'any',
                'meta_query' => [
                    [
                        'key' => 'mec_event_id',
                        'value' => $event_id,
                        'compare' => '='
                    ]
                ]
            ]);
            
            // Convert wp_posts bookings to same structure
            foreach ($booking_posts as $booking_post) {
                // Check if this booking is for the specific occurrence
                $booking_timestamp = get_post_meta($booking_post->ID, 'mec_booking_timestamp', true);
                $all_occurrences = get_post_meta($booking_post->ID, 'mec_all_occurrences', true);
                
                // Include if: matches timestamp OR all_occurrences OR no timestamp
                $should_include = false;
                if (empty($booking_timestamp) || $booking_timestamp == 0) {
                    $should_include = true; // No timestamp means for all occurrences
                } elseif ($booking_timestamp == $occurrence_timestamp) {
                    $should_include = true; // Specific occurrence
                } elseif ($all_occurrences == 1) {
                    $should_include = true; // All occurrences
                }
                
                if (!$should_include) {
                    continue;
                }
                
                // Create pseudo booking object matching custom table structure
                $bookings[] = (object)[
                    'booking_id' => $booking_post->ID,
                    'event_id' => $event_id,
                    'status' => $booking_post->post_status,
                    'confirmed' => get_post_meta($booking_post->ID, 'mec_confirmed', true),
                    'verified' => get_post_meta($booking_post->ID, 'mec_verified', true),
                    'timestamp' => $occurrence_timestamp,
                    'all_occurrences' => $all_occurrences
                ];
            }
        }

        $detailed_attendees = [];

        foreach ($bookings as $booking) {
            $booking_id = isset($booking->booking_id) ? $booking->booking_id : $booking->ID;

            // Get attendees from booking post meta
            $attendees = get_post_meta($booking_id, 'mec_attendees', true);

            if (is_array($attendees)) {
                foreach ($attendees as $key => $attendee) {
                    if (!is_numeric($key)) continue; // Skip non-numeric keys

                    // Get ticket information
                    $ticket_info = [];
                    if (isset($attendee['id'])) {
                        $tickets = get_post_meta($event_id, 'mec_tickets', true);
                        if (is_array($tickets) && isset($tickets[$attendee['id']])) {
                            $ticket_info = $tickets[$attendee['id']];
                        }
                    }

                    // Get booking details
                    $booking_post = get_post($booking_id);

                    $detailed_attendee = [
                        'booking_id' => $booking_id,
                        'attendee_key' => $key + 1,
                        'first_name' => isset($attendee['first_name']) ? $attendee['first_name'] : '',
                        'last_name' => isset($attendee['last_name']) ? $attendee['last_name'] : '',
                        'name' => isset($attendee['name']) ? $attendee['name'] : '',
                        'email' => isset($attendee['email']) ? $attendee['email'] : '',
                        'phone' => isset($attendee['phone']) ? $attendee['phone'] : '',
                        'ticket_id' => isset($attendee['id']) ? $attendee['id'] : '',
                        'ticket_name' => isset($attendee['ticket_name']) ? $attendee['ticket_name'] : '',
                        'ticket_info' => $ticket_info,
                        'booking_status' => $booking->status,
                        'booking_confirmed' => (bool) $booking->confirmed,
                        'booking_verified' => (bool) $booking->verified,
                        'booking_date' => $booking_post ? $booking_post->post_date : '',
                        'transaction_id' => get_post_meta($booking_id, 'mec_transaction_id', true),
                        'reg' => isset($attendee['reg']) ? $attendee['reg'] : []
                    ];

                    // Add avatar
                    if (isset($attendee['email']) && !empty($attendee['email'])) {
                        $user = get_user_by('email', $attendee['email']);
                        if ($user) {
                            $detailed_attendee['avatar'] = get_avatar_url($user->ID, ['size' => 96]);
                        } else {
                            $detailed_attendee['avatar'] = get_avatar_url($attendee['email'], ['size' => 96]);
                        }
                    }

                    // Add check-in status
                    $checkin_status = null;
                    $checkin_available = false;
                    if (class_exists('MEC_Invoice\\Attendee')) {
                        $checkin_available = true;
                        $invoice_id = $this->get_invoice_id_by_booking($booking_id);
                        if ($invoice_id) {
                            $attendee_class = 'MEC_Invoice\\Attendee';
                            $checkin_status = $attendee_class::hasCheckedIn(
                                $invoice_id,
                                $attendee['email'] ?? '',
                                $key + 1,
                                $occurrence_timestamp
                            );
                        }
                    }

                    $detailed_attendee['checkin_status'] = $checkin_status;
                    $detailed_attendee['checkin_available'] = $checkin_available;

                    $detailed_attendees[] = $detailed_attendee;
                }
            }
        }

        return $detailed_attendees;
    }

    /**
     * Get invoice ID by booking ID
     */
    private function get_invoice_id_by_booking($booking_id)
    {
        $invoices = get_posts([
            'post_type' => 'mec_invoice',
            'posts_per_page' => 1,
            'meta_query' => [
                [
                    'key' => 'book_id',
                    'value' => $booking_id,
                    'compare' => '='
                ]
            ]
        ]);

        return !empty($invoices) ? $invoices[0]->ID : null;
    }

    /**
     * Get plugin status for required MEC plugins
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_plugin_status($request)
    {
        try {
            $plugin_status = array();

            // Check mec-rsvp plugin (both plugin active status and class existence)
            $mec_rsvp_plugin_active = $this->is_plugin_active('mec-rsvp/mec-rsvp.php');
            
            // Try to load RSVP class if plugin is active but class not loaded yet
            if ($mec_rsvp_plugin_active && !class_exists('MEC_RSVP\\Base')) {
                $rsvp_autoload = WP_PLUGIN_DIR . '/mec-rsvp/vendor/autoload.php';
                if (file_exists($rsvp_autoload)) {
                    require_once $rsvp_autoload;
                }
            }
            
            $mec_rsvp_class_exists = class_exists('MEC_RSVP\\Base');
            
            $plugin_status['mec_rsvp'] = array(
                'active' => $mec_rsvp_plugin_active && $mec_rsvp_class_exists,
                'plugin_active' => $mec_rsvp_plugin_active,
                'class_loaded' => $mec_rsvp_class_exists,
                'name' => 'MEC RSVP',
                'version' => $this->get_plugin_version('mec-rsvp/mec-rsvp.php')
            );

            // Check mec-invoice plugin (both plugin active status and class existence)
            $mec_invoice_plugin_active = $this->is_plugin_active('mec-invoice/mec-invoice.php');
            $mec_invoice_class_exists = class_exists('MEC_Invoice\\Attendee');
            
            $plugin_status['mec_invoice'] = array(
                'active' => $mec_invoice_plugin_active && $mec_invoice_class_exists,
                'plugin_active' => $mec_invoice_plugin_active,
                'class_loaded' => $mec_invoice_class_exists,
                'name' => 'MEC Invoice',
                'version' => $this->get_plugin_version('mec-invoice/mec-invoice.php')
            );

            // Check mec-waiting-list plugin (both plugin active status and class existence)
            // First check if class is already loaded (most reliable method)
            $mec_waiting_list_class_exists = class_exists('MEC_Waiting_List\\MEC_Waiting_Base');
            
            // Check plugin active status using WordPress function
            $mec_waiting_list_plugin_active = $this->is_plugin_active('mec-waiting-list/mec-waiting-list.php');
            
            // Also check by checking active_plugins option directly as fallback
            if (!$mec_waiting_list_plugin_active) {
                if (!function_exists('is_plugin_active')) {
                    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
                }
                $active_plugins = get_option('active_plugins', array());
                $network_active_plugins = is_multisite() ? get_site_option('active_sitewide_plugins', array()) : array();
                $mec_waiting_list_plugin_active = in_array('mec-waiting-list/mec-waiting-list.php', $active_plugins) || 
                                                  array_key_exists('mec-waiting-list/mec-waiting-list.php', $network_active_plugins);
            }
            
            // If class exists, plugin is definitely active (class can't exist if plugin isn't loaded)
            if ($mec_waiting_list_class_exists) {
                $mec_waiting_list_plugin_active = true;
            } else {
                // Try to load waiting list class if plugin file exists but class not loaded yet
                $waiting_list_autoload = WP_PLUGIN_DIR . '/mec-waiting-list/core/autoloader.php';
                if (file_exists($waiting_list_autoload) && $mec_waiting_list_plugin_active) {
                    require_once $waiting_list_autoload;
                    $mec_waiting_list_class_exists = class_exists('MEC_Waiting_List\\MEC_Waiting_Base');
                }
            }
            
            $plugin_status['mec_waiting_list'] = array(
                'active' => $mec_waiting_list_plugin_active && $mec_waiting_list_class_exists,
                'plugin_active' => $mec_waiting_list_plugin_active,
                'class_loaded' => $mec_waiting_list_class_exists,
                'name' => 'MEC Waiting List',
                'version' => $this->get_plugin_version('mec-waiting-list/mec-waiting-list.php')
            );

            // Check mec-zoom-integration plugin
            $mec_zoom_plugin_active = $this->is_plugin_active('mec-zoom-integration/mec-zoom-integration.php');
            $mec_zoom_class_exists = class_exists('MEC_Zoom_Integration\\Base');
            
            $plugin_status['mec_zoom_integration'] = array(
                'active' => $mec_zoom_plugin_active && $mec_zoom_class_exists,
                'plugin_active' => $mec_zoom_plugin_active,
                'class_loaded' => $mec_zoom_class_exists,
                'name' => 'MEC Zoom Integration',
                'version' => $this->get_plugin_version('mec-zoom-integration/mec-zoom-integration.php')
            );

            // Check mec-virtual-events plugin
            $mec_virtual_plugin_active = $this->is_plugin_active('mec-virtual-events/mec-virtual-events.php');
            $mec_virtual_class_exists = class_exists('MEC_Virtual_Events\\Base');
            
            $plugin_status['mec_virtual_events'] = array(
                'active' => $mec_virtual_plugin_active && $mec_virtual_class_exists,
                'plugin_active' => $mec_virtual_plugin_active,
                'class_loaded' => $mec_virtual_class_exists,
                'name' => 'MEC Virtual Events',
                'version' => $this->get_plugin_version('mec-virtual-events/mec-virtual-events.php')
            );

            // Check modern-events-calendar plugin and determine if it's Pro or Lite
            $mec_active = $this->is_plugin_active('modern-events-calendar/mec.php');
            $mec_version = $this->get_plugin_version('modern-events-calendar/mec.php');
            $mec_type = $this->get_mec_type();

            $plugin_status['modern_events_calendar'] = array(
                'active' => $mec_active,
                'name' => 'Modern Events Calendar',
                'version' => $mec_version,
                'type' => $mec_type // 'lite' or 'pro'
            );

            return \rest_ensure_response($plugin_status);
        } catch (Exception $e) {
            return new WP_Error(
                'mec_utility_plugin_status_error',
                __('Unable to retrieve plugin status.', 'mec-utility'),
                array('status' => 500)
            );
        }
    }

    /**
     * Check if a plugin is active
     *
     * @param string $plugin_file Plugin file path
     * @return bool
     */
    private function is_plugin_active($plugin_file)
    {
        if (!function_exists('is_plugin_active')) {
            include_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }

        return \is_plugin_active($plugin_file);
    }

    /**
     * Get plugin version
     *
     * @param string $plugin_file Plugin file path
     * @return string|null
     */
    private function get_plugin_version($plugin_file)
    {
        if (!function_exists('get_plugin_data')) {
            include_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }

        $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_file;

        if (!file_exists($plugin_path)) {
            return null;
        }

        $plugin_data = \get_plugin_data($plugin_path, false, false);
        return isset($plugin_data['Version']) ? $plugin_data['Version'] : null;
    }

    /**
     * Determine if MEC is Lite or Pro version
     *
     * @return string 'lite' or 'pro'
     */
    private function get_mec_type()
    {
        // Check if MEC Pro is active by looking for pro-specific files or functions
        if (
            class_exists('MEC_Pro') ||
            function_exists('mec_pro_activate') ||
            file_exists(WP_PLUGIN_DIR . '/modern-events-calendar-pro/modern-events-calendar-pro.php')
        ) {
            return 'pro';
        }

        // Check for pro license or pro features
        if (function_exists('mec_get_option')) {
            $license = \mec_get_option('license', '');
            if (!empty($license)) {
                return 'pro';
            }
        }

        // Default to lite if no pro indicators found
        return 'lite';
    }

    /**
     * Apply Zoom meta payload to event
     */
    private function applyZoomMeta($event_id, array $zoom_data)
    {
        if (empty($zoom_data)) {
            return;
        }

        $map = [
            'event_type' => [
                'meta' => 'mec_zoom_event',
                'type' => 'enum',
                'options' => ['none', 'webinar', 'meeting'],
                'default' => 'none',
            ],
            'badge_shortcode' => [
                'meta' => 'mec_zoom_badge_shortcode',
                'type' => 'bool',
            ],
            'badge_single' => [
                'meta' => 'mec_zoom_badge_single',
                'type' => 'bool',
            ],
            'display_booking_history' => [
                'meta' => 'mec_display_booking_history',
                'type' => 'flag',
            ],
            'join_url' => [
                'meta' => 'mec_zoom_join_url',
                'type' => 'url',
            ],
            'join_title' => [
                'meta' => 'mec_zoom_join_title',
                'type' => 'text',
            ],
            'join_target' => [
                'meta' => 'mec_zoom_join_target',
                'type' => 'enum',
                'options' => ['_self', '_blank'],
                'default' => '_self',
            ],
            'display_join_in_booking' => [
                'meta' => 'mec_zoom_display_join_in_booking',
                'type' => 'bool',
            ],
            'link_url' => [
                'meta' => 'mec_zoom_link_url',
                'type' => 'url',
            ],
            'link_title' => [
                'meta' => 'mec_zoom_link_title',
                'type' => 'text',
            ],
            'link_target' => [
                'meta' => 'mec_zoom_link_target',
                'type' => 'enum',
                'options' => ['_self', '_blank'],
                'default' => '_self',
            ],
            'display_link_in_booking' => [
                'meta' => 'mec_zoom_display_link_in_booking',
                'type' => 'bool',
            ],
            'embed' => [
                'meta' => 'mec_zoom_embed',
                'type' => 'textarea',
            ],
            'display_embed_in_booking' => [
                'meta' => 'mec_zoom_display_embed_in_booking',
                'type' => 'bool',
            ],
            'hide_info_before_start' => [
                'meta' => 'mec_zoom_hide_info_before_start',
                'type' => 'bool',
            ],
            'show_info_time' => [
                'meta' => 'mec_zoom_show_info_time',
                'type' => 'int',
            ],
            'show_info_hm' => [
                'meta' => 'mec_zoom_show_info_hm',
                'type' => 'enum',
                'options' => ['day', 'hour', 'minute'],
                'default' => 'day',
            ],
            'hide_info_when_live' => [
                'meta' => 'mec_zoom_hide_info',
                'type' => 'bool',
            ],
            'password' => [
                'meta' => 'mec_zoom_password',
                'type' => 'text',
            ],
            'display_password_in_booking' => [
                'meta' => 'mec_zoom_display_password_in_booking',
                'type' => 'bool',
            ],
            'meeting_id' => [
                'meta' => 'mec_zoom_meeting_id',
                'type' => 'text',
            ],
            'display_meeting_id_in_booking' => [
                'meta' => 'mec_zoom_display_meeting_id_in_booking',
                'type' => 'bool',
            ],
        ];

        $this->applyMetaMap($event_id, $zoom_data, $map);
    }

    /**
     * Apply Virtual Event meta payload to event
     */
    private function applyVirtualEventMeta($event_id, array $virtual_data)
    {
        if (empty($virtual_data)) {
            return;
        }

        $map = [
            'enabled' => [
                'meta' => 'mec_virtual_event',
                'type' => 'bool',
            ],
            'badge_shortcode' => [
                'meta' => 'mec_virtual_badge_shortcode',
                'type' => 'bool',
            ],
            'badge_single' => [
                'meta' => 'mec_virtual_badge_single',
                'type' => 'bool',
            ],
            'display_user_booking_history' => [
                'meta' => 'mec_virtual_display_user_booking_history',
                'type' => 'yesno',
            ],
            'link_url' => [
                'meta' => 'mec_virtual_link_url',
                'type' => 'url',
            ],
            'link_title' => [
                'meta' => 'mec_virtual_link_title',
                'type' => 'text',
            ],
            'link_target' => [
                'meta' => 'mec_virtual_link_target',
                'type' => 'enum',
                'options' => ['_self', '_blank'],
                'default' => '_self',
            ],
            'display_link_in_booking' => [
                'meta' => 'mec_virtual_display_link_in_booking',
                'type' => 'bool',
            ],
            'password' => [
                'meta' => 'mec_virtual_password',
                'type' => 'text',
            ],
            'display_password_in_booking' => [
                'meta' => 'mec_virtual_display_password_in_booking',
                'type' => 'bool',
            ],
            'embed' => [
                'meta' => 'mec_virtual_embed',
                'type' => 'textarea',
            ],
            'display_embed_in_booking' => [
                'meta' => 'mec_virtual_display_embed_in_booking',
                'type' => 'bool',
            ],
            'hide_info_before_start' => [
                'meta' => 'mec_virtual_hide_info_before_start',
                'type' => 'bool',
            ],
            'show_info_time' => [
                'meta' => 'mec_virtual_show_info_time',
                'type' => 'int',
            ],
            'show_info_hm' => [
                'meta' => 'mec_virtual_show_info_hm',
                'type' => 'enum',
                'options' => ['day', 'hour', 'minute'],
                'default' => 'day',
            ],
            'hide_info_when_live' => [
                'meta' => 'mec_virtual_hide_info',
                'type' => 'bool',
            ],
        ];

        $this->applyMetaMap($event_id, $virtual_data, $map);
    }

    /**
     * Generic meta applier using field map definitions
     */
    private function applyMetaMap($event_id, array $payload, array $map)
    {
        foreach ($map as $public_key => $config) {
            if (empty($config['meta'])) {
                continue;
            }

            $meta_key = $config['meta'];
            $candidate_keys = [$public_key];

            if ($public_key !== $meta_key) {
                $candidate_keys[] = $meta_key;
            }

            if (!empty($config['aliases']) && is_array($config['aliases'])) {
                $candidate_keys = array_merge($candidate_keys, $config['aliases']);
            }

            $found = false;
            $raw_value = null;

            foreach ($candidate_keys as $candidate) {
                if (array_key_exists($candidate, $payload)) {
                    $raw_value = $payload[$candidate];
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                continue;
            }

            $sanitized = $this->sanitizeMetaMapValue($raw_value, $config);
            \update_post_meta($event_id, $meta_key, $sanitized);
        }
    }

    /**
     * Sanitize mapped meta value according to configuration
     */
    private function sanitizeMetaMapValue($value, array $config)
    {
        $type = $config['type'] ?? 'text';

        switch ($type) {
            case 'bool':
                return $this->toBool($value);
            case 'flag':
                return $this->toBool($value) ? '1' : '0';
            case 'yesno':
                if (is_string($value)) {
                    $compare = strtolower(trim($value));
                    if (in_array($compare, ['yes', 'no'], true)) {
                        return $compare;
                    }
                }
                return $this->toBool($value) ? 'yes' : 'no';
            case 'int':
                return \absint($value);
            case 'url':
                return $value !== null ? \esc_url_raw((string) $value) : '';
            case 'textarea':
                return $value !== null ? \wp_kses_post((string) $value) : '';
            case 'enum':
                $options = $config['options'] ?? [];
                $default = $config['default'] ?? ($options[0] ?? '');
                $candidate = $value !== null ? strtolower(trim((string) $value)) : '';
                foreach ($options as $option) {
                    if (strtolower($option) === $candidate) {
                        return $option;
                    }
                }
                return $default;
            case 'text':
            default:
                return $value !== null ? \sanitize_text_field((string) $value) : '';
        }
    }

    /**
     * Convert mixed value to boolean
     */
    private function toBool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return ((int) $value) === 1;
        }

        if (is_string($value)) {
            $trimmed = strtolower(trim($value));
            return in_array($trimmed, ['1', 'true', 'yes', 'on'], true);
        }

        return (bool) $value;
    }

    /**
     * Get Zoom meta formatted for API response
     */
    private function get_zoom_meta($event_id): array
    {
        $event_type = \get_post_meta($event_id, 'mec_zoom_event', true);

        return [
            'event_type' => $event_type !== '' ? $event_type : 'none',
            'badge_shortcode' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_badge_shortcode', true)),
            'badge_single' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_badge_single', true)),
            'display_booking_history' => $this->toBool(\get_post_meta($event_id, 'mec_display_booking_history', true)),
            'join_url' => \get_post_meta($event_id, 'mec_zoom_join_url', true) ?: '',
            'join_title' => \get_post_meta($event_id, 'mec_zoom_join_title', true) ?: '',
            'join_target' => \get_post_meta($event_id, 'mec_zoom_join_target', true) ?: '_self',
            'display_join_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_display_join_in_booking', true)),
            'link_url' => \get_post_meta($event_id, 'mec_zoom_link_url', true) ?: '',
            'link_title' => \get_post_meta($event_id, 'mec_zoom_link_title', true) ?: '',
            'link_target' => \get_post_meta($event_id, 'mec_zoom_link_target', true) ?: '_self',
            'display_link_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_display_link_in_booking', true)),
            'embed' => \get_post_meta($event_id, 'mec_zoom_embed', true) ?: '',
            'display_embed_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_display_embed_in_booking', true)),
            'hide_info_before_start' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_hide_info_before_start', true)),
            'show_info_time' => \absint(\get_post_meta($event_id, 'mec_zoom_show_info_time', true)),
            'show_info_hm' => \get_post_meta($event_id, 'mec_zoom_show_info_hm', true) ?: 'day',
            'hide_info_when_live' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_hide_info', true)),
            'password' => \get_post_meta($event_id, 'mec_zoom_password', true) ?: '',
            'display_password_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_display_password_in_booking', true)),
            'meeting_id' => \get_post_meta($event_id, 'mec_zoom_meeting_id', true) ?: '',
            'display_meeting_id_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_zoom_display_meeting_id_in_booking', true)),
        ];
    }

    /**
     * Get Virtual Event meta formatted for API response
     */
    private function get_virtual_event_meta($event_id): array
    {
        $booking_history_raw = \get_post_meta($event_id, 'mec_virtual_display_user_booking_history', true);

        return [
            'enabled' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_event', true)),
            'badge_shortcode' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_badge_shortcode', true)),
            'badge_single' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_badge_single', true)),
            'display_user_booking_history' => ($booking_history_raw === 'yes'),
            'link_url' => \get_post_meta($event_id, 'mec_virtual_link_url', true) ?: '',
            'link_title' => \get_post_meta($event_id, 'mec_virtual_link_title', true) ?: '',
            'link_target' => \get_post_meta($event_id, 'mec_virtual_link_target', true) ?: '_self',
            'display_link_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_display_link_in_booking', true)),
            'password' => \get_post_meta($event_id, 'mec_virtual_password', true) ?: '',
            'display_password_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_display_password_in_booking', true)),
            'embed' => \get_post_meta($event_id, 'mec_virtual_embed', true) ?: '',
            'display_embed_in_booking' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_display_embed_in_booking', true)),
            'hide_info_before_start' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_hide_info_before_start', true)),
            'show_info_time' => \absint(\get_post_meta($event_id, 'mec_virtual_show_info_time', true)),
            'show_info_hm' => \get_post_meta($event_id, 'mec_virtual_show_info_hm', true) ?: 'day',
            'hide_info_when_live' => $this->toBool(\get_post_meta($event_id, 'mec_virtual_hide_info', true)),
        ];
    }

    /**
     * Get stored entity type meta
     */
    private function get_entity_type_meta($event_id): string
    {
        $entity_type = (string) \get_post_meta($event_id, 'mec_entity_type', true);
        if (!in_array($entity_type, array('event', 'appointment'), true)) {
            $entity_type = 'event';
        }

        return $entity_type;
    }

    /**
     * Get appointments configuration
     */
    private function get_appointments_meta($event_id): array
    {
        $config = \get_post_meta($event_id, 'mec_appointments', true);
        if (!is_array($config) || empty($config)) {
            return [];
        }

        $normalize_point = function ($point) {
            if (!is_array($point)) {
                $point = [];
            }

            $ampm = '';
            if (isset($point['ampm'])) {
                $ampm_candidate = strtoupper((string) $point['ampm']);
                if (in_array($ampm_candidate, array('AM', 'PM'), true)) {
                    $ampm = $ampm_candidate;
                }
            }

            return array(
                'hour' => isset($point['hour']) ? (int) $point['hour'] : 8,
                'minutes' => isset($point['minutes']) ? (int) $point['minutes'] : 0,
                'ampm' => $ampm,
            );
        };

        $normalize_slot = function ($slot) use ($normalize_point) {
            if (!is_array($slot)) {
                $slot = [];
            }

            return array(
                'start' => $normalize_point($slot['start'] ?? []),
                'end' => $normalize_point($slot['end'] ?? []),
            );
        };

        $availability = array();
        if (isset($config['availability']) && is_array($config['availability'])) {
            foreach ($config['availability'] as $day_key => $slots) {
                if ($day_key === ':t:' || !is_array($slots)) {
                    continue;
                }

                $availability[$day_key] = array();
                foreach ($slots as $slot_key => $slot) {
                    if ($slot_key === ':t:' || !is_array($slot)) {
                        continue;
                    }

                    $availability[$day_key][$slot_key] = $normalize_slot($slot);
                }
            }
        }

        $adjusted = array();
        if (isset($config['adjusted_availability']) && is_array($config['adjusted_availability'])) {
            foreach ($config['adjusted_availability'] as $index => $day) {
                if (!is_array($day)) {
                    continue;
                }

                $entry = array();
                if (isset($day['date'])) {
                    $entry['date'] = (string) $day['date'];
                }

                foreach ($day as $slot_key => $slot) {
                    if ($slot_key === ':t:' || $slot_key === 'date' || !is_array($slot)) {
                        continue;
                    }

                    $entry[$slot_key] = $normalize_slot($slot);
                }

                if (!empty($entry)) {
                    $adjusted[$index] = $entry;
                }
            }
        }

        return array(
            'saved' => isset($config['saved']) ? (int) $config['saved'] : 0,
            'duration' => isset($config['duration']) ? (int) $config['duration'] : 60,
            'buffer' => isset($config['buffer']) ? (int) $config['buffer'] : 0,
            'max_bookings_per_day' => isset($config['max_bookings_per_day']) && $config['max_bookings_per_day'] !== '' ? (int) $config['max_bookings_per_day'] : '',
            'availability_repeat_type' => isset($config['availability_repeat_type']) ? (string) $config['availability_repeat_type'] : 'weekly',
            'start_date' => isset($config['start_date']) ? (string) $config['start_date'] : '',
            'availability' => $availability,
            'adjusted_availability' => $adjusted,
            'scheduling_advance_status' => $this->toBool($config['scheduling_advance_status'] ?? true),
            'scheduling_advance' => isset($config['scheduling_advance']) ? (int) $config['scheduling_advance'] : null,
            'scheduling_before_status' => $this->toBool($config['scheduling_before_status'] ?? true),
            'scheduling_before' => isset($config['scheduling_before']) ? (int) $config['scheduling_before'] : null,
        );
    }

    /**
     * Handle repeat options for events
     *
     * @param int $event_id
     * @param array $request
     */
    protected function handle_repeat_options($event_id, $request)
    {
        // Debug logging for full request
        error_log('=== HANDLE REPEAT OPTIONS DEBUG ===');
        error_log('Event ID: ' . $event_id);
        error_log('Full request: ' . print_r($request, true));
        
        // Helper to read nested values like mec_data.*
        $get_nested = function ($array, $path, $default = null) {
            $cursor = $array;
            foreach ($path as $key) {
                if (!is_array($cursor) || !array_key_exists($key, $cursor)) {
                    return $default;
                }
                $cursor = $cursor[$key];
            }
            return $cursor;
        };

        // Prepare JSON params if WP_REST_Request provided
        $json_params = null;
        if (is_object($request) && method_exists($request, 'get_json_params')) {
            $json_params = $request->get_json_params();
            error_log('Extracted JSON params via get_json_params: ' . print_r($json_params, true));
        }

        // Get repeat data from request (array) or JSON
        $mec_data = $get_nested($request, array('mec_data'), array());
        if (empty($mec_data) && is_array($json_params) && isset($json_params['mec_data'])) {
            $mec_data = $json_params['mec_data'];
            error_log('Found mec_data in JSON params: ' . print_r($mec_data, true));
        }

        // Debug mec_data
        error_log('MEC data extracted: ' . print_r($mec_data, true));

        // Repeat status
        $repeat_status = isset($request['repeat_status']) ? (bool)$request['repeat_status'] : (isset($mec_data['repeat_status']) ? (bool)$mec_data['repeat_status'] : false);

        // Repeat type
        $repeat_type = isset($request['repeat_type']) ? $request['repeat_type'] : (isset($mec_data['repeat_type']) ? $mec_data['repeat_type'] : '');
        if (empty($repeat_type) && is_array($json_params) && isset($json_params['mec_data']['repeat_type'])) {
            $repeat_type = $json_params['mec_data']['repeat_type'];
            error_log('Found repeat_type in JSON params: ' . $repeat_type);
        }

        // Repeat interval
        $repeat_interval = isset($request['repeat_interval']) ? intval($request['repeat_interval']) : (isset($mec_data['repeat_interval']) ? intval($mec_data['repeat_interval']) : 1);

        // Repeat end options
        $repeat_end = isset($request['repeat_end']) ? $request['repeat_end'] : (isset($mec_data['repeat_end']) ? $mec_data['repeat_end'] : 'never');

        $repeat_end_at_date = isset($request['repeat_end_at_date']) ? $request['repeat_end_at_date'] : (isset($mec_data['repeat_end_at_date']) ? $mec_data['repeat_end_at_date'] : '');

        $repeat_end_at_occurrences = isset($request['repeat_end_at_occurrences']) ? intval($request['repeat_end_at_occurrences']) : (isset($mec_data['repeat_end_at_occurrences']) ? intval($mec_data['repeat_end_at_occurrences']) : 9);

        // Advanced days for advanced repeat type
        $advanced_days = isset($request['advanced_days']) ? $request['advanced_days'] : (isset($mec_data['advanced_days']) ? $mec_data['advanced_days'] : array());

        // Convert advanced_days array to string format if needed
        if (is_array($advanced_days) && !empty($advanced_days)) {
            $advanced_days_string = implode('-', $advanced_days);
        } elseif (is_string($advanced_days) && !empty($advanced_days)) {
            $advanced_days_string = $advanced_days;
        } else {
            $advanced_days_string = '';
        }

        // If advanced_days is empty but we have advanced repeat type, try to get from existing meta
        if (empty($advanced_days_string) && $repeat_type === 'advanced') {
            $existing_advanced_days = get_post_meta($event_id, 'mec_advanced_days', true);
            if (is_array($existing_advanced_days) && !empty($existing_advanced_days)) {
                $advanced_days_string = implode('-', $existing_advanced_days);
            } elseif (is_string($existing_advanced_days) && !empty($existing_advanced_days)) {
                $advanced_days_string = $existing_advanced_days;
            }
        }

        // Certain weekdays for certain_weekdays repeat type
        $certain_weekdays = isset($request['certain_weekdays']) ? $request['certain_weekdays'] : (isset($mec_data['certain_weekdays']) ? $mec_data['certain_weekdays'] : array());

        // If certain_weekdays is empty but we have certain_weekdays repeat type, try to get from existing meta
        if (empty($certain_weekdays) && $repeat_type === 'certain_weekdays') {
            $existing_certain_weekdays = get_post_meta($event_id, 'mec_certain_weekdays', true);
            if (is_array($existing_certain_weekdays) && !empty($existing_certain_weekdays)) {
                $certain_weekdays = $existing_certain_weekdays;
            }
        }

        // Custom days for custom_days repeat type
        $custom_days = isset($request['custom_days']) ? $request['custom_days'] : (isset($mec_data['custom_days']) ? $mec_data['custom_days'] : array());
        if ((empty($custom_days) || (is_array($custom_days) && !count($custom_days))) && is_array($json_params) && isset($json_params['mec_data']['custom_days'])) {
            $custom_days = $json_params['mec_data']['custom_days'];
            error_log('Found custom_days in JSON params: ' . print_r($custom_days, true));
        }
        
        // Debug logging
        error_log('=== CUSTOM DAYS DEBUG ===');
        error_log('Request custom_days: ' . print_r($request['custom_days'] ?? 'NOT SET', true));
        error_log('MEC data custom_days: ' . print_r($mec_data['custom_days'] ?? 'NOT SET', true));
        error_log('Final custom_days: ' . print_r($custom_days, true));
        error_log('Custom_days type: ' . gettype($custom_days));
        error_log('Repeat type: ' . $repeat_type);

        // Convert custom_days to string format if needed
        if (is_array($custom_days) && !empty($custom_days)) {
            $custom_days_strings = [];
            
            // Check if it's an object with date keys (new format)
            if (isset($custom_days['2025-10-01']) || isset($custom_days['2025-10-09'])) {
                // Object format: {"2025-10-01": {"start": "08:00 AM", "end": "06:00 PM"}}
                foreach ($custom_days as $date => $times) {
                    if (is_array($times) && isset($times['start'], $times['end'])) {
                        // Convert time format from "08:00 AM" to "08-00-AM"
                        $start_time = str_replace([':', ' '], ['-', '-'], $times['start']);
                        $end_time = str_replace([':', ' '], ['-', '-'], $times['end']);
                        
                        // For single day events, start and end dates are the same
                        $custom_days_strings[] = $date . ':' . $date . ':' . $start_time . ':' . $end_time;
                    }
                }
            } else {
                // Array format: [{"startDate": "2025-10-01", "endDate": "2025-10-02", "startTime": {...}, "endTime": {...}}]
                foreach ($custom_days as $day) {
                    if (is_array($day) && isset($day['startDate'], $day['endDate'], $day['startTime'], $day['endTime'])) {
                        // Format time properly with leading zeros
                        $start_hour = str_pad($day['startTime']['hour'], 2, '0', STR_PAD_LEFT);
                        $start_minute = str_pad($day['startTime']['minute'], 2, '0', STR_PAD_LEFT);
                        $end_hour = str_pad($day['endTime']['hour'], 2, '0', STR_PAD_LEFT);
                        $end_minute = str_pad($day['endTime']['minute'], 2, '0', STR_PAD_LEFT);
                        
                        $start_time = $start_hour . '-' . $start_minute . '-' . $day['startTime']['ampm'];
                        $end_time = $end_hour . '-' . $end_minute . '-' . $day['endTime']['ampm'];
                        
                        $custom_days_strings[] = $day['startDate'] . ':' . $day['endDate'] . ':' . $start_time . ':' . $end_time;
                    } elseif (is_string($day) && !empty($day)) {
                        $custom_days_strings[] = $day;
                    }
                }
            }
            
            $custom_days = implode(',', $custom_days_strings);
            error_log('Converted custom_days to string: ' . $custom_days);
        } elseif (!is_string($custom_days)) {
            // Ensure custom_days is always a string
            $custom_days = '';
            error_log('Custom_days set to empty string');
        }
        
        error_log('Final custom_days before saving: ' . $custom_days);
        error_log('Final custom_days type: ' . gettype($custom_days));

        // If custom_days is empty but we have custom_days repeat type, try to get from existing meta
        if (empty($custom_days) && $repeat_type === 'custom_days') {
            $existing_in_days = get_post_meta($event_id, 'mec_in_days', true);
            error_log('Existing mec_in_days from meta: ' . print_r($existing_in_days, true));
            error_log('Existing mec_in_days type: ' . gettype($existing_in_days));
            if (!empty($existing_in_days)) {
                $custom_days = $existing_in_days;
                error_log('Using existing custom_days: ' . $custom_days);
            }
        }

        // One occurrence flag
        $one_occurrence = isset($request['one_occurrence']) ? (bool)$request['one_occurrence'] : (isset($mec_data['one_occurrence']) ? (bool)$mec_data['one_occurrence'] : false);

        // Adjust interval for weekly repeats
        if ($repeat_type == 'weekly') {
            $repeat_interval = $repeat_interval * 7;
        }

        // Save repeat meta data
        \update_post_meta($event_id, 'mec_repeat_status', $repeat_status ? '1' : '0');
        \update_post_meta($event_id, 'mec_repeat_type', $repeat_type);
        \update_post_meta($event_id, 'mec_repeat_interval', $repeat_interval);
        \update_post_meta($event_id, 'mec_repeat_end', $repeat_end);
        \update_post_meta($event_id, 'mec_repeat_end_at_date', $repeat_end_at_date);
        \update_post_meta($event_id, 'mec_repeat_end_at_occurrences', $repeat_end_at_occurrences - 1); // MEC stores occurrences - 1
        \update_post_meta($event_id, 'one_occurrence', $one_occurrence ? '1' : '0');

        // Handle advanced days
        if ($repeat_type === 'advanced' && !empty($advanced_days_string)) {
            // Convert string back to array for storage
            $advanced_days_array = explode('-', $advanced_days_string);
            \update_post_meta($event_id, 'mec_advanced_days', $advanced_days_array);
        } else {
            \delete_post_meta($event_id, 'mec_advanced_days');
        }

        // Handle certain weekdays
        if ($repeat_type === 'certain_weekdays' && !empty($certain_weekdays)) {
            \update_post_meta($event_id, 'mec_certain_weekdays', $certain_weekdays);
        } else {
            \delete_post_meta($event_id, 'mec_certain_weekdays');
        }

        // Handle custom days (in_days) - Always save as string, even if empty
        if ($repeat_type === 'custom_days' && !empty($custom_days)) {
            // custom_days should be a string, not array
            $in_days_string = is_string($custom_days) ? $custom_days : '';
            // Ensure it's always a string, never array
            error_log('Saving mec_in_days as: ' . (string)$in_days_string);
            \update_post_meta($event_id, 'mec_in_days', (string)$in_days_string);
        } else {
            // Always save as empty string, not delete the meta - MEC expects string
            error_log('Saving mec_in_days as empty string (repeat_type: ' . $repeat_type . ', custom_days empty: ' . (empty($custom_days) ? 'YES' : 'NO') . ')');
            \update_post_meta($event_id, 'mec_in_days', '');
        }

        // Create/update MEC date array for compatibility
        $mec_date = get_post_meta($event_id, 'mec_date', true);
        if (!is_array($mec_date)) {
            $mec_date = array();
        }

        // Update repeat section in mec_date
        if (!isset($mec_date['repeat'])) {
            $mec_date['repeat'] = array();
        }

        $mec_date['repeat']['status'] = $repeat_status ? '1' : '0';
        $mec_date['repeat']['type'] = $repeat_type;
        $mec_date['repeat']['interval'] = $repeat_interval;
        $mec_date['repeat']['end'] = $repeat_end;
        $mec_date['repeat']['end_at_date'] = $repeat_end_at_date;
        $mec_date['repeat']['end_at_occurrences'] = $repeat_end_at_occurrences;

        // Add advanced days to repeat array if applicable
        if ($repeat_type === 'advanced' && !empty($advanced_days_string)) {
            $mec_date['repeat']['advanced'] = $advanced_days_string;
        }

        // Add certain weekdays to repeat array if applicable
        if ($repeat_type === 'certain_weekdays' && !empty($certain_weekdays)) {
            $mec_date['repeat']['certain_weekdays'] = $certain_weekdays;
        }

        // Add custom days to repeat array if applicable
        if ($repeat_type === 'custom_days' && !empty($custom_days)) {
            $mec_date['repeat']['in_days'] = $custom_days;
        }

        // Add one occurrence flag
        $mec_date['one_occurrence'] = $one_occurrence ? '1' : '0';

        \update_post_meta($event_id, 'mec_date', $mec_date);
        \update_post_meta($event_id, 'mec_repeat', $mec_date['repeat']);
    }

    /**
     * Ensure MEC regenerates occurrences in mec_dates after changes
     */
    protected function reschedule_event($event_id)
    {
        try {
            if (!class_exists('MEC_schedule') && function_exists('mec_init')) {
                mec_init();
            }

            if (class_exists('MEC_schedule')) {
                $schedule = new \MEC_schedule();
                $repeat_type = \get_post_meta($event_id, 'mec_repeat_type', true);
                if ($repeat_type === '' || $repeat_type === 'custom_days') {
                    $schedule->reschedule($event_id, 200);
                } else {
                    $schedule->reschedule($event_id, $schedule->get_reschedule_maximum($repeat_type));
                }
            }
        } catch (\Throwable $e) {
            // Fail silently; API response should not break
        }
    }

    /**
     * Normalize the "more_info_target" value coming from API clients into
     * the canonical MEC values: "_self" or "_blank".
     *
     * Clients (like the mobile app) may send human-readable labels
     * such as "Current Window" or "New Window". This helper ensures
     * the stored meta always matches what MEC core expects.
     *
     * @param string $value Raw target value from client
     * @return string Normalized target ("_self" or "_blank")
     */
    private function normalize_more_info_target($value)
    {
        $v = strtolower(trim((string) $value));

        if (in_array($v, ['_blank', 'new window', 'new_window', 'blank'], true)) {
            return '_blank';
        }

        // Default and all other cases map to "_self"
        return '_self';
    }

    /**
     * Delete temporary file and attachment
     * Called by scheduled event hook
     */
    public static function delete_temp_file($file_path, $attachment_id)
    {
        // Delete physical file
        if (file_exists($file_path)) {
            @unlink($file_path);
        }
        
        // Delete attachment from media library
        if ($attachment_id) {
            wp_delete_attachment($attachment_id, true);
        }
    }
}
