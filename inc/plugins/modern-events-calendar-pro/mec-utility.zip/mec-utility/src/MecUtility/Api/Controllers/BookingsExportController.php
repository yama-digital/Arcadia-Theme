<?php

namespace MecUtility\Api\Controllers;

/**
 * Bookings Export Controller
 * Handles CSV and Excel export for bookings (similar to MEC books.php bulk actions)
 */
class BookingsExportController
{
    /**
     * Register routes and hooks
     */
    public static function register_routes()
    {
        // Register cleanup hook
        add_action('mec_utility_delete_temp_file', array(__CLASS__, 'delete_temp_file'), 10, 2);
        // Export bookings as CSV
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/export/csv',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'export_csv'),
                'permission_callback' => '__return_true',
            )
        );

        // Export bookings as Excel
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/export/excel',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'export_excel'),
                'permission_callback' => '__return_true',
            )
        );

        // Export event attendees as CSV
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/attendees/export/csv',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'export_event_attendees_csv'),
                'permission_callback' => '__return_true',
            )
        );

        // Export event attendees as Excel
        \register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/attendees/export/excel',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'export_event_attendees_excel'),
                'permission_callback' => '__return_true',
            )
        );
    }

    /**
     * Export bookings as CSV
     */
    public static function export_csv($request)
    {
        try {
            // Get booking IDs from request
            $booking_ids = $request->get_param('booking_ids');
            
            if (empty($booking_ids) || !is_array($booking_ids)) {
                return new \WP_Error('invalid_booking_ids', 'Please provide booking IDs array.', ['status' => 400]);
            }

            // Get MEC instance
            if (!class_exists('MEC')) {
                return new \WP_Error('mec_not_found', 'MEC plugin not found.', ['status' => 500]);
            }

            $mec = \MEC::getInstance('app.features.books');
            if (!$mec) {
                return new \WP_Error('mec_books_not_found', 'MEC Books feature not found.', ['status' => 500]);
            }

            // Generate CSV data using MEC's csvexcel method
            $rows = $mec->csvexcel($booking_ids);

            if (empty($rows)) {
                return new \WP_Error('no_data', 'No data to export.', ['status' => 404]);
            }

            // Generate filename
            $filename = 'bookings-export-' . date('Y-m-d-His') . '.csv';

            // Generate CSV content
            $csv_content = '';
            foreach ($rows as $row) {
                $csv_content .= '"' . implode('","', array_map(function($cell) {
                    return str_replace('"', '""', $cell);
                }, $row)) . '"' . "\n";
            }

            // Save CSV file to uploads directory
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['basedir'] . '/' . $filename;
            $file_url = $upload_dir['baseurl'] . '/' . $filename;
            
            if (file_put_contents($file_path, $csv_content)) {
                // Create attachment in media library
                $attachment = array(
                    'post_mime_type' => 'text/csv',
                    'post_title' => 'Bookings Export - ' . date('Y-m-d H:i:s'),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );
                
                $attachment_id = wp_insert_attachment($attachment, $file_path);
                
                if ($attachment_id) {
                    // Schedule file deletion after 1 hour
                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($file_path, $attachment_id));
                    
                    return new \WP_REST_Response([
                        'success' => true,
                        'download_url' => $file_url,
                        'filename' => $filename,
                        'attachment_id' => $attachment_id,
                        'rows_count' => count($rows),
                        'expires_in' => '1 hour'
                    ], 200);
                }
            }
            
            return new \WP_Error('file_upload_failed', 'Failed to save CSV file.', ['status' => 500]);

        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting CSV: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Export bookings as Excel
     */
    public static function export_excel($request)
    {
        try {
            // Get booking IDs from request
            $booking_ids = $request->get_param('booking_ids');
            
            if (empty($booking_ids) || !is_array($booking_ids)) {
                return new \WP_Error('invalid_booking_ids', 'Please provide booking IDs array.', ['status' => 400]);
            }

            // Get MEC instance
            if (!class_exists('MEC')) {
                return new \WP_Error('mec_not_found', 'MEC plugin not found.', ['status' => 500]);
            }

            $mec = \MEC::getInstance('app.features.books');
            if (!$mec) {
                return new \WP_Error('mec_books_not_found', 'MEC Books feature not found.', ['status' => 500]);
            }

            // Generate Excel data using MEC's csvexcel method
            $rows = $mec->csvexcel($booking_ids);

            if (empty($rows)) {
                return new \WP_Error('no_data', 'No data to export.', ['status' => 404]);
            }

            // Generate filename
            $filename = 'bookings-export-' . date('Y-m-d-His') . '.xlsx';

            // Get MEC main instance for Excel generation
            $main = new \MEC_main();
            
            // Create temporary file
            $temp_file = tempnam(sys_get_temp_dir(), 'mec_excel_');
            
            // Generate Excel file
            ob_start();
            $main->generate_download_excel($rows, $filename);
            $excel_content = ob_get_clean();

            // If generate_download_excel doesn't return content, try alternative method
            if (empty($excel_content)) {
                // Use PHPSpreadsheet if available
                if (class_exists('\PhpOffice\PhpSpreadsheet\Spreadsheet')) {
                    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
                    $sheet = $spreadsheet->getActiveSheet();
                    
                    // Add data to sheet
                    $row_num = 1;
                    foreach ($rows as $row) {
                        $col_num = 1;
                        foreach ($row as $cell) {
                            $sheet->setCellValueByColumnAndRow($col_num, $row_num, $cell);
                            $col_num++;
                        }
                        $row_num++;
                    }
                    
                    // Save to temp file
                    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
                    $writer->save($temp_file);
                    
                    // Read file content
                    $excel_content = file_get_contents($temp_file);
                    unlink($temp_file);
                } else {
                    return new \WP_Error('excel_library_not_found', 'Excel library not available.', ['status' => 500]);
                }
            }

            // Save Excel file to uploads directory
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['basedir'] . '/' . $filename;
            $file_url = $upload_dir['baseurl'] . '/' . $filename;
            
            if (file_put_contents($file_path, $excel_content)) {
                // Create attachment in media library
                $attachment = array(
                    'post_mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    'post_title' => 'Bookings Export Excel - ' . date('Y-m-d H:i:s'),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );
                
                $attachment_id = wp_insert_attachment($attachment, $file_path);
                
                if ($attachment_id) {
                    // Schedule file deletion after 1 hour
                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($file_path, $attachment_id));
                    
                    return new \WP_REST_Response([
                        'success' => true,
                        'download_url' => $file_url,
                        'filename' => $filename,
                        'attachment_id' => $attachment_id,
                        'rows_count' => count($rows),
                        'expires_in' => '1 hour'
                    ], 200);
                }
            }
            
            return new \WP_Error('file_upload_failed', 'Failed to save Excel file.', ['status' => 500]);

        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting Excel: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Export event attendees as CSV
     * Gets all bookings for a specific event
     */
    public static function export_event_attendees_csv($request)
    {
        try {
            $event_id = (int) $request->get_param('event_id');
            
            if (!$event_id) {
                return new \WP_Error('invalid_event_id', 'Please provide event ID.', ['status' => 400]);
            }

            // Get all booking IDs for this event
            $args = array(
                'post_type' => 'mec-books',
                'post_status' => array('publish', 'future'),
                'posts_per_page' => -1,
                'meta_query' => array(
                    array(
                        'key' => 'mec_event_id',
                        'value' => $event_id,
                        'compare' => '='
                    )
                )
            );

            $query = new \WP_Query($args);
            $booking_ids = array();

            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $booking_ids[] = get_the_ID();
                }
                wp_reset_postdata();
            }

            if (empty($booking_ids)) {
                return new \WP_Error('no_bookings', 'No bookings found for this event.', ['status' => 404]);
            }

            // Get MEC instance
            if (!class_exists('MEC')) {
                return new \WP_Error('mec_not_found', 'MEC plugin not found.', ['status' => 500]);
            }

            $mec = \MEC::getInstance('app.features.books');
            if (!$mec) {
                return new \WP_Error('mec_books_not_found', 'MEC Books feature not found.', ['status' => 500]);
            }

            // Generate CSV data
            $rows = $mec->csvexcel($booking_ids);

            if (empty($rows)) {
                return new \WP_Error('no_data', 'No data to export.', ['status' => 404]);
            }

            // Get event title for filename
            $event = \get_post($event_id);
            $event_slug = $event ? sanitize_title($event->post_title) : 'event';

            // Generate filename
            $filename = 'attendees-' . $event_slug . '-' . date('Y-m-d-His') . '.csv';

            // Generate CSV content
            $csv_content = '';
            foreach ($rows as $row) {
                $csv_content .= '"' . implode('","', array_map(function($cell) {
                    return str_replace('"', '""', $cell);
                }, $row)) . '"' . "\n";
            }

            // Save CSV file to uploads directory
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['basedir'] . '/' . $filename;
            $file_url = $upload_dir['baseurl'] . '/' . $filename;
            
            if (file_put_contents($file_path, $csv_content)) {
                // Create attachment in media library
                $attachment = array(
                    'post_mime_type' => 'text/csv',
                    'post_title' => 'Event Attendees Export - ' . date('Y-m-d H:i:s'),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );
                
                $attachment_id = wp_insert_attachment($attachment, $file_path);
                
                if ($attachment_id) {
                    // Schedule file deletion after 1 hour
                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($file_path, $attachment_id));
                    
                    return new \WP_REST_Response([
                        'success' => true,
                        'download_url' => $file_url,
                        'filename' => $filename,
                        'attachment_id' => $attachment_id,
                        'rows_count' => count($rows),
                        'bookings_count' => count($booking_ids),
                        'event_id' => $event_id,
                        'expires_in' => '1 hour'
                    ], 200);
                }
            }
            
            return new \WP_Error('file_upload_failed', 'Failed to save CSV file.', ['status' => 500]);

        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting CSV: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Export event attendees as Excel
     */
    public static function export_event_attendees_excel($request)
    {
        try {
            $event_id = (int) $request->get_param('event_id');
            
            if (!$event_id) {
                return new \WP_Error('invalid_event_id', 'Please provide event ID.', ['status' => 400]);
            }

            // Get all booking IDs for this event
            $args = array(
                'post_type' => 'mec-books',
                'post_status' => array('publish', 'future'),
                'posts_per_page' => -1,
                'meta_query' => array(
                    array(
                        'key' => 'mec_event_id',
                        'value' => $event_id,
                        'compare' => '='
                    )
                )
            );

            $query = new \WP_Query($args);
            $booking_ids = array();

            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $booking_ids[] = get_the_ID();
                }
                wp_reset_postdata();
            }

            if (empty($booking_ids)) {
                return new \WP_Error('no_bookings', 'No bookings found for this event.', ['status' => 404]);
            }

            // Get MEC instance
            if (!class_exists('MEC')) {
                return new \WP_Error('mec_not_found', 'MEC plugin not found.', ['status' => 500]);
            }

            $mec = \MEC::getInstance('app.features.books');
            if (!$mec) {
                return new \WP_Error('mec_books_not_found', 'MEC Books feature not found.', ['status' => 500]);
            }

            // Generate Excel data
            $rows = $mec->csvexcel($booking_ids);

            if (empty($rows)) {
                return new \WP_Error('no_data', 'No data to export.', ['status' => 404]);
            }

            // Get event title for filename
            $event = \get_post($event_id);
            $event_slug = $event ? sanitize_title($event->post_title) : 'event';

            // Generate filename
            $filename = 'attendees-' . $event_slug . '-' . date('Y-m-d-His') . '.xlsx';

            // Get MEC main instance for Excel generation
            $main = new \MEC_main();
            
            // Create temporary file
            $temp_file = tempnam(sys_get_temp_dir(), 'mec_excel_');
            
            // Try to generate Excel
            $excel_content = '';
            
            if (class_exists('\PhpOffice\PhpSpreadsheet\Spreadsheet')) {
                $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                
                // Add data to sheet
                $row_num = 1;
                foreach ($rows as $row) {
                    $col_num = 1;
                    foreach ($row as $cell) {
                        $sheet->setCellValueByColumnAndRow($col_num, $row_num, $cell);
                        $col_num++;
                    }
                    $row_num++;
                }
                
                // Save to temp file
                $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
                $writer->save($temp_file);
                
                // Read file content
                $excel_content = file_get_contents($temp_file);
                unlink($temp_file);
            } else {
                return new \WP_Error('excel_library_not_found', 'Excel library not available.', ['status' => 500]);
            }

            // Save Excel file to uploads directory
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['basedir'] . '/' . $filename;
            $file_url = $upload_dir['baseurl'] . '/' . $filename;
            
            if (file_put_contents($file_path, $excel_content)) {
                // Create attachment in media library
                $attachment = array(
                    'post_mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    'post_title' => 'Event Attendees Export Excel - ' . date('Y-m-d H:i:s'),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );
                
                $attachment_id = wp_insert_attachment($attachment, $file_path);
                
                if ($attachment_id) {
                    // Schedule file deletion after 1 hour
                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($file_path, $attachment_id));
                    
                    return new \WP_REST_Response([
                        'success' => true,
                        'download_url' => $file_url,
                        'filename' => $filename,
                        'attachment_id' => $attachment_id,
                        'rows_count' => count($rows),
                        'bookings_count' => count($booking_ids),
                        'event_id' => $event_id,
                        'expires_in' => '1 hour'
                    ], 200);
                }
            }
            
            return new \WP_Error('file_upload_failed', 'Failed to save Excel file.', ['status' => 500]);

        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting Excel: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Delete temporary file and attachment
     */
    public static function delete_temp_file($file_path, $attachment_id)
    {
        // Delete physical file
        if (file_exists($file_path)) {
            @unlink($file_path);
        }
        
        // Delete attachment from media library
        if ($attachment_id) {
            wp_delete_attachment($attachment_id, true);
        }
    }
}

