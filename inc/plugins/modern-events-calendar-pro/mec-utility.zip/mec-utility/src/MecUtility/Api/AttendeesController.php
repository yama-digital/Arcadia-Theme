<?php

namespace MecUtility\Api;

use WP_REST_Controller;
use WP_REST_Response;
use WP_Error;
use WP_Query;
use MecUtility\Auth\AuthHelper;

/**
 * Attendees Controller for MEC Utility API
 * 
 * Handles attendees listing, filtering, and check-in/check-out functionality
 */
class AttendeesController extends WP_REST_Controller 
{
    /**
     * Register the routes
     */
    public function register_routes() 
    {
        $namespace = 'mec-utility/v1';
        
        // Get event attendees
        register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/attendees',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event_attendees'),
                'permission_callback' => AuthHelper::permission_callback('read_attendees'),
            )
        );

        // Get event attendees by occurrence (alternative format: /events/{id}/attendees/{occurrence})
        register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/attendees/(?P<occurrence>[\d-]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event_attendees'),
                'permission_callback' => AuthHelper::permission_callback('read_attendees'),
            )
        );

        // Get event attendees by occurrence (standard format: /events/{id}/occurrences/{occurrence}/attendees)
        register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/occurrences/(?P<occurrence>[\d-]+)/attendees',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event_attendees'),
                'permission_callback' => AuthHelper::permission_callback('read_attendees'),
            )
        );

        // Get single attendee
        register_rest_route(
            'mec-utility/v1',
            '/attendees/(?P<booking_id>[\d]+)/(?P<attendee_key>[\w-]+)',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_single_attendee'),
                'permission_callback' => AuthHelper::permission_callback('read_attendees'),
            )
        );

        // Check-in attendee
        register_rest_route(
            'mec-utility/v1',
            '/attendees/(?P<booking_id>[\d]+)/(?P<attendee_key>[\w-]+)/checkin',
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'checkin_attendee'),
                'permission_callback' => AuthHelper::permission_callback('checkin_attendees'),
            )
        );

        // Check-out attendee
        register_rest_route(
            'mec-utility/v1',
            '/attendees/(?P<booking_id>[\d]+)/(?P<attendee_key>[\w-]+)/checkout',
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'checkout_attendee'),
                'permission_callback' => AuthHelper::permission_callback('checkin_attendees'),
            )
        );

        // Bulk check-in/check-out
        register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/attendees/bulk-checkin',
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'bulk_checkin_attendees'),
                'permission_callback' => AuthHelper::permission_callback('bulk_checkin'),
            )
        );

        // Get attendees statistics
        register_rest_route(
            'mec-utility/v1',
            '/events/(?P<event_id>[\d]+)/attendees/stats',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_attendees_stats'),
                'permission_callback' => AuthHelper::permission_callback('view_stats'),
            )
        );

        // Debug endpoint - Get raw booking data
        register_rest_route(
            'mec-utility/v1',
            '/debug/events/(?P<event_id>[\d]+)/bookings',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'debug_event_bookings'),
                'permission_callback' => '__return_true',
            )
        );
    }
    
    /**
     * Get attendees for an event
     */
    public function get_event_attendees($request) 
    {
        try {
            $event_id = (int) $request['event_id'];
            $params = $request->get_params();
            
            // Debug info
            $debug_info = [
                'controller' => 'AttendeesController',
                'event_id' => $event_id,
                'occurrence' => $params['occurrence'] ?? 'not_provided',
                'all_params' => $params
            ];
            
            // Validate event exists
            if (!get_post($event_id) || get_post_type($event_id) !== 'mec-events') {
                return new WP_Error(
                    'event_not_found',
                    'Event not found.',
                    ['status' => 404]
                );
            }
            
            // Get bookings for this event
            $bookings = $this->get_event_bookings($event_id, $params);
            $debug_info['bookings_found'] = count($bookings);
            $debug_info['booking_ids'] = array_map(function($b) { return $b->ID; }, $bookings);
            
            // Collect all attendees
            $attendees = [];
            $total_attendees = 0;
            $checked_in_count = 0;
            
            foreach ($bookings as $booking) {
                $booking_attendees = $this->get_booking_attendees($booking->ID, $params);
                
                // Add booking info to each attendee
                foreach ($booking_attendees as &$attendee) {
                    $attendee['booking_info'] = [
                        'booking_id' => $booking->ID,
                        'transaction_id' => get_post_meta($booking->ID, 'mec_transaction_id', true),
                        'booking_date' => $booking->post_date,
                        'booking_status' => $booking->post_status,
                        'verified' => get_post_meta($booking->ID, 'mec_verified', true),
                        'confirmed' => get_post_meta($booking->ID, 'mec_confirmed', true)
                    ];
                    
                    // Add check-in status
                    $attendee = $this->add_checkin_status($attendee, $params['occurrence'] ?? null);
                    
                    if (isset($attendee['checkin_status']) && $attendee['checkin_status']) {
                        $checked_in_count++;
                    }
                    
                    $total_attendees++;
                }
                
                $attendees = array_merge($attendees, $booking_attendees);
            }
            
            // Apply filters
            $attendees = $this->filter_attendees($attendees, $params);
            
            // Sort attendees
            $attendees = $this->sort_attendees($attendees, $params);
            
            // Apply pagination
            $paginated_data = $this->paginate_attendees($attendees, $params);
            
            $response_data = [
                'attendees' => $paginated_data['attendees'],
                'stats' => [
                    'total_attendees' => $total_attendees,
                    'checked_in_count' => $checked_in_count,
                    'checked_out_count' => $total_attendees - $checked_in_count,
                    'filtered_count' => count($attendees),
                    'displayed_count' => count($paginated_data['attendees'])
                ],
                'pagination' => $paginated_data['pagination'],
                'debug' => $debug_info  // Debug information
            ];
            
            $response = new WP_REST_Response($response_data, 200);
            $response->header('X-WP-Total', $total_attendees);
            $response->header('X-WP-TotalPages', $paginated_data['pagination']['total_pages']);
            
            return $response;
            
        } catch (\Exception $e) {
            return new WP_Error(
                'attendees_error',
                'Unable to retrieve attendees: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }
    
    /**
     * Get attendees for specific occurrence
     */
    public function get_occurrence_attendees($request) 
    {
        $request->set_param('occurrence', $request['occurrence']);
        return $this->get_event_attendees($request);
    }
    
    /**
     * Get single attendee
     */
    public function get_single_attendee($request) 
    {
        try {
            $booking_id = (int) $request['booking_id'];
            $attendee_key = (int) $request['attendee_key'];
            
            // Get booking
            $booking = get_post($booking_id);
            if (!$booking || $booking->post_type !== 'mec-books') {
                return new WP_Error(
                    'booking_not_found',
                    'Booking not found.',
                    ['status' => 404]
                );
            }
            
            // Get attendees from booking
            $attendees = get_post_meta($booking_id, 'mec_attendees', true);
            if (!is_array($attendees)) {
                $attendees = [];
            }
            
            // Find the specific attendee
            $attendee_index = $attendee_key - 1; // Convert to 0-based index
            if (!isset($attendees[$attendee_index])) {
                return new WP_Error(
                    'attendee_not_found',
                    'Attendee not found.',
                    ['status' => 404]
                );
            }
            
            $attendee = $attendees[$attendee_index];
            $attendee['key'] = $attendee_key;
            $attendee['booking_id'] = $booking_id;
            
            // Add booking info
            $attendee['booking_info'] = [
                'booking_id' => $booking_id,
                'transaction_id' => get_post_meta($booking_id, 'mec_transaction_id', true),
                'event_id' => get_post_meta($booking_id, 'mec_event_id', true),
                'booking_date' => $booking->post_date,
                'booking_status' => $booking->post_status,
                'verified' => get_post_meta($booking_id, 'mec_verified', true),
                'confirmed' => get_post_meta($booking_id, 'mec_confirmed', true)
            ];
            
            // Add avatar if user exists for this email
            $attendee = $this->maybe_add_user_avatar($attendee);

            // Add check-in status
            $attendee = $this->add_checkin_status($attendee);
            
            return new WP_REST_Response($attendee, 200);
            
        } catch (\Exception $e) {
            return new WP_Error(
                'attendee_error',
                'Unable to retrieve attendee: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }
    
    /**
     * Check-in attendee
     */
    public function checkin_attendee($request) 
    {
        try {
            $booking_id = (int) $request['booking_id'];
            $attendee_key = (int) $request['attendee_key'];
            $email = sanitize_email($request['email']);
            $timestamp = $request['timestamp'] ?? null;
            
            // Validate inputs
            if (!is_email($email)) {
                return new WP_Error(
                    'invalid_email',
                    'Invalid email address.',
                    ['status' => 400]
                );
            }
            
            // Get invoice ID
            $invoice_id = $this->get_invoice_id_by_booking($booking_id);
            if (!$invoice_id) {
                return new WP_Error(
                    'invoice_not_found',
                    'Invoice not found for this booking.',
                    ['status' => 404]
                );
            }
            
            // Verify booking
            $verified = get_post_meta($booking_id, 'mec_verified', true);
            if ($verified !== '1') {
                return new WP_Error(
                    'booking_not_verified',
                    'Booking is not verified.',
                    ['status' => 400]
                );
            }
            
            // Check if attendee exists and email matches
            $attendee = $this->get_attendee_by_key($booking_id, $attendee_key);
            if (!$attendee) {
                return new WP_Error(
                    'attendee_not_found',
                    'Attendee not found.',
                    ['status' => 404]
                );
            }
            
            if ($attendee['email'] !== $email) {
                return new WP_Error(
                    'email_mismatch',
                    'Email does not match attendee record.',
                    ['status' => 400]
                );
            }
            
            // Check if using MEC Invoice plugin methods
            if (class_exists('MEC_Invoice\\Attendee')) {
                $attendee_class = 'MEC_Invoice\\Attendee';
                
                // Check current status (use null for timestamp to auto-detect)
                $is_checked_in = $attendee_class::hasCheckedIn($invoice_id, $email, $attendee_key, null);
                
                if ($is_checked_in) {
                    return new WP_Error(
                        'already_checked_in',
                        'Attendee is already checked in.',
                        ['status' => 400]
                    );
                }
                
                // Perform check-in (use null for timestamp to auto-detect)
                $result = $attendee_class::doCheckIn($invoice_id, $email, $attendee_key, null, true);
                
                if ($result) {
                    // Trigger hooks for notifications
                    do_action('mec-invoice-check-in', $invoice_id, $email, $attendee_key, $timestamp);
                    
                    $response_data = [
                        'success' => true,
                        'message' => 'Attendee checked in successfully.',
                        'attendee' => array_merge($attendee, [
                            'checkin_status' => true,
                            'checkin_time' => current_time('mysql'),
                            'action_performed' => 'checkin'
                        ])
                    ];
                    
                    return new WP_REST_Response($response_data, 200);
                } else {
                    return new WP_Error(
                        'checkin_failed',
                        'Check-in failed.',
                        ['status' => 500]
                    );
                }
            } else {
                return new WP_Error(
                    'checkin_unavailable',
                    'Check-in functionality is not available. MEC Invoice plugin required.',
                    ['status' => 501]
                );
            }
            
        } catch (\Exception $e) {
            return new WP_Error(
                'checkin_error',
                'Check-in error: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }
    
    /**
     * Check-out attendee
     */
    public function checkout_attendee($request) 
    {
        try {
            $booking_id = (int) $request['booking_id'];
            $attendee_key = (int) $request['attendee_key'];
            $email = sanitize_email($request['email']);
            $timestamp = $request['timestamp'] ?? null;
            
            // Validate inputs
            if (!is_email($email)) {
                return new WP_Error(
                    'invalid_email',
                    'Invalid email address.',
                    ['status' => 400]
                );
            }
            
            // Get invoice ID
            $invoice_id = $this->get_invoice_id_by_booking($booking_id);
            if (!$invoice_id) {
                return new WP_Error(
                    'invoice_not_found',
                    'Invoice not found for this booking.',
                    ['status' => 404]
                );
            }
            
            // Check if attendee exists and email matches
            $attendee = $this->get_attendee_by_key($booking_id, $attendee_key);
            if (!$attendee) {
                return new WP_Error(
                    'attendee_not_found',
                    'Attendee not found.',
                    ['status' => 404]
                );
            }
            
            if ($attendee['email'] !== $email) {
                return new WP_Error(
                    'email_mismatch',
                    'Email does not match attendee record.',
                    ['status' => 400]
                );
            }
            
            // Check if using MEC Invoice plugin methods
            if (class_exists('MEC_Invoice\\Attendee')) {
                $attendee_class = 'MEC_Invoice\\Attendee';
                
                // Check current status (use null for timestamp to auto-detect)
                $is_checked_in = $attendee_class::hasCheckedIn($invoice_id, $email, $attendee_key, null);
                
                if (!$is_checked_in) {
                    return new WP_Error(
                        'not_checked_in',
                        'Attendee is not checked in.',
                        ['status' => 400]
                    );
                }
                
                // Perform check-out (use null for timestamp to auto-detect)
                $result = $attendee_class::doCheckOut($invoice_id, $email, $attendee_key, null, true);
                
                if ($result) {
                    // Trigger hooks for notifications
                    do_action('mec-invoice-check-out', $invoice_id, $email, $attendee_key);
                    
                    $response_data = [
                        'success' => true,
                        'message' => 'Attendee checked out successfully.',
                        'attendee' => array_merge($attendee, [
                            'checkin_status' => false,
                            'checkout_time' => current_time('mysql'),
                            'action_performed' => 'checkout'
                        ])
                    ];
                    
                    return new WP_REST_Response($response_data, 200);
                } else {
                    return new WP_Error(
                        'checkout_failed',
                        'Check-out failed.',
                        ['status' => 500]
                    );
                }
            } else {
                return new WP_Error(
                    'checkout_unavailable',
                    'Check-out functionality is not available. MEC Invoice plugin required.',
                    ['status' => 501]
                );
            }
            
        } catch (\Exception $e) {
            return new WP_Error(
                'checkout_error',
                'Check-out error: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }
    
    /**
     * Bulk check-in/check-out attendees
     */
    public function bulk_checkin_attendees($request) 
    {
        try {
            $event_id = (int) $request['event_id'];
            $action = sanitize_text_field($request['action']);
            $occurrence = $request['occurrence'] ?? null;
            $specific_attendees = $request['attendees'] ?? [];
            
            // Validate event
            if (!get_post($event_id) || get_post_type($event_id) !== 'mec-events') {
                return new WP_Error(
                    'event_not_found',
                    'Event not found.',
                    ['status' => 404]
                );
            }
            
            // Get bookings
            $bookings = $this->get_event_bookings($event_id, ['occurrence' => $occurrence]);
            
            $results = [];
            $success_count = 0;
            $error_count = 0;
            
            foreach ($bookings as $booking) {
                $attendees = get_post_meta($booking->ID, 'mec_attendees', true);
                if (!is_array($attendees)) continue;
                
                foreach ($attendees as $key => $attendee) {
                    $attendee_key = $key + 1;
                    $attendee_id = $booking->ID . '-' . $attendee_key;
                    
                    // Skip if specific attendees provided and this one is not in the list
                    if (!empty($specific_attendees) && !in_array($attendee_id, $specific_attendees)) {
                        continue;
                    }
                    
                    // Perform action
                    $result = $this->perform_checkin_action($booking->ID, $attendee_key, $attendee['email'], $action, $occurrence);
                    
                    if (is_wp_error($result)) {
                        $error_count++;
                        $results[] = [
                            'attendee_id' => $attendee_id,
                            'name' => $attendee['name'],
                            'email' => $attendee['email'],
                            'success' => false,
                            'message' => $result->get_error_message()
                        ];
                    } else {
                        $success_count++;
                        $results[] = [
                            'attendee_id' => $attendee_id,
                            'name' => $attendee['name'],
                            'email' => $attendee['email'],
                            'success' => true,
                            'action' => $result['action'],
                            'message' => $result['message']
                        ];
                    }
                }
            }
            
            $response_data = [
                'success' => true,
                'message' => sprintf(
                    'Bulk operation completed. %d successful, %d errors.',
                    $success_count,
                    $error_count
                ),
                'stats' => [
                    'total_processed' => count($results),
                    'successful' => $success_count,
                    'errors' => $error_count
                ],
                'results' => $results
            ];
            
            return new WP_REST_Response($response_data, 200);
            
        } catch (\Exception $e) {
            return new WP_Error(
                'bulk_operation_error',
                'Bulk operation error: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }
    
    /**
     * Get attendees statistics
     */
    public function get_attendees_stats($request) 
    {
        try {
            $event_id = (int) $request['event_id'];
            $occurrence = $request['occurrence'] ?? null;
            
            // Validate event
            if (!get_post($event_id) || get_post_type($event_id) !== 'mec-events') {
                return new WP_Error(
                    'event_not_found',
                    'Event not found.',
                    ['status' => 404]
                );
            }
            
            // Get bookings
            $bookings = $this->get_event_bookings($event_id, ['occurrence' => $occurrence]);
            
            $stats = [
                'total_bookings' => count($bookings),
                'total_attendees' => 0,
                'checked_in_count' => 0,
                'checked_out_count' => 0,
                'verified_bookings' => 0,
                'confirmed_bookings' => 0,
                'tickets_breakdown' => [],
                'status_breakdown' => []
            ];
            
            foreach ($bookings as $booking) {
                // Booking status
                if (get_post_meta($booking->ID, 'mec_verified', true) === '1') {
                    $stats['verified_bookings']++;
                }
                if (get_post_meta($booking->ID, 'mec_confirmed', true) === '1') {
                    $stats['confirmed_bookings']++;
                }
                
                // Attendees
                $attendees = get_post_meta($booking->ID, 'mec_attendees', true);
                if (!is_array($attendees)) continue;
                
                foreach ($attendees as $key => $attendee) {
                    $stats['total_attendees']++;
                    
                    // Check-in status
                    $attendee_with_status = $this->add_checkin_status(
                        array_merge($attendee, ['key' => $key + 1, 'booking_id' => $booking->ID]),
                        $occurrence
                    );
                    
                    if (isset($attendee_with_status['checkin_status']) && $attendee_with_status['checkin_status']) {
                        $stats['checked_in_count']++;
                    } else {
                        $stats['checked_out_count']++;
                    }
                    
                    // Ticket breakdown
                    $ticket_id = $attendee['id'] ?? 'unknown';
                    if (!isset($stats['tickets_breakdown'][$ticket_id])) {
                        $stats['tickets_breakdown'][$ticket_id] = 0;
                    }
                    $stats['tickets_breakdown'][$ticket_id]++;
                }
            }
            
            // Add percentages
            if ($stats['total_attendees'] > 0) {
                $stats['checkin_percentage'] = round(($stats['checked_in_count'] / $stats['total_attendees']) * 100, 2);
                $stats['verified_percentage'] = round(($stats['verified_bookings'] / $stats['total_bookings']) * 100, 2);
            } else {
                $stats['checkin_percentage'] = 0;
                $stats['verified_percentage'] = 0;
            }
            
            return new WP_REST_Response($stats, 200);
            
        } catch (\Exception $e) {
            return new WP_Error(
                'stats_error',
                'Unable to retrieve statistics: ' . $e->getMessage(),
                ['status' => 500]
            );
        }
    }
    
    /**
     * Debug endpoint - Get raw booking data
     */
    public function debug_event_bookings($request) 
    {
        global $wpdb;
        
        $event_id = (int) $request['event_id'];
        $occurrence = $request->get_param('occurrence');
        
        $debug_data = [
            'event_id' => $event_id,
            'occurrence_requested' => $occurrence,
            'request_params' => $request->get_params()
        ];
        
        // Check event exists
        $event = get_post($event_id);
        $debug_data['event_exists'] = $event ? true : false;
        $debug_data['event_type'] = $event ? $event->post_type : null;
        $debug_data['event_title'] = $event ? html_entity_decode($event->post_title, ENT_QUOTES | ENT_HTML5, 'UTF-8') : null;
        
        // Check mec_bookings table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}mec_bookings'");
        $debug_data['mec_bookings_table_exists'] = $table_exists ? true : false;
        
        if ($table_exists) {
            // All bookings for this event
            $all_bookings = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}mec_bookings WHERE event_id = %d",
                $event_id
            ), ARRAY_A);
            $debug_data['all_bookings_count'] = count($all_bookings);
            $debug_data['all_bookings'] = $all_bookings;
            
            // Bookings for specific occurrence
            if ($occurrence) {
                $occurrence_bookings = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}mec_bookings WHERE event_id = %d AND timestamp = %d",
                    $event_id,
                    (int) $occurrence
                ), ARRAY_A);
                $debug_data['occurrence_bookings_count'] = count($occurrence_bookings);
                $debug_data['occurrence_bookings'] = $occurrence_bookings;
            }
        }
        
        // Check posts (mec-books)
        $booking_posts = get_posts([
            'post_type' => 'mec-books',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => 'mec_event_id',
                    'value' => $event_id,
                    'compare' => '='
                ]
            ]
        ]);
        $debug_data['booking_posts_count'] = count($booking_posts);
        $debug_data['booking_posts'] = array_map(function($post) {
            return [
                'ID' => $post->ID,
                'title' => html_entity_decode($post->post_title, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
                'status' => $post->post_status,
                'attendees' => get_post_meta($post->ID, 'mec_attendees', true)
            ];
        }, $booking_posts);
        
        // Check invoices
        $invoices = get_posts([
            'post_type' => 'mec_invoice',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => 'event_id',
                    'value' => $event_id,
                    'compare' => '='
                ]
            ]
        ]);
        $debug_data['invoices_count'] = count($invoices);
        $debug_data['invoices'] = array_map(function($post) {
            return [
                'ID' => $post->ID,
                'title' => $post->post_title,
                'book_id' => get_post_meta($post->ID, 'book_id', true),
                'event_id' => get_post_meta($post->ID, 'event_id', true)
            ];
        }, $invoices);
        
        return new WP_REST_Response($debug_data, 200);
    }
    
    /**
     * Helper Methods
     */
    
    /**
     * Get event bookings
     */
    public function get_event_bookings($event_id, $params = []) 
    {
        global $wpdb;
        
        // Check if mec_bookings table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}mec_bookings'");
        
        // Use mec_bookings table for accurate occurrence filtering (if table exists)
        if ($table_exists && !empty($params['occurrence'])) {
            // Filter by specific occurrence timestamp
            $booking_records = $wpdb->get_results($wpdb->prepare(
                "SELECT booking_id, event_id, timestamp, date, status, confirmed, verified, seats 
                FROM {$wpdb->prefix}mec_bookings 
                WHERE event_id = %d AND timestamp = %d",
                $event_id,
                (int) $params['occurrence']
            ));
            
            // Get post objects for these bookings
            $booking_ids = array_column($booking_records, 'booking_id');
            
            if (empty($booking_ids)) {
                return [];
            }
            
            $args = [
                'post_type' => 'mec-books',
                'post_status' => 'any',
                'posts_per_page' => -1,
                'post__in' => $booking_ids,
                'orderby' => 'post__in'
            ];
        } else {
            // Fallback: Use meta_query (when table doesn't exist or no occurrence filter)
            $args = [
                'post_type' => 'mec-books',
                'post_status' => 'any',
                'posts_per_page' => -1,
                'meta_query' => [
                    [
                        'key' => 'mec_event_id',
                        'value' => $event_id,
                        'compare' => '='
                    ]
                ]
            ];
            
            // Try to filter by occurrence using meta if provided
            if (!empty($params['occurrence'])) {
                // Try matching with mec_date meta (format: "timestamp_start:timestamp_end")
                $occurrence = (int) $params['occurrence'];
                
                // Get all bookings first, then filter in PHP
                $query = new WP_Query($args);
                $filtered_posts = [];
                
                foreach ($query->posts as $post) {
                    $mec_date = get_post_meta($post->ID, 'mec_date', true);
                    
                    // mec_date format: "1761897600:1761927600"
                    if ($mec_date && strpos($mec_date, ':') !== false) {
                        $parts = explode(':', $mec_date);
                        $booking_timestamp = (int) $parts[0];
                        
                        // Match if timestamps match
                        if ($booking_timestamp == $occurrence) {
                            $filtered_posts[] = $post;
                        }
                    }
                }
                
                return $filtered_posts;
            }
        }
        
        $query = new WP_Query($args);
        return $query->posts;
    }
    
    /**
     * Get attendees from a booking
     */
    private function get_booking_attendees($booking_id, $params = []) 
    {
        $attendees = get_post_meta($booking_id, 'mec_attendees', true);
        if (!is_array($attendees)) {
            return [];
        }
        
        $formatted_attendees = [];
        foreach ($attendees as $key => $attendee) {
            if (!is_numeric($key)) continue; // Skip non-numeric keys like 'attachments'
            
            $formatted_attendee = $attendee;
            $formatted_attendee['key'] = $key + 1; // 1-based key
            $formatted_attendee['booking_id'] = $booking_id;
            $formatted_attendee['attendee_id'] = $booking_id . '-' . ($key + 1);
            
            // Add ticket information
            $event_id = get_post_meta($booking_id, 'mec_event_id', true);
            $tickets = get_post_meta($event_id, 'mec_tickets', true);
            if (is_array($tickets) && isset($attendee['id']) && isset($tickets[$attendee['id']])) {
                $formatted_attendee['ticket_info'] = $tickets[$attendee['id']];
            }
            
            // Add avatar if user exists for this email
            $formatted_attendee = $this->maybe_add_user_avatar($formatted_attendee);

            $formatted_attendees[] = $formatted_attendee;
        }
        
        return $formatted_attendees;
    }
    
    /**
     * Add WordPress user avatar to attendee if a user with the same email exists
     */
    private function maybe_add_user_avatar($attendee)
    {
        try {
            $attendee['avatar'] = $attendee['avatar'] ?? '';
            $email = isset($attendee['email']) ? $attendee['email'] : '';
            if ($email && is_email($email)) {
                // Prefer WP user avatar if a user exists for this email
                $user = get_user_by('email', $email);
                if ($user && isset($user->ID)) {
                    $url = get_avatar_url($user->ID, ['size' => 96]);
                    if ($url) {
                        $attendee['avatar'] = $url;
                        return $attendee;
                    }
                }
                // Fallback to Gravatar by email (even if no WP user exists)
                $fallbackUrl = get_avatar_url($email, ['size' => 96]);
                if ($fallbackUrl) {
                    $attendee['avatar'] = $fallbackUrl;
                    return $attendee;
                }
                // If avatars are disabled or get_avatar_url failed, build gravatar URL manually
                $emailHash = md5(strtolower(trim($email)));
                $attendee['avatar'] = 'https://www.gravatar.com/avatar/' . $emailHash . '?s=96&d=mm';
            }
        } catch (\Throwable $e) {
            // Silently ignore avatar errors to not block attendees API
        }
        return $attendee;
    }

    /**
     * Add check-in status to attendee
     */
    private function add_checkin_status($attendee, $occurrence = null) 
    {
        // Always set a default boolean value for checkin_status
        $attendee['checkin_status'] = false;
        $attendee['checkin_available'] = false;
        
        if (!class_exists('MEC_Invoice\\Attendee')) {
            return $attendee;
        }
        
        $attendee['checkin_available'] = true;
        
        // Get invoice ID
        $invoice_id = $this->get_invoice_id_by_booking($attendee['booking_id']);
        if (!$invoice_id) {
            return $attendee;
        }
        
        $attendee_class = 'MEC_Invoice\\Attendee';
        
        // Use null for timestamp to let MEC Invoice determine the correct occurrence timestamp
        $is_checked_in = $attendee_class::hasCheckedIn(
            $invoice_id, 
            $attendee['email'], 
            $attendee['key'], 
            null  // Let MEC Invoice auto-determine the timestamp
        );
        
        $attendee['checkin_status'] = (bool) $is_checked_in;
        
        if ($is_checked_in) {
            $checkin_time = $attendee_class::get_checkedin_time(
                $invoice_id, 
                $attendee['key'], 
                null  // Use null to get the default timestamp
            );
            if ($checkin_time) {
                $attendee['checkin_time'] = date('Y-m-d H:i:s', $checkin_time);
            }
        }
        
        return $attendee;
    }
    
    /**
     * Get invoice ID by booking ID
     */
    private function get_invoice_id_by_booking($booking_id) 
    {
        $invoices = get_posts([
            'post_type' => 'mec_invoice',
            'posts_per_page' => 1,
            'meta_query' => [
                [
                    'key' => 'book_id',
                    'value' => $booking_id,
                    'compare' => '='
                ]
            ]
        ]);
        
        return !empty($invoices) ? $invoices[0]->ID : null;
    }
    
    /**
     * Get attendee by key from booking
     */
    private function get_attendee_by_key($booking_id, $attendee_key) 
    {
        $attendees = get_post_meta($booking_id, 'mec_attendees', true);
        if (!is_array($attendees)) return null;
        
        $index = $attendee_key - 1; // Convert to 0-based
        if (!isset($attendees[$index])) return null;
        
        $attendee = $attendees[$index];
        $attendee['key'] = $attendee_key;
        $attendee['booking_id'] = $booking_id;
        
        return $attendee;
    }
    
    /**
     * Perform check-in action (checkin, checkout, or toggle)
     */
    private function perform_checkin_action($booking_id, $attendee_key, $email, $action, $occurrence = null) 
    {
        if (!class_exists('MEC_Invoice\\Attendee')) {
            return new WP_Error('checkin_unavailable', 'Check-in functionality not available.');
        }
        
        $invoice_id = $this->get_invoice_id_by_booking($booking_id);
        if (!$invoice_id) {
            return new WP_Error('invoice_not_found', 'Invoice not found.');
        }
        
        $attendee_class = 'MEC_Invoice\\Attendee';
        // Use null for timestamp to auto-detect like the original MEC Invoice plugin
        $is_checked_in = $attendee_class::hasCheckedIn($invoice_id, $email, $attendee_key, null);
        
        $performed_action = '';
        $message = '';
        
        switch ($action) {
            case 'checkin':
                if ($is_checked_in) {
                    return new WP_Error('already_checked_in', 'Already checked in.');
                }
                $attendee_class::doCheckIn($invoice_id, $email, $attendee_key, null, true);
                $performed_action = 'checkin';
                $message = 'Checked in successfully.';
                do_action('mec-invoice-check-in', $invoice_id, $email, $attendee_key, null);
                break;
                
            case 'checkout':
                if (!$is_checked_in) {
                    return new WP_Error('not_checked_in', 'Not checked in.');
                }
                $attendee_class::doCheckOut($invoice_id, $email, $attendee_key, null, true);
                $performed_action = 'checkout';
                $message = 'Checked out successfully.';
                do_action('mec-invoice-check-out', $invoice_id, $email, $attendee_key);
                break;
                
            case 'toggle':
                if ($is_checked_in) {
                    $attendee_class::doCheckOut($invoice_id, $email, $attendee_key, null, true);
                    $performed_action = 'checkout';
                    $message = 'Checked out successfully.';
                    do_action('mec-invoice-check-out', $invoice_id, $email, $attendee_key);
                } else {
                    $attendee_class::doCheckIn($invoice_id, $email, $attendee_key, null, true);
                    $performed_action = 'checkin';
                    $message = 'Checked in successfully.';
                    do_action('mec-invoice-check-in', $invoice_id, $email, $attendee_key, null);
                }
                break;
                
            default:
                return new WP_Error('invalid_action', 'Invalid action.');
        }
        
        return [
            'action' => $performed_action,
            'message' => $message
        ];
    }
    
    /**
     * Filter attendees based on parameters
     */
    private function filter_attendees($attendees, $params) 
    {
        // Filter by checkin status
        if (isset($params['checkin_status'])) {
            $status = $params['checkin_status'];
            if ($status === 'checked_in') {
                $attendees = array_filter($attendees, function($attendee) {
                    return isset($attendee['checkin_status']) && $attendee['checkin_status'] === true;
                });
            } elseif ($status === 'checked_out') {
                $attendees = array_filter($attendees, function($attendee) {
                    return !isset($attendee['checkin_status']) || $attendee['checkin_status'] === false || $attendee['checkin_status'] === null;
                });
            }
        }
        
        // Filter by name
        if (!empty($params['name'])) {
            $name = strtolower($params['name']);
            $attendees = array_filter($attendees, function($attendee) use ($name) {
                return strpos(strtolower($attendee['name'] ?? ''), $name) !== false;
            });
        }
        
        // Filter by email
        if (!empty($params['email'])) {
            $email = strtolower($params['email']);
            $attendees = array_filter($attendees, function($attendee) use ($email) {
                return strpos(strtolower($attendee['email'] ?? ''), $email) !== false;
            });
        }
        
        // Filter by ticket
        if (!empty($params['ticket_id'])) {
            $ticket_id = $params['ticket_id'];
            $attendees = array_filter($attendees, function($attendee) use ($ticket_id) {
                return isset($attendee['id']) && $attendee['id'] == $ticket_id;
            });
        }
        
        return array_values($attendees); // Re-index array
    }
    
    /**
     * Sort attendees
     */
    private function sort_attendees($attendees, $params) 
    {
        $orderby = $params['orderby'] ?? 'name';
        $order = strtolower($params['order'] ?? 'asc');
        
        usort($attendees, function($a, $b) use ($orderby, $order) {
            $value_a = '';
            $value_b = '';
            
            switch ($orderby) {
                case 'name':
                    $value_a = strtolower($a['name'] ?? '');
                    $value_b = strtolower($b['name'] ?? '');
                    break;
                case 'email':
                    $value_a = strtolower($a['email'] ?? '');
                    $value_b = strtolower($b['email'] ?? '');
                    break;
                case 'checkin_status':
                    $value_a = ($a['checkin_status'] ?? false) ? 1 : 0;
                    $value_b = ($b['checkin_status'] ?? false) ? 1 : 0;
                    break;
                case 'booking_id':
                    $value_a = $a['booking_id'] ?? 0;
                    $value_b = $b['booking_id'] ?? 0;
                    break;
                default:
                    $value_a = $a[$orderby] ?? '';
                    $value_b = $b[$orderby] ?? '';
            }
            
            if ($value_a == $value_b) return 0;
            
            $result = $value_a < $value_b ? -1 : 1;
            return ($order === 'desc') ? -$result : $result;
        });
        
        return $attendees;
    }
    
    /**
     * Paginate attendees
     */
    private function paginate_attendees($attendees, $params) 
    {
        $per_page = min((int) ($params['per_page'] ?? 10), 100);
        $page = max((int) ($params['page'] ?? 1), 1);
        
        $total = count($attendees);
        $total_pages = ceil($total / $per_page);
        $offset = ($page - 1) * $per_page;
        
        $paginated_attendees = array_slice($attendees, $offset, $per_page);
        
        return [
            'attendees' => $paginated_attendees,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => $total,
                'total_pages' => $total_pages,
                'has_more' => $page < $total_pages
            ]
        ];
    }
    
    /**
     * Get parameters for attendees endpoints
     */
    private function get_attendees_params() 
    {
        return [
            'occurrence' => [
                'description' => 'Event occurrence timestamp',
                'type' => 'string',
                'required' => false
            ],
            'per_page' => [
                'description' => 'Number of attendees per page',
                'type' => 'integer',
                'default' => 10,
                'minimum' => 1,
                'maximum' => 100
            ],
            'page' => [
                'description' => 'Page number',
                'type' => 'integer',
                'default' => 1,
                'minimum' => 1
            ],
            'orderby' => [
                'description' => 'Sort attendees by field',
                'type' => 'string',
                'enum' => ['name', 'email', 'checkin_status', 'booking_id'],
                'default' => 'name'
            ],
            'order' => [
                'description' => 'Sort order',
                'type' => 'string',
                'enum' => ['asc', 'desc'],
                'default' => 'asc'
            ],
            'checkin_status' => [
                'description' => 'Filter by check-in status',
                'type' => 'string',
                'enum' => ['checked_in', 'checked_out']
            ],
            'name' => [
                'description' => 'Filter by attendee name',
                'type' => 'string'
            ],
            'email' => [
                'description' => 'Filter by attendee email',
                'type' => 'string'
            ],
            'ticket_id' => [
                'description' => 'Filter by ticket ID',
                'type' => 'string'
            ]
        ];
    }
} 