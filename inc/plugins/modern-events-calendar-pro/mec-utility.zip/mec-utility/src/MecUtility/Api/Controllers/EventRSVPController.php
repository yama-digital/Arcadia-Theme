<?php

/**
 * Event RSVP API Controller
 *
 * @package    MecUtility
 * @subpackage MecUtility/Api/Controllers
 * @since      1.0.0
 */

namespace MecUtility\Api\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use WP_Error;
use MecUtility\Auth\AuthHelper;

/**
 * Event RSVP Controller class
 */
class EventRSVPController
{

    /**
     * The namespace for this controller's routes.
     *
     * @var string
     */
    protected $namespace = 'mec-utility/v1';

    /**
     * Register the routes for the objects of the controller.
     */
    public function register_routes()
    {
        $namespace = 'mec-utility/v1';

        // Get event RSVP settings
        \register_rest_route(
            $namespace,
            '/events/(?P<id>[\d]+)/rsvp',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event_rsvp'),
                'permission_callback' => AuthHelper::permission_callback('read_bookings'),
                'args'                => array(
                    'id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        },
                        'required' => true,
                        'description' => \__('Event ID', 'mec-utility'),
                    ),
                ),
            )
        );

        // Update event RSVP settings
        \register_rest_route(
            $namespace,
            '/events/(?P<id>[\d]+)/rsvp',
            array(
                'methods'             => 'PUT',
                'callback'            => array($this, 'update_event_rsvp'),
                'permission_callback' => AuthHelper::permission_callback('update_bookings'),
                'args'                => $this->get_update_rsvp_args(),
            )
        );
    }

    /**
     * Get event RSVP settings
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_event_rsvp($request)
    {
        $event_id = $request->get_param('id');
        $event    = \get_post($event_id);

        // Validate event exists and is correct type
        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Do not expose trashed events
        if ('trash' === $event->post_status) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Get RSVP status
        $rsvp_status = (bool) \get_post_meta($event_id, 'mec_rsvp_status', true);

        // Get RSVP options
        $rsvp_options = \get_post_meta($event_id, 'mec_rsvp', true);
        if (!is_array($rsvp_options)) {
            $rsvp_options = array();
        }

        // Prepare response data
        $response_data = $this->prepare_rsvp_for_response($rsvp_options, $event, $rsvp_status);

        return \rest_ensure_response($response_data);
    }

    /**
     * Update event RSVP settings
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function update_event_rsvp($request)
    {
        $event_id = $request->get_param('id');
        $event    = \get_post($event_id);

        // Validate event exists and is correct type
        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Do not update trashed events
        if ('trash' === $event->post_status) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Get existing RSVP options
        $rsvp_options = \get_post_meta($event_id, 'mec_rsvp', true);
        if (!is_array($rsvp_options)) {
            $rsvp_options = array();
        }

        // Update RSVP status
        if ($request->has_param('rsvp_status')) {
            $rsvp_status = $request->get_param('rsvp_status') ? 1 : 0;
            \update_post_meta($event_id, 'mec_rsvp_status', $rsvp_status);
        }

        // Update total RSVP limit - unlimited checkbox
        if ($request->has_param('rsvp_limit_unlimited')) {
            $rsvp_options['rsvp_limit_unlimited'] = $request->get_param('rsvp_limit_unlimited') ? 1 : 0;
        }

        // Update total RSVP limit - value
        if ($request->has_param('rsvp_limit')) {
            $rsvp_limit = $request->get_param('rsvp_limit');
            if (!empty($rsvp_limit) || $rsvp_limit === 0 || $rsvp_limit === '0') {
                $rsvp_options['rsvp_limit'] = \absint($rsvp_limit);
            }
        }

        // Display Attendees List in RSVP Form
        if ($request->has_param('rsvp_attendees_list')) {
            $attendees_list = $request->get_param('rsvp_attendees_list');
            if (is_array($attendees_list)) {
                $valid_values = array('global', 'yes', 'no', 'maybe');
                $sanitized_list = array();
                foreach ($attendees_list as $value) {
                    if (in_array($value, $valid_values)) {
                        $sanitized_list[] = $value;
                    }
                }
                $rsvp_options['rsvp_attendees_list'] = !empty($sanitized_list) ? $sanitized_list : array('global');
            }
        }

        // Display form only for logged in users
        if ($request->has_param('rsvp_display_form_only_for_logged_in_users')) {
            $logged_in_users = $request->get_param('rsvp_display_form_only_for_logged_in_users');
            if (in_array($logged_in_users, array('global', '0', '1'), true)) {
                $rsvp_options['rsvp_display_form_only_for_logged_in_users'] = $logged_in_users;
            }
        }

        // Display RSVP report in RSVP form
        if ($request->has_param('rsvp_display_rsvp_report')) {
            $display_report = $request->get_param('rsvp_display_rsvp_report');
            if (in_array($display_report, array('global', '0', '1'), true)) {
                $rsvp_options['rsvp_display_rsvp_report'] = $display_report;
            }
        }

        // Display RSVP conversation
        if ($request->has_param('rsvp_display_conversation')) {
            $display_conversation = $request->get_param('rsvp_display_conversation');
            if (in_array($display_conversation, array('global', '0', '1'), true)) {
                $rsvp_options['rsvp_display_conversation'] = $display_conversation;
            }
        }

        // Enable RSVP modification in event page
        if ($request->has_param('rsvp_display_rsvp_modification')) {
            $rsvp_modification = $request->get_param('rsvp_display_rsvp_modification');
            if (in_array($rsvp_modification, array('global', '0', '1'), true)) {
                $rsvp_options['rsvp_display_rsvp_modification'] = $rsvp_modification;
            }
        }

        // Enable RSVP modification without email verification
        if ($request->has_param('rsvp_modification_without_email_verification')) {
            $modification_no_verify = $request->get_param('rsvp_modification_without_email_verification');
            if (in_array($modification_no_verify, array('global', '0', '1'), true)) {
                $rsvp_options['rsvp_modification_without_email_verification'] = $modification_no_verify;
            }
        }

        // RSVP modification location
        if ($request->has_param('rsvp_display_rsvp_modification_location')) {
            $modification_location = $request->get_param('rsvp_display_rsvp_modification_location');
            if (in_array($modification_location, array('global', 'top', 'bottom'), true)) {
                $rsvp_options['rsvp_display_rsvp_modification_location'] = $modification_location;
            }
        }

        // Minimum attendees to start the event - global checkbox
        if ($request->has_param('rsvp_min_attendees_global')) {
            $rsvp_options['rsvp_min_attendees_global'] = $request->get_param('rsvp_min_attendees_global') ? 1 : 0;
        }

        // Minimum attendees to start the event - value
        if ($request->has_param('rsvp_min_attendees')) {
            $min_attendees = $request->get_param('rsvp_min_attendees');
            if (!empty($min_attendees) || $min_attendees === 0 || $min_attendees === '0') {
                $rsvp_options['rsvp_min_attendees'] = \absint($min_attendees);
            }
        }

        // Show RSVP Form Interval - global checkbox
        if ($request->has_param('show_rsvp_form_interval_global')) {
            $rsvp_options['show_rsvp_form_interval_global'] = $request->get_param('show_rsvp_form_interval_global') ? 1 : 0;
        }

        // Show RSVP Form Interval - value (in minutes)
        if ($request->has_param('show_rsvp_form_interval')) {
            $interval = $request->get_param('show_rsvp_form_interval');
            if ($interval === '' || $interval === null) {
                $rsvp_options['show_rsvp_form_interval'] = '';
            } else {
                $rsvp_options['show_rsvp_form_interval'] = \absint($interval);
            }
        }

        // Automatic Approval - Email Verification
        if ($request->has_param('auto_verify')) {
            $auto_verify = $request->get_param('auto_verify');
            if (in_array($auto_verify, array('global', '0', '1'), true)) {
                $rsvp_options['auto_verify'] = $auto_verify;
            }
        }

        // Automatic Approval - RSVP Confirmation
        if ($request->has_param('auto_confirm')) {
            $auto_confirm = $request->get_param('auto_confirm');
            if (in_array($auto_confirm, array('global', '0', '1'), true)) {
                $rsvp_options['auto_confirm'] = $auto_confirm;
            }
        }

        // Total attendees in each RSVP limit - unlimited checkbox
        if ($request->has_param('rsvp_total_attendees_in_each_rsvp_limit_unlimited')) {
            $rsvp_options['rsvp_total_attendees_in_each_rsvp_limit_unlimited'] = $request->get_param('rsvp_total_attendees_in_each_rsvp_limit_unlimited') ? 1 : 0;
        }

        // Total attendees in each RSVP limit - value
        if ($request->has_param('rsvp_total_attendees_in_each_rsvp_limit')) {
            $attendees_limit = $request->get_param('rsvp_total_attendees_in_each_rsvp_limit');
            if (!empty($attendees_limit) || $attendees_limit === 0 || $attendees_limit === '0') {
                $rsvp_options['rsvp_total_attendees_in_each_rsvp_limit'] = \absint($attendees_limit);
            }
        }

        // RSVP Limit By Email - global checkbox
        if ($request->has_param('rsvp_limit_by_email_global')) {
            $rsvp_options['rsvp_limit_by_email_global'] = $request->get_param('rsvp_limit_by_email_global') ? 1 : 0;
        }

        // RSVP Limit By Email - value
        if ($request->has_param('rsvp_limit_by_email')) {
            $email_limit = $request->get_param('rsvp_limit_by_email');
            if (!empty($email_limit) || $email_limit === 0 || $email_limit === '0') {
                $rsvp_options['rsvp_limit_by_email'] = \absint($email_limit);
            }
        }

        // Total User RSVP Limit By IP - unlimited checkbox
        if ($request->has_param('rsvps_user_limit_unlimited')) {
            $rsvp_options['rsvps_user_limit_unlimited'] = $request->get_param('rsvps_user_limit_unlimited') ? 1 : 0;
        }

        // Total User RSVP Limit By IP - value
        if ($request->has_param('rsvps_user_limit')) {
            $user_limit = $request->get_param('rsvps_user_limit');
            if (!empty($user_limit) || $user_limit === 0 || $user_limit === '0') {
                $rsvp_options['rsvps_user_limit'] = \absint($user_limit);
            }
        }

        // Save updated RSVP options
        \update_post_meta($event_id, 'mec_rsvp', $rsvp_options);

        // Get updated status and options
        $rsvp_status = (bool) \get_post_meta($event_id, 'mec_rsvp_status', true);
        $rsvp_options = \get_post_meta($event_id, 'mec_rsvp', true);
        if (!is_array($rsvp_options)) {
            $rsvp_options = array();
        }

        // Prepare response data
        $response_data = $this->prepare_rsvp_for_response($rsvp_options, $event, $rsvp_status);

        return \rest_ensure_response(array(
            'success' => true,
            'message' => \__('RSVP settings updated successfully.', 'mec-utility'),
            'data'    => $response_data,
        ));
    }

    /**
     * Prepare RSVP options for response
     *
     * @param array $rsvp_options RSVP options from post meta.
     * @param \WP_Post $event Event post object.
     * @param bool $rsvp_status RSVP status.
     * @return array Formatted RSVP data.
     */
    private function prepare_rsvp_for_response($rsvp_options, $event, $rsvp_status)
    {
        // Total RSVP limit
        $rsvp_limit = isset($rsvp_options['rsvp_limit']) ? $rsvp_options['rsvp_limit'] : '';
        $rsvp_limit_unlimited = isset($rsvp_options['rsvp_limit_unlimited']) && $rsvp_options['rsvp_limit_unlimited'] == 1 ? true : false;

        // Display options
        $rsvp_attendees_list = isset($rsvp_options['rsvp_attendees_list']) && is_array($rsvp_options['rsvp_attendees_list']) && !empty($rsvp_options['rsvp_attendees_list']) 
            ? $rsvp_options['rsvp_attendees_list'] 
            : array('global');
        
        $rsvp_display_form_only_for_logged_in_users = isset($rsvp_options['rsvp_display_form_only_for_logged_in_users']) 
            ? $rsvp_options['rsvp_display_form_only_for_logged_in_users'] 
            : 'global';

        $rsvp_display_rsvp_report = isset($rsvp_options['rsvp_display_rsvp_report']) 
            ? $rsvp_options['rsvp_display_rsvp_report'] 
            : 'global';

        $rsvp_display_conversation = isset($rsvp_options['rsvp_display_conversation']) 
            ? $rsvp_options['rsvp_display_conversation'] 
            : 'global';

        $rsvp_display_rsvp_modification = isset($rsvp_options['rsvp_display_rsvp_modification']) 
            ? $rsvp_options['rsvp_display_rsvp_modification'] 
            : 'global';

        $rsvp_modification_without_email_verification = isset($rsvp_options['rsvp_modification_without_email_verification']) 
            ? $rsvp_options['rsvp_modification_without_email_verification'] 
            : 'global';

        $rsvp_display_rsvp_modification_location = isset($rsvp_options['rsvp_display_rsvp_modification_location']) 
            ? $rsvp_options['rsvp_display_rsvp_modification_location'] 
            : 'global';

        // Minimum attendees
        $rsvp_min_attendees_global = isset($rsvp_options['rsvp_min_attendees_global']) && $rsvp_options['rsvp_min_attendees_global'] == 1 ? true : false;
        $rsvp_min_attendees = isset($rsvp_options['rsvp_min_attendees']) ? (int) $rsvp_options['rsvp_min_attendees'] : 0;

        // Show RSVP form interval
        $show_rsvp_form_interval_global = isset($rsvp_options['show_rsvp_form_interval_global']) && $rsvp_options['show_rsvp_form_interval_global'] == 1 ? true : false;
        $show_rsvp_form_interval = (isset($rsvp_options['show_rsvp_form_interval']) && trim($rsvp_options['show_rsvp_form_interval']) !== '') 
            ? (int) $rsvp_options['show_rsvp_form_interval'] 
            : null;

        // Automatic Approval
        $auto_verify = isset($rsvp_options['auto_verify']) ? $rsvp_options['auto_verify'] : 'global';
        $auto_confirm = isset($rsvp_options['auto_confirm']) ? $rsvp_options['auto_confirm'] : 'global';

        // Total attendees in each RSVP limit
        $rsvp_total_attendees_in_each_rsvp_limit_unlimited = isset($rsvp_options['rsvp_total_attendees_in_each_rsvp_limit_unlimited']) && $rsvp_options['rsvp_total_attendees_in_each_rsvp_limit_unlimited'] == 1 ? true : false;
        $rsvp_total_attendees_in_each_rsvp_limit = isset($rsvp_options['rsvp_total_attendees_in_each_rsvp_limit']) ? (int) $rsvp_options['rsvp_total_attendees_in_each_rsvp_limit'] : 0;

        // RSVP Limit By Email
        $rsvp_limit_by_email_global = isset($rsvp_options['rsvp_limit_by_email_global']) && $rsvp_options['rsvp_limit_by_email_global'] == 1 ? true : false;
        $rsvp_limit_by_email = (isset($rsvp_options['rsvp_limit_by_email']) && trim($rsvp_options['rsvp_limit_by_email']) !== '') 
            ? (int) $rsvp_options['rsvp_limit_by_email'] 
            : null;

        // Total User RSVP Limit By IP
        $rsvps_user_limit_unlimited = isset($rsvp_options['rsvps_user_limit_unlimited']) && $rsvp_options['rsvps_user_limit_unlimited'] == 1 ? true : false;
        $rsvps_user_limit = isset($rsvp_options['rsvps_user_limit']) ? (int) $rsvp_options['rsvps_user_limit'] : 0;

        return array(
            'event' => array(
                'id'    => $event->ID,
                'title' => $event->post_title,
                'status' => $event->post_status,
            ),
            'rsvp_enabled' => $rsvp_status,
            'total_rsvp_limit' => array(
                'unlimited' => $rsvp_limit_unlimited,
                'limit'     => $rsvp_limit_unlimited ? null : (int) $rsvp_limit,
            ),
            'display_options' => array(
                'attendees_list' => $rsvp_attendees_list,
                'form_only_for_logged_in_users' => $rsvp_display_form_only_for_logged_in_users,
                'display_rsvp_report' => $rsvp_display_rsvp_report,
                'display_conversation' => $rsvp_display_conversation,
                'enable_rsvp_modification' => $rsvp_display_rsvp_modification,
                'modification_without_email_verification' => $rsvp_modification_without_email_verification,
                'modification_location' => $rsvp_display_rsvp_modification_location,
            ),
            'minimum_attendees' => array(
                'use_global' => $rsvp_min_attendees_global,
                'value' => $rsvp_min_attendees_global ? null : $rsvp_min_attendees,
            ),
            'show_rsvp_form_interval' => array(
                'use_global' => $show_rsvp_form_interval_global,
                'minutes' => $show_rsvp_form_interval_global ? null : $show_rsvp_form_interval,
            ),
            'automatic_approval' => array(
                'email_verification' => $auto_verify,
                'rsvp_confirmation' => $auto_confirm,
            ),
            'total_attendees_in_each_rsvp_limit' => array(
                'unlimited' => $rsvp_total_attendees_in_each_rsvp_limit_unlimited,
                'limit' => $rsvp_total_attendees_in_each_rsvp_limit_unlimited ? null : $rsvp_total_attendees_in_each_rsvp_limit,
            ),
            'rsvp_limit_by_email' => array(
                'use_global' => $rsvp_limit_by_email_global,
                'limit' => $rsvp_limit_by_email_global ? null : $rsvp_limit_by_email,
            ),
            'user_rsvp_limit_by_ip' => array(
                'unlimited' => $rsvps_user_limit_unlimited,
                'limit' => $rsvps_user_limit_unlimited ? null : $rsvps_user_limit,
            ),
        );
    }

    /**
     * Get the arguments for updating RSVP settings
     *
     * @return array Arguments array.
     */
    private function get_update_rsvp_args()
    {
        return array(
            'id' => array(
                'validate_callback' => function ($param, $request, $key) {
                    return is_numeric($param);
                },
                'required' => true,
                'description' => \__('Event ID', 'mec-utility'),
            ),
            'rsvp_status' => array(
                'type'        => 'boolean',
                'description' => \__('Enable/disable RSVP module for this event', 'mec-utility'),
                'required'    => false,
            ),
            'rsvp_limit_unlimited' => array(
                'type'        => 'boolean',
                'description' => \__('Whether total RSVP limit is unlimited', 'mec-utility'),
                'required'    => false,
            ),
            'rsvp_limit' => array(
                'type'        => 'integer',
                'description' => \__('Total RSVP limit (ignored if unlimited is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'rsvp_attendees_list' => array(
                'type'        => 'array',
                'description' => \__('Display attendees list for which RSVP answers (array of: global, yes, no, maybe)', 'mec-utility'),
                'required'    => false,
                'items'       => array(
                    'type' => 'string',
                    'enum' => array('global', 'yes', 'no', 'maybe'),
                ),
            ),
            'rsvp_display_form_only_for_logged_in_users' => array(
                'type'        => 'string',
                'description' => \__('Display form only for logged in users (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'rsvp_display_rsvp_report' => array(
                'type'        => 'string',
                'description' => \__('Display RSVP report in form (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'rsvp_display_conversation' => array(
                'type'        => 'string',
                'description' => \__('Display RSVP conversation (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'rsvp_display_rsvp_modification' => array(
                'type'        => 'string',
                'description' => \__('Enable RSVP modification in event page (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'rsvp_modification_without_email_verification' => array(
                'type'        => 'string',
                'description' => \__('Enable RSVP modification without email verification (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'rsvp_display_rsvp_modification_location' => array(
                'type'        => 'string',
                'description' => \__('RSVP modification form location (global, top, bottom)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', 'top', 'bottom'),
            ),
            'rsvp_min_attendees_global' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit minimum attendees from global options', 'mec-utility'),
                'required'    => false,
            ),
            'rsvp_min_attendees' => array(
                'type'        => 'integer',
                'description' => \__('Minimum attendees required to start the event (ignored if use_global is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'show_rsvp_form_interval_global' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit show RSVP form interval from global options', 'mec-utility'),
                'required'    => false,
            ),
            'show_rsvp_form_interval' => array(
                'type'        => 'integer',
                'description' => \__('Show RSVP form only X minutes before event starts (ignored if use_global is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'auto_verify' => array(
                'type'        => 'string',
                'description' => \__('Email verification setting (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'auto_confirm' => array(
                'type'        => 'string',
                'description' => \__('RSVP confirmation setting (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'rsvp_total_attendees_in_each_rsvp_limit_unlimited' => array(
                'type'        => 'boolean',
                'description' => \__('Whether total attendees in each RSVP is unlimited', 'mec-utility'),
                'required'    => false,
            ),
            'rsvp_total_attendees_in_each_rsvp_limit' => array(
                'type'        => 'integer',
                'description' => \__('Total attendees allowed in each RSVP submission (ignored if unlimited is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'rsvp_limit_by_email_global' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit RSVP limit by email from global options', 'mec-utility'),
                'required'    => false,
            ),
            'rsvp_limit_by_email' => array(
                'type'        => 'integer',
                'description' => \__('Total number of RSVP recorded with one email per event (ignored if use_global is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'rsvps_user_limit_unlimited' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit user RSVP limit by IP from global options', 'mec-utility'),
                'required'    => false,
            ),
            'rsvps_user_limit' => array(
                'type'        => 'integer',
                'description' => \__('Maximum RSVPs per user by IP address (ignored if unlimited is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
        );
    }
}
