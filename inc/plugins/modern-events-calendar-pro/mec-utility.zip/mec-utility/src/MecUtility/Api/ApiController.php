<?php

/**
 * The API functionality of the plugin.
 *
 * @link       https://your-domain.com
 * @since      1.0.0
 *
 * @package    MecUtility
 * @subpackage MecUtility/Api
 */

namespace MecUtility\Api;

use MecUtility\Api\Controllers\EventsController;
use MecUtility\Api\Controllers\EventBookingController;
use MecUtility\Api\Controllers\EventRSVPController;
use MecUtility\Api\Controllers\BookingsExportController;
use MecUtility\Api\Controllers\InvoiceController;
use MecUtility\Api\AttendeesController;
use MecUtility\Api\DirectRoutes;
use MecUtility\Api\BookingFieldsRoutes;
use MecUtility\Api\RSVPRoutes;
use MecUtility\Api\WaitingListRoutes;

/**
 * The API functionality of the plugin.
 *
 * Defines the plugin name, version, and API routes for mobile app integration.
 *
 * @package    MecUtility
 * @subpackage MecUtility/Api
 * @author     Webnus Inc. <info@webnus.net>
 */
class ApiController {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Events Controller instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      EventsController    $events_controller
	 */
	private $events_controller;

	/**
	 * Event Booking Controller instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      EventBookingController    $event_booking_controller
	 */
	private $event_booking_controller;

	/**
	 * Event RSVP Controller instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      EventRSVPController    $event_rsvp_controller
	 */
	private $event_rsvp_controller;

	/**
	 * Attendees Controller instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      AttendeesController    $attendees_controller
	 */
	private $attendees_controller;

	/**
	 * Booking Fields Routes instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      BookingFieldsRoutes    $booking_fields_routes
	 */
	private $booking_fields_routes;

	/**
	 * RSVP Routes instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      RSVPRoutes    $rsvp_routes
	 */
	private $rsvp_routes;

	/**
	 * Waiting List Routes instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      WaitingListRoutes    $waiting_list_routes
	 */
	private $waiting_list_routes;

	/**
	 * Translate Controller instance.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      \MecUtility\Controllers\TranslateController    $translate_controller
	 */
	private $translate_controller;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param    string $plugin_name       The name of the plugin.
	 * @param    string $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{
		$this->plugin_name = $plugin_name;
		$this->version     = $version;

		// Initialize controllers
		$this->events_controller = new EventsController();
		$this->event_booking_controller = new EventBookingController();
		$this->event_rsvp_controller = new EventRSVPController();
		$this->attendees_controller = new AttendeesController();
		$this->booking_fields_routes = new BookingFieldsRoutes();

		// Initialize RSVP routes only if the class exists (lazy loading)
		$rsvp_routes_file = __DIR__ . '/RSVPRoutes.php';
		if (file_exists($rsvp_routes_file)) {
			require_once $rsvp_routes_file;

			if (class_exists('MecUtility\\Api\\RSVPRoutes')) {
				$this->rsvp_routes = new RSVPRoutes();
			} else {
			}
		}

		// Initialize Waiting List routes only if the class exists (lazy loading)
		$waiting_list_routes_file = __DIR__ . '/WaitingListRoutes.php';
		if (file_exists($waiting_list_routes_file)) {
			require_once $waiting_list_routes_file;

			if (class_exists('MecUtility\\Api\\WaitingListRoutes')) {
				$this->waiting_list_routes = new WaitingListRoutes();
			} else {
			}
		} else {
		}

		// Initialize TranslateController
		if (class_exists('MecUtility\\Controllers\\TranslateController')) {
			$this->translate_controller = new \MecUtility\Controllers\TranslateController();
		}
	}

	/**
	 * Register the REST API routes.
	 *
	 * @since    1.0.0
	 */
	public function register_routes() {
		// Register EventsController routes
		if ($this->events_controller) {
			$this->events_controller->register_routes();
		}

		// Register EventBookingController routes
		if ($this->event_booking_controller) {
			$this->event_booking_controller->register_routes();
		}

		// Register EventRSVPController routes
		if ($this->event_rsvp_controller) {
			$this->event_rsvp_controller->register_routes();
		}

		// Register AttendeesController routes
		if ($this->attendees_controller) {
			$this->attendees_controller->register_routes();
		}

		// Register BookingFieldsRoutes
		if ($this->booking_fields_routes) {
			$this->booking_fields_routes->register_routes();
		}

		// Register RSVPRoutes
		if ($this->rsvp_routes) {
			$this->rsvp_routes->register_routes();
		}

		// Register WaitingListRoutes
		if ($this->waiting_list_routes) {
			$this->waiting_list_routes->register_routes();
		}

		// Register TranslateController routes
		if ($this->translate_controller) {
			$this->translate_controller->register_routes();
		}

		// Register DirectRoutes (Bookings, QR, etc.)
		if ( class_exists( 'MecUtility\Api\DirectRoutes' ) ) {
			DirectRoutes::init();
			DirectRoutes::register_routes();
		}

		// Register BookingsExportController routes (CSV/Excel export)
		if ( class_exists( 'MecUtility\Api\Controllers\BookingsExportController' ) ) {
			BookingsExportController::register_routes();
		}

		// Register InvoiceController routes (PDF download)
		if ( class_exists( 'MecUtility\Api\Controllers\InvoiceController' ) ) {
			InvoiceController::register_routes();
		}

		// Status endpoint (public)
		\register_rest_route(
			'mec-utility/v1',
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array($this, 'get_status'),
				'permission_callback' => '__return_true',
			)
		);

		// Authentication endpoints
		\register_rest_route(
			'mec-utility/v1',
			'/auth/validate-api-key',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'validate_api_key' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'api_key' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => array( $this, 'validate_api_key_format' ),
					),
					'website_url' => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'esc_url_raw',
					),
				),
			)
		);

		\register_rest_route(
			'mec-utility/v1',
			'/auth/validate-qr-token',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'validate_qr_token' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'qr_token' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => array( $this, 'validate_qr_token_format' ),
					),
				),
			)
		);

		\register_rest_route(
			'mec-utility/v1',
			'/auth/exchange-qr-for-session',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'exchange_qr_for_session' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'qr_token' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'device_info' => array(
						'required'          => false,
						'type'              => 'object',
					),
				),
			)
		);

		\register_rest_route(
			'mec-utility/v1',
			'/auth/refresh-session',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'refresh_session' ),
				'permission_callback' => array( $this, 'verify_api_authentication' ),
				'args'                => array(
					'session_token' => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// User information endpoint
		\register_rest_route(
			'mec-utility/v1',
			'/user/info',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'get_user_info' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Get plugin status.
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   \WP_REST_Response
	 */
	public function get_status($request)
	{
		return \rest_ensure_response(
			array(
				'status'         => 'active',
				'version'        => $this->version,
				'plugin'         => $this->plugin_name,
				'website_url'    => \home_url(),
				'api_enabled'    => \get_option( 'mec_utility_api_enabled', 1 ) ? true : false,
				'qr_enabled'     => \get_option( 'mec_utility_qr_enabled', 1 ) ? true : false,
				'server_time'    => \current_time( 'mysql' ),
				'timezone'       => \get_option( 'timezone_string' ),
			)
		);
	}

	/**
	 * Get user information based on API key and website URL.
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   \WP_REST_Response
	 */
	public function get_user_info( $request ) {
		global $wpdb;

		// Try to get parameters from headers first
		$api_key = $request->get_header( 'api_key' )
			?: $request->get_header( 'api-key' )
			?: $request->get_header( 'X-API-Key' )
			?: $_SERVER['HTTP_API_KEY'] ?? null;

		$website_url = $request->get_header( 'website_url' )
			?: $request->get_header( 'website-url' )
			?: $request->get_header( 'X-Website-URL' )
			?: $_SERVER['HTTP_WEBSITE_URL'] ?? null;

		// If headers not found, try body parameters
		if ( empty( $api_key ) || empty( $website_url ) ) {
			$body_params = $request->get_json_params();
			if ( is_array( $body_params ) ) {
				$api_key = $api_key ?: ( $body_params['api_key'] ?? null );
				$website_url = $website_url ?: ( $body_params['website_url'] ?? null );
			}
		}

		// If still not found, try regular POST parameters
		if ( empty( $api_key ) || empty( $website_url ) ) {
			$api_key = $api_key ?: $request->get_param( 'api_key' );
			$website_url = $website_url ?: $request->get_param( 'website_url' );
		}

		// Check if required parameters are present
		if ( empty( $api_key ) || empty( $website_url ) ) {
			// Debug info
			$debug_info = array(
				'headers_received' => $request->get_headers(),
				'body_params' => $request->get_json_params(),
				'post_params' => $request->get_params(),
				'server_vars' => array_filter( $_SERVER, function( $key ) {
					return strpos( $key, 'HTTP_' ) === 0;
				}, ARRAY_FILTER_USE_KEY ),
				'final_values' => array(
					'api_key' => $api_key,
					'website_url' => $website_url,
				),
			);

			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'Missing required parameters: api_key, website_url. Send in headers, JSON body, or POST parameters.', 'mec-utility' ),
					'code'    => 'missing_parameters',
					'debug'   => $debug_info,
				),
				400
			);
		}

		// Sanitize the values
		$api_key = sanitize_text_field( $api_key );
		$website_url = esc_url_raw( $website_url );

		// Check if API is enabled
		if ( ! get_option( 'mec_utility_api_enabled', 1 ) ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'API is currently disabled.', 'mec-utility' ),
					'code'    => 'api_disabled',
				),
				503
			);
		}

		// Validate website URL
		if ( $website_url !== home_url() ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'Website URL mismatch.', 'mec-utility' ),
					'code'    => 'url_mismatch',
				),
				400
			);
		}

		// Check API key in database
		$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
		$api_key_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$api_keys_table} WHERE api_key = %s AND is_active = 1",
				$api_key
			)
		);

		if ( ! $api_key_data ) {
			// Log failed attempt
			$this->log_authentication_attempt( 'user_info_invalid_key', $api_key, $request );

			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'Invalid or inactive API key.', 'mec-utility' ),
					'code'    => 'invalid_api_key',
				),
				401
			);
		}

		// Update last access time
		$wpdb->update(
			$api_keys_table,
			array( 'last_access' => current_time( 'mysql' ) ),
			array( 'id' => $api_key_data->id ),
			array( '%s' ),
			array( '%d' )
		);

		// Get user info
		$user_info = get_userdata( $api_key_data->user_id );
		$permissions = json_decode( $api_key_data->permissions, true ) ?: array();

		// Get plugin settings
		$plugin_settings = array(
			'api_enabled'        => get_option( 'mec_utility_api_enabled', 1 ) ? true : false,
			'qr_enabled'         => get_option( 'mec_utility_qr_enabled', 1 ) ? true : false,
			'qr_expiry'          => get_option( 'mec_utility_qr_expiry', 300 ),
			'rate_limit'         => get_option( 'mec_utility_rate_limit', 100 ),
			'require_ssl'        => get_option( 'mec_utility_require_ssl', 0 ) ? true : false,
			'allowed_origins'    => get_option( 'mec_utility_allowed_origins', '' ),
			'app_name'           => get_option( 'mec_utility_app_name', 'MEC Mobile App' ),
			'app_version'        => get_option( 'mec_utility_app_version', '1.0.0' ),
			'support_url'        => get_option( 'mec_utility_support_url', '' ),
			'debug_mode'         => get_option( 'mec_utility_debug_mode', 0 ) ? true : false,
			'cache_duration'     => get_option( 'mec_utility_cache_duration', 300 ),
			'log_retention'      => get_option( 'mec_utility_log_retention', 30 ),
		);

		// Get user-specific settings (if any)
		$user_settings = array(
			'timezone'           => get_user_meta( $api_key_data->user_id, 'timezone', true ) ?: get_option( 'timezone_string' ),
			'language'           => get_user_meta( $api_key_data->user_id, 'locale', true ) ?: get_locale(),
			'date_format'        => get_option( 'date_format' ),
			'time_format'        => get_option( 'time_format' ),
		);

		// Get MEC plugin information if available
		$mec_info = array(
			'installed' => is_plugin_active( 'modern-events-calendar/mec.php' ),
			'version'   => defined( 'MEC_VERSION' ) ? MEC_VERSION : 'unknown',
		);

		// Get site information
		$site_info = array(
			'name'        => get_bloginfo( 'name' ),
			'description' => get_bloginfo( 'description' ),
			'url'         => home_url(),
			'admin_email' => get_option( 'admin_email' ),
			'timezone'    => get_option( 'timezone_string' ),
			'language'    => get_locale(),
			'wp_version'  => get_bloginfo( 'version' ),
			'php_version' => PHP_VERSION,
		);

		// Log successful access
		$this->log_authentication_attempt( 'user_info_success', $api_key, $request, $api_key_data->user_id );

		return rest_ensure_response(
			array(
				'success' => true,
				'message' => __( 'User information retrieved successfully.', 'mec-utility' ),
				'data'    => array(
					'user' => array(
						'id'           => $api_key_data->user_id,
						'login'        => $user_info ? $user_info->user_login : '',
						'email'        => $user_info ? $user_info->user_email : '',
						'display_name' => $user_info ? $user_info->display_name : '',
						'first_name'   => $user_info ? get_user_meta( $api_key_data->user_id, 'first_name', true ) : '',
						'last_name'    => $user_info ? get_user_meta( $api_key_data->user_id, 'last_name', true ) : '',
						'roles'        => $user_info ? $user_info->roles : array(),
						'registered'   => $user_info ? $user_info->user_registered : '',
					),
					'api_key' => array(
						'id'           => $api_key_data->id,
						'name'         => $api_key_data->name,
						'api_key'      => $api_key_data->api_key,
						'api_secret'   => $api_key_data->api_secret,
						'permissions'  => $permissions,
						'created_at'   => $api_key_data->created_at,
						'last_access'  => $api_key_data->last_access,
					),
					'plugin_settings'  => $plugin_settings,
					'user_settings'    => $user_settings,
					'mec_info'         => $mec_info,
					'site_info'        => $site_info,
				),
				'timestamp' => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Validate API Key
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   \WP_REST_Response
	 */
	public function validate_api_key( $request ) {
		global $wpdb;

		$api_key = $request->get_param( 'api_key' );
		$website_url = $request->get_param( 'website_url' );

		// Check if API is enabled
		if ( ! get_option( 'mec_utility_api_enabled', 1 ) ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'API is currently disabled.', 'mec-utility' ),
					'code'    => 'api_disabled',
				),
				503
			);
		}

		// Validate website URL if provided
		if ( $website_url && $website_url !== home_url() ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'Website URL mismatch.', 'mec-utility' ),
					'code'    => 'url_mismatch',
				),
				400
			);
		}

		// Check API key in database
		$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
		$api_key_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$api_keys_table} WHERE api_key = %s AND is_active = 1",
				$api_key
			)
		);

		if ( ! $api_key_data ) {
			// Log failed attempt
			$this->log_authentication_attempt( 'api_key_validation_failed', $api_key, $request );

			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'Invalid or inactive API key.', 'mec-utility' ),
					'code'    => 'invalid_api_key',
				),
				401
			);
		}

		// Update last access time
		$wpdb->update(
			$api_keys_table,
			array( 'last_access' => current_time( 'mysql' ) ),
			array( 'id' => $api_key_data->id ),
			array( '%s' ),
			array( '%d' )
		);

		// Get user info
		$user_info = get_userdata( $api_key_data->user_id );
		$permissions = json_decode( $api_key_data->permissions, true ) ?: array();

		// Log successful authentication
		$this->log_authentication_attempt( 'api_key_validation_success', $api_key, $request, $api_key_data->user_id );

		return rest_ensure_response(
			array(
				'success'     => true,
				'message'     => __( 'API key is valid.', 'mec-utility' ),
				'data'        => array(
					'api_key_id'   => $api_key_data->id,
					'api_key_name' => $api_key_data->name,
					'user_id'      => $api_key_data->user_id,
					'user_login'   => $user_info ? $user_info->user_login : '',
					'user_email'   => $user_info ? $user_info->user_email : '',
					'permissions'  => $permissions,
					'created_at'   => $api_key_data->created_at,
					'last_access'  => $api_key_data->last_access,
				),
				'session'     => array(
					'expires_at'   => date( 'Y-m-d H:i:s', strtotime( '+24 hours' ) ),
					'website_url'  => home_url(),
					'api_version'  => $this->version,
				),
			)
		);
	}

	/**
	 * Validate QR Token
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   \WP_REST_Response
	 */
	public function validate_qr_token( $request ) {
		global $wpdb;

		$qr_token = $request->get_param( 'qr_token' );

		// Check if QR codes are enabled
		if ( ! get_option( 'mec_utility_qr_enabled', 1 ) ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'QR code authentication is currently disabled.', 'mec-utility' ),
					'code'    => 'qr_disabled',
				),
				503
			);
		}

		// Check QR token in database - Allow reused tokens
		$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
		$qr_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$qr_sessions_table} WHERE qr_token = %s",
				$qr_token
			)
		);

		if ( ! $qr_data ) {
			// Log failed attempt
			$this->log_authentication_attempt( 'qr_token_validation_failed', $qr_token, $request );

			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'Invalid QR token.', 'mec-utility' ),
					'code'    => 'invalid_qr_token',
				),
				401
			);
		}

		// Check if QR code has expired (if expires_at is set)
		if ( $qr_data->expires_at && strtotime( $qr_data->expires_at ) < current_time( 'timestamp' ) ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'QR token has expired.', 'mec-utility' ),
					'code'    => 'qr_token_expired',
				),
				401
			);
		}

		// Get session data
		$session_data = json_decode( $qr_data->session_data, true ) ?: array();
		$user_info = get_userdata( $qr_data->user_id );

		// Log successful validation
		$this->log_authentication_attempt( 'qr_token_validation_success', $qr_token, $request, $qr_data->user_id );

		return rest_ensure_response(
			array(
				'success' => true,
				'message' => __( 'QR token is valid and ready for exchange (reusable).', 'mec-utility' ),
				'data'    => array(
					'qr_token'     => $qr_token,
					'user_id'      => $qr_data->user_id,
					'user_login'   => $user_info ? $user_info->user_login : '',
					'website_url'  => $session_data['website_url'] ?? home_url(),
					'app_name'     => $session_data['app_name'] ?? '',
					'permissions'  => $session_data['permissions'] ?? array(),
					'created_at'   => $qr_data->created_at,
					'expires_at'   => $qr_data->expires_at,
				),
			)
		);
	}

	/**
	 * Exchange QR Token for Session
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   \WP_REST_Response
	 */
	public function exchange_qr_for_session( $request ) {
		global $wpdb;

		try {
			$qr_token = $request->get_param( 'qr_token' );
			$device_info = $request->get_param( 'device_info' ) ?: array();

			// First validate the QR token
			$validation_request = new \WP_REST_Request( 'POST', '/mec-utility/v1/auth/validate-qr-token' );
			$validation_request->set_param( 'qr_token', $qr_token );
			$validation_response = $this->validate_qr_token( $validation_request );

			// Safe way to check validation response
			$validation_data = $validation_response->get_data();
			if ( ! isset( $validation_data['success'] ) || ! $validation_data['success'] ) {
				return $validation_response;
			}

			// Get QR data - Allow reuse by removing is_used = 0 condition
			$qr_sessions_table = $wpdb->prefix . 'mec_utility_qr_sessions';
			$qr_data = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$qr_sessions_table} WHERE qr_token = %s",
					$qr_token
				)
			);

			if ( ! $qr_data ) {
				return rest_ensure_response(
					array(
						'success' => false,
						'message' => __( 'QR token not found.', 'mec-utility' ),
						'code'    => 'qr_token_not_found',
						'error'   => __( 'QR token not found.', 'mec-utility' ),
					),
					404
				);
			}

			// Get associated API key
			$session_data = json_decode( $qr_data->session_data, true ) ?: array();
			$api_key_id   = $session_data['api_key_id'] ?? null;

			// Fallback: if QR was generated without api_key_id (e.g. default/legacy QR),
			// try to find the latest active API key for the same user and persist it.
			$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
			if ( ! $api_key_id ) {
				$fallback_api_key = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT id FROM {$api_keys_table} WHERE user_id = %d AND is_active = 1 ORDER BY created_at DESC LIMIT 1",
						$qr_data->user_id
					)
				);

				if ( $fallback_api_key ) {
					$api_key_id = (int) $fallback_api_key->id;

					// Persist association so subsequent scans work without fallback
					$session_data['api_key_id'] = $api_key_id;
					$wpdb->update(
						$qr_sessions_table,
						array( 'session_data' => wp_json_encode( $session_data ) ),
						array( 'id' => $qr_data->id ),
						array( '%s' ),
						array( '%d' )
					);
				}
			}

			if ( ! $api_key_id ) {
				return rest_ensure_response(
					array(
						'success' => false,
						'message' => __( 'No API key associated with this QR token.', 'mec-utility' ),
						'code'    => 'no_api_key_associated',
						'error'   => __( 'No API key associated with this QR token.', 'mec-utility' ),
					),
					400
				);
			}

			// Get API key data
			$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
			$api_key_data = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$api_keys_table} WHERE id = %d AND is_active = 1",
					$api_key_id
				)
			);

			if ( ! $api_key_data ) {
				return rest_ensure_response(
					array(
						'success' => false,
						'message' => __( 'Associated API key is not active.', 'mec-utility' ),
						'code'    => 'api_key_inactive',
						'error'   => __( 'Associated API key is not active.', 'mec-utility' ),
					),
					400
				);
			}

			// Update last access time (QR token remains reusable)
			$wpdb->update(
				$qr_sessions_table,
				array(
					'used_at'  => current_time( 'mysql' ),
				),
				array( 'id' => $qr_data->id ),
				array( '%s' ),
				array( '%d' )
			);

			// Update API key last access
			$wpdb->update(
				$api_keys_table,
				array( 'last_access' => current_time( 'mysql' ) ),
				array( 'id' => $api_key_data->id ),
				array( '%s' ),
				array( '%d' )
			);

			// Get user info
			$user_info = get_userdata( $api_key_data->user_id );
			$permissions = json_decode( $api_key_data->permissions, true ) ?: array();

			// Log successful exchange
			$this->log_authentication_attempt( 'qr_token_exchange_success', $qr_token, $request, $api_key_data->user_id );

			// Log device info if provided
			if ( ! empty( $device_info ) ) {
				$this->log_activity(
					'device_registered',
					'device',
					null,
					$api_key_data->user_id,
					array(
						'api_key_id'  => $api_key_data->id,
						'qr_token'    => $qr_token,
						'device_info' => $device_info,
					)
				);
			}

			// Structure response to match frontend expectations
			// Frontend expects: exchangeResult.data.data.api_key and exchangeResult.data.session
			return rest_ensure_response(
				array(
					'success' => true,
					'message' => __( 'QR token exchanged successfully (token remains reusable).', 'mec-utility' ),
					'data'    => array(
						'api_key'      => $api_key_data->api_key,
						'api_key_id'   => $api_key_data->id,
						'api_key_name' => $api_key_data->name,
						'user_id'      => $api_key_data->user_id,
						'user_login'   => $user_info ? $user_info->user_login : '',
						'user_email'   => $user_info ? $user_info->user_email : '',
						'permissions'  => $permissions,
						'created_at'   => $api_key_data->created_at,
					),
					'session' => array(
						'established_at' => current_time( 'mysql' ),
						'expires_at'     => date( 'Y-m-d H:i:s', strtotime( '+30 days' ) ),
						'website_url'    => home_url(),
						'api_version'    => $this->version,
					),
				)
			);
		} catch ( \Exception $e ) {
			// Log the error
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
				error_log( 'MEC Utility QR Exchange Error: ' . $e->getMessage() );
				error_log( 'Stack trace: ' . $e->getTraceAsString() );
			}

			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'An error occurred during QR token exchange.', 'mec-utility' ),
					'error'   => $e->getMessage(),
					'code'    => 'exchange_error',
				),
				500
			);
		}
	}

	/**
	 * Refresh Session
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   \WP_REST_Response
	 */
	public function refresh_session( $request ) {
		global $wpdb;

		$api_key = $this->get_api_key_from_request( $request );

		if ( ! $api_key ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'API key not provided.', 'mec-utility' ),
					'code'    => 'missing_api_key',
				),
				400
			);
		}

		// Get API key data
		$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
		$api_key_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$api_keys_table} WHERE api_key = %s AND is_active = 1",
				$api_key
			)
		);

		if ( ! $api_key_data ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'Invalid API key.', 'mec-utility' ),
					'code'    => 'invalid_api_key',
				),
				401
			);
		}

		// Update last access
		$wpdb->update(
			$api_keys_table,
			array( 'last_access' => current_time( 'mysql' ) ),
			array( 'id' => $api_key_data->id ),
			array( '%s' ),
			array( '%d' )
		);

		// Get user info
		$user_info = get_userdata( $api_key_data->user_id );
		$permissions = json_decode( $api_key_data->permissions, true ) ?: array();

		return rest_ensure_response(
			array(
				'success' => true,
				'message' => __( 'Session refreshed successfully.', 'mec-utility' ),
				'data'    => array(
					'api_key_id'   => $api_key_data->id,
					'api_key_name' => $api_key_data->name,
					'user_id'      => $api_key_data->user_id,
					'user_login'   => $user_info ? $user_info->user_login : '',
					'permissions'  => $permissions,
					'last_access'  => $api_key_data->last_access,
				),
				'session' => array(
					'refreshed_at' => current_time( 'mysql' ),
					'expires_at'   => date( 'Y-m-d H:i:s', strtotime( '+30 days' ) ),
					'website_url'  => home_url(),
					'api_version'  => $this->version,
				),
			)
		);
	}

	/**
	 * Verify API authentication for protected endpoints
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   bool|WP_Error
	 */
	public function verify_api_authentication( $request ) {
		global $wpdb;

		$api_key = $this->get_api_key_from_request( $request );

		if ( ! $api_key ) {
			return new \WP_Error(
				'missing_api_key',
				__( 'API key is required.', 'mec-utility' ),
				array( 'status' => 401 )
			);
		}

		// Check API key in database
		$api_keys_table = $wpdb->prefix . 'mec_utility_api_keys';
		$api_key_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$api_keys_table} WHERE api_key = %s AND is_active = 1",
				$api_key
			)
		);

		if ( ! $api_key_data ) {
			return new \WP_Error(
				'invalid_api_key',
				__( 'Invalid or inactive API key.', 'mec-utility' ),
				array( 'status' => 401 )
			);
		}

		return true;
	}

	/**
	 * Get API key from request headers
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The REST request.
	 * @return   string|null
	 */
	private function get_api_key_from_request( $request ) {
		$authorization = $request->get_header( 'Authorization' );

		if ( $authorization && strpos( $authorization, 'Bearer ' ) === 0 ) {
			return substr( $authorization, 7 );
		}

		// Also check for API key in request parameters (less secure)
		return $request->get_param( 'api_key' );
	}

	/**
	 * Validate API key format
	 *
	 * @since    1.0.0
	 * @param    string $value The API key.
	 * @return   bool
	 */
	public function validate_api_key_format( $value ) {
		return preg_match( '/^mec_[a-zA-Z0-9]{32}$/', $value );
	}

	/**
	 * Validate QR token format
	 *
	 * @since    1.0.0
	 * @param    string $value The QR token.
	 * @return   bool
	 */
	public function validate_qr_token_format( $value ) {
		return preg_match( '/^qr_[a-zA-Z0-9]{32}$/', $value );
	}

	/**
	 * Log authentication attempt
	 *
	 * @since    1.0.0
	 * @param    string $action The action performed.
	 * @param    string $credential The credential used.
	 * @param    \WP_REST_Request $request The request object.
	 * @param    int|null $user_id The user ID if successful.
	 */
	private function log_authentication_attempt( $action, $credential, $request, $user_id = null ) {
		$this->log_activity(
			$action,
			'authentication',
			null,
			$user_id,
			array(
				'credential'  => substr( $credential, 0, 10 ) . '...',
				'ip_address'  => $this->get_client_ip( $request ),
				'user_agent'  => $request->get_header( 'User-Agent' ),
				'request_uri' => $request->get_route(),
			)
		);
	}

	/**
	 * Log activity
	 *
	 * @since    1.0.0
	 * @param    string $action The action performed.
	 * @param    string $object_type The object type.
	 * @param    int|null $object_id The object ID.
	 * @param    int|null $user_id The user ID.
	 * @param    array $additional_data Additional data to log.
	 */
	private function log_activity( $action, $object_type, $object_id = null, $user_id = null, $additional_data = array() ) {
		global $wpdb;

		$activity_logs_table = $wpdb->prefix . 'mec_utility_activity_logs';

		$log_data = array(
			'user_id'       => $user_id,
			'action'        => $action,
			'object_type'   => $object_type,
			'object_id'     => $object_id,
			'ip_address'    => $additional_data['ip_address'] ?? '',
			'user_agent'    => $additional_data['user_agent'] ?? '',
			'request_data'  => wp_json_encode( $additional_data ),
			'status'        => 'success',
			'created_at'    => current_time( 'mysql' ),
		);

		$wpdb->insert( $activity_logs_table, $log_data );
	}

	/**
	 * Get client IP address
	 *
	 * @since    1.0.0
	 * @param    \WP_REST_Request $request The request object.
	 * @return   string
	 */
	private function get_client_ip( $request ) {
		$ip_headers = array(
			'HTTP_CF_CONNECTING_IP',
			'HTTP_CLIENT_IP',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_FORWARDED',
			'HTTP_X_CLUSTER_CLIENT_IP',
			'HTTP_FORWARDED_FOR',
			'HTTP_FORWARDED',
			'REMOTE_ADDR'
		);

		foreach ( $ip_headers as $header ) {
			if ( ! empty( $_SERVER[ $header ] ) ) {
				$ips = explode( ',', $_SERVER[ $header ] );
				$ip = trim( $ips[0] );

				if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
					return $ip;
				}
			}
		}

		return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
	}
}
