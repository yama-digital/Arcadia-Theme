<?php

namespace MecUtility\Api\Controllers;

/**
 * Invoice Controller
 * Handles invoice PDF download (similar to MEC Invoice plugin)
 */
class InvoiceController
{
    /**
     * Register routes and hooks
     */
    public static function register_routes()
    {
        // Register cleanup hook
        add_action('mec_utility_delete_temp_file', array(__CLASS__, 'delete_temp_file'), 10, 2);
        // Download invoice PDF by invoice ID
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/(?P<invoice_id>[\d]+)/pdf',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'download_pdf'),
                'permission_callback' => '__return_true',
            )
        );

        // Download invoice PDF by booking ID (finds invoice automatically)
        \register_rest_route(
            'mec-utility/v1',
            '/bookings/(?P<booking_id>[\d]+)/invoice',
            array(
                'methods'             => 'GET',
                'callback'            => array(__CLASS__, 'download_pdf_by_booking'),
                'permission_callback' => '__return_true',
            )
        );

        // Bulk export invoices as PDF (ZIP file)
        \register_rest_route(
            'mec-utility/v1',
            '/invoices/export/pdf',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'export_pdf_bulk'),
                'permission_callback' => '__return_true',
            )
        );
    }

    /**
     * Download invoice PDF by invoice ID
     */
    public static function download_pdf($request)
    {
        try {
            $invoice_id = (int) $request->get_param('invoice_id');

            // Validate invoice exists
            $invoice = \get_post($invoice_id);
            if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                return new \WP_Error('invoice_not_found', 'Invoice not found.', ['status' => 404]);
            }

            // Check if MEC Invoice plugin is available
            if (!class_exists('MEC_Invoice\PDF')) {
                return new \WP_Error('plugin_not_available', 'MEC Invoice plugin required for PDF functionality.', ['status' => 501]);
            }

            // Get invoice hash
            $invoice_hash = \get_post_meta($invoice_id, 'invoiceID', true);
            if (!$invoice_hash) {
                return new \WP_Error('invoice_hash_not_found', 'Invoice hash not found.', ['status' => 404]);
            }

            // Get booking ID for transaction info
            $book_id = \get_post_meta($invoice_id, 'book_id', true);
            $transaction_id = \get_post_meta($book_id, 'mec_transaction_id', true);

            // Generate PDF URL
            $pdf_url = \get_site_url(null, '?invoiceID=' . $invoice_id . '&makePreview=' . $invoice_hash . '&showPDF=true');

            // Get invoice number
            $invoice_number = '';
            if (class_exists('MEC_Invoice\Helper\Invoice')) {
                $invoice_number = \MEC_Invoice\Helper\Invoice::get_invoice_number($invoice_id);
            }

            // Generate filename
            $filename = 'invoice-' . ($invoice_number ?: $invoice_id) . '.pdf';

            return new \WP_REST_Response([
                'success' => true,
                'pdf_url' => $pdf_url,
                'invoice_id' => $invoice_id,
                'invoice_number' => $invoice_number,
                'invoice_hash' => $invoice_hash,
                'booking_id' => $book_id,
                'transaction_id' => $transaction_id,
                'filename' => $filename
            ], 200);

        } catch (\Exception $e) {
            return new \WP_Error('invoice_download_error', 'Error getting invoice: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Download invoice PDF by booking ID (finds invoice automatically)
     */
    public static function download_pdf_by_booking($request)
    {
        try {
            $booking_id = (int) $request->get_param('booking_id');

            // Validate booking exists
            $booking = \get_post($booking_id);
            if (!$booking || $booking->post_type !== 'mec-books') {
                return new \WP_Error('booking_not_found', 'Booking not found.', ['status' => 404]);
            }

            // Find invoice for this booking
            $invoice_id = \get_post_meta($booking_id, 'invoiceID', true);
            
            if (!$invoice_id) {
                // Try alternative method: search by book_id meta
                $invoices = \get_posts([
                    'post_type' => 'mec_invoice',
                    'post_status' => 'any',
                    'posts_per_page' => 1,
                    'meta_query' => [
                        [
                            'key' => 'book_id',
                            'value' => $booking_id,
                            'compare' => '='
                        ]
                    ]
                ]);

                if (empty($invoices)) {
                    return new \WP_Error('invoice_not_found', 'Invoice not found for this booking.', ['status' => 404]);
                }

                $invoice_id = $invoices[0]->ID;
            }

            // Use the invoice download method
            $request->set_param('invoice_id', $invoice_id);
            return self::download_pdf($request);

        } catch (\Exception $e) {
            return new \WP_Error('invoice_download_error', 'Error getting invoice: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Bulk export invoices as PDF (ZIP file)
     * Similar to MEC Invoice bulk action "Export as PDF"
     */
    public static function export_pdf_bulk($request)
    {
        try {
            // Get invoice IDs from request
            $invoice_ids = $request->get_param('invoice_ids');
            
            if (empty($invoice_ids) || !is_array($invoice_ids)) {
                return new \WP_Error('invalid_invoice_ids', 'Please provide invoice IDs array.', ['status' => 400]);
            }

            // Check if MEC Invoice plugin is available
            if (!class_exists('MEC_Invoice\PDF')) {
                return new \WP_Error('plugin_not_available', 'MEC Invoice plugin required for PDF functionality.', ['status' => 501]);
            }

            // Create temporary directory for PDFs
            $upload = wp_upload_dir();
            $upload_dir = $upload['basedir'] . '/mec-invoices-temp';
            $upload_url = $upload['baseurl'] . '/mec-invoices-temp';
            
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0700, true);
            }

            // Create ZIP file
            $zip = new \ZipArchive();
            $zip_filename = 'invoices-' . md5(implode('_', $invoice_ids)) . '-' . time() . '.zip';
            $zip_path = $upload_dir . '/' . $zip_filename;
            
            if ($zip->open($zip_path, \ZipArchive::CREATE) !== true) {
                return new \WP_Error('zip_creation_failed', 'Failed to create ZIP file.', ['status' => 500]);
            }

            $added_count = 0;
            foreach ($invoice_ids as $invoice_id) {
                $invoice_id = (int) $invoice_id;
                
                // Validate invoice exists
                $invoice = \get_post($invoice_id);
                if (!$invoice || $invoice->post_type !== 'mec_invoice') {
                    continue;
                }

                try {
                    // Create PDF file
                    $pdf_filename = \MEC_Invoice\PDF::createFromInvoice($invoice_id, true);
                    
                    if ($pdf_filename && file_exists($pdf_filename)) {
                        // Get invoice number for better filename
                        $invoice_number = '';
                        if (class_exists('MEC_Invoice\Helper\Invoice')) {
                            $invoice_number = \MEC_Invoice\Helper\Invoice::get_invoice_number($invoice_id);
                        }
                        
                        $zip_entry_name = 'invoice-' . ($invoice_number ?: $invoice_id) . '.pdf';
                        $zip->addFile($pdf_filename, $zip_entry_name);
                        $added_count++;
                    }
                } catch (\Exception $e) {
                    // Skip this invoice if there's an error
                    continue;
                }
            }

            $zip->close();

            if ($added_count === 0) {
                @unlink($zip_path);
                return new \WP_Error('no_invoices_exported', 'No invoices could be exported.', ['status' => 404]);
            }

            // Move ZIP file to uploads directory
            $upload_dir = wp_upload_dir();
            $final_zip_path = $upload_dir['basedir'] . '/' . $zip_filename;
            $final_zip_url = $upload_dir['baseurl'] . '/' . $zip_filename;
            
            // Move file to uploads directory
            if (rename($zip_path, $final_zip_path)) {
                // Create attachment in media library
                $attachment = array(
                    'post_mime_type' => 'application/zip',
                    'post_title' => 'Invoice Export - ' . date('Y-m-d H:i:s'),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );
                
                $attachment_id = wp_insert_attachment($attachment, $final_zip_path);
                
                if ($attachment_id) {
                    // Generate attachment metadata
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    $attachment_data = wp_generate_attachment_metadata($attachment_id, $final_zip_path);
                    wp_update_attachment_metadata($attachment_id, $attachment_data);
                    
                    // Schedule file deletion after 1 hour
                    wp_schedule_single_event(time() + 3600, 'mec_utility_delete_temp_file', array($final_zip_path, $attachment_id));
                    
                    return new \WP_REST_Response([
                        'success' => true,
                        'download_url' => $final_zip_url,
                        'filename' => $zip_filename,
                        'attachment_id' => $attachment_id,
                        'invoices_count' => $added_count,
                        'expires_in' => '1 hour'
                    ], 200);
                }
            }
            
            // Fallback: clean up and return error
            @unlink($zip_path);
            return new \WP_Error('file_upload_failed', 'Failed to upload ZIP file to media library.', ['status' => 500]);

        } catch (\Exception $e) {
            return new \WP_Error('export_error', 'Error exporting invoices: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Delete temporary file and attachment
     */
    public static function delete_temp_file($file_path, $attachment_id)
    {
        // Delete physical file
        if (file_exists($file_path)) {
            @unlink($file_path);
        }
        
        // Delete attachment from media library
        if ($attachment_id) {
            wp_delete_attachment($attachment_id, true);
        }
    }
}

