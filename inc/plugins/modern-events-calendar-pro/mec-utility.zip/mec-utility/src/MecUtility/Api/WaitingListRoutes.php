<?php

namespace MecUtility\Api;

use WP_REST_Request;
use WP_REST_Response;
use WP_Error;
use MecUtility\Auth\AuthHelper;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class WaitingListRoutes
 * 
 * RESTful API routes for Waiting List management
 * Provides CRUD operations for waiting lists with filtering, searching and bulk operations
 */
class WaitingListRoutes
{
    private const POST_TYPE = 'mec-waiting';
    private $tickets_cache = [];
    private $occurrences_cache = [];

    /**
     * Register all waiting list routes
     */
    public function register_routes()
    {
        // List waiting lists with filtering and search
        register_rest_route('mec-utility/v1', '/waiting-lists', [
            'methods' => 'GET',
            'callback' => [$this, 'get_waiting_lists'],
            'permission_callback' => '__return_true',
            'args' => [
                'page' => [
                    'default' => 1,
                    'sanitize_callback' => 'absint',
                ],
                'per_page' => [
                    'default' => 20,
                    'sanitize_callback' => 'absint',
                ],
                'search' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'event_id' => [
                    'required' => true,
                    'description' => 'Event ID to filter waiting lists. This parameter is required.',
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function($param, $request, $key) {
                        return is_numeric($param) && $param > 0;
                    },
                ],
                'ticket_id' => [
                    'sanitize_callback' => 'absint',
                ],
                'confirmation' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'verification' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'location' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'date_from' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'date_to' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'orderby' => [
                    'default' => 'date',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'order' => [
                    'default' => 'DESC',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ]
        ]);

        // Get specific waiting list details
        register_rest_route('mec-utility/v1', '/waiting-lists/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'get_waiting_list'],
            'permission_callback' => '__return_true',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
            ]
        ]);

        // Update waiting list status (confirmation/verification)
        register_rest_route('mec-utility/v1', '/waiting-lists/(?P<id>\d+)/status', [
            'methods' => 'PUT',
            'callback' => [$this, 'update_waiting_list_status'],
            'permission_callback' => '__return_true',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'confirmation' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'verification' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ]
        ]);

        // Update waiting list details
        register_rest_route('mec-utility/v1', '/waiting-lists/(?P<id>\d+)', [
            'methods' => 'PUT',
            'callback' => [$this, 'update_waiting_list'],
            'permission_callback' => '__return_true',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'event_id' => [
                    'sanitize_callback' => 'absint',
                ],
                'date' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'attendees' => [
                    'sanitize_callback' => [$this, 'sanitize_attendees'],
                ],
                'waiting_fields' => [
                    'sanitize_callback' => [$this, 'sanitize_waiting_fields'],
                ],
            ]
        ]);

        // Delete waiting list
        register_rest_route('mec-utility/v1', '/waiting-lists/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$this, 'delete_waiting_list'],
            'permission_callback' => '__return_true',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'force' => [
                    'description' => 'Whether to permanently delete (true) or move to trash (false, default)',
                    'type' => 'boolean',
                    'default' => false,
                ],
            ]
        ]);

        // Get waiting list attendees
        register_rest_route('mec-utility/v1', '/waiting-lists/(?P<id>\d+)/attendees', [
            'methods' => 'GET',
            'callback' => [$this, 'get_waiting_list_attendees'],
            'permission_callback' => '__return_true',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
            ]
        ]);

        // Bulk status update
        register_rest_route('mec-utility/v1', '/waiting-lists/bulk-status', [
            'methods' => 'PUT',
            'callback' => [$this, 'bulk_update_status'],
            'permission_callback' => '__return_true',
            'args' => [
                'waiting_list_ids' => [
                    'required' => true,
                    'validate_callback' => [$this, 'validate_ids_array'],
                ],
                'confirmation' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'verification' => [
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ]
        ]);

        // Bulk delete
        register_rest_route('mec-utility/v1', '/waiting-lists/bulk-delete', [
            'methods' => 'DELETE',
            'callback' => [$this, 'bulk_delete_waiting_lists'],
            'permission_callback' => '__return_true',
            'args' => [
                'waiting_list_ids' => [
                    'required' => true,
                    'validate_callback' => [$this, 'validate_ids_array'],
                ],
                'force' => [
                    'description' => 'Whether to permanently delete (true) or move to trash (false, default)',
                    'type' => 'boolean',
                    'default' => false,
                ],
            ]
        ]);
    }

    /**
     * Get list of waiting lists with filtering and pagination
     */
    public function get_waiting_lists(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $page = $request->get_param('page');
            $per_page = min($request->get_param('per_page'), 100); // Max 100 items per page
            $search = $request->get_param('search');
            $event_id = $request->get_param('event_id');
            $ticket_id = $request->get_param('ticket_id');
            $confirmation = $request->get_param('confirmation');
            $verification = $request->get_param('verification');
            $location = $request->get_param('location');
            $date_from = $request->get_param('date_from');
            $date_to = $request->get_param('date_to');
            $orderby = $request->get_param('orderby');
            $order = $request->get_param('order');

            // Validate event_id is required
            if (empty($event_id) || !is_numeric($event_id) || $event_id <= 0) {
                return new WP_Error('missing_event_id', 'event_id parameter is required and must be a positive integer', ['status' => 400]);
            }

            // Verify event exists
            $event = get_post($event_id);
            if (!$event || $event->post_type !== 'mec-events') {
                return new WP_Error('invalid_event_id', 'Event not found with the provided event_id', ['status' => 404]);
            }

            // Build query arguments
            $args = [
                'post_type' => self::POST_TYPE,
                'posts_per_page' => $per_page,
                'paged' => $page,
                'post_status' => ['publish', 'draft', 'pending', 'private'],
                'orderby' => $this->map_orderby($orderby),
                'order' => strtoupper($order) === 'ASC' ? 'ASC' : 'DESC',
                'meta_query' => [
                    [
                        'key' => 'mec_event_id',
                        'value' => $event_id,
                        'compare' => '='
                    ]
                ],
            ];

            // Add search functionality
            if (!empty($search)) {
                $args['s'] = $search;
            }

            if (!empty($ticket_id)) {
                $args['meta_query'][] = [
                    'key' => 'mec_ticket_id',
                    'value' => $ticket_id,
                    'compare' => '='
                ];
            }

            if (!empty($confirmation)) {
                $args['meta_query'][] = [
                    'key' => 'mec_confirmed',
                    'value' => $confirmation,
                    'compare' => '='
                ];
            }

            if (!empty($verification)) {
                $args['meta_query'][] = [
                    'key' => 'mec_verified',
                    'value' => $verification,
                    'compare' => '='
                ];
            }

            // Date range filtering based on waiting time (mec_waiting_time meta)
            // so that UI "Order Date" matches what user sees.
            if (!empty($date_from) || !empty($date_to)) {
                $from = !empty($date_from) ? $date_from . ' 00:00:00' : '0000-01-01 00:00:00';
                $to   = !empty($date_to)   ? $date_to   . ' 23:59:59' : '9999-12-31 23:59:59';

                $args['meta_query'][] = [
                    'key'     => 'mec_waiting_time',
                    'value'   => [$from, $to],
                    'compare' => 'BETWEEN',
                    'type'    => 'DATETIME',
                ];
            }

            // Location filtering (verify event location matches, if location parameter is provided)
            // Since event_id is required, we only verify that the specified event matches the location filter
            if (!empty($location)) {
                $event_location = $this->get_event_location($event_id);
                // Check if event location contains the searched location string
                if (empty($event_location) || stripos($event_location, $location) === false) {
                    // Event doesn't match location filter, return empty result
                    return new WP_REST_Response([
                        'waiting_lists' => [],
                        'total' => 0,
                        'total_pages' => 0,
                        'current_page' => $page,
                        'per_page' => $per_page
                    ]);
                }
            }

            // Set meta_query relation
            if (count($args['meta_query']) > 1) {
                $args['meta_query']['relation'] = 'AND';
            }

            // Execute query
            $query = new \WP_Query($args);
            $waiting_lists = [];

            foreach ($query->posts as $post) {
                $waiting_lists[] = $this->format_waiting_list_summary($post);
            }

            $total_pages = $query->max_num_pages;

            return new WP_REST_Response([
                'waiting_lists' => $waiting_lists,
                'total' => (int) $query->found_posts,
                'total_pages' => (int) $total_pages,
                'current_page' => $page,
                'per_page' => $per_page,
                'filters_applied' => $this->get_applied_filters($request)
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to retrieve waiting lists: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Get specific waiting list details
     */
    public function get_waiting_list(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $waiting_list_id = $request->get_param('id');
            
            $post = get_post($waiting_list_id);
            
            if (!$post || $post->post_type !== self::POST_TYPE) {
                return new WP_Error('waiting_list_not_found', 'Waiting list not found', ['status' => 404]);
            }

            $waiting_list_data = $this->format_waiting_list_details($post);

            return new WP_REST_Response([
                'waiting_list' => $waiting_list_data
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to retrieve waiting list: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Update waiting list status (confirmation/verification)
     */
    public function update_waiting_list_status(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $waiting_list_id = $request->get_param('id');
            $confirmation = $request->get_param('confirmation');
            $verification = $request->get_param('verification');

            $post = get_post($waiting_list_id);
            
            if (!$post || $post->post_type !== self::POST_TYPE) {
                return new WP_Error('waiting_list_not_found', 'Waiting list not found', ['status' => 404]);
            }

            $updated_fields = [];

            // Update confirmation status
            if ($confirmation !== null) {
                $valid_confirmations = ['-1', '0', '1']; // pending, rejected, confirmed
                if (in_array($confirmation, $valid_confirmations)) {
                    update_post_meta($waiting_list_id, 'mec_confirmed', $confirmation);
                    $updated_fields['confirmation'] = $confirmation;
                    
                    // Trigger confirmation actions if confirmed
                    if ($confirmation === '1') {
                        do_action('mec_waiting_confirmated', $waiting_list_id, 'api');
                    }
                } else {
                    return new WP_Error('invalid_confirmation', 'Invalid confirmation status. Must be -1, 0, or 1', ['status' => 400]);
                }
            }

            // Update verification status
            if ($verification !== null) {
                $valid_verifications = ['-1', '0', '1']; // pending, rejected, verified
                if (in_array($verification, $valid_verifications)) {
                    update_post_meta($waiting_list_id, 'mec_verified', $verification);
                    $updated_fields['verification'] = $verification;
                } else {
                    return new WP_Error('invalid_verification', 'Invalid verification status. Must be -1, 0, or 1', ['status' => 400]);
                }
            }

            if (empty($updated_fields)) {
                return new WP_Error('no_updates', 'No valid status updates provided', ['status' => 400]);
            }

            // Get updated waiting list data
            $updated_waiting_list = $this->format_waiting_list_details($post);

            return new WP_REST_Response([
                'message' => 'Waiting list status updated successfully',
                'updated_fields' => $updated_fields,
                'waiting_list' => $updated_waiting_list
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to update waiting list status: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Update waiting list details
     */
    public function update_waiting_list(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $waiting_list_id = $request->get_param('id');
            $event_id = $request->get_param('event_id');
            $date = $request->get_param('date');
        $ticket_id_param = $request->get_param('ticket_id');
            $attendees = $request->get_param('attendees');
            $waiting_fields = $request->get_param('waiting_fields');

            $post = get_post($waiting_list_id);
            
            if (!$post || $post->post_type !== self::POST_TYPE) {
                return new WP_Error('waiting_list_not_found', 'Waiting list not found', ['status' => 404]);
            }

            $updated_fields = [];

            // Update event ID
            if (!empty($event_id)) {
                update_post_meta($waiting_list_id, 'mec_event_id', $event_id);
                $updated_fields['event_id'] = $event_id;
            }

        // Update primary ticket ID
        if ($ticket_id_param !== null) {
            $sanitized_ticket_id = is_numeric($ticket_id_param) ? (int) $ticket_id_param : sanitize_text_field($ticket_id_param);
            update_post_meta($waiting_list_id, 'mec_ticket_id', $sanitized_ticket_id);
            $updated_fields['ticket_id'] = $sanitized_ticket_id;
        }

            // Update date
            if (!empty($date)) {
                $sanitized_date = sanitize_text_field($date);
                update_post_meta($waiting_list_id, 'mec_date', $sanitized_date);
                $updated_fields['date'] = $sanitized_date;
            }

            // Update attendees
            if (!empty($attendees) && is_array($attendees)) {
                update_post_meta($waiting_list_id, 'mec_attendees', $attendees);
                update_post_meta($waiting_list_id, 'mec_attendees_count', count($attendees));
                $updated_fields['attendees'] = $attendees;
                $updated_fields['attendees_count'] = count($attendees);
            }

            // Update waiting fields
            if (!empty($waiting_fields) && is_array($waiting_fields)) {
                update_post_meta($waiting_list_id, 'mec_waite', $waiting_fields);
                $updated_fields['waiting_fields'] = $waiting_fields;
            }

            if (empty($updated_fields)) {
                return new WP_Error('no_updates', 'No valid updates provided', ['status' => 400]);
            }

            // Get updated waiting list data
            $updated_waiting_list = $this->format_waiting_list_details($post);

            return new WP_REST_Response([
                'message' => 'Waiting list updated successfully',
                'updated_fields' => array_keys($updated_fields),
                'waiting_list' => $updated_waiting_list
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to update waiting list: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Delete waiting list
     */
    public function delete_waiting_list(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $waiting_list_id = (int) $request->get_param('id');
            $force = (bool) $request->get_param('force'); // Get force parameter (default: false)
            
            if (!$waiting_list_id || $waiting_list_id <= 0) {
                return new WP_Error('invalid_id', 'Invalid waiting list ID', ['status' => 400]);
            }
            
            $post = get_post($waiting_list_id);
            
            if (!$post) {
                return new WP_Error('waiting_list_not_found', 'Waiting list not found', ['status' => 404]);
            }
            
            if ($post->post_type !== self::POST_TYPE) {
                return new WP_Error('invalid_post_type', 'Post is not a waiting list', ['status' => 400]);
            }

            // Get waiting list data before deletion for response
            $waiting_list_data = $this->format_waiting_list_summary($post);
            
            $current_status = $post->post_status;
            $result = false;
            $error_message = '';

            // If already in trash and force delete requested, or if force delete requested
            if ($force || $current_status === 'trash') {
                // Force delete permanently
                // First check if there are any filters preventing deletion
                $check = apply_filters('pre_delete_post', null, $post, true);
                if ($check !== null) {
                    return new WP_Error('delete_prevented', 'Deletion prevented by filter: ' . (is_string($check) ? $check : 'Unknown reason'), ['status' => 403]);
                }
                
                // Use wp_delete_post with force = true
                $result = wp_delete_post($waiting_list_id, true);
                
                if (!$result) {
                    // Try alternative method: direct database deletion
                    global $wpdb;
                    $deleted = $wpdb->delete(
                        $wpdb->posts,
                        ['ID' => $waiting_list_id],
                        ['%d']
                    );
                    
                    if ($deleted) {
                        // Clean up post meta
                        $wpdb->delete(
                            $wpdb->postmeta,
                            ['post_id' => $waiting_list_id],
                            ['%d']
                        );
                        
                        // Clean up term relationships
                        wp_delete_object_term_relationships($waiting_list_id, get_object_taxonomies(self::POST_TYPE));
                        
                        clean_post_cache($post);
                        $result = $post; // Return post object to indicate success
                    } else {
                        $error_message = 'Database deletion failed. Post may not exist or may have been already deleted.';
                    }
                }
            } else {
                // Trash the post
                // Check if already trashed
                if ($current_status === 'trash') {
                    // Already trashed, return success
                    return new WP_REST_Response([
                        'message' => 'Waiting list is already in trash',
                        'deleted_waiting_list' => $waiting_list_data,
                        'force' => false,
                        'trashed' => true,
                        'already_trashed' => true
                    ]);
                }
                
                // Check if there are filters preventing trash
                $check = apply_filters('pre_trash_post', null, $post);
                if ($check !== null) {
                    return new WP_Error('trash_prevented', 'Trash prevented by filter: ' . (is_string($check) ? $check : 'Unknown reason'), ['status' => 403]);
                }
                
                // Use wp_update_post to change status to trash
                $result = wp_update_post([
                    'ID' => $waiting_list_id,
                    'post_status' => 'trash'
                ], true);
                
                if (is_wp_error($result)) {
                    return new WP_Error('trash_failed', 'Failed to trash waiting list: ' . $result->get_error_message(), ['status' => 500]);
                }
                
                // Also call wp_trash_post for compatibility
                wp_trash_post($waiting_list_id);
                
                // Verify the status was changed
                $updated_post = get_post($waiting_list_id);
                if ($updated_post && $updated_post->post_status === 'trash') {
                    $result = $updated_post;
                } else {
                    $error_message = 'Post status was not changed to trash';
                }
            }

            if (!$result) {
                // Get more detailed error information
                $post_status = get_post_status($waiting_list_id);
                $post_exists = get_post($waiting_list_id) !== null;
                
                return new WP_Error('delete_failed', 
                    'Failed to delete waiting list. ' . ($error_message ?: 'Unknown error.') . 
                    ' Post exists: ' . ($post_exists ? 'yes' : 'no') . 
                    ', Current status: ' . ($post_status ?: 'unknown'),
                    [
                        'status' => 500,
                        'post_id' => $waiting_list_id,
                        'post_status' => $post_status,
                        'post_exists' => $post_exists,
                        'force' => $force
                    ]
                );
            }

            return new WP_REST_Response([
                'message' => $force ? 'Waiting list deleted permanently' : 'Waiting list moved to trash',
                'deleted_waiting_list' => $waiting_list_data,
                'force' => $force,
                'trashed' => !$force,
                'previous_status' => $current_status
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to delete waiting list: ' . $e->getMessage(), [
                'status' => 500,
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
        }
    }

    /**
     * Get waiting list attendees
     */
    public function get_waiting_list_attendees(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $waiting_list_id = $request->get_param('id');
            
            $post = get_post($waiting_list_id);
            
            if (!$post || $post->post_type !== self::POST_TYPE) {
                return new WP_Error('waiting_list_not_found', 'Waiting list not found', ['status' => 404]);
            }

            $attendees = get_post_meta($waiting_list_id, 'mec_attendees', true);
            $attendees = is_array($attendees) ? $attendees : [];

            // Format attendees
            $formatted_attendees = [];
            foreach ($attendees as $index => $attendee) {
                $formatted_attendees[] = [
                    'index' => $index,
                    'name' => $attendee['name'] ?? '',
                    'email' => $attendee['email'] ?? '',
                    'ticket_id' => $attendee['id'] ?? '',
                    'count' => $attendee['count'] ?? 1,
                    'waiting_fields' => $attendee['waite'] ?? [],
                    'variations' => $attendee['variations'] ?? [],
                    'reg' => $attendee['reg'] ?? null,
                ];
            }

            return new WP_REST_Response([
                'waiting_list_id' => $waiting_list_id,
                'attendees' => $formatted_attendees,
                'total_attendees' => count($formatted_attendees)
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to retrieve attendees: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Bulk update status for multiple waiting lists
     */
    public function bulk_update_status(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $waiting_list_ids = $request->get_param('waiting_list_ids');
            $confirmation = $request->get_param('confirmation');
            $verification = $request->get_param('verification');

            if (empty($waiting_list_ids) || !is_array($waiting_list_ids)) {
                return new WP_Error('invalid_ids', 'Valid waiting list IDs array required', ['status' => 400]);
            }

            if ($confirmation === null && $verification === null) {
                return new WP_Error('no_updates', 'At least one status field must be provided', ['status' => 400]);
            }

            $updated_count = 0;
            $failed_updates = [];
            $updated_fields = [];

            foreach ($waiting_list_ids as $waiting_list_id) {
                $post = get_post($waiting_list_id);
                
                if (!$post || $post->post_type !== self::POST_TYPE) {
                    $failed_updates[] = [
                        'id' => $waiting_list_id,
                        'error' => 'Waiting list not found'
                    ];
                    continue;
                }

                $success = true;

                // Update confirmation status
                if ($confirmation !== null) {
                    $valid_confirmations = ['-1', '0', '1'];
                    if (in_array($confirmation, $valid_confirmations)) {
                        update_post_meta($waiting_list_id, 'mec_confirmed', $confirmation);
                        $updated_fields['confirmation'] = $confirmation;
                        
                        // Trigger confirmation actions if confirmed
                        if ($confirmation === '1') {
                            do_action('mec_waiting_confirmated', $waiting_list_id, 'api_bulk');
                        }
                    } else {
                        $success = false;
                    }
                }

                // Update verification status
                if ($verification !== null) {
                    $valid_verifications = ['-1', '0', '1'];
                    if (in_array($verification, $valid_verifications)) {
                        update_post_meta($waiting_list_id, 'mec_verified', $verification);
                        $updated_fields['verification'] = $verification;
                    } else {
                        $success = false;
                    }
                }

                if ($success) {
                    $updated_count++;
                } else {
                    $failed_updates[] = [
                        'id' => $waiting_list_id,
                        'error' => 'Invalid status values'
                    ];
                }
            }

            return new WP_REST_Response([
                'message' => "Bulk status update completed",
                'updated_count' => $updated_count,
                'total_requested' => count($waiting_list_ids),
                'updated_fields' => array_keys($updated_fields),
                'failed_updates' => $failed_updates
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to bulk update status: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Bulk delete multiple waiting lists
     */
    public function bulk_delete_waiting_lists(WP_REST_Request $request)
    {
        try {
            // Check authentication
            if (!$this->check_authentication($request)) {
                return new WP_Error('rest_forbidden', 'Authentication required', ['status' => 401]);
            }

            $waiting_list_ids = $request->get_param('waiting_list_ids');
            $force = (bool) $request->get_param('force'); // Get force parameter (default: false)

            if (empty($waiting_list_ids) || !is_array($waiting_list_ids)) {
                return new WP_Error('invalid_ids', 'Valid waiting list IDs array required', ['status' => 400]);
            }

            $deleted_count = 0;
            $trashed_count = 0;
            $failed_deletions = [];
            $processed_waiting_lists = [];

            foreach ($waiting_list_ids as $waiting_list_id) {
                $post = get_post($waiting_list_id);
                
                if (!$post || $post->post_type !== self::POST_TYPE) {
                    $failed_deletions[] = [
                        'id' => $waiting_list_id,
                        'error' => 'Waiting list not found'
                    ];
                    continue;
                }

                // Get waiting list data before deletion
                $waiting_list_data = $this->format_waiting_list_summary($post);

                // Delete or trash the post based on force parameter
                if ($force) {
                    $result = wp_delete_post($waiting_list_id, true);
                    if ($result) {
                        $deleted_count++;
                        $processed_waiting_lists[] = $waiting_list_data;
                    } else {
                        $failed_deletions[] = [
                            'id' => $waiting_list_id,
                            'error' => 'Failed to delete permanently'
                        ];
                    }
                } else {
                    $result = wp_trash_post($waiting_list_id);
                    if ($result) {
                        $trashed_count++;
                        $processed_waiting_lists[] = $waiting_list_data;
                    } else {
                        $failed_deletions[] = [
                            'id' => $waiting_list_id,
                            'error' => 'Failed to move to trash'
                        ];
                    }
                }
            }

            $success_count = $force ? $deleted_count : $trashed_count;
            $action = $force ? 'deleted permanently' : 'moved to trash';

            return new WP_REST_Response([
                'message' => "Bulk deletion completed: {$success_count} waiting lists {$action}",
                'deleted_count' => $deleted_count,
                'trashed_count' => $trashed_count,
                'total_requested' => count($waiting_list_ids),
                'failed_deletions' => $failed_deletions,
                'processed_waiting_lists' => $processed_waiting_lists,
                'force' => $force
            ]);

        } catch (\Exception $e) {
            return new WP_Error('waiting_list_error', 'Failed to bulk delete: ' . $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Format waiting list summary data
     */
    private function format_waiting_list_summary($post)
    {
        $event_id = get_post_meta($post->ID, 'mec_event_id', true);
        $event_title = $event_id ? $this->clean_title(get_the_title($event_id)) : 'Unknown Event';
        $event_date = get_post_meta($post->ID, 'mec_date', true);
        $confirmation = get_post_meta($post->ID, 'mec_confirmed', true);
        $verification = get_post_meta($post->ID, 'mec_verified', true);
        $price = get_post_meta($post->ID, 'mec_price', true);
        $ticket_id = get_post_meta($post->ID, 'mec_ticket_id', true);
        $ticket_name = $this->get_ticket_name($event_id, $ticket_id);
        $waiting_time = get_post_meta($post->ID, 'mec_waiting_time', true);
        $attendees_count = get_post_meta($post->ID, 'mec_attendees_count', true);
        $event_date_value = $event_date;
        
        // Get event location
        $event_location = '';
        if ($event_id) {
            $event_location = $this->get_event_location($event_id);
        }

        // Get primary attendee info from post title
        $title_parts = explode(' ', $post->post_title, 2);
        $primary_name = $title_parts[0] ?? '';
        $primary_email = $title_parts[1] ?? '';

        // Format statuses
        $confirmation_text = $this->format_status($confirmation);
        $verification_text = $this->format_status($verification);

        return [
            'id' => $post->ID,
            'event_id' => (int) $event_id,
            'event_title' => $event_title,
            'event_date' => $event_date,
            'event_date_normalized' => $this->normalize_occurrence_value($event_date_value),
            'event_location' => $event_location,
            'primary_attendee' => [
                'name' => $primary_name,
                'email' => $primary_email,
            ],
            'attendees_count' => (int) $attendees_count,
            'ticket_id' => is_numeric($ticket_id) ? (int) $ticket_id : $ticket_id,
            'ticket_name' => $ticket_name,
            'price' => floatval($price),
            'confirmation' => [
                'status' => $confirmation,
                'text' => $confirmation_text,
            ],
            'verification' => [
                'status' => $verification,
                'text' => $verification_text,
            ],
            'waiting_time' => $waiting_time,
            'created_at' => $post->post_date,
            'updated_at' => $post->post_modified,
        ];
    }

    /**
     * Format detailed waiting list data
     */
    private function format_waiting_list_details($post)
    {
        $summary = $this->format_waiting_list_summary($post);
        
        // Add detailed information
        $attendees = get_post_meta($post->ID, 'mec_attendees', true);
        $attendees = is_array($attendees) ? $attendees : [];
        
        $waiting_fields = get_post_meta($post->ID, 'mec_waite', true);
        $waiting_fields = is_array($waiting_fields) ? $waiting_fields : [];

        // Format attendees
        $formatted_attendees = [];
        foreach ($attendees as $index => $attendee) {
            $attendee_ticket_id = $attendee['id'] ?? '';
            $formatted_attendees[] = [
                'index' => $index,
                'name' => $attendee['name'] ?? '',
                'email' => $attendee['email'] ?? '',
                'ticket_id' => is_numeric($attendee_ticket_id) ? (int) $attendee_ticket_id : $attendee_ticket_id,
                'ticket_name' => $this->get_ticket_name($summary['event_id'], $attendee_ticket_id),
                'count' => $attendee['count'] ?? 1,
                'waiting_fields' => $attendee['waite'] ?? [],
                'variations' => $attendee['variations'] ?? [],
                'reg' => $attendee['reg'] ?? null,
            ];
        }

        // Get event waiting fields definition
        $event_waiting_fields = [];
        if (!empty($summary['event_id'])) {
            $event_waiting_fields = $this->get_event_waiting_fields($summary['event_id']);
        }

        $summary['attendees'] = $formatted_attendees;
        $summary['waiting_fields'] = $waiting_fields;
        $summary['event_waiting_fields'] = $event_waiting_fields;
        $summary['event_ticket_options'] = $this->get_event_ticket_options($summary['event_id'], $summary['ticket_id']);
        $summary['event_occurrences'] = $this->get_event_occurrence_options($summary['event_id'], $summary['event_date']);

        return $summary;
    }

    /**
     * Get ticket name by event and ticket ID
     */
    private function get_ticket_name($event_id, $ticket_id)
    {
        if (empty($event_id) || $ticket_id === '' || $ticket_id === null) {
            return '';
        }

        if (!isset($this->tickets_cache[$event_id])) {
            $tickets = get_post_meta($event_id, 'mec_tickets', true);
            $this->tickets_cache[$event_id] = is_array($tickets) ? $tickets : [];
        }

        $tickets = $this->tickets_cache[$event_id];
        $ticket_key = (string) $ticket_id;

        if (isset($tickets[$ticket_key]) && is_array($tickets[$ticket_key])) {
            $ticket = $tickets[$ticket_key];
            if (isset($ticket['name'])) {
                return $this->clean_title($ticket['name']);
            }
        }

        foreach ($tickets as $ticket) {
            if (!is_array($ticket)) {
                continue;
            }

            $ticketIdentifiers = [
                isset($ticket['id']) ? (string) $ticket['id'] : null,
                isset($ticket['ticket_id']) ? (string) $ticket['ticket_id'] : null,
            ];

            if (in_array($ticket_key, array_filter($ticketIdentifiers, function ($value) {
                return $value !== null && $value !== '';
            }), true) && isset($ticket['name'])) {
                return $this->clean_title($ticket['name']);
            }
        }

        return '';
    }

    /**
     * Get ticket options for the event
     */
    private function get_event_ticket_options($event_id, $selected_ticket_id = null)
    {
        if (empty($event_id)) {
            return [];
        }

        if (!isset($this->tickets_cache[$event_id])) {
            $tickets = get_post_meta($event_id, 'mec_tickets', true);
            $this->tickets_cache[$event_id] = is_array($tickets) ? $tickets : [];
        }

        $tickets = $this->tickets_cache[$event_id];
        $selected_key = $selected_ticket_id !== null ? (string) $selected_ticket_id : null;

        $options = [];
        foreach ($tickets as $ticket_key => $ticket) {
            if (!is_array($ticket)) {
                continue;
            }

            $option_id = isset($ticket['id']) ? $ticket['id'] : $ticket_key;
            $option_key = (string) $ticket_key;
            $normalized_option_id = is_numeric($option_id) ? (int) $option_id : (string) $option_id;

            $option = [
                'key' => is_numeric($ticket_key) ? (int) $ticket_key : $ticket_key,
                'id' => $normalized_option_id,
                'name' => isset($ticket['name']) ? $this->clean_title($ticket['name']) : '',
            ];

            if (isset($ticket['price'])) {
                $option['price'] = floatval($ticket['price']);
            }

            if (isset($ticket['description'])) {
                $option['description'] = wp_kses_post($ticket['description']);
            }

            $option_selected_keys = array_filter([
                $option_key,
                isset($ticket['id']) ? (string) $ticket['id'] : null,
                isset($ticket['ticket_id']) ? (string) $ticket['ticket_id'] : null,
            ], function ($value) {
                return $value !== null && $value !== '';
            });

            $option['selected'] = $selected_key !== null && in_array($selected_key, $option_selected_keys, true);

            $option['raw'] = $ticket;

            $options[] = $option;
        }

        return $options;
    }

    /**
     * Get occurrence options for event date selection
     */
    private function get_event_occurrence_options($event_id, $selected_value = null)
    {
        if (empty($event_id)) {
            return [];
        }

        if (!isset($this->occurrences_cache[$event_id])) {
            $occurrence_options = [];

            if (class_exists('\MEC')) {
                $render = \MEC::getInstance('app.libraries.render');
                if ($render && method_exists($render, 'dates')) {
                    $raw_occurrences = $render->dates($event_id, null, 100);

                    if (is_array($raw_occurrences)) {
                        foreach ($raw_occurrences as $occurrence) {
                            if (!isset($occurrence['start']) || !isset($occurrence['end'])) {
                                continue;
                            }

                            $start_ts = $this->extract_occurrence_timestamp($occurrence['start']);
                            $end_ts = $this->extract_occurrence_timestamp($occurrence['end']);
                            $value = $this->build_occurrence_value($occurrence['start'], $occurrence['end'], $start_ts, $end_ts);
                            $normalized_value = $this->normalize_occurrence_value($value, $start_ts, $end_ts);

                            $occurrence_options[] = [
                                'value' => $value,
                                'normalized_value' => $normalized_value,
                                'label' => $this->format_occurrence_label($occurrence['start'], $occurrence['end'], $start_ts, $end_ts, $event_id),
                                'start_date' => $occurrence['start']['date'] ?? '',
                                'end_date' => $occurrence['end']['date'] ?? '',
                                'start_timestamp' => $start_ts,
                                'end_timestamp' => $end_ts,
                            ];
                        }
                    }
                }
            }

            $this->occurrences_cache[$event_id] = $occurrence_options;
        }

        $selected_normalized = $this->normalize_occurrence_value($selected_value);

        return array_map(function ($option) use ($selected_normalized) {
            $option['selected'] = ($selected_normalized !== null && $selected_normalized === $option['normalized_value']);
            return $option;
        }, $this->occurrences_cache[$event_id]);
    }

    /**
     * Extract timestamp from occurrence data
     */
    private function extract_occurrence_timestamp($point)
    {
        if (!is_array($point)) {
            return null;
        }

        if (isset($point['timestamp']) && is_numeric($point['timestamp'])) {
            return (int) $point['timestamp'];
        }

        $date = $point['date'] ?? '';
        if (empty($date)) {
            return null;
        }

        if (isset($point['hour'], $point['minutes'], $point['ampm'])) {
            $hour = (int) $point['hour'];
            $minutes = (int) $point['minutes'];
            $ampm = strtoupper($point['ampm']);

            if ($ampm === 'PM' && $hour < 12) {
                $hour += 12;
            }

            if ($ampm === 'AM' && $hour === 12) {
                $hour = 0;
            }

            $time = sprintf('%02d:%02d:00', $hour, $minutes);
        } elseif (isset($point['time'])) {
            $time = $point['time'];
        } else {
            $time = '00:00:00';
        }

        $datetime = trim($date . ' ' . $time);
        $timestamp = strtotime($datetime);

        return $timestamp ?: null;
    }

    /**
     * Build occurrence value string from start/end data
     */
    private function build_occurrence_value($start, $end, $start_ts, $end_ts)
    {
        if ($start_ts && $end_ts) {
            return $start_ts . ':' . $end_ts;
        }

        $start_date = $start['date'] ?? '';
        $end_date = $end['date'] ?? '';

        if ($start_date || $end_date) {
            return $start_date . ':' . $end_date;
        }

        return '';
    }

    /**
     * Format occurrence label for API response
     */
    private function format_occurrence_label($start, $end, $start_ts, $end_ts, $event_id)
    {
        if ($start_ts && $end_ts && class_exists('\MEC')) {
            $main = \MEC::getInstance('app.libraries.main');
            if ($main && method_exists($main, 'date_label')) {
                $label = $main->date_label($start, $end, get_option('date_format', 'Y-m-d'));
                if (!empty($label)) {
                    return strip_tags($label);
                }
            }
        }

        $date_format = get_option('date_format', 'Y-m-d');
        $time_format = get_option('time_format', 'H:i');

        if ($start_ts && $end_ts) {
            $start_date = date_i18n($date_format, $start_ts);
            $end_date = date_i18n($date_format, $end_ts);

            if ($start_date === $end_date) {
                $start_time = date_i18n($time_format, $start_ts);
                $end_time = date_i18n($time_format, $end_ts);
                return sprintf('%s %s - %s', $start_date, $start_time, $end_time);
            }

            $start_full = date_i18n($date_format . ' ' . $time_format, $start_ts);
            $end_full = date_i18n($date_format . ' ' . $time_format, $end_ts);

            return sprintf('%s - %s', $start_full, $end_full);
        }

        $start_date = $start['date'] ?? '';
        $end_date = $end['date'] ?? '';

        return trim($start_date . ' - ' . $end_date, ' -');
    }

    /**
     * Normalize occurrence value for comparison
     */
    private function normalize_occurrence_value($value, $fallback_start = null, $fallback_end = null)
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_string($value) && strpos($value, ':') !== false) {
            [$start, $end] = explode(':', $value, 2);

            if (is_numeric($start) && is_numeric($end)) {
                return $start . ':' . $end;
            }

            $start_ts = strtotime($start);
            $end_ts = strtotime($end);

            if ($start_ts && $end_ts) {
                return $start_ts . ':' . $end_ts;
            }
        }

        if ($fallback_start && $fallback_end) {
            return $fallback_start . ':' . $fallback_end;
        }

        return is_scalar($value) ? (string) $value : null;
    }

    /**
     * Clean HTML entities and tags from title
     */
    private function clean_title($title)
    {
        if (empty($title)) {
            return $title;
        }

        // Decode HTML entities (&#8217; -> ')
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Remove HTML tags
        $title = strip_tags($title);

        // Clean up any remaining entities
        $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Trim whitespace
        return trim($title);
    }

    /**
     * Get event location
     */
    private function get_event_location($event_id)
    {
        $location_id = get_post_meta($event_id, 'mec_location_id', true);
        if ($location_id) {
            $location = get_term($location_id, 'mec_location');
            if ($location && !is_wp_error($location)) {
                return $location->name;
            }
        }
        return '';
    }

    /**
     * Get events by location
     */
    private function get_events_by_location($location)
    {
        $events = get_posts([
            'post_type' => 'mec-events',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [
                [
                    'key' => 'mec_location_id',
                    'value' => $location,
                    'compare' => 'LIKE'
                ]
            ]
        ]);

        return $events;
    }

    /**
     * Get event waiting fields definition
     */
    private function get_event_waiting_fields($event_id)
    {
        // This would typically be in the waiting list class
        if (class_exists('\MEC_Waiting_List\Core\Base\MEC_feature_waiting')) {
            return \MEC_Waiting_List\Core\Base\MEC_feature_waiting::get_waite_fields($event_id);
        }
        return [];
    }

    /**
     * Format status text
     */
    private function format_status($status)
    {
        switch ($status) {
            case '1': return 'confirmed';
            case '0': return 'pending';
            case '-1': return 'rejected';
            default: return 'unknown';
        }
    }

    /**
     * Map orderby parameter to valid WP_Query orderby
     */
    private function map_orderby($orderby)
    {
        $mapping = [
            'date' => 'date',
            'title' => 'title',
            'event' => 'meta_value',
            'confirmation' => 'meta_value',
            'verification' => 'meta_value',
            'price' => 'meta_value_num',
            'waiting_time' => 'meta_value',
        ];

        return $mapping[$orderby] ?? 'date';
    }

    /**
     * Get applied filters for response
     */
    private function get_applied_filters(WP_REST_Request $request)
    {
        $filters = [];
        
        $filter_params = ['search', 'event_id', 'ticket_id', 'confirmation', 'verification', 'location', 'date_from', 'date_to'];
        
        foreach ($filter_params as $param) {
            $value = $request->get_param($param);
            if (!empty($value)) {
                $filters[$param] = $value;
            }
        }
        
        return $filters;
    }

    /**
     * Check API authentication
     */
    private function check_authentication(WP_REST_Request $request)
    {
        // First check for API key authentication
        if (class_exists('MecUtility\Auth\AuthHelper')) {
            $auth_result = AuthHelper::verify_authentication($request);
            if (!is_wp_error($auth_result)) {
                // Check for waiting list specific permissions
                return $this->check_waiting_list_permissions($request);
            }
        }

        // Fallback to WordPress user authentication
        return is_user_logged_in() && current_user_can('manage_options');
    }

    /**
     * Check waiting list specific permissions
     */
    private function check_waiting_list_permissions(WP_REST_Request $request)
    {
        $method = $request->get_method();
        $route = $request->get_route();

        // Define required permissions for different operations
        $permission_map = [
            'GET' => ['read_waiting_list', 'manage_waiting_list'],
            'POST' => ['create_waiting_list', 'manage_waiting_list'],
            'PUT' => ['update_waiting_list', 'manage_waiting_list'],
            'DELETE' => ['delete_waiting_list', 'manage_waiting_list'],
        ];

        $required_permissions = $permission_map[$method] ?? ['manage_waiting_list'];

        // Get user data from authentication
        $auth_result = AuthHelper::verify_authentication($request);
        if (is_wp_error($auth_result)) {
            return false;
        }

        // Check if user has any of the required permissions
        foreach ($required_permissions as $permission) {
            $permission_check = AuthHelper::check_permission($auth_result, $permission);
            if (!is_wp_error($permission_check)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Sanitize attendees array
     */
    public function sanitize_attendees($attendees)
    {
        if (!is_array($attendees)) {
            return [];
        }

        $sanitized = [];
        foreach ($attendees as $attendee) {
            if (is_array($attendee)) {
                $sanitized[] = [
                    'name' => sanitize_text_field($attendee['name'] ?? ''),
                    'email' => sanitize_email($attendee['email'] ?? ''),
                    'id' => absint($attendee['id'] ?? 0),
                    'count' => absint($attendee['count'] ?? 1),
                    'waite' => is_array($attendee['waite'] ?? null) ? $attendee['waite'] : [],
                    'variations' => is_array($attendee['variations'] ?? null) ? $attendee['variations'] : [],
                    'reg' => $attendee['reg'] ?? null,
                ];
            }
        }

        return $sanitized;
    }

    /**
     * Sanitize waiting fields array
     */
    public function sanitize_waiting_fields($fields)
    {
        if (!is_array($fields)) {
            return [];
        }

        $sanitized = [];
        foreach ($fields as $key => $value) {
            $sanitized[sanitize_key($key)] = sanitize_text_field($value);
        }

        return $sanitized;
    }

    /**
     * Validate IDs array
     */
    public function validate_ids_array($ids)
    {
        if (!is_array($ids)) {
            return false;
        }

        foreach ($ids as $id) {
            if (!is_numeric($id) || $id <= 0) {
                return false;
            }
        }

        return true;
    }
} 