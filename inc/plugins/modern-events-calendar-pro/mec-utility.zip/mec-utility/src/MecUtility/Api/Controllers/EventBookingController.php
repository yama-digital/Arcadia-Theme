<?php

/**
 * Event Booking API Controller
 *
 * @package    MecUtility
 * @subpackage MecUtility/Api/Controllers
 * @since      1.0.0
 */

namespace MecUtility\Api\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use WP_Error;
use MecUtility\Auth\AuthHelper;

/**
 * Event Booking Controller class
 */
class EventBookingController
{

    /**
     * The namespace for this controller's routes.
     *
     * @var string
     */
    protected $namespace = 'mec-utility/v1';

    /**
     * Register the routes for the objects of the controller.
     */
    public function register_routes()
    {
        $namespace = 'mec-utility/v1';

        // Get event booking settings
        \register_rest_route(
            $namespace,
            '/events/(?P<id>[\d]+)/booking',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_event_booking'),
                'permission_callback' => AuthHelper::permission_callback('read_bookings'),
                'args'                => array(
                    'id' => array(
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        },
                        'required' => true,
                        'description' => \__('Event ID', 'mec-utility'),
                    ),
                ),
            )
        );

        // Update event booking settings
        \register_rest_route(
            $namespace,
            '/events/(?P<id>[\d]+)/booking',
            array(
                'methods'             => 'PUT',
                'callback'            => array($this, 'update_event_booking'),
                'permission_callback' => AuthHelper::permission_callback('update_bookings'),
                'args'                => $this->get_update_booking_args(),
            )
        );

        // Get available field types for booking form
        \register_rest_route(
            $namespace,
            '/booking/field-types',
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'get_field_types'),
                'permission_callback' => AuthHelper::permission_callback('read_bookings'),
            )
        );
    }

    /**
     * Get event booking settings
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_event_booking($request)
    {
        $event_id = $request->get_param('id');
        $event    = \get_post($event_id);

        // Validate event exists and is correct type
        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Do not expose trashed events
        if ('trash' === $event->post_status) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Get booking options
        $booking_options = \get_post_meta($event_id, 'mec_booking', true);
        if (!is_array($booking_options)) {
            $booking_options = array();
        }

        // Get tickets
        $tickets = \get_post_meta($event_id, 'mec_tickets', true);
        if (!is_array($tickets)) {
            $tickets = array();
        }

        // Get fees
        $fees = \get_post_meta($event_id, 'mec_fees', true);
        if (!is_array($fees)) {
            $fees = array();
        }
        $fees_global_inheritance = \get_post_meta($event_id, 'mec_fees_global_inheritance', true);
        if (trim($fees_global_inheritance) === '') {
            $fees_global_inheritance = 1;
        }

        // Get ticket variations
        $ticket_variations = \get_post_meta($event_id, 'mec_ticket_variations', true);
        if (!is_array($ticket_variations)) {
            $ticket_variations = array();
        }
        $ticket_variations_global_inheritance = \get_post_meta($event_id, 'mec_ticket_variations_global_inheritance', true);
        if (trim($ticket_variations_global_inheritance) === '') {
            $ticket_variations_global_inheritance = 1;
        }

        // Get booking form fields
        $reg_fields = \get_post_meta($event_id, 'mec_reg_fields', true);
        if (!is_array($reg_fields)) {
            $reg_fields = array();
        }
        $reg_fields_global_inheritance = \get_post_meta($event_id, 'mec_reg_fields_global_inheritance', true);
        if (trim($reg_fields_global_inheritance) === '') {
            $reg_fields_global_inheritance = 1;
        }

        $bfixed_fields = \get_post_meta($event_id, 'mec_bfixed_fields', true);
        if (!is_array($bfixed_fields)) {
            $bfixed_fields = array();
        }

        // Prepare response data
        $response_data = $this->prepare_booking_for_response($booking_options, $event, $tickets, $fees, $fees_global_inheritance, $ticket_variations, $ticket_variations_global_inheritance, $reg_fields, $reg_fields_global_inheritance, $bfixed_fields);

        return \rest_ensure_response($response_data);
    }

    /**
     * Get available field types for booking form
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response Response object on success.
     */
    public function get_field_types($request)
    {
        $field_types = array(
            'per_attendee_fields' => array(
                array('type' => 'name', 'label' => \__('MEC Name', 'mec-utility'), 'is_required' => true),
                array('type' => 'mec_email', 'label' => \__('MEC Email', 'mec-utility'), 'is_required' => true),
                array('type' => 'text', 'label' => \__('Text', 'mec-utility'), 'is_required' => false),
                array('type' => 'email', 'label' => \__('Email', 'mec-utility'), 'is_required' => false),
                array('type' => 'date', 'label' => \__('Date', 'mec-utility'), 'is_required' => false),
                array('type' => 'tel', 'label' => \__('Tel', 'mec-utility'), 'is_required' => false),
                array('type' => 'file', 'label' => \__('File', 'mec-utility'), 'is_required' => false),
                array('type' => 'textarea', 'label' => \__('Textarea', 'mec-utility'), 'is_required' => false),
                array('type' => 'checkbox', 'label' => \__('Checkboxes', 'mec-utility'), 'is_required' => false),
                array('type' => 'radio', 'label' => \__('Radio Buttons', 'mec-utility'), 'is_required' => false),
                array('type' => 'select', 'label' => \__('Dropdown', 'mec-utility'), 'is_required' => false),
                array('type' => 'agreement', 'label' => \__('Agreement', 'mec-utility'), 'is_required' => false),
                array('type' => 'p', 'label' => \__('Paragraph', 'mec-utility'), 'is_required' => false),
            ),
            'fixed_fields' => array(
                array('type' => 'text', 'label' => \__('Text', 'mec-utility')),
                array('type' => 'email', 'label' => \__('Email', 'mec-utility')),
                array('type' => 'date', 'label' => \__('Date', 'mec-utility')),
                array('type' => 'tel', 'label' => \__('Tel', 'mec-utility')),
                array('type' => 'textarea', 'label' => \__('Textarea', 'mec-utility')),
                array('type' => 'checkbox', 'label' => \__('Checkboxes', 'mec-utility')),
                array('type' => 'radio', 'label' => \__('Radio Buttons', 'mec-utility')),
                array('type' => 'select', 'label' => \__('Dropdown', 'mec-utility')),
                array('type' => 'agreement', 'label' => \__('Agreement', 'mec-utility')),
                array('type' => 'p', 'label' => \__('Paragraph', 'mec-utility')),
            ),
        );

        return \rest_ensure_response($field_types);
    }

    /**
     * Update event booking settings
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function update_event_booking($request)
    {
        $event_id = $request->get_param('id');
        $event    = \get_post($event_id);

        // Validate event exists and is correct type
        if (empty($event) || 'mec-events' !== $event->post_type) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Do not update trashed events
        if ('trash' === $event->post_status) {
            return new \WP_Error(
                'mec_utility_event_not_found',
                \__('Event not found.', 'mec-utility'),
                array('status' => 404)
            );
        }

        // Get existing booking options
        $booking_options = \get_post_meta($event_id, 'mec_booking', true);
        if (!is_array($booking_options)) {
            $booking_options = array();
        }

        // Update total booking limit
        if ($request->has_param('bookings_limit_unlimited')) {
            $booking_options['bookings_limit_unlimited'] = $request->get_param('bookings_limit_unlimited') ? 1 : 0;
        }

        if ($request->has_param('bookings_limit')) {
            $bookings_limit = $request->get_param('bookings_limit');
            if (!empty($bookings_limit) || $bookings_limit === 0 || $bookings_limit === '0') {
                $booking_options['bookings_limit'] = \absint($bookings_limit);
            }
        }

        // Update minimum ticket per booking
        if ($request->has_param('bookings_minimum_per_booking')) {
            $bookings_minimum_per_booking = $request->get_param('bookings_minimum_per_booking');
            if (!empty($bookings_minimum_per_booking) || $bookings_minimum_per_booking === 1) {
                $booking_options['bookings_minimum_per_booking'] = max(1, \absint($bookings_minimum_per_booking));
            }
        }

        // Update book all occurrences
        if ($request->has_param('bookings_all_occurrences')) {
            $booking_options['bookings_all_occurrences'] = $request->get_param('bookings_all_occurrences') ? 1 : 0;
        }

        // Update book all occurrences multiple
        if ($request->has_param('bookings_all_occurrences_multiple')) {
            $booking_options['bookings_all_occurrences_multiple'] = $request->get_param('bookings_all_occurrences_multiple') ? 1 : 0;
        }

        // Update show booking form interval
        if ($request->has_param('show_booking_form_interval')) {
            $show_booking_form_interval = $request->get_param('show_booking_form_interval');
            if ($show_booking_form_interval === '' || $show_booking_form_interval === null) {
                $booking_options['show_booking_form_interval'] = '';
            } else {
                $booking_options['show_booking_form_interval'] = \absint($show_booking_form_interval);
            }
        }

        // Update stop selling after first occurrence
        if ($request->has_param('stop_selling_after_first_occurrence')) {
            $booking_options['stop_selling_after_first_occurrence'] = $request->get_param('stop_selling_after_first_occurrence') ? 1 : 0;
        }

        // Automatic Approval - Email Verification
        if ($request->has_param('auto_verify')) {
            $auto_verify = $request->get_param('auto_verify');
            if (in_array($auto_verify, array('global', '0', '1'), true)) {
                $booking_options['auto_verify'] = $auto_verify;
            }
        }

        // Automatic Approval - Booking Confirmation
        if ($request->has_param('auto_confirm')) {
            $auto_confirm = $request->get_param('auto_confirm');
            if (in_array($auto_confirm, array('global', '0', '1'), true)) {
                $booking_options['auto_confirm'] = $auto_confirm;
            }
        }

        // Booking Button Label
        if ($request->has_param('bookings_booking_button_label')) {
            $button_label = $request->get_param('bookings_booking_button_label');
            $booking_options['bookings_booking_button_label'] = \sanitize_text_field($button_label);
        }

        // Total User Booking Limits - Unlimited checkbox
        if ($request->has_param('bookings_user_limit_unlimited')) {
            $booking_options['bookings_user_limit_unlimited'] = $request->get_param('bookings_user_limit_unlimited') ? 1 : 0;
        }

        // Total User Booking Limits - Limit value
        if ($request->has_param('bookings_user_limit')) {
            $user_limit = $request->get_param('bookings_user_limit');
            if (!empty($user_limit) || $user_limit === 0 || $user_limit === '0') {
                $booking_options['bookings_user_limit'] = \absint($user_limit);
            }
        }

        // Save updated booking options
        \update_post_meta($event_id, 'mec_booking', $booking_options);

        // Tickets (stored separately in mec_tickets meta)
        if ($request->has_param('tickets')) {
            $tickets = $request->get_param('tickets');
            if (is_array($tickets)) {
                $sanitized_tickets = $this->sanitize_tickets($tickets);
                \update_post_meta($event_id, 'mec_tickets', $sanitized_tickets);
            }
        }

        // Fees - Global inheritance
        if ($request->has_param('fees_global_inheritance')) {
            $fees_global_inheritance = $request->get_param('fees_global_inheritance') ? 1 : 0;
            \update_post_meta($event_id, 'mec_fees_global_inheritance', $fees_global_inheritance);
        }

        // Fees - Stored separately in mec_fees meta
        if ($request->has_param('fees')) {
            $fees = $request->get_param('fees');
            if (is_array($fees)) {
                $sanitized_fees = $this->sanitize_fees($fees);
                \update_post_meta($event_id, 'mec_fees', $sanitized_fees);
            }
        }

        // Ticket Variations - Global inheritance
        if ($request->has_param('ticket_variations_global_inheritance')) {
            $variations_global_inheritance = $request->get_param('ticket_variations_global_inheritance') ? 1 : 0;
            \update_post_meta($event_id, 'mec_ticket_variations_global_inheritance', $variations_global_inheritance);
        }

        // Ticket Variations - Stored separately in mec_ticket_variations meta
        if ($request->has_param('ticket_variations')) {
            $variations = $request->get_param('ticket_variations');
            if (is_array($variations)) {
                $sanitized_variations = $this->sanitize_ticket_variations($variations);
                \update_post_meta($event_id, 'mec_ticket_variations', $sanitized_variations);
            }
        }

        // Booking Form - Global inheritance
        if ($request->has_param('reg_fields_global_inheritance')) {
            $reg_fields_global_inheritance = $request->get_param('reg_fields_global_inheritance') ? 1 : 0;
            \update_post_meta($event_id, 'mec_reg_fields_global_inheritance', $reg_fields_global_inheritance);
        }

        // Per Attendee Fields - Stored in mec_reg_fields meta
        if ($request->has_param('per_attendee_fields')) {
            $reg_fields = $request->get_param('per_attendee_fields');
            if (is_array($reg_fields)) {
                $sanitized_reg_fields = $this->sanitize_form_fields($reg_fields);
                \update_post_meta($event_id, 'mec_reg_fields', $sanitized_reg_fields);
            }
        }

        // Fixed Fields - Stored in mec_bfixed_fields meta
        if ($request->has_param('fixed_fields')) {
            $bfixed_fields = $request->get_param('fixed_fields');
            if (is_array($bfixed_fields)) {
                $sanitized_bfixed_fields = $this->sanitize_form_fields($bfixed_fields);
                \update_post_meta($event_id, 'mec_bfixed_fields', $sanitized_bfixed_fields);
            }
        }

        // Get updated tickets
        $tickets = \get_post_meta($event_id, 'mec_tickets', true);
        if (!is_array($tickets)) {
            $tickets = array();
        }

        // Get updated fees
        $fees = \get_post_meta($event_id, 'mec_fees', true);
        if (!is_array($fees)) {
            $fees = array();
        }
        $fees_global_inheritance = \get_post_meta($event_id, 'mec_fees_global_inheritance', true);
        if (trim($fees_global_inheritance) === '') {
            $fees_global_inheritance = 1;
        }

        // Get updated ticket variations
        $ticket_variations = \get_post_meta($event_id, 'mec_ticket_variations', true);
        if (!is_array($ticket_variations)) {
            $ticket_variations = array();
        }
        $ticket_variations_global_inheritance = \get_post_meta($event_id, 'mec_ticket_variations_global_inheritance', true);
        if (trim($ticket_variations_global_inheritance) === '') {
            $ticket_variations_global_inheritance = 1;
        }

        // Get updated form fields
        $reg_fields = \get_post_meta($event_id, 'mec_reg_fields', true);
        if (!is_array($reg_fields)) {
            $reg_fields = array();
        }
        $reg_fields_global_inheritance = \get_post_meta($event_id, 'mec_reg_fields_global_inheritance', true);
        if (trim($reg_fields_global_inheritance) === '') {
            $reg_fields_global_inheritance = 1;
        }

        $bfixed_fields = \get_post_meta($event_id, 'mec_bfixed_fields', true);
        if (!is_array($bfixed_fields)) {
            $bfixed_fields = array();
        }

        // Prepare response data
        $response_data = $this->prepare_booking_for_response($booking_options, $event, $tickets, $fees, $fees_global_inheritance, $ticket_variations, $ticket_variations_global_inheritance, $reg_fields, $reg_fields_global_inheritance, $bfixed_fields);

        return \rest_ensure_response(array(
            'success' => true,
            'message' => \__('Booking settings updated successfully.', 'mec-utility'),
            'data'    => $response_data,
        ));
    }

    /**
     * Prepare booking options for response
     *
     * @param array $booking_options Booking options from post meta.
     * @param \WP_Post $event Event post object.
     * @param array $tickets Tickets data.
     * @param array $fees Fees data.
     * @param int $fees_global_inheritance Fees global inheritance flag.
     * @param array $ticket_variations Ticket variations data.
     * @param int $ticket_variations_global_inheritance Ticket variations global inheritance flag.
     * @param array $reg_fields Per attendee fields data.
     * @param int $reg_fields_global_inheritance Form fields global inheritance flag.
     * @param array $bfixed_fields Fixed fields data.
     * @return array Formatted booking data.
     */
    private function prepare_booking_for_response($booking_options, $event, $tickets = array(), $fees = array(), $fees_global_inheritance = 1, $ticket_variations = array(), $ticket_variations_global_inheritance = 1, $reg_fields = array(), $reg_fields_global_inheritance = 1, $bfixed_fields = array())
    {
        // Total booking limit
        $bookings_limit = isset($booking_options['bookings_limit']) ? $booking_options['bookings_limit'] : '';
        $bookings_limit_unlimited = isset($booking_options['bookings_limit_unlimited']) && $booking_options['bookings_limit_unlimited'] == 1 ? true : false;

        // Minimum ticket per booking
        $bookings_minimum_per_booking = (isset($booking_options['bookings_minimum_per_booking']) && trim($booking_options['bookings_minimum_per_booking'])) 
            ? (int) $booking_options['bookings_minimum_per_booking'] 
            : 1;

        // Book all occurrences
        $bookings_all_occurrences = isset($booking_options['bookings_all_occurrences']) && $booking_options['bookings_all_occurrences'] == 1 ? true : false;
        $bookings_all_occurrences_multiple = isset($booking_options['bookings_all_occurrences_multiple']) && $booking_options['bookings_all_occurrences_multiple'] == 1 ? true : false;

        // Interval options
        $show_booking_form_interval = (isset($booking_options['show_booking_form_interval']) && trim($booking_options['show_booking_form_interval']) !== '') 
            ? (int) $booking_options['show_booking_form_interval'] 
            : null;
        $stop_selling_after_first_occurrence = isset($booking_options['stop_selling_after_first_occurrence']) && $booking_options['stop_selling_after_first_occurrence'] == 1 ? true : false;

        // Automatic Approval
        $auto_verify = isset($booking_options['auto_verify']) ? $booking_options['auto_verify'] : 'global';
        $auto_confirm = isset($booking_options['auto_confirm']) ? $booking_options['auto_confirm'] : 'global';

        // Booking Button Label
        $booking_button_label = (isset($booking_options['bookings_booking_button_label']) && trim($booking_options['bookings_booking_button_label']) !== '') 
            ? $booking_options['bookings_booking_button_label'] 
            : '';

        // Total User Booking Limits
        $bookings_user_limit = isset($booking_options['bookings_user_limit']) ? $booking_options['bookings_user_limit'] : '';
        $bookings_user_limit_unlimited = isset($booking_options['bookings_user_limit_unlimited']) && $booking_options['bookings_user_limit_unlimited'] == 1 ? true : false;

        return array(
            'event' => array(
                'id'    => $event->ID,
                'title' => $event->post_title,
                'status' => $event->post_status,
            ),
            'total_booking_limit' => array(
                'unlimited' => $bookings_limit_unlimited,
                'limit'     => $bookings_limit_unlimited ? null : (int) $bookings_limit,
            ),
            'minimum_ticket_per_booking' => $bookings_minimum_per_booking,
            'book_all_occurrences' => array(
                'enabled' => $bookings_all_occurrences,
                'allow_multiple_bookings' => $bookings_all_occurrences_multiple,
            ),
            'interval_options' => array(
                'show_booking_form_interval' => $show_booking_form_interval,
                'stop_selling_after_first_occurrence' => $stop_selling_after_first_occurrence,
            ),
            'automatic_approval' => array(
                'email_verification' => $auto_verify,
                'booking_confirmation' => $auto_confirm,
            ),
            'booking_button_label' => $booking_button_label,
            'total_user_booking_limits' => array(
                'unlimited' => $bookings_user_limit_unlimited,
                'limit' => $bookings_user_limit_unlimited ? null : (int) $bookings_user_limit,
            ),
            'tickets' => $this->prepare_tickets_for_response($tickets),
            'fees' => array(
                'global_inheritance' => $fees_global_inheritance == 1,
                'items' => $this->prepare_fees_for_response($fees),
            ),
            'ticket_variations' => array(
                'global_inheritance' => $ticket_variations_global_inheritance == 1,
                'items' => $this->prepare_ticket_variations_for_response($ticket_variations),
            ),
            'booking_form' => array(
                'global_inheritance' => $reg_fields_global_inheritance == 1,
                'per_attendee_fields' => $this->prepare_form_fields_for_response($reg_fields),
                'fixed_fields' => $this->prepare_form_fields_for_response($bfixed_fields),
            ),
        );
    }

    /**
     * Prepare form fields for response
     *
     * @param array $fields Raw form fields data
     * @return array Formatted fields
     */
    private function prepare_form_fields_for_response($fields)
    {
        if (!is_array($fields) || empty($fields)) {
            return array();
        }

        $formatted_fields = array();

        foreach ($fields as $field_id => $field) {
            if (!is_array($field) || !is_numeric($field_id)) {
                continue;
            }

            $formatted_field = array(
                'id' => (int) $field_id,
                'type' => isset($field['type']) ? $field['type'] : 'text',
                'label' => isset($field['label']) ? $field['label'] : '',
                'mandatory' => isset($field['mandatory']) && $field['mandatory'] == '1',
            );

            // Options for select, checkbox, radio
            if (isset($field['options']) && is_array($field['options'])) {
                $formatted_field['options'] = array();
                foreach ($field['options'] as $option_id => $option) {
                    if (is_numeric($option_id) && is_array($option)) {
                        $formatted_field['options'][] = array(
                            'id' => (int) $option_id,
                            'label' => isset($option['label']) ? $option['label'] : '',
                        );
                    }
                }
            }

            $formatted_fields[] = $formatted_field;
        }

        return $formatted_fields;
    }

    /**
     * Prepare ticket variations for response
     *
     * @param array $variations Raw variations data
     * @return array Formatted variations
     */
    private function prepare_ticket_variations_for_response($variations)
    {
        if (!is_array($variations) || empty($variations)) {
            return array();
        }

        $formatted_variations = array();

        foreach ($variations as $variation_id => $variation) {
            if (!is_array($variation) || !is_numeric($variation_id)) {
                continue;
            }

            $formatted_variations[] = array(
                'id' => (int) $variation_id,
                'title' => isset($variation['title']) ? $variation['title'] : '',
                'price' => isset($variation['price']) ? floatval($variation['price']) : 0,
                'max' => isset($variation['max']) && trim($variation['max']) !== '' ? (int) $variation['max'] : null,
                'notification_placeholders' => array(
                    'title' => '%%ticket_variations_' . $variation_id . '_title%%',
                    'count' => '%%ticket_variations_' . $variation_id . '_count%%',
                ),
            );
        }

        return $formatted_variations;
    }

    /**
     * Prepare fees for response
     *
     * @param array $fees Raw fees data
     * @return array Formatted fees
     */
    private function prepare_fees_for_response($fees)
    {
        if (!is_array($fees) || empty($fees)) {
            return array();
        }

        $formatted_fees = array();

        foreach ($fees as $fee_id => $fee) {
            if (!is_array($fee) || !is_numeric($fee_id)) {
                continue;
            }

            $formatted_fees[] = array(
                'id' => (int) $fee_id,
                'title' => isset($fee['title']) ? $fee['title'] : '',
                'amount' => isset($fee['amount']) ? floatval($fee['amount']) : 0,
                'type' => isset($fee['type']) ? $fee['type'] : 'amount_per_booking',
            );
        }

        return $formatted_fees;
    }

    /**
     * Prepare tickets for response
     *
     * @param array $tickets Raw tickets data
     * @return array Formatted tickets
     */
    private function prepare_tickets_for_response($tickets)
    {
        if (!is_array($tickets) || empty($tickets)) {
            return array();
        }

        $formatted_tickets = array();

        foreach ($tickets as $ticket_id => $ticket) {
            if (!is_array($ticket) || !is_numeric($ticket_id)) {
                continue;
            }

            $formatted_ticket = array(
                'id' => (int) $ticket_id,
                'name' => isset($ticket['name']) ? $ticket['name'] : '',
                'description' => isset($ticket['description']) ? $ticket['description'] : '',
                'private_description' => isset($ticket['private_description']) ? $ticket['private_description'] : '',
                'price' => isset($ticket['price']) ? floatval($ticket['price']) : 0,
                'price_label' => isset($ticket['price_label']) ? $ticket['price_label'] : '',
                'limit' => isset($ticket['limit']) ? (int) $ticket['limit'] : 100,
                'unlimited' => isset($ticket['unlimited']) && $ticket['unlimited'] == 1,
                'seats' => isset($ticket['seats']) ? (int) $ticket['seats'] : 1,
                'minimum_ticket' => isset($ticket['minimum_ticket']) ? (int) $ticket['minimum_ticket'] : 0,
                'maximum_ticket' => isset($ticket['maximum_ticket']) ? (int) $ticket['maximum_ticket'] : 0,
                'stop_selling' => array(
                    'value' => isset($ticket['stop_selling_value']) ? (int) $ticket['stop_selling_value'] : 0,
                    'type' => isset($ticket['stop_selling_type']) ? $ticket['stop_selling_type'] : 'day',
                ),
            );

            // Ticket times
            if (isset($ticket['ticket_start_time_hour']) || isset($ticket['ticket_end_time_hour'])) {
                $formatted_ticket['times'] = array(
                    'start' => array(
                        'hour' => isset($ticket['ticket_start_time_hour']) ? (int) $ticket['ticket_start_time_hour'] : 8,
                        'minute' => isset($ticket['ticket_start_time_minute']) ? (int) $ticket['ticket_start_time_minute'] : 0,
                        'ampm' => isset($ticket['ticket_start_time_ampm']) ? $ticket['ticket_start_time_ampm'] : 'AM',
                    ),
                    'end' => array(
                        'hour' => isset($ticket['ticket_end_time_hour']) ? (int) $ticket['ticket_end_time_hour'] : 6,
                        'minute' => isset($ticket['ticket_end_time_minute']) ? (int) $ticket['ticket_end_time_minute'] : 0,
                        'ampm' => isset($ticket['ticket_end_time_ampm']) ? $ticket['ticket_end_time_ampm'] : 'PM',
                    ),
                );
            }

            // Price per date
            if (isset($ticket['dates']) && is_array($ticket['dates']) && !empty($ticket['dates'])) {
                $formatted_ticket['price_per_date'] = array();
                foreach ($ticket['dates'] as $date_id => $date) {
                    if (!is_numeric($date_id)) continue;
                    $formatted_ticket['price_per_date'][] = array(
                        'id' => (int) $date_id,
                        'start' => isset($date['start']) ? $date['start'] : '',
                        'end' => isset($date['end']) ? $date['end'] : '',
                        'price' => isset($date['price']) ? floatval($date['price']) : 0,
                        'label' => isset($date['label']) ? $date['label'] : '',
                    );
                }
            }

            // Variations per ticket
            if (isset($ticket['variations']) && is_array($ticket['variations']) && !empty($ticket['variations'])) {
                $formatted_ticket['variations'] = array(
                    'event_inheritance' => isset($ticket['variations_event_inheritance']) && $ticket['variations_event_inheritance'] == 1,
                    'items' => array(),
                );
                foreach ($ticket['variations'] as $variation_id => $variation) {
                    if (!is_numeric($variation_id)) continue;
                    $formatted_ticket['variations']['items'][] = array(
                        'id' => (int) $variation_id,
                        'title' => isset($variation['title']) ? $variation['title'] : '',
                        'price' => isset($variation['price']) ? floatval($variation['price']) : 0,
                        'max' => isset($variation['max']) ? (int) $variation['max'] : 0,
                    );
                }
            }

            // Availability dates
            if (isset($ticket['availability_start']) || isset($ticket['availability_end'])) {
                $formatted_ticket['availability_dates'] = array(
                    'start' => isset($ticket['availability_start']) ? $ticket['availability_start'] : '',
                    'end' => isset($ticket['availability_end']) ? $ticket['availability_end'] : '',
                );
            }

            $formatted_tickets[] = $formatted_ticket;
        }

        return $formatted_tickets;
    }

    /**
     * Get the arguments for updating booking settings
     *
     * @return array Arguments array.
     */
    private function get_update_booking_args()
    {
        return array(
            'id' => array(
                'validate_callback' => function ($param, $request, $key) {
                    return is_numeric($param);
                },
                'required' => true,
                'description' => \__('Event ID', 'mec-utility'),
            ),
            'bookings_limit_unlimited' => array(
                'type'        => 'boolean',
                'description' => \__('Whether booking limit is unlimited', 'mec-utility'),
                'required'    => false,
            ),
            'bookings_limit' => array(
                'type'        => 'integer',
                'description' => \__('Total booking limit (ignored if unlimited is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'bookings_minimum_per_booking' => array(
                'type'        => 'integer',
                'description' => \__('Minimum tickets per booking', 'mec-utility'),
                'required'    => false,
                'minimum'     => 1,
            ),
            'bookings_all_occurrences' => array(
                'type'        => 'boolean',
                'description' => \__('Sell all occurrences by one booking', 'mec-utility'),
                'required'    => false,
            ),
            'bookings_all_occurrences_multiple' => array(
                'type'        => 'boolean',
                'description' => \__('Allow multiple bookings by same email on different dates', 'mec-utility'),
                'required'    => false,
            ),
            'show_booking_form_interval' => array(
                'type'        => 'integer',
                'description' => \__('Show booking form only X minutes before event starts (empty or null for no limit)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'stop_selling_after_first_occurrence' => array(
                'type'        => 'boolean',
                'description' => \__('Stop selling tickets after first occurrence', 'mec-utility'),
                'required'    => false,
            ),
            'auto_verify' => array(
                'type'        => 'string',
                'description' => \__('Email verification setting (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'auto_confirm' => array(
                'type'        => 'string',
                'description' => \__('Booking confirmation setting (global, 0, 1)', 'mec-utility'),
                'required'    => false,
                'enum'        => array('global', '0', '1'),
            ),
            'bookings_booking_button_label' => array(
                'type'        => 'string',
                'description' => \__('Custom label for booking button (e.g., "Book Now", "Register", etc.)', 'mec-utility'),
                'required'    => false,
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'bookings_user_limit_unlimited' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit user booking limit from global options', 'mec-utility'),
                'required'    => false,
            ),
            'bookings_user_limit' => array(
                'type'        => 'integer',
                'description' => \__('Maximum number of bookings per user (ignored if unlimited is true)', 'mec-utility'),
                'required'    => false,
                'minimum'     => 0,
            ),
            'tickets' => array(
                'type'        => 'object',
                'description' => \__('Event tickets configuration', 'mec-utility'),
                'required'    => false,
                'properties'  => array(
                    'additionalProperties' => array(
                        'type' => 'object',
                        'properties' => array(
                            'name' => array('type' => 'string'),
                            'description' => array('type' => 'string'),
                            'private_description' => array('type' => 'string'),
                            'price' => array('type' => 'number'),
                            'price_label' => array('type' => 'string'),
                            'limit' => array('type' => 'integer'),
                            'unlimited' => array('type' => 'boolean'),
                            'seats' => array('type' => 'integer'),
                            'minimum_ticket' => array('type' => 'integer'),
                            'maximum_ticket' => array('type' => 'integer'),
                            'stop_selling_value' => array('type' => 'integer'),
                            'stop_selling_type' => array('type' => 'string', 'enum' => array('day', 'hour')),
                        ),
                    ),
                ),
            ),
            'fees_global_inheritance' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit fees from global options', 'mec-utility'),
                'required'    => false,
            ),
            'fees' => array(
                'type'        => 'object',
                'description' => \__('Event fees/taxes configuration', 'mec-utility'),
                'required'    => false,
                'properties'  => array(
                    'additionalProperties' => array(
                        'type' => 'object',
                        'properties' => array(
                            'title' => array('type' => 'string', 'description' => 'Fee title'),
                            'amount' => array('type' => 'number', 'description' => 'Fee amount (percentage or fixed)'),
                            'type' => array(
                                'type' => 'string', 
                                'enum' => array('percent', 'amount', 'amount_per_date', 'amount_per_booking'),
                                'description' => 'Fee type',
                            ),
                        ),
                    ),
                ),
            ),
            'ticket_variations_global_inheritance' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit ticket variations from global options', 'mec-utility'),
                'required'    => false,
            ),
            'ticket_variations' => array(
                'type'        => 'object',
                'description' => \__('Event ticket variations/options configuration', 'mec-utility'),
                'required'    => false,
                'properties'  => array(
                    'additionalProperties' => array(
                        'type' => 'object',
                        'properties' => array(
                            'title' => array('type' => 'string', 'description' => 'Variation title (e.g., "With Lunch")'),
                            'price' => array('type' => 'number', 'description' => 'Additional price for this variation'),
                            'max' => array('type' => 'integer', 'description' => 'Maximum per ticket (null/empty for unlimited)'),
                        ),
                    ),
                ),
            ),
            'reg_fields_global_inheritance' => array(
                'type'        => 'boolean',
                'description' => \__('Inherit booking form fields from global options', 'mec-utility'),
                'required'    => false,
            ),
            'per_attendee_fields' => array(
                'type'        => 'object',
                'description' => \__('Per attendee fields configuration', 'mec-utility'),
                'required'    => false,
            ),
            'fixed_fields' => array(
                'type'        => 'object',
                'description' => \__('Fixed fields configuration', 'mec-utility'),
                'required'    => false,
            ),
        );
    }

    /**
     * Sanitize tickets data
     *
     * @param array $tickets Raw tickets data
     * @return array Sanitized tickets
     */
    private function sanitize_tickets($tickets)
    {
        if (!is_array($tickets)) {
            return array();
        }

        $sanitized_tickets = array();

        foreach ($tickets as $ticket_id => $ticket) {
            if (!is_array($ticket)) {
                continue;
            }

            $sanitized_ticket = array();

            // Basic fields
            if (isset($ticket['name'])) {
                $sanitized_ticket['name'] = \sanitize_text_field($ticket['name']);
            }

            if (isset($ticket['description'])) {
                $sanitized_ticket['description'] = \sanitize_textarea_field($ticket['description']);
            }

            if (isset($ticket['private_description'])) {
                $sanitized_ticket['private_description'] = \sanitize_textarea_field($ticket['private_description']);
            }

            // Price fields
            if (isset($ticket['price'])) {
                $sanitized_ticket['price'] = floatval($ticket['price']);
            }

            if (isset($ticket['price_label'])) {
                $sanitized_ticket['price_label'] = \sanitize_text_field($ticket['price_label']);
            }

            // Limit fields
            if (isset($ticket['limit'])) {
                $sanitized_ticket['limit'] = \absint($ticket['limit']);
            }

            if (isset($ticket['unlimited'])) {
                $sanitized_ticket['unlimited'] = $ticket['unlimited'] ? 1 : 0;
            }

            if (isset($ticket['seats'])) {
                $sanitized_ticket['seats'] = max(1, \absint($ticket['seats']));
            }

            // Min/Max ticket
            if (isset($ticket['minimum_ticket'])) {
                $sanitized_ticket['minimum_ticket'] = \absint($ticket['minimum_ticket']);
            }

            if (isset($ticket['maximum_ticket'])) {
                $sanitized_ticket['maximum_ticket'] = \absint($ticket['maximum_ticket']);
            }

            // Stop selling
            if (isset($ticket['stop_selling_value'])) {
                $sanitized_ticket['stop_selling_value'] = \absint($ticket['stop_selling_value']);
            }

            if (isset($ticket['stop_selling_type'])) {
                $stop_selling_type = $ticket['stop_selling_type'];
                $sanitized_ticket['stop_selling_type'] = in_array($stop_selling_type, array('day', 'hour')) ? $stop_selling_type : 'day';
            }

            // Ticket times
            if (isset($ticket['ticket_start_time_hour'])) {
                $sanitized_ticket['ticket_start_time_hour'] = \absint($ticket['ticket_start_time_hour']);
            }

            if (isset($ticket['ticket_start_time_minute'])) {
                $sanitized_ticket['ticket_start_time_minute'] = \absint($ticket['ticket_start_time_minute']);
            }

            if (isset($ticket['ticket_start_time_ampm'])) {
                $ampm = strtoupper($ticket['ticket_start_time_ampm']);
                $sanitized_ticket['ticket_start_time_ampm'] = in_array($ampm, array('AM', 'PM')) ? $ampm : 'AM';
            }

            if (isset($ticket['ticket_end_time_hour'])) {
                $sanitized_ticket['ticket_end_time_hour'] = \absint($ticket['ticket_end_time_hour']);
            }

            if (isset($ticket['ticket_end_time_minute'])) {
                $sanitized_ticket['ticket_end_time_minute'] = \absint($ticket['ticket_end_time_minute']);
            }

            if (isset($ticket['ticket_end_time_ampm'])) {
                $ampm = strtoupper($ticket['ticket_end_time_ampm']);
                $sanitized_ticket['ticket_end_time_ampm'] = in_array($ampm, array('AM', 'PM')) ? $ampm : 'PM';
            }

            // Price per date
            if (isset($ticket['dates']) && is_array($ticket['dates'])) {
                $sanitized_ticket['dates'] = $this->sanitize_ticket_dates($ticket['dates']);
            }

            // Variations per ticket
            if (isset($ticket['variations_event_inheritance'])) {
                $sanitized_ticket['variations_event_inheritance'] = $ticket['variations_event_inheritance'] ? 1 : 0;
            }

            if (isset($ticket['variations']) && is_array($ticket['variations'])) {
                $sanitized_ticket['variations'] = $this->sanitize_ticket_variations($ticket['variations']);
            }

            // Availability dates
            if (isset($ticket['availability_start'])) {
                $sanitized_ticket['availability_start'] = \sanitize_text_field($ticket['availability_start']);
            }

            if (isset($ticket['availability_end'])) {
                $sanitized_ticket['availability_end'] = \sanitize_text_field($ticket['availability_end']);
            }

            $sanitized_tickets[$ticket_id] = $sanitized_ticket;
        }

        return $sanitized_tickets;
    }

    /**
     * Sanitize ticket dates (price per date)
     *
     * @param array $dates Raw dates data
     * @return array Sanitized dates
     */
    private function sanitize_ticket_dates($dates)
    {
        if (!is_array($dates)) {
            return array();
        }

        $sanitized_dates = array();

        foreach ($dates as $date_id => $date) {
            if (!is_array($date)) {
                continue;
            }

            $sanitized_date = array();

            if (isset($date['start'])) {
                $sanitized_date['start'] = \sanitize_text_field($date['start']);
            }

            if (isset($date['end'])) {
                $sanitized_date['end'] = \sanitize_text_field($date['end']);
            }

            if (isset($date['price'])) {
                $sanitized_date['price'] = floatval($date['price']);
            }

            if (isset($date['label'])) {
                $sanitized_date['label'] = \sanitize_text_field($date['label']);
            }

            $sanitized_dates[$date_id] = $sanitized_date;
        }

        return $sanitized_dates;
    }

    /**
     * Sanitize ticket variations
     *
     * @param array $variations Raw variations data
     * @return array Sanitized variations
     */
    private function sanitize_ticket_variations($variations)
    {
        if (!is_array($variations)) {
            return array();
        }

        $sanitized_variations = array();

        foreach ($variations as $variation_id => $variation) {
            if (!is_array($variation)) {
                continue;
            }

            $sanitized_variation = array();

            if (isset($variation['title'])) {
                $sanitized_variation['title'] = \sanitize_text_field($variation['title']);
            }

            if (isset($variation['price'])) {
                $sanitized_variation['price'] = floatval($variation['price']);
            }

            if (isset($variation['max'])) {
                $sanitized_variation['max'] = \absint($variation['max']);
            }

            $sanitized_variations[$variation_id] = $sanitized_variation;
        }

        return $sanitized_variations;
    }

    /**
     * Sanitize fees data
     *
     * @param array $fees Raw fees data
     * @return array Sanitized fees
     */
    private function sanitize_fees($fees)
    {
        if (!is_array($fees)) {
            return array();
        }

        $sanitized_fees = array();

        foreach ($fees as $fee_id => $fee) {
            if (!is_array($fee)) {
                continue;
            }

            $sanitized_fee = array();

            if (isset($fee['title'])) {
                $sanitized_fee['title'] = \sanitize_text_field($fee['title']);
            }

            if (isset($fee['amount'])) {
                $sanitized_fee['amount'] = floatval($fee['amount']);
            }

            if (isset($fee['type'])) {
                $fee_type = $fee['type'];
                $valid_types = array('percent', 'amount', 'amount_per_date', 'amount_per_booking');
                $sanitized_fee['type'] = in_array($fee_type, $valid_types) ? $fee_type : 'amount_per_booking';
            }

            $sanitized_fees[$fee_id] = $sanitized_fee;
        }

        return $sanitized_fees;
    }

    /**
     * Sanitize form fields (per attendee or fixed fields)
     *
     * @param array $fields Raw fields data
     * @return array Sanitized fields
     */
    private function sanitize_form_fields($fields)
    {
        if (!is_array($fields)) {
            return array();
        }

        $sanitized_fields = array();

        foreach ($fields as $field_id => $field) {
            if (!is_array($field)) {
                continue;
            }

            $sanitized_field = array();

            // Type
            if (isset($field['type'])) {
                $valid_types = array('name', 'mec_email', 'text', 'email', 'date', 'tel', 'file', 'textarea', 'checkbox', 'radio', 'select', 'agreement', 'p');
                $sanitized_field['type'] = in_array($field['type'], $valid_types) ? $field['type'] : 'text';
            }

            // Label
            if (isset($field['label'])) {
                $sanitized_field['label'] = \sanitize_text_field($field['label']);
            }

            // Mandatory
            if (isset($field['mandatory'])) {
                $sanitized_field['mandatory'] = $field['mandatory'] ? '1' : '0';
            }

            // Options for select, checkbox, radio
            if (isset($field['options']) && is_array($field['options'])) {
                $sanitized_field['options'] = array();
                foreach ($field['options'] as $option_id => $option) {
                    if (is_array($option) && isset($option['label'])) {
                        $sanitized_field['options'][$option_id] = array(
                            'label' => \sanitize_text_field($option['label']),
                        );
                    }
                }
            }

            $sanitized_fields[$field_id] = $sanitized_field;
        }

        return $sanitized_fields;
    }
}

