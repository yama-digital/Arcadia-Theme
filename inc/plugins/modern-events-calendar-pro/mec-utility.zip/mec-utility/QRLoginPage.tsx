import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { usePlatformStyles } from '../hooks'
import mecAuthService from '../services/MECAuthService'
import {
	CapacitorBarcodeScanner,
	CapacitorBarcodeScannerTypeHint
} from '@capacitor/barcode-scanner'
import qrlogin from '../assets/icons/qrlogin.png'
import justLogo from '../assets/icons/just-logo.svg'

interface QRLoginPageProps { }

function extractUrlsFromText(text: string): string[] {
	const urlRegex = /(https?:\/\/[^\s"'<>),]+|www\.[^\s"'<>),]+)/gi
	const matches = text.match(urlRegex) || []
	// Normalize urls starting with www.
	return Array.from(
		new Set(matches.map((u) => (u.startsWith('www.') ? `https://${u}` : u)))
	)
}

function extractLinksFromQrContent(content: string): string[] {
	// If JSON, try to find urls inside
	try {
		const parsed = JSON.parse(content)
		const links: string[] = []
		const visit = (val: any) => {
			if (!val) return
			if (typeof val === 'string') {
				links.push(...extractUrlsFromText(val))
			} else if (Array.isArray(val)) {
				val.forEach(visit)
			} else if (typeof val === 'object') {
				Object.values(val).forEach(visit)
			}
		}
		visit(parsed)
		if (links.length) return Array.from(new Set(links))
	} catch {
		// not JSON
	}
	// Fallback: extract from plain text
	return extractUrlsFromText(content)
}

const QRLoginPage: React.FC<QRLoginPageProps> = () => {
	const navigate = useNavigate()
	const { getTopPadding } = usePlatformStyles()
	const [isScanning, setIsScanning] = useState(false)
	const [showErrorModal, setShowErrorModal] = useState(false)
	const [showSuccessModal, setShowSuccessModal] = useState(false)
	const [errorMessage, setErrorMessage] = useState('')
	const [authService] = useState(mecAuthService)

	// Cleanup when component unmounts
	useEffect(() => {
		return () => {
			// Cleanup any ongoing operations
		}
	}, [])



	const detectPlatform = (): string => {
		const ua = navigator.userAgent || navigator.vendor || (window as any).opera || ''
		if (/android/i.test(ua)) return 'Android'
		if (/iPad|iPhone|iPod/.test(ua)) return 'iOS'
		if (/Windows/.test(ua)) return 'Windows'
		if (/Macintosh|Mac OS X/.test(ua)) return 'macOS'
		if (/Linux/.test(ua)) return 'Linux'
		return 'Web'
	}

	const handleStartScan = async () => {
		setIsScanning(true)
		setErrorMessage('')

		try {
			// Start real-time scanning
			const result = await CapacitorBarcodeScanner.scanBarcode({
				hint: CapacitorBarcodeScannerTypeHint.QR_CODE
			})

			if (!result.ScanResult) {
				throw new Error('No QR code detected')
			}

			const decoded = result.ScanResult
			if (!decoded) throw new Error('No QR code detected')


			// Try to parse QR as JSON payload (preferred)
			try {
				const parsed = JSON.parse(decoded)

				if (parsed?.website_url && parsed?.qr_token) {
					await handleQRScan(parsed)
					return
				} else {
					setErrorMessage(
						'Invalid QR code format. QR code must contain website_url and qr_token.'
					)
					setShowErrorModal(true)
					return
				}
			} catch (parseError) {
				// If not JSON, show error
				setErrorMessage(
					'Invalid or unsupported QR code. Please scan MEC QR code from your website.'
				)
				setShowErrorModal(true)
			}
		} catch (error: any) {
			setErrorMessage(error.message || 'Failed to scan QR code')
			setShowErrorModal(true)
		} finally {
			setIsScanning(false)
		}
	}

	const handleQRScan = async (qrData: any) => {
		try {

			// Validate QR data structure
			if (!qrData.qr_token || !qrData.website_url) {
				throw new Error(
					'Invalid QR code format. Please ensure you are scanning a valid MEC QR code.'
				)
			}


			// Set base URL from QR data
			authService.setBaseURL(qrData.website_url)

			// Prepare device info
			const deviceInfo = {
				device_name: navigator.userAgent,
				os_version: detectPlatform(),
				app_version: '1.0.0',
				platform: detectPlatform().toLowerCase(),
				timestamp: new Date().toISOString()
			}

			// Step 1: Validate QR Token

			const validationResult = await authService.makePublicRequest('/auth/validate-qr-token', {
				method: 'POST',
				data: {
					qr_token: qrData.qr_token
				}
			})


			if (!validationResult.success) {
				throw new Error(validationResult.error || 'QR token validation failed')
			}


			// Step 2: Exchange QR Token for API Key

			const exchangeResult = await authService.makePublicRequest('/auth/exchange-qr-for-session', {
				method: 'POST',
				data: {
					qr_token: qrData.qr_token,
					device_info: deviceInfo
				}
			})


			if (!exchangeResult.success) {
				throw new Error(exchangeResult.error || 'QR token exchange failed')
			}


			// Store the API key and session data
			const apiKey = exchangeResult.data.data.api_key
			const sessionData = exchangeResult.data.session


			// Set the API key in auth service
			authService.apiKey = apiKey
			authService.sessionData = sessionData

			// Store credentials in localStorage
			localStorage.setItem('mec_api_key', apiKey)
			localStorage.setItem('mec_website_url', qrData.website_url)
			localStorage.setItem('mec_session_data', JSON.stringify(sessionData))



			// Proactively verify session with server to ensure App bootstrap will consider it valid
			try {
				const verify = await authService.refreshSession()
			} catch (e) {
			}

			setShowSuccessModal(true)
		} catch (error: any) {
			setErrorMessage(error.message || 'Authentication failed')
			setShowErrorModal(true)
		}
	}

	const handleTryAgain = () => {
		setShowErrorModal(false)
		setErrorMessage('')
	}

	const handleGetStarted = () => {
		setShowSuccessModal(false)
		// Robust navigation (like LoginPage): router navigate + hard reload fallback
		navigate('/calendar', { replace: true })
		setTimeout(() => {
			if (window.location.pathname !== '/calendar') {
				window.location.href = '/calendar'
			}
		}, 100)
	}

	const handleGoBack = () => {
		navigate('/')
	}

	return (
		<div className={`min-h-screen bg-gray-50 flex justify-center`}>
			{/* Container with max width for tablet/desktop */}
			<div className='max-w-[100%] mx-auto w-full min-h-screen bg-white shadow-lg flex flex-col'>
				{/* Main Content */}
				<div className='flex-1 flex flex-col p-6'>
					{/* Header */}
					<button
						onClick={handleGoBack}
						className='w-[40px] h-[40px] p-2 rounded-full hover:bg-gray-100 transition-colors'>
						<svg
							className='w-6 h-6 text-gray-600'
							fill='none'
							stroke='currentColor'
							viewBox='0 0 24 24'>
							<path
								strokeLinecap='round'
								strokeLinejoin='round'
								strokeWidth={2}
								d='M15 19l-7-7 7-7'
							/>
						</svg>
					</button>
					<div className='flex items-center justify-between mt-[15px] mb-[99px]'>
						<div className='flex flex-col'>
							{/* Logo */}
							<div className='h-[53px] relative'>
								<div className='text-left text-2xl font-bold text-black flex gap-2'>
									<img src={justLogo} alt='Mec Logo' className='h-14' />
								</div>
							</div>
						</div>
						<div className='w-10'></div> {/* Spacer for centering */}
					</div>

					{/* Welcome Section */}
					<div className='mb-[30px]'>
						<h2 className='text-[24px] font-extrabold text-black mb-[5px] flex items-center'>
							Welcome Back!
							<span className='text-2xl'>👋</span>
						</h2>
						<p className='text-[16px] text-gray-600 '>
							Sign in to your account
						</p>
					</div>

					{/* QR Scanner Area */}
					<div className='flex-1 flex flex-col items-center justify-between'>
						<div className='relative w-70 h-70 mb-8'>
							{/* Scanner Frame */}
							<div
								className={`w-[250px] h-[250px] mx-[auto] rounded-3xl border-4 relative overflow-hidden transition-all duration-300 ${isScanning
										? 'border-cyan-400 bg-cyan-50'
										: 'border-gray-300 bg-gray-50'
									}`}>
								{/* Corner Brackets */}
								<div className='absolute top-4 left-4 w-8 h-8 border-t-4 border-l-4 border-cyan-400 rounded-tl-lg'></div>
								<div className='absolute top-4 right-4 w-8 h-8 border-t-4 border-r-4 border-cyan-400 rounded-tr-lg'></div>
								<div className='absolute bottom-4 left-4 w-8 h-8 border-b-4 border-l-4 border-cyan-400 rounded-bl-lg'></div>
								<div className='absolute bottom-4 right-4 w-8 h-8 border-b-4 border-r-4 border-cyan-400 rounded-br-lg'></div>

								{/* Scanner Content */}
								<div className='absolute inset-0 flex items-center justify-center'>
									{!isScanning ? (
										<div className='text-center'>
											<div className='w-24 h-24 mx-auto mb-4 opacity-40'>
												<svg
													fill='none'
													stroke='currentColor'
													viewBox='0 0 24 24'
													className='w-full h-full text-gray-400'>
													<path
														strokeLinecap='round'
														strokeLinejoin='round'
														strokeWidth={1.5}
														d='M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z'
													/>
												</svg>
											</div>
											<p className='text-gray-500 text-sm'>
												Position QR code within frame
											</p>
										</div>
									) : (
										<div className='text-center'>
											{/* Scanning Animation */}
											<div className='relative w-24 h-24 mx-auto mb-4'>
												<div className='absolute inset-0 border-4 border-cyan-400 rounded-lg animate-pulse'></div>
												<div className='absolute inset-2 bg-cyan-400 rounded opacity-20 animate-ping'></div>
												<svg
													className='w-full h-full text-cyan-600'
													fill='none'
													stroke='currentColor'
													viewBox='0 0 24 24'>
													<path
														strokeLinecap='round'
														strokeLinejoin='round'
														strokeWidth={2}
														d='M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z'
													/>
												</svg>
											</div>
											<p className='text-cyan-600 text-sm font-medium'>
												Scanning QR code...
											</p>
										</div>
									)}
								</div>

								{/* Scanning Line Animation */}
								{isScanning && (
									<div className='absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse'></div>
								)}
							</div>
						</div>

						{/* Scan Button */}
						<button
							onClick={handleStartScan}
							disabled={isScanning}
							className={`mobile-button w-full text-[16px] leading-[24px] bg-[#00d2f7] hover:bg-[#00c0e3] text-white font-semibold p-[16px] rounded-[12px] shadow-sm transition-colors ${isScanning
									? 'bg-gray-400 text-white cursor-not-allowed'
									: 'bg-[#00d2f7] hover:bg-[#00c0e3] text-white'
								}`}>
							{isScanning ? (
								<div className='flex items-center justify-center gap-3'>
									<div className='w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin'></div>
									Scanning...
								</div>
							) : (
								<div className='flex items-center justify-center gap-3'>
									<svg
										className='w-5 h-5'
										fill='none'
										stroke='currentColor'
										viewBox='0 0 24 24'>
										<path
											strokeLinecap='round'
											strokeLinejoin='round'
											strokeWidth={2}
											d='M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z'
										/>
									</svg>
									Start Scanning
								</div>
							)}
						</button>

						{/* Help Text */}
						<div className='text-center'>
							<p className='text-center text-[12px] leading-[15px] mt-[37px] max-w-[305px] mx-[auto] text-gray-500'>
								Scan the QR code from your MEC website admin panel
								<a
									href='https://webnus.net/dox/modern-events-calendar/mec-utility/'
									target='_blank'
									rel='noopener noreferrer'
									className='text-center text-[12px] leading-[15px] text-cyan-400 mt-[10px] hover:underline cursor-pointer block'>
									Need help finding QR code?
								</a>
							</p>
						</div>


					</div>
				</div>
			</div>

			{/* Error Modal - use the same bottom-sheet design as success */}
			{showErrorModal && (
				<div className='fixed inset-0 z-50 flex items-center justify-center p-4'>
					<div
						className='absolute inset-0 bg-black/40 backdrop-blur-sm'
						style={{ backgroundColor: 'rgba(6, 18, 55, 0.5)' }}
					/>
					<div className='relative w-full max-w-md mx-auto flex flex-col justify-end h-full'>
						<div className='p-8 text-center flex flex-col content-center items-center rounded-3xl'>
							{/* QR frame with image */}
							<div className='relative w-[240px] h-[240px] flex items-center justify-center'>
								<div className='absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-white/75 rounded-tl-xl'></div>
								<div className='absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-white/75 rounded-tr-xl'></div>
								<div className='absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-white/75 rounded-bl-xl'></div>
								<div className='absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-white/75 rounded-br-xl'></div>

								<div className='mx-auto w-[206px] h-[206px] rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shadow-inner'>
									<img
										className='mx-auto w-[176px] h-[176px]'
										src={qrlogin}
									/>
								</div>
							</div>
						</div>
						<div className='mt-4 bg-white pt-[16px] pb-[28px] pl-[28px] pr-[28px] rounded-3xl max-w-sm w-full mx-auto text-center relative z-10'>
							<div className='flex items-center justify-center'>
								<svg
									width='40'
									height='6'
									viewBox='0 0 40 6'
									fill='none'
									xmlns='http://www.w3.org/2000/svg'>
									<rect width='40' height='6' rx='3' fill='#E8EAED' />
								</svg>
							</div>
							<div className='w-[87px] h-[87px] bg-red-100 rounded-full flex items-center justify-center mx-auto mb-[19px] mt-[18px]'>
								<div className='w-[50px] h-[50px] bg-red-500 rounded-full flex items-center justify-center'>
									<span className='text-white text-[30px] font-bold'>
										!
									</span>
								</div>
							</div>
							<h3 className='text-[15px] font-bold text-red-500 mb-2'>
								Something went wrong!
							</h3>
							<p className='text-[13px] text-[#111827] mb-4'>
								{errorMessage ||
									'Something went wrong. Please try again.'}
							</p>
							<button
								onClick={handleTryAgain}
								className='mobile-button w-full bg-[#00DCFF] hover:bg-[#ff5757] text-white font-semibold py-4 rounded-[12px] text-lg transition-colors'>
								Try again
							</button>
						</div>
					</div>
				</div>
			)}

			{/* Success Modal - Glassmorphism */}
			{showSuccessModal && (
				<div className='fixed inset-0 z-50 flex items-center justify-center p-4'>
					<div
						className='absolute inset-0 bg-black/40 backdrop-blur-sm'
						style={{ backgroundColor: 'rgba(6, 18, 55, 0.5)' }}
					/>
					<div className='relative w-full max-w-md mx-auto flex flex-col justify-end h-full'>
						<div className='p-8 text-center flex flex-col content-center items-center rounded-3xl'>
							{/* QR placeholder */}
							<div className='relative w-[240px] h-[240px] flex items-center justify-center'>
								<div className='absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-[##FFFFFFBF] rounded-tl-xl'></div>
								<div className='absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-[##FFFFFFBF] rounded-tr-xl'></div>
								<div className='absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-[##FFFFFFBF] rounded-bl-xl'></div>
								<div className='absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-[##FFFFFFBF] rounded-br-xl'></div>

								<div className='mx-auto w-[206px] h-[206px] rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shadow-inner'>
									<img
										className='mx-auto w-[176px] h-[176px]'
										src={qrlogin}
									/>
								</div>
							</div>
						</div>
						<div className='mt-4 bg-white pt-[16px] pb-[28px] pl-[28px] pr-[28px] rounded-3xl max-w-sm w-full mx-auto text-center relative z-10'>
							<div className='flex items-center justify-center'>
								<svg
									width='40'
									height='6'
									viewBox='0 0 40 6'
									fill='none'
									xmlns='http://www.w3.org/2000/svg'>
									<rect width='40' height='6' rx='3' fill='#E8EAED' />
								</svg>
							</div>
							<div className='w-[87px] h-[87px] bg-green-100 rounded-full flex items-center justify-center mx-auto mb-[19px] mt-[18px]'>
								<svg
									className='w-[50px] h-[50px] text-[#29CC39]'
									viewBox='0 0 24 24'
									fill='none'>
									<path
										d='M20 6L9 17L4 12'
										stroke='currentColor'
										strokeWidth='2'
										strokeLinecap='round'
										strokeLinejoin='round'
									/>
								</svg>
							</div>
							<h3 className='text-[15px] font-bold text-green-500 mb-4'>
								App is connected
							</h3>
							<button
								onClick={handleGetStarted}
								className='mobile-button w-full bg-[#1BE367] hover:bg-[#00c0e3] text-white font-semibold py-4 rounded-[12px] text-lg transition-colors'>
								Let's get started
							</button>
						</div>
					</div>
				</div>
			)}
		</div>
	)
}

export default QRLoginPage
