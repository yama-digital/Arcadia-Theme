===  ===


== Changelog ==
= 2.2.0 - 14 April 2025 =
- Improved: Order details in order edit page.
- Fixed: Tax calculation issue when "Tax Method" is set to "Tax Included".
- Fixed: Booking not recorded on some sites when using WooCommerce integration.
- Fixed: Maximum discount not applied correctly.
- Fixed: Language switch issue during cart redirection in multilingual sites.
- Fixed: Booking and MEC Tickets metabox not showing.
- Fixed: Booking not saved and quantity editable in new WooCommerce cart block.

= 2.1.3 - 23 June 2024 =
- Fixed: Sync orders with confirmation and verification status

= 2.1.2 - 1 October 2023 =
- Changed: Somethings in settings values and labels

= 2.1.1 - 13 August 2023 =
- Fixed: Booking sync status
- Fixed: Product title on the card

= 2.1.0 - 30 April 2023 =
- Fixed: Count attendee
- Fixed: Price per occurence in wocommerce cart
- Fixed: Translate issues
- Fixed: Partial payment
- Fixed: Some minor issues

= 2.0.0 - 4 March 2023 =
- Improved: Compatibility with MEC
- Fixed: Some minor issues

= 1.6.5 - 31 December 2022 =
- Fixed: Display attached files
- Fixed: Issue in Events Confirmation email translation

= 1.6.0 - 19 October 2022 =
- Fixed: Issue adding the same tickets to cart twice
- Fixed: Some minor issues

= 1.5.6 - 25 July 2022 =
- Fixed: Calculate tax in Invoice
- Fixed: Calculate price after using discount code
- Fixed: Some minor issues

= 1.5.5 - 29 June 2022 =
- Fixed: Activation section in backend

= 1.5.4 - 12 June 2022 =
- Fixed: Variations per ticket
- Fixed: Total attedees

= 1.5.3 - 29 May 2022 =
- Fixed: Error in booking

= 1.5.2 - 23 May 2022 =
- Fixed: Product Category
- Fixed: Total user booking limit

= 1.5.1 - 7 May 2022 =
- Improved: ticket product added for translation in wpml
- Fixed: redirect to index after add to cart
- Fixed: add incomplete products to cart
- Fixed: removed add to cart notices
- Fixed: Some minor issues

= 1.5.0 - 2 February 2022 =
- Added: Show the ticket time on the cart page
- Added: An option to set the action after adding to the cart

= 1.4.7 - 28 November 2021 =
- Improved: Booking process in the addon
- Fixed: some issue with user limitation
- Fixed: Some minor issues

= 1.4.6 - 31 October 2021 =
- compatibility: Modern Events Calendar v6.1.0
- Fixed: Auto-update message
- Fixed: Notification placeholders
- Fixed: Some minor issues

= 1.4.5 - 9 September 2021 =
- compatibility: WooCommerce v5.6
- Added: New option to show WooCommerce categories for ticket to use woo-copun when ticket is into the cart
- Fixed: Email placeholder

= 1.4.3 - 12 August 2021 =
- compatibility: WooCommerce v5.5.2
- compatibility: Modern Events Calendar v5.22.0
- compatibility: MEC Invoice Add-On v1.2.7
- Fixed: Duplicated email
- Fixed: An issue regarding the total user booking limit
- Fixed: Some issues with third-party plugins
- Fixed: Guest user payment
- Fixed: Ticket number on adding to the cart
- Fixed: Some minor issues

= 1.4.2 - 18 March 2021 =
- Compatibility: With Modern Events Calendar Version 5.17.6
- Improved: Disabled edit quantity ticket if it is 1
- Fixed: Fixed notice error and change product name
- Fixed: Fix call API
- Fixed: Some minor issues

= 1.4.1 - 16 January 2021 =
- Fixed: An issue regarding the total booking
- Fixed: Ticket variation character encoding
- Fixed: File field in booking form influencing the cart
- Fixed: Quantity of the tickets

= 1.4.0 - 12 December 2020 =
- Added: Option to remove WooCommerce taxes from WooCoommerce cart page
- Compatibility: WooCommerce v4.8.0
- Fixed: Confirmation email sent twice
- Fixed: Email information from booking form
- Fixed: Some minor issues

= 1.3.5 - 14 November 2020 =
- Refactored: New structure of the codes
- Fixed: Total attendees
- Fixed: Confirmation before connecting to payment gateways(sandbox)
- Fixed: Confirmation email
- Fixed: Discount Per User Roles
- Fixed: Some minor issues

= 1.3.0 - 13 September 2020 =
- Fixed: Wrong price when added two or more bookings
- Fixed: Date format
- Fixed: Ticket name

= 1.2.9 - 26 August 2020 =
- Fixed: Event title and ticket name on order details

= 1.2.8 - 24 August 2020 =
- Fixed: Order Status and emails
- Fixed: Available tickets

= 1.2.7 - 22 August 2020 =
- compatibility: WooCommerce v4.4.0

= 1.2.6 - 20 July 2020 =
- Removed: Debug codes

= 1.2.5 - 16 July 2020 =
- Refactored: Sync option (MEC Status and WooCommerce order status)
- compatibility: WooCommerce 
- Added: WooCommerce taxes on MEC booking items
- Fixed: Booking items regarding removing MEC taxes/fees
- Fixed: Translation issues
- Fixed: Tickets counting issue
- Fixed: Quantity for tickets
- Fixed: Some PHP notices
- Fixed: Some minor issues

= 1.2.1 - 11 June 2020 =
- compatibility: With Modern Events Calendar Version 5.6.0

= 1.2.0 - 14 May 2020 =
- Fixed: Formula for booking price calculation
- Fixed: Sync option and the order status
- Fixed: Email warning
- Fixed: Remove fee from cart (Amount Per Booking)
- Fixed: Date format
- Fixed: Some minor issues

= 1.1.8 - 7 April 2020 =
- Fixed: Payment Status
- Fixed: Fix Email Details

= 1.1.7 - 16 February 2020 =
- Fixed: License notice
- Fixed: PHP warnings in WooCommerce email
- Fixed: Some minor issues

= 1.1.6 - 16 February 2020 =
- Added: An option to manage sync booking status with WooCommerce
- Fixed: Per booking taxes in cart
- Fixed: Duplicated bookings

= 1.1.5 - 31 January 2020 =
- Added: "Adding tax to tickets added to cart" option
- Fixed: Quantity for tickets
- Fixed: Confirmation and verification emails
- Fixed: Attendees information in WooCommerce email
- Fixed: Activation
- Fixed: Some minor issues

= 1.1.2 - 2 November 2019 =
- Compatibility with WordPress 5.2.4
- Added: Cart view link
- Improved: Coupons
- Fixed: WooCommerce Order in Excel
- Fixed: Translation of "add to cart" notification

= 1.1.1 - 21 October 2019 =
- Fixed: Addon deletes the products when acitve
- Fixed: Fee with percent calculate on cart
- Fixed: waiting for add to cart
- Fixed: Seciurty nonce

= 1.1.0 - 26 September 2019 =
- Compatibility: WooCommerce 3.7.0
- Added: Name of buyer of the ticket
- Added: Order label on Woo Order
- Added: Access to booking menu (MEC Booking Menu) from Woo Order
- Added: The billing information after the checkout process
- Added: Apply MEC coupon in WooCommerce Cart
- Added: "Successfully Add to Cart" Message
- Integrated: WooCommerce Order and Bookings in MEC
- improved: UX for adding to cart
- Fixed: Fee pricing calculations in cart
- Fixed: Redirecting to cart
- Fixed: Ticket variations
- Fixed: Date on ticket item (ticket date not order date)
- Fixed: When removing one ticket (on before, delete all tickets when you delete one ticket)
- fixed: Quantity on all tickets
- fixed: Send email to admin and end users
- Fixed: Billing information in WooCommerce Order records and MEC Bookings Records
- Fixed: Some minor issues

= 1.0.6 =
- Fixed: Payments selection
- Fixed: Some minor issues

= 1.0.0 =
- Initial Release