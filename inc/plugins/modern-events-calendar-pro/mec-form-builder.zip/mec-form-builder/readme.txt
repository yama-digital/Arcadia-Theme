===  ===


== Changelog ==
= 1.6.0 - 16 December 2025 =
- Fixed: Spacing issue between fields when using Third-Width or Half-Width layouts.
- Fixed: Inconsistent styling Name and Email fields in the frontend.
- Fixed: Elementor Form Builder template selection not saving correctly in FES Form settings.

= 1.5.5 - 28 September 2025 =
- Fixed: Settings not saving consistently in global and single event forms.
- Fixed: Checkbox and radio button styling issue.

= 1.5.0 - 28 April 2025 =
- Improved: Added spacing between columns when fields are set to half or third width
- Fixed: Field width changes only applied in Elementor editor, not on frontend
- Fixed: Some minor issues and improvements

= 1.4.0 - 24 December 2024 =
- Fixed: Visibility of booking form fields in Elementor editor
- Fixed: Some minor issues

= 1.3.8 - 24 June 2024 =
- Fixed: Form widget
- Fixed: Some minor issues

= 1.3.7 - 9 January 2024 =
- Fixed: Fatal error

= 1.3.6 - 1 August 2023 =
- Fixed: Date is not valid
- Fixed: Some minor issues

= 1.3.5 - 17 May 2023 =
- Compatibility: MEC version 6.9.5

= 1.3.1 - 17 April 2023 =
- Fixed: Fixed form styling

= 1.3.0 - 31 October 2022 =
- Fixed: Required option for select field
- Fixed: Field title in excel file

= 1.2.2 - 24 May 2022 =
- Fixed: Select form in edit event page

= 1.2.1 - 7 May 2022 =
- Fixed: Some minor issues

= 1.2.0 - 4 December 2021 =
- Added: An option to show/hide fixed fields
- Improved: Displaing the form in Elementor enviornment

= 1.1.6 - 12 May 2021 =
- Compatibility: With Elementor Version 3.2.0
- Fixed: Paragraph issue in the form
- Fixed: Style for modal view in the single event page
- Fixed: Third and Half-width for fields
- Fixed: Third and Half-width for the form
- Fixed: Some minor issues

= 1.1.5 - 18 March 2021 =
- Compatibility: With Modern Events Calendar Version 5.17.6
- Added: Map fields to MEC form
- Fixed: An issue regarding the datepicker

= 1.1.0 - 14 October 2020 =
- Added: Third-Width styling options
- Fixed: Attendees form title
- Fixed: Some minor issue

= 1.0.8 - 17 May 2020 =
- Fixed: Style Generation Progress

= 1.0.7 - 11 April 2020 =
- Fixed: Agreement URL
- Fixed: Paragraph length issue
- Fixed: Customize Form Builder Columns

= 1.0.6 - 7 February 2020 =
- Fixed: License error

= 1.0.5 - 2 February 2020 =
- Added: Paragraph typography
- Added: Checkbox and radio button typography
- Added: Agreement styles
- Improved: All fields styling
- Fixed: Half-width option for each item
- Fixed: Extra empty space
- Fixed: Set form in settings and single event back-end page

= 1.0.3 - 30 November 2019 =
- Fixed: Checkbox in Agreement field
- Fixed: Checkbox field
- Fixed: Radio button field
- Fixed: Next button moving
- Fixed: Showing form builder on single event backend page
- Fixed: Mandatory fields label 
- Fixed: Form Builder show on settings
- Fixed: Some minor issue

= 1.0.2 - 6 August 2019 =
- Added: Language files
- Added: Optimize speed

= 1.0.1 - 5 August 2019 =
- Fixed: Form id problem when update event or settings

= 1.0.0 - 16 Jul 2019 =
- Initial Release