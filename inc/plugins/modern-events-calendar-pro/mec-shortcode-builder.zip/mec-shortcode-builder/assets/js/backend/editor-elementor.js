(function ($) {
    'use strict';
    $(document).ready(function () {

        elementor.hooks.addAction('panel/open_editor/widget/MEC-SHORTCODE-BUILDER', function (panel, model, view) {

            let $element_style = panel.$el.find('[data-setting="full_calendar_style"]');

            $element_style.off('change').on("change", function (e) {

                let $element_default_view = panel.$el.find('[data-setting="full_calendar_default_view"]');

                if ($(this).val() === "liquid") {
                    // let $option = panel.$el.find( 'option[value="monthly"]' );
                    $element_default_view.html(
                        '<option value="list">List View</option>' +
                        '<option value="grid">Grid View</option>' +
                        '<option value="tile">Tile View</option>' +
                        '<option value="yearly">Yearly View</option>' +
                        '<option value="weekly">Weekly View</option>' +
                        '<option value="daily">Daily View</option>'
                    );
                } else {
                    $element_default_view.html(
                        '<option value="list">List View</option>' +
                        '<option value="grid">Grid View</option>' +
                        '<option value="tile">Tile View</option>' +
                        '<option value="yearly">Yearly View</option>' +
                        '<option value="monthly">Monthly/Calendar View</option>' +
                        '<option value="weekly">Weekly View</option>' +
                        '<option value="daily">Daily View</option>'
                    );
                }
            });

        });
    });
})(jQuery);

