<?php

namespace MEC_Single_Builder\Inc\Frontend;

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @link       https://webnus.net
 * @since      1.0.0
 *
 * @author    Webnus
 */
class Frontend
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * The text domain of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_text_domain    The text domain of this plugin.
	 */
	private $plugin_text_domain;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since       1.0.0
	 * @param       string $plugin_name        The name of this plugin.
	 * @param       string $version            The version of this plugin.
	 * @param       string $plugin_text_domain The text domain of this plugin.
	 */
	public function __construct($plugin_name, $version, $plugin_text_domain)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->plugin_text_domain = $plugin_text_domain;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/mec-single-builder-frontend.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/mec-single-builder-frontend.js', array('jquery'), $this->version, false);
	}

	/**
	 * Enqueue map scripts for Google Map widget
	 *
	 * @since    1.0.0
	 */
	public function enqueue_map_scripts()
	{

		// Check if MEC is active
		if (! class_exists('\MEC\Base')) {
			return;
		}

		// Check if we're on a single event page
		if (! is_single()) {
			return;
		}

		$mainClass = new \MEC_main();
		$PT = $mainClass->get_main_post_type();

		// Check if current post type is MEC event
		if (get_post_type() != $PT) {
			return;
		}

		// Check if the page uses builder template
		$event_id = get_the_ID();
		if (! $event_id) {
			return;
		}

		$single_template_style = \MEC_Single_Builder\Inc\Core\Init::get_single_event_template_settings($event_id);
		if ('builder' !== $single_template_style) {
			return;
		}

		$main = \MEC\Base::get_main();
		if (! $main) {
			return;
		}

		// Get MEC settings for map configuration
		$settings = get_option('mec_options');
		$mec_settings = isset($settings['settings']) ? $settings['settings'] : array();

		// Prepare define_settings for load_map_assets to allow filters to work properly
		$define_settings = array(
			'map' => isset($mec_settings['default_maps_view']) ? $mec_settings['default_maps_view'] : 'google',
			'google_maps_zoomlevel' => isset($mec_settings['google_maps_zoomlevel']) ? $mec_settings['google_maps_zoomlevel'] : 14,
			'default_maps_scrollwheel' => isset($mec_settings['default_maps_scrollwheel']) ? $mec_settings['default_maps_scrollwheel'] : 0,
		);

		$map_type = isset($define_settings['map']) ? $define_settings['map'] : 'google';

		// Load map assets with settings to allow mec-advanced-map filter to work
		$main->load_map_assets(false, $define_settings);

		// Check if mec-advanced-map exists and load OpenStreetMap scripts directly if needed
		if ('openstreetmap' === $map_type) {
			// Check if mec-advanced-map plugin directory exists (even if not active)
			$mec_map_plugin_path = \WP_PLUGIN_DIR . '/mec-advanced-map';
			$mec_map_plugin_file = $mec_map_plugin_path . '/mec-advanced-map.php';

			if (file_exists($mec_map_plugin_file)) {
				// Define MECMAPASSETS if not already defined
				if (! defined('MECMAPASSETS')) {
					$mec_map_plugin_url = \plugin_dir_url($mec_map_plugin_file);
					define('MECMAPASSETS', $mec_map_plugin_url . 'assets/');
				}

				// Load OpenStreetMap scripts if MECMAPASSETS is defined
				if (defined('MECMAPASSETS')) {
					// Verify files exist before enqueuing
					$leaflet_js_path = $mec_map_plugin_path . '/assets/vendore/leaflet/leaflet.js';
					$openstreetmap_js_path = $mec_map_plugin_path . '/assets/js/openstreetmap.js';

					if (file_exists($leaflet_js_path) && file_exists($openstreetmap_js_path)) {
						// Load Leaflet CSS
						wp_enqueue_style('mec-leaflet-css', MECMAPASSETS . 'vendore/leaflet/leaflet.css', array(), '1.0.0');
						wp_enqueue_style('mec-leaflet-marker-cluster-css', MECMAPASSETS . 'vendore/leaflet-marker-cluster/MarkerCluster.css', array(), '1.0.0');
						wp_enqueue_style('mec-leaflet-marker-cluster-default-css', MECMAPASSETS . 'vendore/leaflet-marker-cluster/MarkerCluster.Default.css', array(), '1.0.0');
						wp_enqueue_style('mec-leaflet-fullscreen-css', MECMAPASSETS . 'vendore/leaflet-fullscreen/leaflet.fullscreen.css', array(), '1.0.0');
						wp_enqueue_style('mec-openstreetmap-css', MECMAPASSETS . 'css/openstreetmap.css', array(), '1.0.0');

						// Load Leaflet JS with proper dependencies (in footer = false to load before inline scripts)
						wp_enqueue_script('mec-leaflet-js', MECMAPASSETS . 'vendore/leaflet/leaflet.js', array('jquery'), '1.0.0', false);
						wp_enqueue_script('mec-leaflet-marker-cluster-js', MECMAPASSETS . 'vendore/leaflet-marker-cluster/leaflet.markercluster.js', array('jquery', 'mec-leaflet-js'), '1.0.0', false);
						wp_enqueue_script('mec-leaflet-fullscreen-js', MECMAPASSETS . 'vendore/leaflet-fullscreen/Leaflet.fullscreen.min.js', array('jquery', 'mec-leaflet-js'), '1.0.0', false);
						wp_enqueue_script('mec-openstreetmap-js', MECMAPASSETS . 'js/openstreetmap.js', array('jquery', 'mec-leaflet-js', 'mec-leaflet-marker-cluster-js', 'mec-leaflet-fullscreen-js'), '1.0.0', false);
					}
				}
			}
		} else {
			// Load Google Maps API
			$api_key = isset($mec_settings['google_maps_api_key']) && trim($mec_settings['google_maps_api_key']) != '' ? $mec_settings['google_maps_api_key'] : '';

			if ($api_key) {
				wp_enqueue_script('googlemap', '//maps.googleapis.com/maps/api/js?libraries=places&key=' . esc_attr($api_key), array(), null, false);
			} else {
				wp_enqueue_script('googlemap', '//maps.googleapis.com/maps/api/js?libraries=places', array(), null, false);
			}

			// Load MEC map scripts (only for Google Maps)
			wp_enqueue_script('mec-richmarker-script');
		}
	}
}
