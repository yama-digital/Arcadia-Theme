/**
 * @todo: convert this file to Vanilla JS.
 */
(function( $ ) {
    'use strict';
    $(function() {
        $( '.woostify-color-picker' ).wpColorPicker();
    });
})( jQuery );
