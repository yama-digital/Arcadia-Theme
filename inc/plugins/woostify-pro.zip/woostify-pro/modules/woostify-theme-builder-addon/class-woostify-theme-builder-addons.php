<?php
/**
 * Woostify theme builder addons
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Theme_Builder_Addons' ) ) {
	/**
	 * Class for woostify builder addons.
	 */

	class Woostify_Theme_Builder_Addons{
		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 * Meta Option
		 *
		 * @var $meta_option
		 */
		private static $meta_option;

		/**
		 *  Initiator
		 */
		public static function init() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->define_constants();

			add_action( 'wp', array( $this, 'hooks') );

			add_action( 'init', array( $this, 'init_action' ), 0 );
			add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 5 );
			add_action( 'load-post.php', array( $this, 'wp_builder_addon_metabox' ) );
			add_action( 'load-post-new.php', array( $this, 'wp_builder_addon_metabox' ) );
			add_filter( 'template_include', array( $this, 'single_template' ) );

			add_filter( 'body_class', [ $this, 'body_class' ] );

			// Add Template Type column on 'wp_builder_addon' list in admin screen.

			if ( is_admin() ) {
				add_filter( 'manage_wp_builder_addon_posts_columns', [ $this, 'set_column_headings' ] );
				add_action( 'manage_wp_builder_addon_posts_custom_column', [ $this, 'render_column_content' ], 10, 2 );
			}

			add_shortcode( 'wp_builder_addon', [ $this, 'render_template' ] );

			// Scripts and styles.
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_assets' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ), 200 );

			// Print dialog template.
			add_action( 'admin_footer', array( $this, 'add_new_template' ) );
			add_action( 'admin_footer', array( $this, 'layout_preview_template' ) );
			// Create new template.
			add_action( 'admin_action_woostify_add_new_template_builder_addons', array( $this, 'admin_action_new_post' ) );

			add_action( 'wp_ajax_woostify_advanced_layout_quick_preview', array( $this, 'woostify_advanced_layout_quick_preview' ) );

			$this->include_files();

		}

		/**
		 * Include files
		 */
		public function include_files(){

			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/inc/class-woostify-builder-condition.php';
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/inc/class-woostify-builder-time-duration.php';
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/inc/woostify-builder-functions.php';
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/inc/class-woostify-builder-ajax.php';

			// Builder Gutenberg Compatibility
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/compatibility/class-woostify-builder-gutenberg-compatibility.php';
			// Header and Footer
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/advanced-header-footer/class-woostify-header-footer.php';
			// Advanced Hooks
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/advanced-hooks/class-woostify-builder-hooks.php';
			// Advanced Popup
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/advanced-popup/class-woostify-builder-popup.php';
			// Advanced Template
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/advanced-template/class-woostify-builder-template.php';
			// Nav Menu
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/nav-menu/class-woostify-builder-nav-menu.php';

		}

		/**
		 * Define constant
		 */
		public function define_constants() {
			if ( ! defined( 'WOOSTIFY_PRO_WOOSTIFY_BUILDER_ADDON' ) ) {
				define( 'WOOSTIFY_PRO_WOOSTIFY_BUILDER_ADDON', WOOSTIFY_PRO_VERSION );
			}
		}

		public function hooks(){

			// Activation hook.
			register_activation_hook( __FILE__, array( $this, 'activation_reset' ) );

			// deActivation hook.
			register_deactivation_hook( __FILE__, array( $this, 'deactivation_reset' ) );
		}

		/**
		 * Activation Reset
		 */
		public function activation_reset() {
			// flush rewrite rules.
			flush_rewrite_rules(); //phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.flush_rewrite_rules_flush_rewrite_rules -- Used for specific cases and kept to minimal use.
		}

		/**
		 * Deactivation Reset
		 */
		public function deactivation_reset() {
			// flush rewrite rules.
			flush_rewrite_rules(); //phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.flush_rewrite_rules_flush_rewrite_rules -- Used for specific cases and kept to minimal use.
			delete_option( 'woostify_wp_builder_addon_flush_rewrite_rules' );
		}

		/**
		 * Init action
		 */
		public function init_action() {
			// Create custom post type.
			$args = array(
				'label'               => __( 'Theme Builder', 'woostify-pro' ),
				'supports'            => array( 'title', 'editor', 'thumbnail', 'elementor' ),
				'rewrite'             => array( 'slug' => 'wp-builder-addon' ),
				'show_in_rest'        => true,
				'hierarchical'        => false,
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_admin_bar'   => true,
				'show_in_nav_menus'   => true,
				'can_export'          => true,
				'has_archive'         => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'capability_type'     => 'page',
			);
			register_post_type( 'wp_builder_addon', $args );

			// Flush rewrite rules.
			if ( ! get_option( 'woostify_wp_builder_addon_flush_rewrite_rules' ) ) {
				flush_rewrite_rules();
				update_option( 'woostify_wp_builder_addon_flush_rewrite_rules', true );
			}
		}

		/**
		 * Add Theme Builder Addons admin menu
		 */
		public function add_admin_menu() {
			$position = 1;
			add_submenu_page( 'woostify-welcome', 'Theme Builder', __( 'Theme Builder', 'woostify-pro' ), 'manage_options', 'edit.php?post_type=wp_builder_addon', '', $position );
		}

		/**
		 * Single wp_builder_addon template
		 *
		 * @param string $template The path of the template to include.
		 */
		public function single_template( $template ) {
			if ( is_singular( 'wp_builder_addon' ) && file_exists( WOOSTIFY_THEME_DIR . 'inc/elementor/elementor-library.php' ) ) {
				$template = WOOSTIFY_THEME_DIR . 'inc/elementor/elementor-library.php';
			}

			return $template;
		}

		/**
		 * Add body class
		 */
		public function body_class( $classes ) {
			$classes[] = 'wp-builder-template-' . get_template();

			return $classes;
		}

		/**
		 * Get template id
		 */
		public function get_template_id( $type ) {

			$option = [
				'location'  => 'woostify_builder_target_include_locations',
				'exclusion' => 'woostify_builder_target_exclude_locations',
				'users'     => 'woostify_builder_target_users_rule',
			];

			$wp_builder_templates = Woostify_Theme_Builder_Addons_Condition::instance()->get_posts_by_conditions( 'wp_builder_addon', $option );

			if( $wp_builder_templates ){

				foreach ( $wp_builder_templates as $key => $template ) {
					if ( get_post_meta( absint( $template['id'] ), 'woostify_wp_builder_addon_template', true ) === $type ) {
						return $template['id'];
					}
				}
			}

			return '';
		}


		/**
		 * Theme Builder metabox
		 */
		public function wp_builder_addon_metabox(){
			add_action( 'add_meta_boxes', array( $this, 'setup_wp_builder_addon_metabox' ) );
			add_action( 'save_post', array( $this, 'save_wp_builder_addon_metabox' ), 10, 2 );

			self::$meta_option = array(
				'woostify_wp_builder_addon_template' => array(
					'value'  => 'default',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_header_footer_stick' => array(
					'value'  => 'default',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_header_footer_stick_on' => array(
					'value'  => 'all-device',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_header_shrink' => array(
					'value'  => 'default',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_display_on' => array(
					'value'  => 'all',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_not_display_on' => array(
					'value'  => '0',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_responsive_desktop' => array(
					'value'  => 'default',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_responsive_tablet' => array(
					'value'  => 'default',
					'sanitize' => 'FILTER_DEFAULT',
				),
				'woostify_builder_responsive_mobile' => array(
					'value'  => 'default',
					'sanitize' => 'FILTER_DEFAULT',
				),
			);

		}

		/**
		 * Get metabox options
		 */
		public static function get_builder_metabox_option() {
			return self::$meta_option;
		}

		/**
		 *  Setup Metabox
		 */
		public function setup_wp_builder_addon_metabox( ){
			add_meta_box(
				'woostify_metabox_settings_wp_builder_addon',
				__( '<span>Custom Layout</span>', 'woostify-pro' ),
				array( $this, 'wp_builder_addon_layout_metabox_markup' ),
				'wp_builder_addon',
				'side'
			);

		}

		/**
		 *  Metabox Layout Markup
		 */
		public function wp_builder_addon_layout_metabox_markup( $post ) {
			wp_nonce_field( basename( __FILE__ ), 'woostify_metabox_settings_wp_builder_addon' );

			$stored = get_post_meta( $post->ID );

			// Set stored and override defaults.
			foreach ( $stored as $key => $value ) {
				self::$meta_option[ $key ]['value'] = isset( $stored[ $key ][0] ) ? $stored[ $key ][0] : '';
			}
			// Get defaults.
			$meta_options = self::get_builder_metabox_option();

			$template = isset( $meta_options['woostify_wp_builder_addon_template'] )? $meta_options['woostify_wp_builder_addon_template']['value'] : 'default';
			$sticky = isset( $meta_options['woostify_builder_header_footer_stick'] )? $meta_options['woostify_builder_header_footer_stick']['value'] : 'default';
			$shrink = isset( $meta_options['woostify_builder_header_shrink'] )? $meta_options['woostify_builder_header_shrink']['value'] : 'default';
			$sticky_on = isset( $meta_options['woostify_builder_header_footer_stick_on'] )? $meta_options['woostify_builder_header_footer_stick_on']['value'] : 'all-device';

			$desktop = isset( $meta_options['woostify_builder_responsive_desktop'] )? $meta_options['woostify_builder_responsive_desktop']['value'] : "default";
			$tablet = isset( $meta_options['woostify_builder_responsive_tablet'] )? $meta_options['woostify_builder_responsive_tablet']['value'] : "default";
			$mobile = isset( $meta_options['woostify_builder_responsive_mobile'] )? $meta_options['woostify_builder_responsive_mobile']['value'] : "default";

			?>
			<div class="woostify-pro-wp-builder-addon-options-wrapper">
				<div class="input-wrapper">
					<div class="woostify-metabox-option">
						<label for="woostify-wp-builder-addon-template-type">
							<p><?php esc_html_e( 'Layout', 'woostify-pro' ); ?></p>
						</label>
						<select name="woostify_wp_builder_addon_template" id="woostify-wp-builder-addon-template-type">
							<option value="default" <?php selected( $template, 'default' ); ?>>
								<?php esc_html_e( 'Select Option', 'woostify-pro' ); ?>
							</option>

							<option value="woostify_builder_header" <?php selected( $template, 'woostify_builder_header' ); ?>>
								<?php esc_html_e( 'Header', 'woostify-pro' ); ?>
							</option>

							<option value="woostify_builder_footer" <?php selected( $template, 'woostify_builder_footer' ); ?>>
								<?php esc_html_e( 'Footer', 'woostify-pro' ); ?>
							</option>

							<option value="woostify_builder_content_hook" <?php selected( $template, 'woostify_builder_content_hook' ); ?>>
								<?php esc_html_e( 'Content/Hook', 'woostify-pro' ); ?>
							</option>

							<option value="woostify_builder_popup" <?php selected( $template, 'woostify_builder_popup' ); ?>>
								<?php esc_html_e( 'Popup', 'woostify-pro' ); ?>
							</option>

							<option value="woostify_builder_404" <?php selected( $template, 'woostify_builder_404' ); ?>>
								<?php esc_html_e( '404', 'woostify-pro' ); ?>
							</option>

							<option value="woostify_builder_archive" <?php selected( $template, 'woostify_builder_archive' ); ?>>
								<?php esc_html_e( 'Archive Template', 'woostify-pro' ); ?>
							</option>

							<option value="woostify_builder_single" <?php selected( $template, 'woostify_builder_single' ); ?>>
								<?php esc_html_e( 'Single Template', 'woostify-pro' ); ?>
							</option>
						</select>
					</div>
				</div>
				<div class="woostify-pro-wp-builder-addon-options">
					<?php
					if ( $template == 'woostify_builder_header' || $template == 'woostify_builder_footer' ) {

						?>
						<div class="input-wrapper template-header-footer">
							<h3 class="components-panel-title">
								<button type="button" aria-expanded="true" class="components-button components-panel__body-toggle components-panel-toggle active">
									<?php esc_html_e( 'Sticky Settings', 'woostify-pro' ); ?>
									<span aria-hidden="true">
										<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
									</span>
								</button>
							</h3>

							<div class="woostify-metabox-option-box is-opened">
								<div class="woostify-metabox-option">
									<div class="components-toggle-wrap">
										<span class="components-toggle">
											<input type="checkbox" class="components-toggle__input" name="woostify_builder_header_footer_stick" id="woostify-builder-header-footer-stick" value="sticky" <?php checked( $sticky, 'sticky' ); ?>>
											<span class="components-toggle__track"></span>
											<span class="components-toggle__thumb"></span>
										</span>
										<label for="woostify-builder-header-footer-stick">
											<?php esc_html_e( 'Stick', 'woostify-pro' ); ?>
										</label>
									</div>
								</div>
								<?php if ( $template == 'woostify_builder_header' ) { ?>
								<div class="woostify-metabox-option">
									<div class="components-toggle-wrap">
										<span class="components-toggle">
											<input type="checkbox" class="components-toggle__input" name="woostify_builder_header_shrink" id="woostify-builder-header-shrink" value="shrink" <?php checked( $shrink, 'shrink' ); ?>>
											<span class="components-toggle__track"></span>
											<span class="components-toggle__thumb"></span>
										</span>
										<label for="woostify-builder-header-shrink">
											<?php esc_html_e( 'Shrink', 'woostify-pro' ); ?>
										</label>
									</div>
								</div>
								<?php } ?>
								<div class="woostify-metabox-option stick-on <?php echo ($sticky == 'sticky')? 'active' : ''; ?>">
									<label for="woostify-builder-header-footer-stick-on">
										<?php esc_html_e( 'Stick On', 'woostify-pro' ); ?>
									</label>
									<select name="woostify_builder_header_footer_stick_on" class="woostify-metabox-option-control" id="woostify-header-footer-template-sticky-on">
										<option value="all-device" <?php selected( $sticky_on, 'all-divice') ?> >
											<?php esc_html_e( 'Desktop + Mobile', 'woostify-pro' ); ?>
										</option>
										<option value="desktop" <?php selected( $sticky_on, 'desktop') ?>>
											<?php esc_html_e( 'Desktop', 'woostify-pro' ); ?>
										</option>
										<option value="mobile" <?php selected( $sticky_on, 'mobile') ?>>
											<?php esc_html_e( 'Mobile', 'woostify-pro' ); ?>
										</option>
									</select>
								</div>
							</div>
						</div>
						<?php
					}
					?>
					<?php
					if ( $template == 'woostify_builder_content_hook' ) {

						$Woostify_Advanced_Hooks_Meta = Woostify_Advanced_Hooks_Meta_Builder_Addons::get_instance();
					?>
						<div class="input-wrapper template-content-hook">
							<h3 class="components-panel-title">
								<button type="button" aria-expanded="true" class="components-button components-panel__body-toggle components-panel-toggle active">
									<?php esc_html_e( 'Action', 'woostify-pro' ); ?>
									<span aria-hidden="true">
										<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
									</span>
								</button>
							</h3>

							<div class="woostify-metabox-option-box is-opened">
								<?php $Woostify_Advanced_Hooks_Meta->render_advanced_hooks( $post); ?>
							</div>
						</div>
					<?php
					}
					?>

					<?php
					if ( $template == 'woostify_builder_popup' ) {

						$Woostify_Advanced_Popup = Woostify_Advanced_Popup_Builder_Addons::get_instance();
					?>
						<div class="input-wrapper template-popup">
							<h3 class="components-panel-title">
								<button type="button" aria-expanded="true" class="components-button components-panel__body-toggle components-panel-toggle active">
									<?php esc_html_e( 'Settings', 'woostify-pro' ); ?>
									<span aria-hidden="true">
										<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
									</span>
								</button>
							</h3>

							<div class="woostify-metabox-option-box is-opened">
								<?php $Woostify_Advanced_Popup->render_advanced_popup( $post); ?>
							</div>
						</div>
					<?php
					}
					?>

					<div class="input-wrapper condition">
						<h3 class="components-panel-title">
							<button type="button" data-popup-type="condition" class="components-button components-panel__body-toggle components-popup-button">
								<?php esc_html_e( 'Display And User Role Settings', 'woostify-pro' ); ?>
								<span class="edit-icon">
									<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path d="M19.5 4.5h-7V6h4.44l-5.97 5.97 1.06 1.06L18 7.06v4.44h1.5v-7Zm-13 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H17v3a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h3V5.5h-3Z"></path></svg>
								</span>
							</button>
						</h3>
					</div>

					<div class="input-wrapper responsive-visibility">
						<h3 class="components-panel-title">
							<button type="button" aria-expanded="true" class="components-button .components-panel__body-toggle components-panel__body-toggle components-panel-toggle active">
								<?php esc_html_e( 'Responsive Visibility', 'woostify-pro' ); ?>
								<span>
									<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
								</span>
							</button>
						</h3>
						<div class="woostify-metabox-option-box is-opened">
							<div class="woostify-metabox-option">
								<div class="components-toggle-wrap">
									<span class="components-toggle">
										<input type="checkbox" class="components-toggle__input" name="woostify_builder_responsive_desktop" id="woostify-builder-responsive-desktop" value="desktop" <?php checked( $desktop, 'desktop' ); ?>>
										<span class="components-toggle__track"></span>
										<span class="components-toggle__thumb"></span>
									</span>
									<label for="woostify-builder-responsive-desktop">
										<?php esc_html_e( 'Hide On Desktop', 'woostify-pro' ); ?>
									</label>
								</div>
							</div>
							<div class="woostify-metabox-option">
								<div class="components-toggle-wrap">
									<span class="components-toggle">
										<input type="checkbox" class="components-toggle__input" name="woostify_builder_responsive_tablet" id="woostify-builder-responsive-tablet" value="tablet" <?php checked( $tablet, 'tablet' ); ?>>
										<span class="components-toggle__track"></span>
										<span class="components-toggle__thumb"></span>
									</span>
									<label for="woostify-builder-responsive-tablet">
										<?php esc_html_e( 'Hide On Tablet', 'woostify-pro' ); ?>
									</label>
								</div>
							</div>
							<div class="woostify-metabox-option">
								<div class="components-toggle-wrap">
									<span class="components-toggle">
										<input type="checkbox" class="components-toggle__input" name="woostify_builder_responsive_mobile" id="woostify-builder-responsive-mobile" value="mobile" <?php checked( $mobile, 'mobile' ); ?>>
										<span class="components-toggle__track"></span>
										<span class="components-toggle__thumb"></span>
									</span>
									<label for="woostify-builder-responsive-mobile">
										<?php esc_html_e( 'Hide On Mobile', 'woostify-pro' ); ?>
									</label>
								</div>
							</div>
						</div>
					</div>

					<div class="input-wrapper expiration">
						<h3 class="components-panel-title">
							<button type="button" data-popup-type="expiration" class="components-button components-panel__body-toggle components-popup-button">
								<?php esc_html_e( 'Time Duration Settings', 'woostify-pro' ); ?>
								<span class="edit-icon">
									<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path d="M19.5 4.5h-7V6h4.44l-5.97 5.97 1.06 1.06L18 7.06v4.44h1.5v-7Zm-13 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H17v3a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h3V5.5h-3Z"></path></svg>
								</span>
							</button>
						</h3>
					</div>

				</div>
			</div>

			<?php $Woostify_Theme_Builder_Addons_Condition = Woostify_Theme_Builder_Addons_Condition::instance(); ?>

			<div id="wp-builder-template-condition" class="wp-builder-template-option-popup woostify-pro-wp-builder-addon-options-wrapper" data-popup-type="condition">
				<?php $Woostify_Theme_Builder_Addons_Condition->render_condition_settings_field(); ?>
			</div>

			<?php $Woostify_Theme_Builder_Addons_Time_Duration = Woostify_Theme_Builder_Addons_Time_Duration::instance(); ?>

			<div id="wp-builder-template-expiration" class="wp-builder-template-option-popup woostify-pro-wp-builder-addon-options-wrapper" data-popup-type="expiration">
				<?php $Woostify_Theme_Builder_Addons_Time_Duration->render_time_duration_settings_field(); ?>
			</div>
			<input type="hidden" id="woostify-wp-builder-addon-template-id" value="<?php echo $post->ID; //phpcs:ignore ?>">
			<input type="hidden" id="woostify-wp-builder-addon-nonce" value="<?php echo wp_create_nonce( 'wp_builder_template_type_ajax_nonce' ); //phpcs:ignore ?>">
			<?php
		}

		/**
		 * Save option meta
		 */
		public function save_wp_builder_addon_metabox( $post_id, $post ) {

			$post_type = get_post_type( $post_id );
			if ( 'wp_builder_addon' !== $post_type ) {
				return;
			}

			$nonce_key = 'woostify_metabox_settings_wp_builder_addon';

			// verify nonce
			if ( !isset( $_POST[$nonce_key] ) && !wp_verify_nonce( sanitize_text_field($_POST[$nonce_key]), $nonce_key ) ) {
				return 'nonce not verified';
			}

			// check permissions
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return 'cannot edit post';
			}

			$meta_options = $this->get_builder_metabox_option();

			foreach ( $meta_options as $key_op => $option ) {

				// Sanitize values.
				$sanitize_filter = isset( $option['sanitize'] ) ? $option['sanitize'] : 'FILTER_DEFAULT';

				switch ( $sanitize_filter ) {

					case 'FILTER_SANITIZE_STRING':
							$meta_value = filter_input( INPUT_POST, $key_op, FILTER_SANITIZE_STRING );
						break;

					case 'FILTER_SANITIZE_URL':
							$meta_value = filter_input( INPUT_POST, $key_op, FILTER_SANITIZE_URL );
						break;

					case 'FILTER_SANITIZE_NUMBER_INT':
							$meta_value = filter_input( INPUT_POST, $key_op, FILTER_SANITIZE_NUMBER_INT );
						break;

					default:
							$meta_value = filter_input( INPUT_POST, $key_op, FILTER_DEFAULT );
						break;
				}

				// Store values.
				if ( $meta_value ) {
					update_post_meta( $post_id, $key_op, $meta_value );
				} else {
					delete_post_meta( $post_id, $key_op );
				}
			}


		}


		/**
		 * Admin enqueue styles and scripts.
		 */
		public function admin_enqueue_assets() {
			$screen              = get_current_screen();
			$is_edit_wp_builder_addon = $screen ? 'edit-wp_builder_addon' === $screen->id : false;
			if ( $is_edit_wp_builder_addon ) {
				wp_enqueue_script(
					'woostify-wp-builder-addon-add-new-template',
					WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/js/add-new-template' . woostify_suffix() . '.js',
					array(),
					WOOSTIFY_PRO_VERSION,
					true
				);

				wp_enqueue_style(
					'woostify-wp-builder-addon-add-new-template',
					WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/css/add-new-template.css',
					array(),
					WOOSTIFY_PRO_VERSION
				);

				wp_localize_script(
					'woostify-wp-builder-addon-add-new-template',
					'woostifyBuilderData',
					array(
						'url'              => admin_url( 'admin-ajax.php' ),
						'quick_view_nonce' => wp_create_nonce( 'woostify-addon-quick-layout-view-nonce' ),
					)
				);
			}

			// Load the datepicker
			wp_enqueue_style(
				'woostify-wp-builder-addon-datetimepicker-style',
				WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/libs/datepicker/jquery-ui-timepicker-addon.min.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);

			wp_enqueue_script(
				'woostify-wp-builder-addon-datetimepicker-script',
				WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/libs/datepicker/jquery-ui-timepicker-addon.min.js',
				array( 'jquery-ui-datepicker', 'jquery-ui-slider' ),
				WOOSTIFY_PRO_VERSION,
				true
			);


			wp_enqueue_style(
				'woostify-wp-builder-addon-editor',
				WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/css/editor-style.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);

			wp_enqueue_script(
				'woostify-wp-builder-addon-editor',
				WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/js/editor-script' . woostify_suffix() . '.js',
				array(),
				WOOSTIFY_PRO_VERSION,
				true
			);


		}

		/**
		 * Enqueue styles and scripts.
		 */
		public function enqueue_assets() {

			if ( class_exists( '\Elementor\Plugin' ) ) {
				$elementor = \Elementor\Plugin::instance();
				$elementor->frontend->enqueue_styles();
			}

			if ( class_exists( '\ElementorPro\Plugin' ) ) {
				$elementor_pro = \ElementorPro\Plugin::instance();
				$elementor_pro->enqueue_styles();
			}

			if ( strpos($_SERVER['REQUEST_URI'], 'elementor') !== false ) {
				return;
			}

			wp_enqueue_style(
				'woostify-wp-builder-addon-style',
				WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/css/style.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);


			wp_enqueue_script(
				'woostify-wp-builder-addon-frontend',
				WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/assets/js/frontend-script' . woostify_suffix() . '.js',
				array(),
				WOOSTIFY_PRO_VERSION,
				true
			);

		}

		/**
		 * Print template
		 */
		public function add_new_template() {
			$screen              = get_current_screen();
			$is_edit_wp_builder_addon = $screen ? 'edit-wp_builder_addon' === $screen->id : false;
			if ( ! $is_edit_wp_builder_addon ) {
				return;
			}
			?>

			<div class="woostify-add-new-template-builder">
				<div class="woostify-add-new-template-inner">
					<div class="woostify-add-new-template-header">
						<span class="woostify-add-new-template-logo">
							<img src="<?php echo esc_url( WOOSTIFY_THEME_URI . 'assets/images/logo.svg' ); ?>" alt="<?php esc_attr_e( 'Admin woostify logo image', 'woostify-pro' ); ?>">
						</span>
						<span class="woostify-add-new-template-title"><?php esc_html_e( 'New Template', 'woostify-pro' ); ?></span>
						<span class="woostify-add-new-template-close-btn dashicons dashicons-no-alt"></span>
					</div>

					<div class="woostify-add-new-template-content">
						<form class="woostify-add-new-template-form">
							<input type="hidden" name="post_type" value="woo_builder">
							<input type="hidden" name="action" value="woostify_add_new_template_builder_addons">
							<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'woostify_add_new_template_builder_addons' ) ); ?>">

							<div class="woostify-add-new-template-form-title"><?php esc_html_e( 'Choose Template Type', 'woostify-pro' ); ?></div>

							<div class="woostify-add-new-template-item">
								<label class="woostify-add-new-template-label"><?php esc_html_e( 'Select the type of template you want to work on', 'woostify-pro' ); ?>:</label>

								<div class="woostify-add-new-template-option-wrapper">
									<select class="woostify-add-new-template-type" name="template_type" required="required">
										<option value=""><?php esc_html_e( 'Select...', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_header"><?php esc_html_e( 'Header', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_footer"><?php esc_html_e( 'Footer', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_content_hook"><?php esc_html_e( 'Custom Content/Hook', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_popup"><?php esc_html_e( 'Popup', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_custom_template"><?php esc_html_e( 'Custom Template', 'woostify-pro' ); ?></option>
									</select>
									<select class="woostify-add-new-custom-template-type" name="custom_template_type">
										<option value=""><?php esc_html_e( 'Choose Template...', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_404"><?php esc_html_e( '404', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_archive"><?php esc_html_e( 'Archive Template', 'woostify-pro' ); ?></option>
										<option value="woostify_builder_single"><?php esc_html_e( 'Single Template', 'woostify-pro' ); ?></option>
									</select>
								</div>
							</div>

							<div class="woostify-add-new-template-item">
								<label class="woostify-add-new-template-label"><?php esc_html_e( 'Name your template', 'woostify-pro' ); ?>:</label>

								<div class="woostify-add-new-template-option-wrapper">
									<input type="text" placeholder="<?php esc_attr_e( 'Enter template name', 'woostify-pro' ); ?>" name="post_title" required="required">
								</div>
							</div>

							<button class="woostify-add-new-template-form-submit"><?php esc_html_e( 'Create Template', 'woostify-pro' ); ?></button>
						</form>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * HTML Template for custom layout preview.
		 *
		 */
		public function layout_preview_template() {
			?>
			<div class="woostify-custom-layout-preview-wrapper"></div>
			<script type="text/template" id="tmpl-woostify-modal-view-layout-details">
				<div class="woostify-layout-modal woostify-data-preview">
					<div class="woostify-layout-modal-content">
						<section class="woostify-layout-modal-main" role="main">
							<header class="woostify-layout-modal-header">
								<h1> {{ data.title }} </h1>
								<mark class="layout-status"><span>{{ data.layout_type }}</span></mark>
								<button id="modal-close-link" class="modal-close modal-close-link dashicons dashicons-no-alt">
									<span class="screen-reader-text"><?php esc_html_e( 'Close modal panel', 'woostify-pro' ); ?></span>
								</button>
							</header>
							<article>
								<div class="woostify-layout-preview-row">
									<div class="woostify-layout-preview-col">
										<h3><?php esc_html_e( 'Display On:', 'woostify-pro' ); ?></h3>
									</div>
									<div class="woostify-layout-preview-col right">
										{{{ data.display_rules }}}
									</div>
									<div class="woostify-layout-preview-col">
										<h3><?php esc_html_e( 'Do Not Display On:', 'woostify-pro' ); ?></h3>
									</div>
									<div class="woostify-layout-preview-col right">
										{{{ data.exclusion_rules }}}
									</div>
									<div class="woostify-layout-preview-col">
										<h3><?php esc_html_e( 'Display for Users:', 'woostify-pro' ); ?></h3>
									</div>
									<div class="woostify-layout-preview-col right">
										{{{ data.user_rules }}}
									</div>
									<div class="woostify-layout-preview-col">
										<h3><?php esc_html_e( 'Hide on Devices:', 'woostify-pro' ); ?></h3>
									</div>
									<div class="woostify-layout-preview-col right">
										{{{ data.display_devices_rules }}}
									</div>
									<div class="woostify-layout-preview-col">
										<h3><?php esc_html_e( 'Time Rule:', 'woostify-pro' ); ?></h3>
									</div>
									<div class="woostify-layout-preview-col right">
										{{{ data.time_duration_rule }}}
									</div>
									<div class="woostify-layout-preview-col">
										<h3><?php esc_html_e( 'Settings:', 'woostify-pro' ); ?></h3>
									</div>
									<div class="woostify-layout-preview-col right">
										{{{ data.settings }}}
									</div>
								</div>
							</article>
							<footer>
								<div class="inner">
									<div class="woostify-layout-action-button-group">
										<label> <strong> <?php esc_html_e( 'Status: ', 'woostify-pro' ); ?> </strong> {{ data.status }} </label> |
										<label> <strong> <?php esc_html_e( 'Published date: ', 'woostify-pro' ); ?> </strong> {{ data.post_date }} </label>
									</div>
									<a class="button button-primary button-large" aria-label="<?php esc_attr_e( 'Edit this layout', 'woostify-pro' ); ?>" href="{{ data.edit_link }}"><?php esc_html_e( 'Edit Layout', 'woostify-pro' ); ?></a>
								</div>
							</footer>
						</section>
					</div>
				</div>
				<div class="woostify-layout-modal-backdrop modal-close"></div>
			</script>
			<?php
		}

		/**
         * Get Markup of Location rules for Display rule column.
         *
         * @param array $locations Array of locations.
         * @return void
         */
        public function column_display_location_rules( $post_id, $locations, $location_special_key ) {

            $location_label = '';
            $index          = array_search( 'specifics', $locations );
            if ( false !== $index && ! empty( $index ) ) {
                unset( $locations[ $index ] );
            }

            if ( isset( $locations ) && is_array( $locations ) ) {

				$location_selection = Woostify_Theme_Builder_Addons_Condition::instance()->get_location_selections( );
				$special_ids = $location_selection['special-ids']['value'];

				$location_label = '<ul>';

                foreach ( $locations as $key => $location ) {

					$i = $key;

					$special_obj = Woostify_Theme_Builder_Addons_Condition::instance()->get_special_id_obj( $post_id, $location_special_key, $i );

					$special_obj_id = !empty($special_obj)? $special_obj['ID'] : '';
					$special_obj_type = !empty($special_obj)? $special_obj['type'] : '';
					$special_obj_title = !empty($special_obj)? $special_obj['title'] : '';
					$special_obj_index = !empty($special_obj)? $special_obj['index'] : '';

					foreach ( $location_selection as $group => $group_data ) {

						foreach ( $group_data['value'] as $opt_key => $opt_value ) {

							if( $opt_key == $location ){

								if( array_key_exists( $location, $special_ids ) || ( strpos($opt_key, "post-tax") !== false ) ){
									$location_label .= '<li>' . __( $opt_value . ': <strong>' . $special_obj_title . '</strong>' , 'woostify-pro' ) . '</li>';
								}else{
									$location_label .= '<li>' . __( $opt_value , 'woostify-pro' ) . '</li>';
								}
							}

						}

					}

                }

				$location_label .= '</ul>';
            }

			return $location_label;
        }

		/**
		 * Get Custom Layout details to send to the AJAX endpoint for quick-preview.
		 *
		 * @param  int $layout_id Custom Layout ID.
		 * @return array
		 */
		public function get_layout_details( $layout_id ) {
			if ( ! $layout_id ) {
				return array();
			}

			$display_rules = __( 'No Conditions', 'woostify-pro' );
			$locations     = get_post_meta( $layout_id, 'woostify_builder_target_include_locations', true );

			if ( ! empty( $locations ) && ! empty( $locations[0] ) ) {
				$display_rules = $this->column_display_location_rules( $layout_id, $locations, 'woostify_builder_target_include_locations' );
			}

			$exclusion_rules = __( 'No Conditions', 'woostify-pro' );
			$locations       = get_post_meta( $layout_id, 'woostify_builder_target_exclude_locations', true );
			if ( ! empty( $locations ) && ! empty( $locations[0] ) ) {
				$exclusion_rules = $this->column_display_location_rules( $layout_id, $locations, 'woostify_builder_target_exclude_locations' );
			}

			$user_rules = __( 'No Conditions', 'woostify-pro' );
			$users      = get_post_meta( $layout_id, 'woostify_builder_target_users_rule', true );

			$users_rule_basic = array(
				'all'        => __( 'All', 'woostify-pro' ),
				'logged-in'  => __( 'Logged In', 'woostify-pro' ),
				'logged-out' => __( 'Logged Out', 'woostify-pro' ),
			);

			if ( isset( $users ) && is_array( $users ) ) {
				if ( isset( $users[0] ) && ! empty( $users[0] ) ) {
					$user_rules = '<ul class="woostify-layout-user-list">';

					foreach ( $users as $user ) {
						if( !array_key_exists( $user, $users_rule_basic) ){
							$role = get_role( $user );
							$user_label = $role->name;
							$user_rules .= '<li>'. __( $user_label ,'woostify-pro') . '</li>';
						}else{
							$user_label = $users_rule_basic[$user];
							$user_rules .= '<li>'. __( $user_label ,'woostify-pro') . '</li>';

						}
					}

					$user_rules .= '</ul>';
				}
			}


			$display_devices_rules = __( 'No Conditions', 'woostify-pro' );

			$desktop = get_post_meta( $layout_id, 'woostify_builder_responsive_desktop', true );
			$tablet  = get_post_meta( $layout_id, 'woostify_builder_responsive_tablet', true );
			$mobile  = get_post_meta( $layout_id, 'woostify_builder_responsive_mobile', true );

			$divices = [];

			$divices[] = $desktop ;
			$divices[] = $tablet ;
			$divices[] = $mobile ;

			if ( is_array( $divices ) && ! empty( $divices ) ) {
				$display_devices_rules = '<ul>';
				foreach ( $divices as $display_device ) {
					switch ( $display_device ) {
						case 'desktop':
							$display_devices_rules .= '<li class="woostify-desktop">' . esc_html( __( 'Desktop', 'woostify-pro' ) ) . '</li>';
							break;
						case 'tablet':
							$display_devices_rules .= '<li class="woostify-tablet">' . esc_html( __( 'Tablet', 'woostify-pro' ) ) . '</li>';
							break;
						case 'mobile':
							$display_devices_rules .= '<li class="woostify-mobile">' . esc_html( __( 'Mobile', 'woostify-pro' ) ) . '</li>';
							break;
					}
				}
				$display_devices_rules .= '</ul>';
			}

			$time_duration_rule = __( 'No Conditions', 'woostify-pro' );

			$time_duration_enable = get_post_meta( $layout_id, 'wp_builder_time_duration_enable', true );
			$time_duration_start_date = get_post_meta( $layout_id, 'wp_builder_time_duration_start_date', true );
			$time_duration_end_date = get_post_meta( $layout_id, 'wp_builder_time_duration_end_date', true );

			$time_duration_start_end_date = '';
			$visible = '';
			if ( $time_duration_enable === 'enabled' ) {

				$start_dt = !empty( $time_duration_start_date ) ? $time_duration_start_date : '—';
				$end_dt   = !empty( $time_duration_end_date ) ? $time_duration_end_date : '—';

				if( !Woostify_Theme_Builder_Addons_Time_Duration::instance()->get_time_duration_eligibility($layout_id) ){
					$visible = 'Not Visible';
				}else{
					$visible = 'Visible';
					$time_duration_start_end_date .= '<div>'.__( '<strong>Start Date: </strong>' . $start_dt , 'woostify-pro' ).'</div>';
					$time_duration_start_end_date .= '<div>'.__( '<strong>End Date: : </strong>' . $end_dt , 'woostify-pro' ).'</div>';
				}


				$time_duration_rule = '<div class="ast-advanced-hook-time-duration-wrap ast-advanced-hook-wrap">';
					$time_duration_rule .= '<div>'. __( '<strong>Visible: </strong>' . $visible , 'woostify-pro' ).'</div>';
					$time_duration_rule .= $time_duration_start_end_date;
				$time_duration_rule .= '</div>';

			}

			$template_type = get_post_meta( $layout_id, 'woostify_wp_builder_addon_template', true );
			$layout_type = '';
			$settings = '<ul>';

			$sticky = get_post_meta( $layout_id, 'woostify_builder_header_footer_stick', true );
			$shrink = get_post_meta( $layout_id, 'woostify_builder_header_shrink', true );
			$sticky_on = get_post_meta( $layout_id, 'woostify_builder_header_footer_stick_on', true );

			// settings popup
			$open_animation = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_open_animation', true );
			$close_animation = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_close_animation', true );
			$animation_duration = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_animation_duration', true );
			$popup_action = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_action', true );

			$popup_width = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_width', true );
			$popup_width_unit = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_width_unit', true );

			$popup_height_type = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_height_type', true);
			$popup_height_position_content = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_height_position_content', true);
			$popup_height_unit = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_height_custom_unit', true);
			$popup_height_custom = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_height_custom', true);

			$popup_position_horizontal = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_position_horizontal', true);
			$popup_position_vertical = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_position_vertical', true);

			$popup_overlay = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_overlay', true );
			$popup_close_button = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_close_button', true );


			switch ( $template_type ) {
				case 'woostify_builder_header':
					$layout_type = __( 'Header', 'woostify-pro' );

					$settings .= '<li>'. __( '<strong>Sticky: </strong>' . $sticky , 'woostify-pro' ) . '</li>';
					$settings .= '<li>'. __( '<strong>Shrink: </strong>' . $shrink , 'woostify-pro' ) . '</li>';
					$settings .= '<li>'. __( '<strong>Sticky on: </strong>' . $sticky_on , 'woostify-pro' ) . '</li>';

					break;
				case 'woostify_builder_footer':
					$layout_type = __( 'Footer', 'woostify-pro' );

					$settings .= '<li>'. __( '<strong>Sticky: </strong> ' . $sticky , 'woostify-pro' ) . '</li>';
					$settings .= '<li>'. __( '<strong>Sticky on: </strong> ' . $sticky_on , 'woostify-pro' ) . '</li>';

					break;
				case 'woostify_builder_content_hook':
					$layout_type = __( 'Content/Hook', 'woostify-pro' );
					break;
				case 'woostify_builder_popup':
					$layout_type = __( 'Popup', 'woostify-pro' );

					switch ( $popup_action ) {
						case 'on-page-load':
							$settings .= '<li>' . __( '<strong>Trigger Condition: </strong> On Page Load', 'woostify-pro' ) . '</li>';
							break;
						case 'on-click':
							$settings .= '<li>' . __( '<strong>Trigger Condition: </strong> On Click', 'woostify-pro' ) . '</li>';
							break;
						case 'on-scroll':
							$scroll_direction = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_action_on_scroll_direction', true );
							$scroll_distance_unit = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_action_on_scroll_distance_unit', true );
							$scroll_distance = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_action_on_scroll_distance', true );

							$settings .= '<li>' . __( '<strong>Trigger Condition: </strong> On Scroll', 'woostify-pro' ) . '</li>';
							$settings .= '<li>' . __( '<strong>Scroll Direction: </strong>' . $scroll_direction, 'woostify-pro' ) . '</li>';
							$settings .= '<li>' . __( '<strong>Scroll Distance: </strong>' . $scroll_distance_unit . $scroll_distance , 'woostify-pro' ) . '</li>';

							break;
						case 'on-scroll-to-element':
							$scroll_to_element = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_action_on_scroll_to_element', true);

							$settings .= '<li>' .  __( '<strong>Trigger Condition: </strong> On Scroll To Element', 'woostify-pro' ) . '</li>';
							$settings .= '<li>' .  __( '<strong>Selector: </strong>' . $scroll_to_element, 'woostify-pro' ) . '</li>';

							break;
						case 'on-after-inactivity':
							$after_inactivity_time = get_post_meta( $layout_id, 'woostify_builder_advanced_popup_action_on_after_inactivity_time', true);

							$settings .= '<li>' .  __( '<strong>Trigger Condition: </strong> After Inactivity', 'woostify-pro' ) . '</li>';
							$settings .= '<li>' .  __( '<strong>Inactivity Time: </strong>' . $after_inactivity_time . 's', 'woostify-pro' ) . '</li>';

							break;
						case 'on-page-exit-intent':
							$settings .= '<li>' . __( '<strong>Trigger Condition: </strong> On Page Exit Intent', 'woostify-pro' ) . '</li>';
							break;
						default:
							$settings = __( '<strong>Trigger Condition: </strong> None', 'woostify-pro' );
							break;
					}

					$popup_open_animation = Woostify_Advanced_Popup_Builder_Addons::get_instance()->get_popup_open_animation();
					if ( is_array( $popup_open_animation ) && ! empty( $popup_open_animation ) ){
						foreach ( $popup_open_animation as $animations ){
							if ( is_array( $animations['animations'] ) && ! empty( $animations['animations'] ) ){
								foreach ( $animations['animations'] as $key => $animation ){
									if( $key == $open_animation ){
										$settings .= '<li>'. __( '<strong>Open Animation: </strong> ' . $animation['title'] , 'woostify-pro' ) . '</li>';
									}
								}
							}

						}
					}

					$popup_close_animation = Woostify_Advanced_Popup_Builder_Addons::get_instance()->get_popup_close_animation();
					if ( is_array( $popup_close_animation ) && ! empty( $popup_close_animation ) ){
						foreach ( $popup_close_animation as $animations ){
							if ( is_array( $animations['animations'] ) && ! empty( $animations['animations'] ) ){
								foreach ( $animations['animations'] as $key => $animation ){
									if( $key == $close_animation ){
										$settings .= '<li>'. __( '<strong>Close Animation: </strong> ' . $animation['title'] , 'woostify-pro' ) . '</li>';
									}
								}
							}

						}
					}

					$settings .= '<li>'. __( '<strong>Duration Animation: </strong> ' . $animation_duration . 's' , 'woostify-pro' ) . '</li>';
					$settings .= '<li>'. __( '<strong>Width: </strong> ' . $popup_width . $popup_width_unit , 'woostify-pro' ) . '</li>';

					$height_position_content = '';
					switch ( $popup_height_position_content ) {
						case 'flex-start':
							$height_position_content .= 'Top';
							break;
						case 'center':
							$height_position_content .= 'Center';
							break;
						case 'flex-end':
							$height_position_content .= 'Bottom';
							break;
					}

					switch ( $popup_height_type ) {
						case 'fit-to-content':
							$settings .= '<li>' . __( '<strong>Height Type: </strong> Fit To Content', 'woostify-pro' ) . '</li>';
							break;
						case 'fit-to-screen':
							$settings .= '<li>' . __( '<strong>Height Type: </strong> Fit To Screen', 'woostify-pro' ) . '</li>';
							$settings .= '<li>'. __( '<strong>Position Content: </strong> ' . $height_position_content , 'woostify-pro' ) . '</li>';
							break;
						case 'fit-to-custom':
							$settings .= '<li>' . __( '<strong>Height Type: </strong> Custom', 'woostify-pro' ) . '</li>';
							$settings .= '<li>'. __( '<strong>Position Content: </strong> ' . $height_position_content , 'woostify-pro' ) . '</li>';
							$settings .= '<li>'. __( '<strong>Height: </strong> ' . $popup_height_custom . $popup_height_unit , 'woostify-pro' ) . '</li>';
							break;
					}

					switch ( $popup_position_horizontal ) {
						case 'flex-start':
							$settings .= '<li>'. __( '<strong>Position Horizontal: </strong> Left'  , 'woostify-pro' ) . '</li>';
							break;
						case 'center':
							$settings .= '<li>'. __( '<strong>Position Horizontal: </strong> Center' , 'woostify-pro' ) . '</li>';
							break;
						case 'flex-end':
							$settings .= '<li>'. __( '<strong>Position Horizontal: </strong> Right' , 'woostify-pro' ) . '</li>';
							break;
					}

					switch ( $popup_position_vertical ) {
						case 'flex-start':
							$settings .= '<li>'. __( '<strong>Position Vertical: </strong> Top'  , 'woostify-pro' ) . '</li>';
							break;
						case 'center':
							$settings .= '<li>'. __( '<strong>Position Vertical: </strong> Center' , 'woostify-pro' ) . '</li>';
							break;
						case 'flex-end':
							$settings .= '<li>'. __( '<strong>Position Vertical: </strong> Bottom' , 'woostify-pro' ) . '</li>';
							break;
					}

					$overlay = ( $popup_overlay == 'hide' )? 'Hide' : 'Show';
					$settings .= '<li>'. __( '<strong>Overlay Popup: </strong>' . $overlay , 'woostify-pro' ) . '</li>';

					$close_button = ( $popup_close_button == 'hide' )? 'Hide' : 'Show';
					$settings .= '<li>'. __( '<strong>Close Button: </strong>' . $close_button , 'woostify-pro' ) . '</li>';

					break;
				case 'woostify_builder_single':
					$layout_type = __( 'Single Template', 'woostify-pro' );
					break;
				case 'woostify_builder_archive':
					$layout_type = __( 'Archive Template', 'woostify-pro' );
					break;
				case 'woostify_builder_404':
					$layout_type = __( '404 Page Template', 'woostify-pro' );
					break;
				default:
					$layout_type = __( 'Unknown', 'woostify-pro' );
					break;
			}
			$settings .= '</ul>';

			$post_title = get_the_title( $layout_id ) ? get_the_title( $layout_id ) : esc_attr( __( '(no title)', 'woostify-pro' ) );

			return apply_filters(
				'woostify_addon_custom_layout_preview_details',
				array(
					'template_type'			=> $template_type,
					'layout_id'             => $layout_id,
					'layout_type'           => $layout_type,
					'settings'				=> $settings,
					'status'                => ucfirst( get_post_status( $layout_id ) ),
					'title'                 => $post_title,
					'edit_link'             => admin_url( '/post.php?post=' . $layout_id . '&action=edit' ),
					'display_rules'         => $display_rules,
					'exclusion_rules'       => $exclusion_rules,
					'display_devices_rules' => $display_devices_rules,
					'time_duration_rule'    => $time_duration_rule,
					'user_rules'            => $user_rules,
					'post_date'             => get_the_date( '', $layout_id ),
				),
				$layout_id
			);
		}

		/**
		 * Quick View popup Ajax request to render dynamic content.
		 *
		 */
		public function woostify_advanced_layout_quick_preview() {
			check_ajax_referer( 'woostify-addon-quick-layout-view-nonce', 'nonce' );

			if ( ! current_user_can( 'edit_posts' ) || ! isset( $_REQUEST['post_id'] ) ) {
				wp_die( -1 );
			}

			$post_id = absint( $_REQUEST['post_id'] );
			$data    = $this->get_layout_details( $post_id );

			if ( $post_id ) {
				wp_send_json_success( $data );
			}

			wp_die();
		}

		/**
		 * Set shortcode column for template list.
		 *
		 * @param array $columns template list columns.
		 */
		function set_column_headings( $columns ) {

			$column_date = $columns['date'];
			unset( $columns['date'] );

			$columns['wp_builder_addon_type'] = __( 'Type', 'woostify-pro' );
			$columns['shortcode'] = __( 'Shortcode', 'woostify-pro' );
			$columns['quick_view'] = __( 'Quick View', 'woostify-pro' );
			$columns['date'] = $column_date;

			return $columns;
		}

		/**
		 * Display shortcode in template list column.
		 *
		 * @param array $column template list column.
		 * @param int   $post_id post id.
		 */
		public function render_column_content( $column, $post_id ) {

			switch ( $column ) {
				case 'wp_builder_addon_type':
					$type = get_post_meta( $post_id, 'woostify_wp_builder_addon_template', true );
					$title = __( 'Unknown', 'woostify-pro' );
					switch ( $type ) {
						case 'woostify_builder_header':
							$title = __( 'Header', 'woostify-pro' );
							break;
						case 'woostify_builder_footer':
							$title = __( 'Footer', 'woostify-pro' );
							break;
						case 'woostify_builder_content_hook':
							$title = __( 'Content/Hook', 'woostify-pro' );
							break;
						case 'woostify_builder_popup':
							$title = __( 'Popup', 'woostify-pro' );
							break;
						case 'woostify_builder_custom_template':
							$title = __( 'Custom Template', 'woostify-pro' );
							break;
						case 'woostify_builder_404':
							$title = __( '404', 'woostify-pro' );
							break;
						case 'woostify_builder_archive':
							$title = __( 'Archive', 'woostify-pro' );
							break;
						case 'woostify_builder_single':
							$title = __( 'Single', 'woostify-pro' );
							break;
						default:
							$title = __( 'Unknown', 'woostify-pro' );
							break;
					}
					?>
						<span><?php echo esc_html( $title ); ?></span>
					<?php
					break;
				case 'shortcode':
					ob_start();
					?>
					<span class="wp-builder-addon-shortcode-col-wrap">
						<input type="text" onfocus="this.select();" readonly="readonly" value="[wp_builder_addon id='<?php echo esc_attr( $post_id ); ?>']" class="wp-builder-addon-large-text code">
					</span>

					<?php

					ob_get_contents();
					break;

				case 'quick_view':
					echo '<button
						 	data-layout_id="' . esc_attr( $post_id ) . '"
							title="Preview"
							class="advanced_hook_data_trigger">
							<span class="dashicons dashicons-visibility">
							</span>
						</button>';
					break;

			}
		}

		/**
		 * Callback to shortcode.
		 *
		 * @param array $atts attributes for shortcode.
		 */
		public function render_template( $atts ) {
			$atts = shortcode_atts(
				[
					'id' => '',
				],
				$atts,
				'wp_builder_addon'
			);

			$id = ! empty( $atts['id'] ) ? intval( $atts['id'] ) : '';

			if ( empty( $id ) ) {
				return '';
			}

			$type = get_post_meta( $id, 'woostify_wp_builder_addon_template', true );

			$Woostify_Advanced_Hooks = Woostify_Advanced_Hooks_Builder_Addons::get_instance();

			if( $type != 'woostify_builder_content_hook' ){

				if ( class_exists( 'Elementor\Plugin' ) ) {
					$elementor_instance = Elementor\Plugin::instance();
					if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
						$css_file = new \Elementor\Core\Files\CSS\Post( $id );
					} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
						// Load elementor styles.
						$css_file = new \Elementor\Post_CSS_File( $id );
					}
					$css_file->enqueue();
				}
				ob_start();
				$Woostify_Advanced_Hooks->get_active_page_builder( $id );
				return ob_get_clean();
			}
			
			ob_start();
			$Woostify_Advanced_Hooks->get_action_content( $id );
			return ob_get_clean();
      
		}

		/**
		 * Admin action new post.
		 *
		 * When a new post action is fired the title is set to 'Elementor' and the post ID.
		 *
		 * Fired by `admin_action_elementor_new_post` action.
		 *
		 * @since 1.0.0
		 * @access public
		 */
		public function admin_action_new_post() {
			check_admin_referer( 'woostify_add_new_template_builder_addons' );
			$post_data = array();

			$template_type           = isset( $_GET['template_type'] ) ? sanitize_text_field( wp_unslash( $_GET['template_type'] ) ) : '';
			$custom_template_type    = isset( $_GET['custom_template_type'] ) ? sanitize_text_field( wp_unslash( $_GET['custom_template_type'] ) ) : '';
			if ( $custom_template_type ) {
				$template_type = $custom_template_type;
			}
			$post_data['post_type']  = 'wp_builder_addon';
			$post_data['post_title'] = isset( $_GET['post_title'] ) ? sanitize_text_field( wp_unslash( $_GET['post_title'] ) ) : 'Woostify Builder #1';
			$post_data               = apply_filters( 'woostify_wp_builder_addon_create_new_post_meta', $post_data );
			$new_post_id             = wp_insert_post( $post_data );

			// Update post meta.
			update_post_meta( $new_post_id, 'woostify_wp_builder_addon_template', $template_type );

			$url = add_query_arg(
				array(
					'post'   => $new_post_id,
					// 'action' => 'elementor',
					'action' => 'edit',
				),
				admin_url( 'post.php' )
			);

			wp_safe_redirect( $url );
			die();
		}


	}

	Woostify_Theme_Builder_Addons::init();

}