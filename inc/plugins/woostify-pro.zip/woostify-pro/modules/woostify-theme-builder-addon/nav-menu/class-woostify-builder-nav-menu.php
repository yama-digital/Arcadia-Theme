<?php
/**
 * Woostify Theme Builder Nav Menu
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Builder_Nav_Menu' ) ) {
	/**
	 * Class for woostify Nav Menu
	 */
	class Woostify_Builder_Nav_Menu {
		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		
		/**
		 * Constructor.
		 */
		public function __construct() {
            global $pagenow;

			add_action( 'after_setup_theme', array( $this, 'init_admin_settings' ), 99 );

			if ( 'nav-menus.php' === $pagenow ) {
				add_action( 'admin_footer', array( $this, 'add_mega_menu_wrap' ) );
                add_action( 'admin_enqueue_scripts', array( $this, 'admin_register_mega_menu_script' ) );
			}
			add_action( 'wp_enqueue_scripts', array( $this, 'register_mega_menu_script' ) );

			add_action( 'init', array(  $this, 'load_walker' ), 1 );
			add_filter( 'wp_nav_menu_args', array( $this, 'modify_nav_menu_args' ) );
			add_filter( 'wp_setup_nav_menu_item', array( $this, 'add_custom_fields_meta' ) );
			
			if ( defined( 'UAGB_VER' ) && version_compare( UAGB_VER, '1.23.0', '>=' ) ) {
				add_action( 'wp_enqueue_scripts', array( $this, 'load_gutenberg_addon_scripts' ) );
			} else {
				add_action( 'wp', array( $this, 'load_gutenberg_addon_scripts' ) );
			}

			add_action( 'wp_ajax_woostify_get_posts_list', array( $this, 'get_post_list_by_query' ) );
			add_action( 'wp_ajax_woostify_load_mega_menu_layout_settings', array( $this, 'load_mega_menu_layout_settings_handler' ) );
			add_action( 'wp_ajax_woostify_save_mega_menu_options', array( $this, 'save_mega_menu_options_handler' ) );

			add_action( 'rest_api_init', array( $this, 'create_rest_routes' ) );

			$this->include_files();
				 
		}

		/**
		 * Include files
		 */
		public function include_files(){

			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/nav-menu/compatibility/class-woostify-builder-nav-gutenberg-compatibility.php';

		}

        /**
		 * Admin settings init
		 */
		public function init_admin_settings() {

            add_action( 'wp_nav_menu_item_custom_fields', array( $this, 'add_custom_fields') , 10, 4 );

        }

		/**
		 * Load UAG scripts and styles.
		 *
		 * @return void
		 *
		 * @since 2.6.0
		 */
		public function load_gutenberg_addon_scripts() {

			$menu_locations = get_nav_menu_locations();

			foreach ( $menu_locations as $menu_id ) {
				$nav_items = wp_get_nav_menu_items( $menu_id );
				
				if ( ! empty( $nav_items ) ) {
					foreach ( $nav_items as $nav_item ) {
						$megamenu_template_id = $nav_item->megamenu_template_id;
						if ( isset( $megamenu_template_id ) && '' != $megamenu_template_id ) {

							if ( class_exists( 'Woostify_Builder_Nav_Gutenberg_Compatibility' ) ) {

								$woostify_nav_gutenberg_instance = new Woostify_Builder_Nav_Gutenberg_Compatibility();
								
								if ( is_callable( array( $woostify_nav_gutenberg_instance, 'enqueue_blocks_assets' ) ) ) {
									$woostify_nav_gutenberg_instance->enqueue_blocks_assets( $megamenu_template_id );
								}
							}
						}
					}
				}
			}
		}

		/**
		 * Function to modify navigation menu parameters.
		 *
		 * @param array $args navigation menu arguments.
		 * @return array modified arguments.
		 */
		public function modify_nav_menu_args( $args ) {

			if ( 'primary' == $args['theme_location'] || 'mobile' == $args['theme_location'] || 'mobile_categories' == $args['theme_location'] ) {
				$args['walker'] = new Woostify_Custom_Nav_Walker();
			}

			return $args;
		}

		/**
		 * Create rest routes
		 */
		public function create_rest_routes() {
			
			register_rest_route(
				'woostify_pro/v1',
				'/mega_menu/(?P<id>\d+)',
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'get_mega_menu_option' ),
					'permission_callback' => array( $this, 'get_mega_menu_option_permission' ),
				)
			);

		}

		/**
		 * Get mega menu option
		 */
		public function get_mega_menu_option( $data ) {

			$menu_id = $data['id'];

			$megamenu_enable = get_post_meta($menu_id,'woostify_menu_item_megamenu_enable',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_enable',true) : 'off';
			$megamenu_settings_width = get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_width',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_width',true) : 'content';
			$megamenu_disable_label = get_post_meta($menu_id,'woostify_menu_item_megamenu_disable_label',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_disable_label',true) : 'off';
			$megamenu_settings_content_src = get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_content_src',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_content_src',true) : 'default';
			$megamenu_custom_text = get_post_meta($menu_id,'woostify_menu_item_megamenu_custom_text',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_custom_text',true) : '';
			$megamenu_template = get_post_meta($menu_id,'woostify_menu_item_megamenu_template',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_template',true) : '';
			$megamenu_template_id = get_post_meta($menu_id,'woostify_menu_item_megamenu_template_id',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_template_id',true) : '';

			$mega_menu_config = array(
				array(
					'name' => 'woostify_menu_item_megamenu_enable',
					'value' => $megamenu_enable,
				),
				array(
					'name' => 'woostify_menu_item_megamenu_settings_width',
					'value' => $megamenu_settings_width,
					'choices' => array(
						'content' => 'Content Width',
						'full' => 'Full Width',
					),
				),
				array(
					'name' => 'woostify_menu_item_megamenu_disable_label',
					'value' => $megamenu_disable_label,
				),
				array(
					'name' => 'woostify_menu_item_megamenu_settings_content_src',
					'value' => $megamenu_settings_content_src,
					'choices' => array(
						'default' => 'Default',
						'custom_text' => 'Custom Text',
						'template' => 'Template',
					),
				),
				array(
					'name' => 'woostify_menu_item_megamenu_custom_text',
					'value' => $megamenu_custom_text,
				),
				array(
					'name' => 'woostify_menu_item_megamenu_template',
					'value' => $megamenu_template,
				),
				array(
					'name' => 'woostify_menu_item_megamenu_template_id',
					'value' => $megamenu_template_id,
				),

			);
			
			return rest_ensure_response( $mega_menu_config );
		}

		/**
		 * Get mega menu option permission
		 */
		public function get_mega_menu_option_permission() {
			return true;
		}

        /**
		 * Add custom megamenu fields data to the menu.
		 *
		 * @access public
		 * @param int    $id menu item id.
		 * @param object $item A single menu item.
		 * @param int    $depth menu item depth.
		 * @param array  $args menu item arguments.
		 * @return void
		 *
		 */
		public function add_custom_fields( $id, $item, $depth, $args ) {
            $item_title = isset( $item->title ) ? $item->title : '';
			?>

			<input type="hidden" class="woostify-nonce-field" value="<?php echo esc_attr( wp_create_nonce( 'woostify-render-opts-' . $id ) ); ?>">

            <p class="description description-wide">
                <a class="button button-secondary button-large woostify-megamenu-opts-btn" data-depth="<?php echo esc_attr( $depth ); ?>" data-menu-id="<?php echo esc_attr( $id ); ?>" data-menu-title="<?php echo esc_attr( $item_title ); ?>">
                    <?php echo esc_html__( 'Woostify Menu Settings', 'woostify-pro' ); ?>
                </a>
            </p>
			<?php
		}

		/**
		 * Add custom menu meta fields data to the menu.
		 *
		 * @param object $menu_item A single menu item.
		 * @return object The menu item.
		 */
		public function add_custom_fields_meta( $menu_item ) {

			$menu_id = $menu_item->ID;
			$menu_item->megamenu_enable = get_post_meta($menu_id,'woostify_menu_item_megamenu_enable',true);
			$menu_item->megamenu_width = get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_width',true);
			$menu_item->megamenu_disable_label = get_post_meta($menu_id,'woostify_menu_item_megamenu_disable_label',true);
			$menu_item->megamenu_content_src = get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_content_src',true);
			$menu_item->megamenu_custom_text = get_post_meta($menu_id,'woostify_menu_item_megamenu_custom_text',true);
			$menu_item->megamenu_template = get_post_meta($menu_id,'woostify_menu_item_megamenu_template',true);
			$menu_item->megamenu_template_id = get_post_meta($menu_id,'woostify_menu_item_megamenu_template_id',true);

			return $menu_item;
		}

		/**
		 * Function to load custom navigation walker.
		 *
		 * @return void.
		 */
		public static function load_walker() {
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/nav-menu/class-woostify-custom-nav-walker.php';
		}

        /**
		 * Add menu options settings popup wrap at footer in admin.
		 *
		 * @return void
		 */
		public function add_mega_menu_wrap() {
			?>
            <div class="woostify-mega-menu-wrap woostify-offcanvas-wrapper" data-menu-id="">
                <div class="woostify-mega-menu-overlay"></div>
                <div class="woostify-mega-menu-content woostify-mm-options-wrap" id="woostify-mega-menu-content">
					<div class="woostify-megamenu-loading-wrapper">
						<div class="spinner-loading"></div>
					</div>
                </div>
            </div>
            <?php
		}

		/**
		 * Load nav menu layuout setting mega menu
		 *
		 */
		public function load_mega_menu_layout_settings_handler(){

			$nav_id = isset($_POST['nav_id'])? $_POST['nav_id'] : '';
			$menu_depth = isset($_POST['menu_depth'])? $_POST['menu_depth'] : '';
			$menu_id = isset($_POST['menu_id'])? $_POST['menu_id'] : '';

			$woostify_render_opts_id = 'woostify-render-opts-'.$menu_id;

			if( empty($nav_id) && empty($menu_id) && !wp_verify_nonce( $_POST('menu_ajax_nonce'), $woostify_render_opts_id ) ){
				wp_send_json_error();
			}

			$megamenu_enable = get_post_meta($menu_id,'woostify_menu_item_megamenu_enable', true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_enable', true) : 'off';
			$megamenu_settings_width = get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_width', true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_width', true) : 'content';
			$megamenu_disable_label = get_post_meta($menu_id,'woostify_menu_item_megamenu_disable_label',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_disable_label',true) : 'off';
			$megamenu_settings_content_src = get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_content_src',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_settings_content_src',true) : 'default';
			$megamenu_custom_text = get_post_meta($menu_id,'woostify_menu_item_megamenu_custom_text',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_custom_text',true) : '';
			$megamenu_template = get_post_meta($menu_id,'woostify_menu_item_megamenu_template',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_template',true) : '';
			$megamenu_template_id = get_post_meta($menu_id,'woostify_menu_item_megamenu_template_id',true)? get_post_meta($menu_id,'woostify_menu_item_megamenu_template_id',true) : '';

			ob_start();
			?>
			<div class="woostify-mega-menu-content-inner">
				<div class="woostify-offcanvas-heading">
					<div class="woostify-actions">
						<button class="mega-menu-close dashicons dashicons-no-alt">
							<span class="screen-reader-text">x</span>
						</button>
						<button class="save-options button button-primary save" id="mega-menu-submit" data-menu-id="<?php echo esc_attr( $menu_id ); ?>">
							<span class="spinner"></span>
							<span><?php echo __('Save Changes','woostify-pro'); ?></span>
						</button>
					</div>
				</div>
				<div class="woostify-offcanvas-content">
					<div class="woostify-menu-details">
						<h3><?php echo __('Woostify Menu Options','woostify-pro'); ?></h3>
					</div>
					<div class="woostify-menu-general-content">
						<?php if( $menu_depth == 0 ): ?>
						<div class="woostify-single-control woostify-settings_menu_item_megamenu woostify-toggle general">
							<div class="woostify-toggle-control-wrapper">
								<span class="woostify-toggle-control-label"><?php echo __('Mega Menu','woostify-pro'); ?></span>
								<span class="woostify-toggle-control-field">
									<input name="woostify_menu_item_megamenu_enable" type="checkbox" class="woostify-checkbox woostify-switch" id="inspector-toggle-control-<?php echo esc_attr( $menu_id ); ?>" value="<?php echo esc_attr($megamenu_enable); ?>" <?php checked( $megamenu_enable, 'on' ); ?>>
									<label for="inspector-toggle-control-<?php echo esc_attr( $menu_id ); ?>" class="woostify-label"></label>
								</span>
							</div>
						</div>
						<div class="woostify-single-control woostify-settings_menu_item_megamenu_width woostify-toggle <?php echo ($megamenu_enable == 'on')? '' : 'woostify-hidden'; ?>">
							<div class="woostify-control-wrapper">
								<span class="woostify-control-label"><?php echo __('Mega Menu Width','woostify-pro'); ?></span>
								<div class="customize-control-content woostify-control-wrap">
									<select class="woostify-select-input" name="woostify_menu_item_megamenu_settings_width" data-value="<?php echo esc_attr($megamenu_settings_width); ?>">
										<option <?php selected( $megamenu_settings_width, 'content'); ?> value="content"><?php echo __('Content','woostify-pro'); ?></option>
										<option <?php selected( $megamenu_settings_width, 'full'); ?> value="full"><?php echo __('Full Width','woostify-pro'); ?></option>
									</select>
								</div>
							</div>
						</div>
						<?php endif; ?>
						<?php if( $menu_depth != 0 ): ?>
						<div class="woostify-single-control woostify-settings_menu_item_title woostify-toggle woostify-title">
							<div class="woostify-toggle-control-wrapper">
								<span class="woostify-toggle-control-label"><?php echo __('Hide Menu Label','woostify-pro'); ?></span>
								<span class="woostify-toggle-control-field">
									<input name="woostify_menu_item_megamenu_disable_label" type="checkbox" class="woostify-checkbox woostify-switch" id="inspector-toggle-control-<?php echo esc_attr( $menu_id ); ?>" value="<?php echo esc_attr($megamenu_disable_label); ?>" <?php checked( $megamenu_disable_label, 'on' ); ?>>
									<label for="inspector-toggle-control-<?php echo esc_attr( $menu_id ); ?>" class="woostify-label"></label>
								</span>
							</div>
						</div>
						<div class="woostify-single-control woostify-settings_menu_item_content_src_title woostify-title woostify-top-section-divider">
							<div class="woostify-control-wrapper">
								<h3><?php echo __('Content Source','woostify-pro'); ?></h3>
							</div>
						</div>
						<div class="woostify-single-control woostify-settings_menu_item_content_src woostify-select">
							<div class="woostify-control-wrapper">
								<span class="woostify-control-label"><?php echo __('Content Source','woostify-pro'); ?></span>
								<div class="customize-control-content woostify-control-wrap">
									<select class="woostify-select-input" name="woostify_menu_item_megamenu_settings_content_src" data-value="<?php echo esc_attr($megamenu_settings_content_src); ?>">
										<option <?php selected( $megamenu_settings_content_src, 'default'); ?> value="default"><?php echo __('Default','woostify-pro'); ?></option>
										<option <?php selected( $megamenu_settings_content_src, 'custom_text'); ?> value="custom_text"><?php echo __('Custom Text','woostify-pro'); ?></option>
										<option <?php selected( $megamenu_settings_content_src, 'template'); ?> value="template"><?php echo __('Template','woostify-pro'); ?></option>
									</select>
								</div>
							</div>
						</div>
						<div class="woostify-single-control woostify-settings_menu_item_megamenu_custom_text woostify-custom_text woostify-content-src <?php echo ($megamenu_settings_content_src == 'custom_text')? '' : 'woostify-hidden'; ?>">
							<div class="woostify-control-wrapper">
								<span class="woostify-control-label"><?php echo __('Custom Text','woostify-pro'); ?></span>
								<textarea name="woostify_menu_item_megamenu_custom_text" class="components-textarea-control__input" id="inspector-textarea-control-<?php echo esc_attr( $menu_id ); ?>" rows="4"><?php echo esc_html__( $megamenu_custom_text ) ; ?></textarea>
							</div>
						</div>
						<div class="woostify-single-control woostify-settings_menu_item_megamenu_template woostify-template woostify-content-src <?php echo ($megamenu_settings_content_src == 'template')? '' : 'woostify-hidden'; ?>">
							<div class="woostify-control-wrapper">
								<span class="woostify-control-label"><?php echo __('Template','woostify-pro'); ?></span>
								<div class="woostify-option-input-container">
									<input class="form-control woostify-input-template" type="text" name="woostify_menu_item_megamenu_template" value="<?php echo esc_attr( $megamenu_template ); ?>" placeholder="<?php echo __('Search Pages/ Posts / Reusable Blocks','woostify-pro'); ?>" id="inspector-template-control-<?php echo esc_attr( $menu_id ); ?>" data-slug="megamenu_template" data-template-id="<?php echo esc_attr( $megamenu_template_id ); ?>">
									<input type="hidden" name="woostify_menu_item_megamenu_template_id" value="<?php echo esc_attr( $megamenu_template_id ); ?>">
								</div>
							</div>
						</div>
						<?php endif; ?>

					</div>
				</div>
			</div>
			<?php
						
			$output = ob_get_clean();

			wp_send_json_success( $output );

		}

		/**
		 * Save mega menu options
		 */
		public function save_mega_menu_options_handler() {
			if ( ! current_user_can( 'edit_theme_options' ) ) {
				wp_send_json_error();
			}

			$menu_id = isset( $_POST['menu_item_id'] ) ? sanitize_text_field( wp_unslash( $_POST['menu_item_id'] ) ) : '';
			$woostify_render_opts_id = 'woostify-render-opts-'.$menu_id;

			if( empty($menu_id) && !wp_verify_nonce( $_POST('menu_ajax_nonce'), $woostify_render_opts_id ) ){
				wp_send_json_error();
			}

			$options = isset( $_POST['options'] ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['options'] ) ), true ) : array();

			if ( ! empty( $options ) ) {
				foreach ( $options as $k => $v ) {
					$value = sanitize_text_field( wp_unslash( $v ) );
					update_post_meta( $menu_id, $k, $value );
				}
			}

			$data = array(
				'menu_id' => $menu_id,
			);

			wp_send_json_success( $data );
		}

		/**
		 * Function to get posts lists to display.
		 *
		 * @return void.
		 */
		public function get_post_list_by_query() {

			$menu_id = isset( $_POST['menu_item_id'] ) ? sanitize_text_field( wp_unslash( $_POST['menu_item_id'] ) ) : '';
			$woostify_render_opts_id = 'woostify-render-opts-'.$menu_id;

			if( empty($menu_id) && !wp_verify_nonce( $_POST('menu_ajax_nonce'), $woostify_render_opts_id ) ){
				wp_send_json_error();
			}

			$search_string = isset( $_POST['q'] ) ? sanitize_text_field( $_POST['q'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$data          = array();
			$result        = array();

			$post_types['"BuilderAddon"'] = 'wp_builder_addon';

			// $post_types['Posts'] = 'post'; 
			// $post_types['Pages'] = 'page';

			foreach ( $post_types as $key => $post_type ) {

				$data = array();

				$query = new WP_Query(
					array(
						's'              => $search_string,
						'post_type'      => $post_type,
						'posts_per_page' => 10,
					)
				);

				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();
						$title  = get_the_title();
						$title .= ( 0 != $query->post->post_parent ) ? ' (' . get_the_title( $query->post->post_parent ) . ')' : '';
						$id     = get_the_id();
						$data[] = array(
							'id'   => $id,
							'text' => $title,
						);
					}
				}

				if ( is_array( $data ) && ! empty( $data ) ) {
					$result[] = array(
						'text'     => $key,
						'children' => $data,
					);
				}
			}

			$data = array();

			wp_reset_postdata();

			// return the result in json.
			wp_send_json_success( $result );
		}

        /**
		 * Register Admin Script for Mega menu.
		 *
		 */
		public function admin_register_mega_menu_script() {

            wp_enqueue_style(
                'woostify-builder-addon-mega-menu-options',
                WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/nav-menu/assets/css/mega-menu-options.css',
                array(),
                WOOSTIFY_PRO_VERSION
            );

            wp_enqueue_script(
                'woostify-builder-addon-mega-menu-options',
                WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/nav-menu/assets/js/mega-menu-options' . woostify_suffix() . '.js',
                array('jquery'),
                WOOSTIFY_PRO_VERSION,
                true
            );

        }

		/**
		 * Register Script for Mega menu.
		 *
		 */
		public function register_mega_menu_script() {

            wp_enqueue_style(
                'woostify-builder-addon-mega-menu-frontend',
                WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/nav-menu/assets/css/mega-menu.css',
                array(),
                WOOSTIFY_PRO_VERSION
            );

            wp_enqueue_script(
                'woostify-builder-addon-mega-menu-frontend',
                WOOSTIFY_PRO_MODULES_URI . 'woostify-theme-builder-addon/nav-menu/assets/js/mega-menu-frontend' . woostify_suffix() . '.js',
                array('jquery'),
                WOOSTIFY_PRO_VERSION,
                true
            );

			$woostify_localize = array(
				'headerBreakpoint' => '992',
				'isRtl'            => is_rtl(),
			);

			wp_localize_script( 'woostify-builder-addon-mega-menu-frontend', 'woostify_nav_menu', apply_filters( 'woostify_nav_menu_js_localize', $woostify_localize ) );

			$template_ids = $this->get_template_ids( 'woostify_builder_content_hook' );

			if ( '' !== $template_ids ) {
				
				foreach ($template_ids as $key => $template_id) {
					if ( class_exists( 'Elementor\Plugin' ) ) {
						if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
							$css_file = new \Elementor\Core\Files\CSS\Post( $template_id );
						} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
							$css_file = new \Elementor\Post_CSS_File( $template_id );
						}
						$css_file->enqueue();
					}
				}

			}

        }

		/**
		 * Get content action of page builder elementor
		 */
		public function get_active_page_builder( $post_id ) {

			if ( is_elementor_activated( $post_id ) ) {
				$elementor_instance = Elementor\Plugin::instance();
				echo $elementor_instance->frontend->get_builder_content_for_display( $post_id );
			} else {
				$this->render_content( $post_id );
			}

		}

		/**
		 * Get content action post in editor
		 */
		public function render_content( $post_id ) {
			$get_posts = get_posts(array(
				'post_type'   => 'wp_builder_addon',
				'posts_per_page' => 1,
				'p' => $post_id,
			));
			$current_post = $get_posts[0];
			ob_start();
			echo do_shortcode( $current_post->post_content );
			echo do_shortcode( ob_get_clean() );

		}

		/**
		 * Get ids popup
		 */
		public function get_template_ids( $type ) {

			$option = [
				'location'  => 'woostify_builder_target_include_locations',
				'exclusion' => 'woostify_builder_target_exclude_locations',
				'users'     => 'woostify_builder_target_users_rule',
			];
	
			$wp_builder_templates = Woostify_Theme_Builder_Addons_Condition::instance()->get_posts_by_conditions( 'wp_builder_addon', $option );
		
			if( $wp_builder_templates ){
				$template_ids = array();
				foreach ( $wp_builder_templates as $key => $template ) {
					if ( get_post_meta( absint( $template['id'] ), 'woostify_wp_builder_addon_template', true ) === $type ) {
						$template_ids[] = $template['id'];
						
					}
				}
				return $template_ids;
			}
			
			return '';
		}

		/**
		 * render template
		 */
		public function render_template( $template_id ,$type = 'woostify_builder_content_hook') {

			$template_ids = $this->get_template_ids( $type );
		
			if ( !empty( $template_ids ) && in_array($template_id, $template_ids) ) {

				$post_id = $template_id;

				$this->get_active_page_builder( $post_id );
				
			}
		}

		/**
		 * Get template exist
		 */
		public function template_exist( $template_id = false ) {
			
			$time_duration_eligibility = Woostify_Theme_Builder_Addons_Time_Duration::instance()->get_time_duration_eligibility( $template_id );

			if( ! $time_duration_eligibility ){
				return false;
            }

			if( $template_id ){
				return true;
			}

			return false;
        }



    }

	/**
	 * Initialize class object with 'get_instance()' method
	 */
	Woostify_Builder_Nav_Menu::get_instance();

}