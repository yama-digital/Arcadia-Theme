/**
 * Frontend script nav menu
 *
 * @package woostify
 */

/* global  Woostify Builder Nav Menu*/
;(function ($) {  

    'use strict';

   
    function apply_megamenu_width_styles() {

        var items = document.getElementsByClassName("woostify-megamenu-li");
        
        if (items.length == 0) {
            return;
        }

        [].slice.call(items).forEach(function (container) {
            var woostify_container = jQuery(container).parents(".woostify-container"),
                $main_container = woostify_container.children('.site-navigation'),
                $full_width_main_container = woostify_container.parent(),
                $this = jQuery(container);
            
            // Full width mega menu
            if (
                $this.hasClass("full-width-mega") ||
                $this.hasClass("full-stretched-width-mega")
            ) {
                $main_container = jQuery($main_container).closest(".woostify-container");
            }

            if (
                parseInt(jQuery(window).width()) > parseInt(992)
            ) {
                if ( $main_container.length == 0 ) {
                    return;
                }

                var $menuWidth = $main_container.width(),
                    $menuPosition = $main_container.offset(),
                    $menuItemPosition = $this.offset(),
                    positionLeft = $menuItemPosition?.left - ($menuPosition?.left + parseFloat($main_container.css("paddingLeft"))),
                    positionRight = $menuWidth - ($menuItemPosition?.left + $menuPosition?.left);

                var $fullMenuWidth = $full_width_main_container.width(),
                    $fullMenuPosition = $full_width_main_container.offset(),
                    fullPositionLeft = $menuItemPosition?.left - ($fullMenuPosition?.left + parseFloat($full_width_main_container.css("paddingLeft")));
                    
                if ($this.hasClass("full-width-mega")) {
                    
                    $this
                        .find(".woostify-megamenu")
                        .css({
                            left: "-" + fullPositionLeft + "px",
                            width: $fullMenuWidth,
                        });

                } else if ($this.hasClass("full-stretched-width-mega")) {

                    $this
                        .find(".woostify-full-megamenu-wrapper")
                        .css({
                            left: "-" + fullPositionLeft + "px",
                            width: $fullMenuWidth,
                        });

                } else {
                    if (woostify_nav_menu.isRtl) {

                        $this
                            .find(".woostify-megamenu")
                            .css({ right: "-" + positionRight + "px", width: $menuWidth });
                    } else {
                        $this
                            .find(".woostify-megamenu")
                            .css({ left: "-" + positionLeft + "px", width: $menuWidth });
                    }
                }
                
            } else {
        
                if (woostify_nav_menu.isRtl) {
                    $this
                        .find(".woostify-megamenu")
                        .css({ right: "", width: "" });
                    $this
                        .find(".woostify-full-megamenu-wrapper")
                        .css({ right: "", width: "" });
                } else {
                    $this
                        .find(".woostify-megamenu")
                        .css({ left: "", width: "" });
                    $this
                        .find(".woostify-full-megamenu-wrapper")
                        .css({ left: "", width: "" });
                }
            }
    
        });
    }
    
    apply_megamenu_width_styles();

    window.addEventListener('resize',function (e) {
        apply_megamenu_width_styles();
    });

    document.addEventListener(
        'DOMContentLoaded',
        function() {
            apply_megamenu_width_styles();
        }
    );
    
    
})(jQuery);