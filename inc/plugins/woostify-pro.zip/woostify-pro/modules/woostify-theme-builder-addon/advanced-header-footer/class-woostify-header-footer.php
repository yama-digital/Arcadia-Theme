<?php
/**
 * Woostify template builder Header Footer
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Header_Footer_Builder_Addons' ) ) {

    class Woostify_Header_Footer_Builder_Addons{

        /**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 * Instance of Elemenntor Frontend class.
		 *
		 * @var \Elementor\Frontend()
		 */
		private static $elementor_instance;

		/**
		 * Post ID
		 *
		 * @var int
		 */
		public $post_id;

		/**
		 * Post type
		 *
		 * @var String
		 */
		public $post_type;

        /**
		 *  Initiator
		 */
		public static function init() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

        public function __construct() {
			if ( class_exists( 'Elementor\Plugin' ) ) {
				self::$elementor_instance = Elementor\Plugin::instance();
			}
			add_action( 'wp', array( $this, 'wp_action' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 9999 );
			add_filter( 'body_class', array( $this, 'add_body_classes' ) );

        }

		public function wp_action() {
			
			$header_template_id     = '';
			$new_header_template_id = $this->template_hf_id( 'woostify_builder_header' );
			
			if ( $new_header_template_id ) {
				$header_template_id = $new_header_template_id;
			}

			if ( $header_template_id ) {

				if ( ! woostify_elementor_has_location( 'header' ) ) {
					// Header.
					remove_action( 'woostify_theme_header', 'woostify_template_header' );
					add_action( 'woostify_theme_header', 'woostify_view_open', 0 );
					add_action( 'woostify_theme_header', array( $this, 'render_header_template' ), 20 );
				}
			}

			$footer_template_id     = '';
			$new_footer_template_id = $this->template_hf_id( 'woostify_builder_footer' );

			if ( $new_footer_template_id ) {
				$footer_template_id = $new_footer_template_id;
			}

			if( $footer_template_id ){
				if ( ! woostify_elementor_has_location( 'footer' ) ) {
					// Footer.
					remove_action( 'woostify_theme_footer', 'woostify_template_footer' );
					add_action( 'woostify_theme_footer', array( $this, 'render_footer_template' ), 20 );
				}
			}

		}

		/**
		 * Add body class for header footer builder template
		 *
		 * @return string
		 */
		public function add_body_classes( $classes ) {

			if ( is_woostify_builder_enabled( 'woostify_builder_header' ) ) {
				$template_id = '';
				$new_id = $this->template_hf_id( 'woostify_builder_header' );
				$classes[] = 'wp-builder-header';

				if ( $new_id ) {
					$template_id = $new_id;
				}
	
				if ( $template_id ) {
					// header setting
					$sticky    = get_post_meta( $template_id, 'woostify_builder_header_footer_stick', true );
					$class = $sticky === 'sticky' ? 'wp-builder-header-has-sticky' : '';
					$classes[] = 'wp-builder-header-'.$template_id;
					$classes[] = $class;
				}
				
			}
	
			if ( is_woostify_builder_enabled( 'woostify_builder_footer' ) ) {
				$template_id = '';
				$new_id = $this->template_hf_id( 'woostify_builder_footer' );
				$classes[] = 'wp-builder-footer';

				if ( $new_id ) {
					$template_id = $new_id;
				}
	
				if ( $template_id ) {
					// footer setting
					$sticky    = get_post_meta( $template_id, 'woostify_builder_header_footer_stick', true );
					$class = $sticky === 'sticky' ? 'wp-builder-footer-has-sticky' : '';
					$classes[] = 'wp-builder-footer-'.$template_id;
					$classes[] = $class;
				}

			}

			
			return $classes;
		}

		/**
		 * Get template id header footer
		 */
		public function template_hf_id( $template = 'woostify_builder_header' ) {
			global $post;

			if ( ! empty( $post ) ) {
				$this->post_id   = $post->ID;
				$this->post_type = get_post_type( $post->ID );
			}

			$post_id = $this->post_id;

			$maintenance_mode     = get_option( 'elementor_maintenance_mode_mode' );
			$maintenance_template = get_option( 'elementor_maintenance_mode_template_id' );
			if ( 'coming_soon' === $maintenance_mode && $maintenance_template != '' ) {
				return false;
			}

			$get_template_id = Woostify_Theme_Builder_Addons::init()->get_template_id( $template );

			if( $get_template_id ){
				return $get_template_id;
			}

			return false;
        }

		/**
		 * Get content action of page builder elementor
		 */
		public function get_active_page_builder( $post_id ) {
			
			if ( is_elementor_activated( $post_id ) ) {
				$elementor_instance = Elementor\Plugin::instance();
				echo do_shortcode($elementor_instance->frontend->get_builder_content_for_display( $post_id ));
			} else {
				$this->render_content( $post_id );
			}

		}

		/**
		 * Get content action post in editor
		 */
		public function render_content( $post_id ) {
            $output       = '';
            $current_post = get_post( $post_id, OBJECT );
            if ( has_blocks( $current_post ) ) {
                $blocks = parse_blocks( $current_post->post_content );
                foreach ( $blocks as $block ) {
                    $output .= render_block( $block );
                }
            } else {
                $output = $current_post->post_content;
            }
			ob_start();
            echo do_shortcode($output );
            echo do_shortcode( ob_get_clean() );
		}
        
		/**
		 * Render header template
		 */
		public function render_header_template() {
			$template_id = '';
			$new_id = $this->template_hf_id( 'woostify_builder_header' );

			if ( $new_id ) {
				$template_id = $new_id;
			}

			if ( ! $template_id ) {
				return;
			}

			// header setting
			$sticky    = get_post_meta( $template_id, 'woostify_builder_header_footer_stick', true );
			$shrink    = get_post_meta( $template_id, 'woostify_builder_header_shrink', true );
			$sticky_on = get_post_meta( $template_id, 'woostify_builder_header_footer_stick_on', true );

			// responsive visibility
			$desktop = get_post_meta( $template_id, 'woostify_builder_responsive_desktop', true );
			$tablet  = get_post_meta( $template_id, 'woostify_builder_responsive_tablet', true );
			$mobile  = get_post_meta( $template_id, 'woostify_builder_responsive_mobile', true );

			$classes[] = 'woostify-header-template-builder';
			$classes[] = 'woostify-header-builder-'.$template_id;
			$classes[] = $sticky === 'sticky' ? 'header-has-sticky' : '';
			$classes[] = $sticky === 'sticky' && 'shrink' === $shrink ? 'header-has-shrink' : '';
			$classes[] = $sticky === 'sticky' ? 'header-sticky-on-' . $sticky_on : '';

			$classes[] = $desktop === 'desktop' ? 'wp-desktop-hidden' : '';
			$classes[] = $tablet === 'tablet' ? 'wp-tablet-hidden' : '';
			$classes[] = $mobile === 'mobile' ? 'wp-mobile-hidden' : '';

			$classes   = implode(' ', $classes );

			$time_duration_eligibility = Woostify_Theme_Builder_Addons_Time_Duration::instance()->get_time_duration_eligibility($template_id);
			
			if( !$time_duration_eligibility ){
				return;
            }
			
			?>
			<div <?php post_class( $classes, $template_id); ?>> 
				<div class="woostify-header-template-builder-inner">
					<?php $this->get_active_page_builder( $template_id ); ?>
				</div>
			</div>
			<?php

		}

		/**
		 * Render footer template
		 */
		public function render_footer_template() {
			$template_id = '';
			$new_id = $this->template_hf_id( 'woostify_builder_footer' );

			if ( $new_id ) {
				$template_id = $new_id;
			}

			if ( ! $template_id ) {
				return;
			}
			
			// header setting
			$sticky    = get_post_meta( $template_id, 'woostify_builder_header_footer_stick', true );
			$sticky_on = get_post_meta( $template_id, 'woostify_builder_header_footer_stick_on', true );

			// responsive visibility
			$desktop = get_post_meta( $template_id, 'woostify_builder_responsive_desktop', true );
			$tablet  = get_post_meta( $template_id, 'woostify_builder_responsive_tablet', true );
			$mobile  = get_post_meta( $template_id, 'woostify_builder_responsive_mobile', true );

			$classes[] = 'woostify-footer-template-builder';
			$classes[] = 'woostify-footer-builder-'.$template_id;
			$classes[] = $sticky === 'sticky' ? 'footer-has-sticky' : '';
			$classes[] = $sticky === 'sticky' ? 'footer-sticky-on-' . $sticky_on : '';

			$classes[] = $desktop === 'desktop'? 'wp-desktop-hidden' : '';
			$classes[] = $tablet === 'tablet' ? 'wp-tablet-hidden' : '';
			$classes[] = $mobile === 'mobile' ? 'wp-mobile-hidden' : '';

			$classes = implode(' ', $classes );

			$time_duration_eligibility = Woostify_Theme_Builder_Addons_Time_Duration::instance()->get_time_duration_eligibility($template_id);
			
			if( !$time_duration_eligibility ){
				return;
            }

			?>
			<div <?php post_class( $classes, $template_id); ?>>
				<div class="woostify-footer-template-builder-inner">
					<?php $this->get_active_page_builder( $template_id ); ?>
				</div>
			</div>
			<?php

		}


		/**
		 * Enqueue styles and scripts.
		 */
		public function enqueue_scripts() {
			$header_id     = '';
			$footer_id     = '';
			$new_header_id = $this->template_hf_id( 'woostify_builder_header' );
			$new_footer_id = $this->template_hf_id( 'woostify_builder_footer' );

			if ( $new_header_id ) {
				$header_id = $new_header_id;
			}
			if ( $new_footer_id ) {
				$footer_id = $new_footer_id;
			}

			if ( $header_id ) {
				if( is_elementor_activated( $header_id ) ){
					if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
						$css_file = new \Elementor\Core\Files\CSS\Post( $header_id );
					} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
						$css_file = new \Elementor\Post_CSS_File( $header_id );
					}
					
					$css_file->enqueue();
				}else{
					if ( class_exists( 'Woostify_Builder_Gutenberg_Compatibility' ) ) {
						$woostify_gutenberg_instance = new Woostify_Builder_Gutenberg_Compatibility();
						if ( is_callable( array( $woostify_gutenberg_instance, 'enqueue_blocks_assets' ) ) ) {
							$woostify_gutenberg_instance->enqueue_blocks_assets( $header_id );
						}
					}
				}

			}

			if ( $footer_id ) {
				if( is_elementor_activated( $footer_id ) ){
					if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
						$css_file = new \Elementor\Core\Files\CSS\Post( $footer_id );
					} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
						$css_file = new \Elementor\Post_CSS_File( $footer_id );
					}

					$css_file->enqueue();
				}else{
					if ( class_exists( 'Woostify_Builder_Gutenberg_Compatibility' ) ) {
						$woostify_gutenberg_instance = new Woostify_Builder_Gutenberg_Compatibility();
						if ( is_callable( array( $woostify_gutenberg_instance, 'enqueue_blocks_assets' ) ) ) {
							$woostify_gutenberg_instance->enqueue_blocks_assets( $footer_id );
						}
					}
				}
				
			}
			
		}

    }

    Woostify_Header_Footer_Builder_Addons::init();

}