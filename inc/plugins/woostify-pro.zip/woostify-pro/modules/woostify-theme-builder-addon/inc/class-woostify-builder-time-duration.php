<?php
/**
 * Woostify template builder addons
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Theme_Builder_Addons_Time_Duration' ) ) {

    class Woostify_Theme_Builder_Addons_Time_Duration {
        /**
         * Instance of Woostify_Theme_Builder_Addons_Time_Duration
         *
         * @var Woostify_Theme_Builder_Addons_Time_Duration
         */
        private static $instance = null;

        /**
         * Instance of Woostify_Theme_Builder_Addons_Time_Duration
         *
         * @return Woostify_Theme_Builder_Addons_Time_Duration Instance of Woostify_Theme_Builder_Addons_Time_Duration
         */
        public static function instance() {
            if ( ! isset( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         */
        public function __construct() {

            add_action( 'save_post', array( $this, 'save_wp_builder_addon_time_duration' ), 10, 2 );

        }

        /**
		 * Get the timezone string as selected in wp general setting.
		 *
		 * @return false|mixed|string|void
		 */
		public function get_wp_timezone_string() {

			$current_offset = get_option( 'gmt_offset' );
			$tzstring       = get_option( 'timezone_string' );

			if ( false !== strpos( $tzstring, 'Etc/GMT' ) ) {
				$tzstring = '';
			}

			if ( empty( $tzstring ) ) {
				if ( 0 == $current_offset ) {
					$tzstring = 'UTC+0';
				} elseif ( $current_offset < 0 ) {
					$tzstring = 'UTC' . $current_offset;
				} else {
					$tzstring = 'UTC+' . $current_offset;
				}
			}

			return $tzstring;
		}

        /**
		 * Check if post eligible to show on time duration
		 *
		 *  @param int $post_id post id.
		 */
		public function get_time_duration_eligibility( $post_id ) {

			$time_duration_enable = get_post_meta( $post_id, 'wp_builder_time_duration_enable', true );
            $time_duration_start_date_timezone = get_post_meta( $post_id, 'wp_builder_time_duration_start_date_timezone', true );
			$time_duration_end_date_timezone = get_post_meta( $post_id, 'wp_builder_time_duration_end_date_timezone', true );
            
			if ( isset( $time_duration_enable ) && 'enabled' !== $time_duration_enable ) {
				return true; // Eligible to display as not enabled time duration.
			}
            
			$start_dt   = isset( $time_duration_start_date_timezone ) ? $time_duration_start_date_timezone : false;
			$end_dt     = isset( $time_duration_end_date_timezone ) ? $time_duration_end_date_timezone : false;
			$current_dt = strtotime( current_time( 'mysql' ) );
            
			if ( $start_dt && $start_dt > $current_dt ) {
				return false; // Not eligible if not started yet.
			}
            
			if ( $end_dt && $end_dt < $current_dt ) {
				return false; // Not eligible if already time passed.
			}
            
			return true; // Fallback true.
		}

        public function render_time_duration_settings_field() {

            global $post;

            $time_duration_enable = get_post_meta( $post->ID, 'wp_builder_time_duration_enable', true );
            $time_enable = !empty( $time_duration_enable )? esc_attr( $time_duration_enable ) : '';

            $time_duration_start_date = get_post_meta( $post->ID,'wp_builder_time_duration_start_date', true );
            $time_duration_start_date_timezone = get_post_meta( $post->ID,'wp_builder_time_duration_start_date_timezone', true );
            $time_start_date = !empty( $time_duration_start_date )? esc_attr( $time_duration_start_date ) : '';
            $time_start_date_timezone = !empty( $time_duration_start_date_timezone )? esc_attr( $time_duration_start_date_timezone ) : '';

            $time_duration_end_date = get_post_meta( $post->ID,'wp_builder_time_duration_end_date', true );
            $time_duration_end_date_timezone = get_post_meta( $post->ID,'wp_builder_time_duration_end_date_timezone', true );
            $time_end_date = !empty( $time_duration_end_date )? esc_attr( $time_duration_end_date ) : '';
            $time_end_date_timezone = !empty( $time_duration_end_date_timezone )? esc_attr( $time_duration_end_date_timezone ) : '';

            ?>
            <div class="ui-popup time-duration">
                <div class="ui-popup-inner">
                    <span type="button" class="ui-popup-close">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false">
                            <path d="M12 13.06l3.712 3.713 1.061-1.06L13.061 12l3.712-3.712-1.06-1.06L12 10.938 8.288 7.227l-1.061 1.06L10.939 12l-3.712 3.712 1.06 1.061L12 13.061z"></path>
                        </svg>
                    </span>
                    <div class="ui-popup-content-top">
                        <h4 class="ui-popup-heading"><?php esc_html_e( 'Time Duration','woostify-pro' ); ?></h4>
                    </div>
                    <div class="ui-popup-content">
                        <div class="ui-popup-content-body">
                            <div class="woostify-metabox-option-settings time-duration-enable">
                                <h4 class="label"><?php esc_html_e( 'Enable', 'woostify-pro' ); ?></h4>
                                <div class="woostify-metabox-option-wrap components-toggle-wrap">
                                    <div class="components-toggle">
                                        <input class="components-toggle__input" type="checkbox" name="wp_builder_time_duration_enable" id="wp-builder-time-duration-enable" value="enabled" <?php checked( $time_enable, 'enabled' ); ?>>
                                        <span class="components-toggle__track"></span>
                                        <span class="components-toggle__thumb"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="woostify-time-duration-date <?php echo ($time_enable == 'enabled')? 'enabled' : '' ?>">
                                <div class="woostify-metabox-option-settings time-duration-start-date">
                                    <h4 class="label"><?php esc_html_e( 'Start Date/Time', 'woostify-pro' ); ?></h4>
                                    <div class="woostify-metabox-option-wrap">
                                        <span class="woostify-schedule-date-time">
                                            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" aria-hidden="true" focusable="false">
                                                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm.5 16c0 .3-.2.5-.5.5H5c-.3 0-.5-.2-.5-.5V7h15v12zM9 10H7v2h2v-2zm0 4H7v2h2v-2zm4-4h-2v2h2v-2zm4 0h-2v2h2v-2zm-4 4h-2v2h2v-2zm4 0h-2v2h2v-2z"></path>
                                            </svg>
                                            <input type="hidden" id="wp-builder-time-duration-start-date-timezone" name="wp_builder_time_duration_start_date_timezone" value="<?php echo $time_start_date_timezone; ?>">
                                            <input placeholder="<?php esc_attr_e( 'Click to pick a date', 'woostify-pro' ); ?>" class="woostify-builder-advanced-date-time-input" type="text" id="wp-builder-time-duration-start-date" name="wp_builder_time_duration_start_date"  value="<?php echo $time_start_date; ?>" readonly />
                                        </span>
                                    </div>
                                </div>
                                <div class="woostify-metabox-option-settings time-duration-end-date">
                                    <h4 class="label"><?php esc_html_e( 'End Date/Time', 'woostify-pro' ); ?></h4>
                                    <div class="woostify-metabox-option-wrap">
                                        <span class="woostify-schedule-date-time">
                                            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" aria-hidden="true" focusable="false">
                                                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm.5 16c0 .3-.2.5-.5.5H5c-.3 0-.5-.2-.5-.5V7h15v12zM9 10H7v2h2v-2zm0 4H7v2h2v-2zm4-4h-2v2h2v-2zm4 0h-2v2h2v-2zm-4 4h-2v2h2v-2zm4 0h-2v2h2v-2z"></path>
                                            </svg>
                                            <input type="hidden" id="wp-builder-time-duration-end-date-timezone" name="wp_builder_time_duration_end_date_timezone" value="<?php echo $time_end_date_timezone; ?>">
                                            <input placeholder="<?php esc_attr_e( 'Click to pick a date', 'woostify-pro' ); ?>" class="woostify-builder-advanced-date-time-input" type="text" id="wp-builder-time-duration-end-date" name="wp_builder_time_duration_end_date" value="<?php echo $time_end_date; ?>" readonly />
                                        </span>
                                    </div>
                                </div>
                                <div class="woostify-metabox-option-settings time-duration-timezone">
                                    <h4 class="label"><?php esc_html_e( 'Timezone:', 'woostify-pro' ); ?></h4>
                                    <div class="woostify-metabox-option-wrap">
                                        <div class="components-datetime__timezone">
                                            <a target="_blank" href="<?php echo esc_url( admin_url( 'options-general.php' ) ); ?>"> <?php echo esc_html( $this->get_wp_timezone_string() ); ?> </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="ui-popup-content-bottom">
                            <span class="description"><?php esc_html_e( 'Make sure to save your post for change to take effect','woostify-pro' ); ?></span>
                            <button type="button" class="button return-to-post" data-post-id="<?php echo $post->ID; ?>">
                                <?php esc_html_e( 'Return To Post', 'woostify-pro' ); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }

        function save_wp_builder_addon_time_duration( $post_id, $post ) {

            $post_type = get_post_type( $post_id );
			if ( 'wp_builder_addon' !== $post_type ) {
				return;
			}
			
			$nonce_key = 'woostify_metabox_settings_wp_builder_addon';
            
            // verify nonce
			if ( !isset( $_POST[$nonce_key] ) && !wp_verify_nonce( sanitize_text_field($_POST[$nonce_key]), $nonce_key ) ) {
				return 'nonce not verified';
			}

			// check permissions
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return 'cannot edit post';
			}

            $wp_builder_time_duration_enable = isset( $_POST['wp_builder_time_duration_enable'] )? $_POST['wp_builder_time_duration_enable'] : '';
            update_post_meta( $post_id ,'wp_builder_time_duration_enable', $wp_builder_time_duration_enable);
            
            $wp_builder_time_duration_start_date = isset( $_POST['wp_builder_time_duration_start_date'] )? $_POST['wp_builder_time_duration_start_date'] : '';
            $wp_builder_time_duration_start_date_timezone = isset( $_POST['wp_builder_time_duration_start_date_timezone'] )? $_POST['wp_builder_time_duration_start_date_timezone'] : '';

            if( $wp_builder_time_duration_start_date ){
                update_post_meta( $post_id ,'wp_builder_time_duration_start_date', $wp_builder_time_duration_start_date);
                update_post_meta( $post_id ,'wp_builder_time_duration_start_date_timezone', $wp_builder_time_duration_start_date_timezone);
            }

            $wp_builder_time_duration_end_date = isset( $_POST['wp_builder_time_duration_end_date'] )? $_POST['wp_builder_time_duration_end_date'] : '';
            $wp_builder_time_duration_end_date_timezone = isset( $_POST['wp_builder_time_duration_end_date_timezone'] )? $_POST['wp_builder_time_duration_end_date_timezone'] : '';

            if( $wp_builder_time_duration_end_date ){
                update_post_meta( $post_id ,'wp_builder_time_duration_end_date', $wp_builder_time_duration_end_date);
                update_post_meta( $post_id ,'wp_builder_time_duration_end_date_timezone', $wp_builder_time_duration_end_date_timezone);
            }

        }

    }

    Woostify_Theme_Builder_Addons_Time_Duration::instance();
}