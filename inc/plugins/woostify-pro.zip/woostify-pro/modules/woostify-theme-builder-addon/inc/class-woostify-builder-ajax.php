<?php
/**
 * Woostify template builder addons
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Theme_Builder_Addons_Ajax' ) ) {
	/**
	 * Class for woostify builder addon.
	 */

    class Woostify_Theme_Builder_Addons_Ajax{
		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

        /**
		 *  Initiator
		 */
		public static function init() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
            add_action( 'wp_ajax_woostify_pro_builder_select_template', array( $this, 'woostify_wp_builder_addon_select_template_func' ) );
            add_action( 'wp_ajax_nopriv_woostify_pro_builder_select_template', array( $this, 'woostify_wp_builder_addon_select_template_func' ) );

        }

		/**
		 * Ajax builder select template.
		 */
        public function woostify_wp_builder_addon_select_template_func() {
            check_ajax_referer('wp_builder_template_type_ajax_nonce');
			
			$template = isset( $_POST['wp_builder_template'] ) ? sanitize_text_field( $_POST['wp_builder_template'] ) : 'default'; //phpcs:ignore
			$tenplate_id = isset( $_POST['wp_builder_template_id'] ) ? sanitize_text_field( $_POST['wp_builder_template_id'] ) : '';
			$post = get_post( $tenplate_id );
			$stored = get_post_meta( $tenplate_id );

			$sticky = $stored['woostify_builder_header_footer_stick'][0];
			$shrink = $stored['woostify_builder_header_shrink'][0];
			$sticky_on = $stored['woostify_builder_header_footer_stick_on'][0];

			$desktop = $stored['woostify_builder_responsive_desktop'][0];
			$tablet = $stored['woostify_builder_responsive_tablet'][0];
			$mobile = $stored['woostify_builder_responsive_mobile'][0];

			$html = '';

			if( $template !== 'default' ){
				ob_start();

				?>
				<?php if ( $template == 'woostify_builder_header' || $template =='woostify_builder_footer' ) {?>
					<div class="input-wrapper template-header-footer">
						<h3 class="components-panel-title">
							<button type="button" aria-expanded="true" class="components-button components-panel__body-toggle components-panel-toggle active">
								<?php esc_html_e( 'Sticky Settings', 'woostify-pro' ); ?>
								<span aria-hidden="true">
									<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
								</span>
							</button>
						</h3>

						<div class="woostify-metabox-option-box is-opened">
							<div class="woostify-metabox-option">
								<div class="components-toggle-wrap">
									<span class="components-toggle">
										<input type="checkbox" class="components-toggle__input" name="woostify_builder_header_footer_stick" id="woostify-builder-header-footer-stick" value="sticky" <?php checked( $sticky, 'sticky' ); ?> data-sticky="<?php echo $sticky; ?>">
										<span class="components-toggle__track"></span>
										<span class="components-toggle__thumb"></span>
									</span>
									<label for="woostify-builder-header-footer-stick">
										<?php esc_html_e( 'Stick', 'woostify-pro' ); ?>								
									</label>
								</div>
							</div>
							<?php if ( $template == 'woostify_builder_header' ) { ?>
							<div class="woostify-metabox-option">
								<div class="components-toggle-wrap">
									<span class="components-toggle">
										<input type="checkbox" class="components-toggle__input" name="woostify_builder_header_shrink" id="woostify-builder-header-shrink" value="shrink" <?php checked( $shrink, 'shrink' ); ?>>
										<span class="components-toggle__track"></span>
										<span class="components-toggle__thumb"></span>
									</span>
									<label for="woostify-builder-header-shrink">				
										<?php esc_html_e( 'Shrink', 'woostify-pro' ); ?>
									</label>
								</div>
							</div>
							<?php } ?>
							<div class="woostify-metabox-option stick-on <?php echo ($sticky == 'sticky' && $template == 'woostify_builder_header' )? 'active' : ''; ?>">
								<label for="woostify-builder-header-footer-stick-on">	
									<?php esc_html_e( 'Stick On', 'woostify-pro' ); ?>
								</label>
								<select name="woostify_builder_header_footer_stick_on" class="woostify-metabox-option-control" id="woostify-header-footer-template-sticky-on">
									<option value="all-device" <?php selected( $sticky_on, 'all-divice') ?>>
										<?php esc_html_e( 'Desktop + Mobile', 'woostify-pro' ); ?>
									</option>
									<option value="desktop" <?php selected( $sticky_on, 'desktop') ?>>
										<?php esc_html_e( 'Desktop', 'woostify-pro' ); ?>
									</option>
									<option value="mobile" <?php selected( $sticky_on, 'mobile') ?>>
										<?php esc_html_e( 'Mobile', 'woostify-pro' ); ?>
									</option>
								</select>
							</div>
						</div>	
					</div>
				<?php } ?>

				<?php	
				if ( $template == 'woostify_builder_content_hook' ) {

					$Woostify_Advanced_Hooks_Meta = Woostify_Advanced_Hooks_Meta_Builder_Addons::get_instance();
				?>
					<div class="input-wrapper template-content-hook">
						<h3 class="components-panel-title">
							<button type="button" aria-expanded="true" class="components-button components-panel__body-toggle components-panel-toggle active">
								<?php esc_html_e( 'Action', 'woostify-pro' ); ?>
								<span aria-hidden="true">
									<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
								</span>
							</button>
						</h3>

						<div class="woostify-metabox-option-box is-opened">
							<?php $Woostify_Advanced_Hooks_Meta->render_advanced_hooks( $post); ?>
						</div>
					</div>
				<?php
				}
				?>

				<?php	
				if ( $template == 'woostify_builder_popup' ) {

					$Woostify_Advanced_Popup = Woostify_Advanced_Popup_Builder_Addons::get_instance();
				?>
					<div class="input-wrapper template-popup">
						<h3 class="components-panel-title">
							<button type="button" aria-expanded="true" class="components-button components-panel__body-toggle components-panel-toggle active">
								<?php esc_html_e( 'Settings', 'woostify-pro' ); ?>
								<span aria-hidden="true">
									<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
								</span>
							</button>
						</h3>

						<div class="woostify-metabox-option-box is-opened">
							<?php $Woostify_Advanced_Popup->render_advanced_popup( $post); ?>
						</div>
					</div>
				<?php
				}
				?>

				<div class="input-wrapper condition">
					<h3 class="components-panel-title">
						<button type="button" data-popup-type="condition" class="components-button components-panel__body-toggle components-popup-button">
							<?php esc_html_e( 'Display And User Role Settings', 'woostify-pro' ); ?>
							<span class="edit-icon">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path d="M19.5 4.5h-7V6h4.44l-5.97 5.97 1.06 1.06L18 7.06v4.44h1.5v-7Zm-13 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H17v3a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h3V5.5h-3Z"></path></svg>
							</span>
						</button>
					</h3>
				</div>

				<div class="input-wrapper responsive-visibility">
					<h3 class="components-panel-title">
						<button type="button" aria-expanded="true" class="components-button components-panel__body-toggle components-panel-toggle active">
							<?php esc_html_e( 'Responsive Visibility', 'woostify-pro' ); ?>
							<span aria-hidden="true">
								<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="components-panel__arrow" aria-hidden="true" focusable="false"><path d="M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z"></path></svg>
							</span>
						</button>
					</h3>
					<div class="woostify-metabox-option-box is-opened">
						<div class="woostify-metabox-option">
							<div class="components-toggle-wrap">
								<span class="components-toggle">
									<input type="checkbox" class="components-toggle__input" name="woostify_builder_responsive_desktop" id="woostify-builder-responsive-desktop" value="desktop" <?php checked( $desktop, 'desktop' ); ?>>
									<span class="components-toggle__track"></span>
									<span class="components-toggle__thumb"></span>
								</span>
								<label for="woostify-builder-responsive-desktop">
									<?php esc_html_e( 'Desktop', 'woostify-pro' ); ?>								
								</label>
							</div>
						</div>
						<div class="woostify-metabox-option">
							<div class="components-toggle-wrap">
								<span class="components-toggle">
									<input type="checkbox" class="components-toggle__input" name="woostify_builder_responsive_tablet" id="woostify-builder-responsive-tablet" value="tablet" <?php checked( $tablet, 'tablet' ); ?>>
									<span class="components-toggle__track"></span>
									<span class="components-toggle__thumb"></span>
								</span>
								<label for="woostify-builder-responsive-tablet">
									<?php esc_html_e( 'Tablet', 'woostify-pro' ); ?>								
								</label>
							</div>
						</div>
						<div class="woostify-metabox-option">
							<div class="components-toggle-wrap">
								<span class="components-toggle">
									<input type="checkbox" class="components-toggle__input" name="woostify_builder_responsive_mobile" id="woostify-builder-responsive-mobile" value="mobile" <?php checked( $mobile, 'mobile' ); ?>>
									<span class="components-toggle__track"></span>
									<span class="components-toggle__thumb"></span>
								</span>
								<label for="woostify-builder-responsive-mobile">
									<?php esc_html_e( 'Mobile', 'woostify-pro' ); ?>								
								</label>
							</div>
						</div>
					</div>
				</div>

				<div class="input-wrapper expiration">
					<h3 class="components-panel-title">
						<button type="button" data-popup-type="expiration" class="components-button components-panel__body-toggle components-popup-button">
							<?php esc_html_e( 'Time Duration Settings', 'woostify-pro' ); ?>
							<span class="edit-icon">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path d="M19.5 4.5h-7V6h4.44l-5.97 5.97 1.06 1.06L18 7.06v4.44h1.5v-7Zm-13 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H17v3a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h3V5.5h-3Z"></path></svg>
							</span>
						</button>
					</h3>
				</div>

				<?php

				$html = ob_get_contents();
				ob_clean();
			}

			wp_send_json_success( $html );
			wp_die();

        }

    }

    Woostify_Theme_Builder_Addons_Ajax::init();
}

