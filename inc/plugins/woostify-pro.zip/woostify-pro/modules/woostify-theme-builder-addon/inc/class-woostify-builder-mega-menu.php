<?php
/**
 * Woostify template builder addons
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Theme_Builder_Addons_Mega_Menu' ) ) {

    class Woostify_Theme_Builder_Addons_Mega_Menu {
        /**
         * Instance of Woostify_Theme_Builder_Addons_Mega_Menu
         *
         * @var Woostify_Theme_Builder_Addons_Mega_Menu
         */
        private static $instance = null;

        /**
         * Instance of Woostify_Theme_Builder_Addons_Mega_Menu
         *
         * @return Woostify_Theme_Builder_Addons_Mega_Menu Instance of Woostify_Theme_Builder_Addons_Mega_Menu
         */
        public static function instance() {
            if ( ! isset( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         */
        public function __construct() {

            if ( ! is_admin() ) {
				return;
			}

            add_action( 'after_setup_theme', array( $this, 'init_admin_settings' ), 99 );

        }

        
		/**
		 * Admin settings init
		 */
		public function init_admin_settings() {

            add_action( 'wp_nav_menu_item_custom_fields', array( $this, 'add_custom_fields') , 10, 4 );

        }

        /**
		 * Add custom megamenu fields data to the menu.
		 *
		 * @access public
		 * @param int    $id menu item id.
		 * @param object $item A single menu item.
		 * @param int    $depth menu item depth.
		 * @param array  $args menu item arguments.
		 * @return void
		 *
		 */
		public static function add_custom_fields( $id, $item, $depth, $args ) {
            $item_title = isset( $item->title ) ? $item->title : '';
			?>
            <p class="description description-wide">
                <a class="button button-secondary button-large woostify-megamenu-opts-btn" data-depth="<?php echo esc_attr( $depth ); ?>" data-menu-id="<?php echo esc_attr( $id ); ?>" data-menu-title="<?php echo esc_attr( $item_title ); ?>">
                    <?php echo esc_html__( 'Woostify Menu Settings', 'woostify-pro' ); ?>
                </a>
            </p>
			<?php
		}

    }

    Woostify_Theme_Builder_Addons_Mega_Menu::instance();
}

