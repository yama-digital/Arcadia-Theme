<?php

/**
 * Check is elementor activated.
 *
 * @param int $id Post/Page Id.
 * @return boolean
 */
function is_elementor_activated( $id ) {

	if ( ! class_exists( '\Elementor\Plugin' ) ) {
		return false;
	}
	
	if ( version_compare( ELEMENTOR_VERSION, '1.5.0', '<' ) ) {
		return ( 'builder' === Elementor\Plugin::$instance->db->get_edit_mode( $id ) );
	} else {
		$elementor_document = Elementor\Plugin::$instance->documents->get( $id );
		if ( $elementor_document ) {
			return $elementor_document->is_built_with_elementor();
		} else {
			return false;
		}
	}

	return false;
}

/**
 * Check is woostify builder enabled enabled.
 *
 * @return boolean
 */
function is_woostify_builder_enabled( $template = false ) {
	$status = false;

	if( !$template ){
		$status = false;
	}

	$Woostify_Theme_Builder_Addons = Woostify_Theme_Builder_Addons::init();
	$template_id = $Woostify_Theme_Builder_Addons->get_template_id( $template );
	
	if ( '' !== $template_id ) {
		$status = true;
	}

	return $status;
}

// Check if Elementor is being used and the page template is "Full Width" or "Canvas"
function get_elementor_page_layout( $template_id ) {
    // Check if the current page uses Elementor
    if ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::instance()->documents->get( $template_id ) ) {
        // Get the page template (Full Width or Canvas, etc.)
        $document = \Elementor\Plugin::instance()->documents->get( $template_id );
        $settings = $document->get_settings_for_display();
		
        // Check if temlate is exists
        if ( isset( $settings['template'] ) ) {
            if ( $settings['template'] === 'elementor_header_footer' ) {
                return 'elementor-template-full-width';
            } elseif ( $settings['template'] === 'elementor_canvas' ) {
                return 'elementor-page-canvas';
            }else{
				return 'theme';
			}
        }
    }
	
    return 'default'; // Return default if no layout info is found
}
