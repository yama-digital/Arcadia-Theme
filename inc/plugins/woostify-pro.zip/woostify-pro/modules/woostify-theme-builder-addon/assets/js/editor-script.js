/**
 * Editor script
 *
 * @package woostify
 */

/* global woostify_theme_builder_addons_editor */
;(function ($) {  

    'use strict';
    
    function woostify_components_panel_toggle() {
        var woostify_metabox_settings_wp_builder_addon = document.getElementById('woostify_metabox_settings_wp_builder_addon');
        var components_panel_toggle = document.querySelectorAll('.components-panel-toggle');
    
        if( woostify_metabox_settings_wp_builder_addon == null || woostify_metabox_settings_wp_builder_addon == ""){
            return;
        }
    
        woostify_metabox_settings_wp_builder_addon.classList.remove('closed');
    
        components_panel_toggle.forEach(
            function (button) {
                button.onclick = function (e) { 
                    let parent_el = this.closest('.components-panel-title');
                    this.classList.toggle('active');
                    parent_el.nextElementSibling.classList.toggle('is-opened');
                }
            }
        );
    }
    
    function woostify_components_popup_button() {
    
        var woostify_metabox_settings_wp_builder_addon = document.getElementById('woostify_metabox_settings_wp_builder_addon');
        var components_popup_button = document.querySelectorAll('.components-popup-button');
        var ui_popup_close = document.querySelectorAll('.wp-builder-template-option-popup .ui-popup-close');
        if( woostify_metabox_settings_wp_builder_addon == null || woostify_metabox_settings_wp_builder_addon == ""){
            return;
        }
    
        var edit_post_layout = document.querySelector('#editor');
    
        components_popup_button.forEach(
            function (button) {
                button.onclick = function (e) { 
                    let popup_type = this.getAttribute('data-popup-type');
                    let template_option_popup = document.querySelector('.wp-builder-template-option-popup[data-popup-type="'+popup_type+'"]');
    
                    edit_post_layout.classList.add('template-option-active');
                    template_option_popup.classList.add('active');
                }
            }
        );
    
        ui_popup_close.forEach(
            function (button) {
                button.onclick = function (e) { 
                    edit_post_layout.classList.remove('template-option-active');
                    this.closest('.wp-builder-template-option-popup').classList.remove('active');
                }
            }
        );
    }
    
    function woostify_header_footer_options() {  
        var header_footer_stick = document.querySelector('#woostify-builder-header-footer-stick');
        var stick_on_el = document.querySelector('.woostify-metabox-option.stick-on');
        
        if ( ! header_footer_stick ) {
            return;
        }   
    
        header_footer_stick.addEventListener(
            'change',
            function (e) {
                if (this.checked) {
                    stick_on_el.classList.add('active');
                }else{
                    stick_on_el.classList.remove('active');
                }
            }
        );
    }
    
    function woostify_content_hook_options() {  
        var builder_advanced_hook_action = document.querySelector('#woostify-builder-advanced-hook-action');
        var advanced_hook_action_custom = document.querySelector('.advanced-hook-action-custom'); 
    
        if ( ! builder_advanced_hook_action ) {
            return;
        }
    
        builder_advanced_hook_action.addEventListener(
            'change',
            function ( event ) {
                var builder_advanced_hook_action_desc = document.querySelector('.woostify-builder-advanced-hook-action-desc');
                var action_hook = event.target.value;
                var action_hook_desc = this.options[this.selectedIndex].getAttribute('data-desc');
    
                if ( action_hook == 'wp_builder_custom_hook' ) {
                    advanced_hook_action_custom.classList.add('show');
                }else{
                    advanced_hook_action_custom.classList.remove('show');
                }
    
                if ( action_hook != 0 ) {
                    builder_advanced_hook_action_desc.innerHTML = action_hook_desc;
                }else{
                    builder_advanced_hook_action_desc.innerHTML = '';
                }
                
                
            }
        );
    }
    
    function woostify_popup_options() { 
        var template_popup = document.querySelector('.template-popup');
    
        if ( !template_popup ) {
            return;
        }
    
        var tabs = template_popup.querySelectorAll('.woostify-metabox-option-tab-btn');
        var tabs_content = template_popup.querySelectorAll('.woostify-metabox-option-tab-content');
    
        if ( tabs.length != 0 && tabs_content.length != 0 ) {
            tabs.forEach(
                function (tab) {
                    var tab_btn = tab;
    
                    tab_btn.addEventListener('click', function (event) {
                        var tab_id = this.getAttribute('id');
                        tabs.forEach(
                            function (ele) { 
                                ele.classList.remove('active');
                            }
                        );
                        this.classList.add('active');
                        tabs_content.forEach(
                            function (tab_content) { 
                                var tab_data = tab_content.getAttribute('data-tab');
                                if (tab_id == tab_data) {
                                    tab_content.classList.add('active');
                                }else{
                                    tab_content.classList.remove('active');
                                }
                            }
                        );
    
                    });
                }
            );
        }
    
        var ranges = template_popup.querySelectorAll('.advanced-popup-range');
    
        if ( ranges.length != 0 ) {
            ranges.forEach(
                function (ele) {
                    var input_range = ele.querySelector('input[type="range"]');
                    var input_number = ele.querySelector('input[type="number"]');
        
                    input_range.addEventListener('input', function (event) { 
                        var tempValue = event.target.value; 
          
                        input_number.value = tempValue;
                    });
        
                    input_number.addEventListener('input', function (event) { 
                        var tempValue = event.target.value; 
        
                        input_range.value = tempValue;
                    });
                }
            );
        }
    
        var popup_height_type = document.querySelector('#woostify-builder-advanced-popup-height-type');
        
        if ( popup_height_type ) {
            popup_height_type.addEventListener(
                'change', 
                function ( event ) {
                    var value = event.target.value;
                    var popup_height_eles = document.querySelectorAll('.woostify-builder-advanced-popup-height');
                    
                    popup_height_eles.forEach(
                        function ( popup_height ) {
                            if ( popup_height.classList.contains(value) ) {
                                popup_height.classList.remove('woostify-hidden');
                            }else{
                                popup_height.classList.add('woostify-hidden');
                            }
                            
                        }
                    );
            });
        }
    
        var popup_select_units = template_popup.querySelectorAll('.advanced-popup-select-unit');
    
        if ( popup_select_units.length != 0 ) {
            popup_select_units.forEach(
                function ( ele ) {
                    var select_unit = ele;
    
                    select_unit.addEventListener(
                        'change', 
                        function ( event ) {
                            var value = event.target.value;
                            var select_unit_setting = this.getAttribute('data-popup-setting');
                            var select_unit_max = this.getAttribute('data-max');
                            var select_unit_value = this.getAttribute('data-value');
                            var input_range = document.querySelector('.advanced-popup-input-range[data-popup-setting="'+select_unit_setting+'"]');
                            var input_number = document.querySelector('.advanced-popup-input-number[data-popup-setting="'+select_unit_setting+'"]');
                            var input_number_data_value = input_number.getAttribute('data-value');
                            var input_number_value = input_number_data_value.split(':')[0];
                            var input_number_unit = input_number_data_value.split(':')[1];
                            
                            var input_value = 100;
                            if ( input_number_data_value.toString().indexOf(input_number_unit) > -1 && value == input_number_unit ) {
                                input_value = input_number_value;
                            }
    
                            if ( value == 'px' ) {
                                input_range.max = select_unit_max;
                                input_range.value = (value == input_number_unit)? input_value : select_unit_value;
                                input_number.max = select_unit_max;
                                input_number.value = ( value == input_number_unit)? input_value : select_unit_value;
                            }else{
                                input_range.max = 100;
                                input_range.value = input_value;
                                input_number.max = 100;
                                input_number.value = input_value;
                            }
    
                        }
                    );
                }
            );
        }
    
        var popup_colors = $('.template-popup .advanced-popup-input-color');
     
        if ( popup_colors.length != 0 ) {
            popup_colors.each( function () {  
                var input_color = $(this);
                input_color.wpColorPicker();
            });
        }
    
        var popup_action = document.querySelector('#woostify-builder-advanced-popup-action');
    
        if ( popup_action ) {
            popup_action.addEventListener(
                'change', 
                function ( event ) {
                    var value = event.target.value;
                    var popup_action_settings = template_popup.querySelectorAll( '.advanced-popup-action-setting' );
                    popup_action_settings.forEach(
                        function ( popup_action_setting ) {
                            var action = popup_action_setting.getAttribute('data-action');
                            if ( action == value ) {
                                popup_action_setting.classList.remove('woostify-hidden');
                            }else{
                                popup_action_setting.classList.add('woostify-hidden');
                            }
                            
                        }
                    );
                }
            );
        }
    
    }
    
    function woostify_builder_addon_ajax( ) {  
        var builder_template_select = document.querySelector('#woostify-wp-builder-addon-template-type');
    
        if( builder_template_select ){
            builder_template_select.addEventListener(
                'change', 
                function ( event ) {
                    var type = event.target.value;
                    var input_wrapper = this.closest('.input-wrapper');
                    var template_id = document.getElementById('woostify-wp-builder-addon-template-id').value;
                    var nonce = document.getElementById('woostify-wp-builder-addon-nonce').value;
    
                    if( type == 'default' ){
                        var input_options = input_wrapper.nextElementSibling;
                        while (input_options.hasChildNodes()) {
                            input_options.removeChild(input_options.firstChild);
                        }
                    }else{
    
                        // Request.
                        var request = new Request(
                            ajaxurl,
                            {
                                method: 'POST',
                                body: 'action=woostify_pro_builder_select_template&_ajax_nonce=' + nonce + '&wp_builder_template=' + type + '&wp_builder_template_id=' +template_id,
                                credentials: 'same-origin',
                                headers: new Headers(
                                    {
                                        'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
                                    }
                                )
                            }
                        );
    
                        fetch(request).then(
                            function (res) {
                                if (200 !== res.status) {
                                    console.log('Status Code: ' + res.status);
                                    return;
                                }
    
                                res.json().then(
                                    function (r) {
                                        
                                        if (!r.success) {
                                            return;
                                        }
                                        
                                        if ('' !== r.data) {
                                            var parser = new DOMParser(),
                                                data = parser.parseFromString(r.data, 'text/html'),
                                                ajaxInputWrapper = data.querySelector('.input-wrapper');
    
                                            document.querySelector('.woostify-pro-wp-builder-addon-options').innerHTML = r.data;
                                        
                                            woostify_components_panel_toggle();
                                            woostify_components_popup_button();
                                            woostify_header_footer_options();
                                            woostify_content_hook_options();
                                            woostify_popup_options();
                                        }
                                    }
                                )
                            }
                        );
    
                    }
                }
            );
        }
    
        woostify_builder_target_rule_autocomplete_condition();
    
    }
    
    function woostify_autocomplete_field( field, data ) {
        var inputTxt = field;
        var inputIndex = inputTxt.getAttribute("data-index");
        var type = data.type;
        var searchResults = ( type == 'post' )? data.posts : data.taxonomies;
        var parentEL = inputTxt.closest('.woostify-target-rule-builder-wrap');
        var inputHidden = parentEL.querySelector('input[type="hidden"]');
        var conditionSearch = parentEL.querySelector('.wooostify-target-rule-condition-search');
        
        if( conditionSearch ){
    
            inputTxt.parentElement.classList.add("active");
            conditionSearch.style.display = "block";
            
            CreatingList(searchResults);
        
            function CreatingList(Results) {
                let createdList = Results.map(function (result) {
    
                    if ( type == 'post') {
                        return "<div data-id=" + result.ID + " data-type=" + result.post_type + ">" + result.post_title + "</div>";
                    }
                    return "<div data-id=" + result.id + " data-type=" + result.taxonomy + ">" + result.name + "</div>";
    
                });
                let CustomListItem;
    
                if (!CreatingList.length) {
                    CustomListItem = "<div>" + inputTxt.value + "</div>";
                } else {
                    CustomListItem = createdList.join("");
                }
                conditionSearch.innerHTML = CustomListItem;
                CompleteText();
            }
            
            
            function CompleteText() {
                var all_list_items = conditionSearch.querySelectorAll("div");
                all_list_items.forEach(function (list) {
                    list.addEventListener("click", function (e) {
                        var value = this.getAttribute('data-id') + ':' + this.getAttribute('data-type');
                        value += (type == 'post')? ':index_' + inputIndex : ':index_cat_' + inputIndex; 
                        inputTxt.value = e.target.textContent;
                        inputTxt.setAttribute("data-index", inputIndex);
                        inputHidden.value = value;
                        inputHidden.setAttribute("data-index", inputIndex);
                        conditionSearch.style.display = "none";
                    });
                });
            }
            
            document.addEventListener('click', function (e) {
                var conditionSearch = document.querySelectorAll('.wooostify-target-rule-condition-search');
                conditionSearch.forEach(function (ele) {
                    var parentSearchEL = ele.closest('.woostify-target-rule-builder-wrap');
                    var inputSearch = parentSearchEL.querySelector('input');
                    var activeElement = document.activeElement;
    
                    if ( activeElement != inputSearch ) {
                        ele.style.display = 'none';    
                    }
                    
                });
            });
    
        }
    
    
    }
    
    var woostifyBuilderAutocomplete = ( event ) => {
        
        var field = event.currentTarget;
        var value = event.target.value;
        var special_key = field.getAttribute('data-special-key');
        var post_tax = field.getAttribute('data-post-tax');
        
        var action = 'woostify_builder_get_all_posts';
        var taxs = ['special-post_taxonomy_id','special-product_taxonomy_id','special-taxonomy_id'];
        var special_keys = ['special-post_id','special-page_id','special-product_id','special-custom_post_type_id'];
        special_keys = special_keys.concat(taxs);
    
        if ( ! special_keys.includes( special_key ) && !post_tax ) {
            return;
        }
    
        if ( taxs.includes( special_key ) ) {
            action = 'woostify_builder_get_all_taxs';
        }else{
            if ( post_tax && post_tax.includes( special_key ) ) {
                special_key = post_tax;
                action = 'woostify_builder_get_all_taxs';
            }
        }
    
        // Request.
        var request = new Request(
            ajaxurl,
            {
                method: 'POST',
                body: 'action=' + action + '&special_key=' + special_key + '&search_query=' + value,
                credentials: 'same-origin',
                headers: new Headers(
                    {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
                    }
                )
            }
        );
        
        fetch(request).then(
            function (res) {
                if (200 !== res.status) {
                    console.log('Status Code: ' + res.status);
                    return;
                }
    
                res.json().then(
                    function (r) {
                        
                        if (!r.success) {
                            return;
                        }
          
                        var data = r.data;
            
                        if ('' !== data) {
                            
                            woostify_autocomplete_field( field, data );
    
                        }
                    }
                )
            }
        );
    
        
    }
    
    function woostify_builder_target_rule_autocomplete_condition() {
    
        var builder_template_condition = document.querySelector('#wp-builder-template-condition');
    
        if ( builder_template_condition ) {
            var inputs = builder_template_condition.querySelectorAll('input.woostify-target-rule-condition');
        
            if ( inputs.length != 0 ) {
                inputs.forEach(function (input) {
    
                    input.addEventListener(
                        'input', 
                        woostifyBuilderAutocomplete 
                    );
    
                    input.addEventListener(
                        'focus', 
                        woostifyBuilderAutocomplete 
                    );
    
                    // input.addEventListener('keydown', function (event) {
                
                    // });
    
                });
            }
        }
        
    }
    
    function woostify_builder_target_rule_condition_delete(taget_rule_element) { 
    
        if( !taget_rule_element ){
            return;
        }
    
        var target_rule_condition_delete = taget_rule_element.querySelectorAll('.woostify-target-rule-condition-delete');
      
        if ( target_rule_condition_delete.length > 1 ) {
            target_rule_condition_delete.forEach(
                function (button) {
                    button.classList.remove('woostify-hidden');
                    button.onclick = function (e) { 
                        var target_rule_builder_wrap = button.closest('.woostify-target-rule-builder-wrap');
                        target_rule_builder_wrap.remove();
                        var woostify_target_rule_builder_wrap = taget_rule_element.querySelectorAll('.woostify-target-rule-builder-wrap');
                        var target_locations = taget_rule_element.querySelectorAll('select.woostify-target-rule-condition');
                        var input_locations = taget_rule_element.querySelectorAll('input[type="hidden"]');
                        var inputs = taget_rule_element.querySelectorAll('input.woostify-target-rule-condition');
                        if ( target_locations.length != 0) {
                            let index = 0;
                            target_locations.forEach(function (ele) {
                                ele.setAttribute('data-index', index);
                                index++;
                            });
                        }
    
                        if ( inputs.length != 0) {
                            let index = 0;
                            inputs.forEach(function (ele) {
                                ele.setAttribute('data-index', index);
                                index++;
                            });
                        }
    
                        if ( input_locations.length != 0) {
                            let index = 0;
                            input_locations.forEach(function (ele) {
                                var value = ele.value;
                                var arrs = value.split(":");
                                var arrs_index = arrs[2];
                                arrs_index = arrs_index.replace(/\d/g, index);
                                ele.value = arrs[0] + ':' + arrs[1] + ':' + arrs_index;
                                ele.setAttribute("data-index", index);
                                index++;
                            });
                        }
    
                        if (woostify_target_rule_builder_wrap.length == 1 ) {
                            woostify_target_rule_builder_wrap[0].querySelector('.woostify-target-rule-condition-delete').classList.add('woostify-hidden');
                        }
                    }
                }
            );
        }else{
            target_rule_condition_delete[0].classList.add('woostify-hidden');
        }
    
    }
    
    function woostify_builder_target_rule_condition_special_ids( target_locations ) {
        
        if ( target_locations.length == 0 ) {
            return;
        }
       
        var special_ids = target_locations;
    
        if( special_ids ){
            special_ids.forEach(
                function (ele) {
                    var index = ele.getAttribute('data-index');
                    
                    ele.addEventListener('change', function (event) {
                        var value = event.target.value;
                        var name = this.name.replace('[]', '');
                        var rule = value.includes('post-tax')? 'post-tax' : value;
                        var wp_template_id = name + '-' + rule + '-input-field';
                        var parent = this.closest('.woostify-target-rule-builder-wrap');
                        var woostify_rule_special_ids = woostify_builder_rule_special_ids.special_ids;
            
                        var inputs = parent.querySelectorAll('input');
                        if ( inputs.length != 0 ) {
                            inputs.forEach(function (input) {
                                input.remove();
                            });
                        }
    
                        if ( (woostify_rule_special_ids.indexOf(rule) !== -1) ||  value.includes( rule ) ) {
                            var template  = wp.template( wp_template_id );
                            var template_field = template( );
                            var parser = new DOMParser();
                            
                            if (template_field) { 
                                var data = parser.parseFromString(template_field, 'text/html'),
                                ajaxInputs = data.querySelectorAll('input');
        
                                if ( ajaxInputs.length != 0 ) {
                                    ajaxInputs.forEach(function (input) {
                                        input.setAttribute("data-index", index);
                                        input.setAttribute("data-post-tax", value);
                                        parent.appendChild( input );
                                    });
                                }
        
                                woostify_builder_target_rule_autocomplete_condition();
                            }
                        }
    
                    });
                }
            );
        }
    }
    
    function woostify_builder_addon_close_condition( builder_template_condition ) {
        
        if ( ! builder_template_condition ) {
            return;
        }
    
        var return_to_post_btn =  builder_template_condition.querySelector('.return-to-post');
        
        if( return_to_post_btn ){
            return_to_post_btn.addEventListener('click', function (e) {
                builder_template_condition.classList.remove('active');
            });
        }
    }
    
    function woostify_builder_addon_condition() {
        var builder_template_condition = document.querySelector('#wp-builder-template-condition');
    
        if ( ! builder_template_condition ) {
            return;
        }
    
        var target_rule_condition_add = builder_template_condition.querySelectorAll('.woostify-target-rule-condition-add');
        var target_rule_condition_display = builder_template_condition.querySelector('.woostify-metabox-option-settings.display-on');
        var target_rule_condition_not_display = builder_template_condition.querySelector('.woostify-metabox-option-settings.not-display');
        var target_rule_condition_users = builder_template_condition.querySelector('.woostify-metabox-option-settings.users');
        var target_locations = builder_template_condition.querySelectorAll('select.woostify-target-rule-condition:not(.woostify_builder_target_users_rule)');
    
        target_rule_condition_add.forEach(
            function (button) {
                button.onclick = function (e) {
                    var btn = this;
                     
                    var taget_rule = btn.getAttribute('data-target-rule');
                    var template  = wp.template( 'wp-builder-target-rule-' + taget_rule + '-condition' );
                    var template_condition = template( );
    
                    var woostify_builder_target_locations = document.querySelector('.woostify-condition[data-condition-location="'+taget_rule+'"]');
                    if( woostify_builder_target_locations ){
                        var parser = new DOMParser(),
                        data = parser.parseFromString(template_condition, 'text/html'),
                        ajaxInputWrapper = data.querySelector('.woostify-target-rule-builder-wrap');
                        woostify_builder_target_locations.appendChild( ajaxInputWrapper );
    
                        var target_locations = woostify_builder_target_locations.querySelectorAll('select.woostify-target-rule-condition:not(.woostify_builder_target_users_rule)');
                        var index = 0;
                        target_locations.forEach(function (ele) {
                            ele.setAttribute( "data-index",index );
                            index++;
                        });
                        
                        // triger remove condition
                        woostify_builder_target_rule_condition_delete(target_rule_condition_display);
                        woostify_builder_target_rule_condition_delete(target_rule_condition_not_display);
                        woostify_builder_target_rule_condition_delete(target_rule_condition_users);
                        woostify_builder_target_rule_condition_special_ids( target_locations );
                    }
            
                }
            }
        );
    
        woostify_builder_target_rule_condition_delete(target_rule_condition_display);
        woostify_builder_target_rule_condition_delete(target_rule_condition_not_display);
        woostify_builder_target_rule_condition_delete(target_rule_condition_users);
        woostify_builder_target_rule_condition_special_ids( target_locations );
    
        woostify_builder_addon_close_condition(builder_template_condition);
    
    }
    
    function woostify_builder_addon_time_duration() {
        var builder_template_expiration = document.querySelector('#wp-builder-template-expiration');
    
        var timeDurationEnable = $('#wp-builder-time-duration-enable');
        var startDateTime = $('#wp-builder-time-duration-start-date');
        var startDateTimeTimeZone = $('#wp-builder-time-duration-start-date-timezone');
        var endDateTime = $('#wp-builder-time-duration-end-date');
        var endDateTimeTimeZone = $('#wp-builder-time-duration-end-date-timezone');
        var timeZone = 'UTC';
    
        if (timeDurationEnable) {
            timeDurationEnable.on('change', function (e) {
                $('.woostify-time-duration-date').toggle(this.checked);
            });
        }
    
        if( startDateTime ){
            startDateTime.datetimepicker({
                timeFormat : "HH:mm tt",
                controlType: 'select',
                onClose: function(dateText, inst) {
                    if (endDateTime.val() !== '') {
                        var testStartDate = startDateTime.datetimepicker('getDate');
                        var testEndDate = endDateTime.datetimepicker('getDate');
                        if (testStartDate > testEndDate)
                            endDateTime.datetimepicker('setDate', testStartDate);
                    }
                    else {
                        endDateTime.val(dateText);
                    }
                },
                onSelect: function (selectedDateTime){
    
                    var selectDate = selectedDateTime + ' ' + timeZone;
                    var dateTime = Math.floor( Date.parse( selectDate ) / 1000 );
    
                    startDateTimeTimeZone.val( dateTime );
                    endDateTime.datetimepicker('option', 'minDate', startDateTime.datetimepicker('getDate') );
                }
            });
        }
    
        if (endDateTime) {
            endDateTime.datetimepicker({
                timeFormat : "HH:mm tt",
                controlType: 'select',
                onClose: function(dateText, inst) {
                    if (startDateTime.val() !== '') {
                        var testStartDate = startDateTime.datetimepicker('getDate');
                        var testEndDate = endDateTime.datetimepicker('getDate');
                        if (testStartDate > testEndDate)
                            startDateTime.datetimepicker('setDate', testEndDate);
                    }
                    else {
                        startDateTime.val(dateText);
                    }
                },
                onSelect: function (selectedDateTime){
    
                    var selectDate = selectedDateTime + ' ' + timeZone;
                    var dateTime = Math.floor( Date.parse( selectDate ) / 1000 );
    
                    endDateTimeTimeZone.val( dateTime );
                    startDateTime.datetimepicker('option', 'maxDate', endDateTime.datetimepicker('getDate') );
                }
            }); 
        }
    
        woostify_builder_addon_close_condition(builder_template_expiration);
    }
    
    
    var woostifyWooBuilderAddon = function() {
    
        woostify_components_panel_toggle();
        woostify_components_popup_button();
        woostify_header_footer_options();
        woostify_content_hook_options();
        woostify_popup_options();
        woostify_builder_addon_ajax();
        woostify_builder_addon_condition();
        woostify_builder_addon_time_duration();
    
    }
    
    
    
    document.addEventListener(
        'DOMContentLoaded',
        function() {
    
            woostifyWooBuilderAddon();
    
        }
    );
    
    
})(jQuery);