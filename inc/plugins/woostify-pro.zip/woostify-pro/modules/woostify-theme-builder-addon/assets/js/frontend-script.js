/**
 * Frontend Theme Builder Addon
 *
 * @package Woostify Pro
 */

'use strict';

function woostifyBuilderHeaderSticky() {
    
	var header = document.querySelector( '.woostify-header-template-builder' );
	if ( ! header || ! header.classList.contains( 'header-has-sticky' ) ) {
		return;
	}

	var sticky         = header.classList.contains( 'header-sticky-on-all-device' ),
		stickyDesktop  = header.classList.contains( 'header-sticky-on-desktop' ),
		stickyMobile   = header.classList.contains( 'header-sticky-on-mobile' ),
		shrink         = header.classList.contains( 'header-has-shrink' ),
		inner          = header.querySelector( '.woostify-header-template-builder-inner' ),
		offsetTop      = header.getBoundingClientRect().top || 0,
		adminBar       = document.getElementById( 'wpadminbar' ),
		adminBarHeight = adminBar ? adminBar.offsetHeight : 0,
		sticked        = document.querySelector( '.woostify-header-template-builder-inner.active' );

	if (
		sticky ||
		( stickyDesktop && window.matchMedia( '( min-width: 992px )' ).matches ) ||
		( stickyMobile && window.matchMedia( '( max-width: 991px )' ).matches )
	) {
		if ( offsetTop - adminBarHeight >= 0 ) {
			// Reset state.
			inner.classList.remove( 'active' );
			header.style.height = '';
		} else {
			inner.classList.add( 'active' );
			header.style.height = inner.offsetHeight + 'px';
		}

		// For user logged in on Mobile.
		if ( ! sticked || ! adminBar ) {
			return;
		}

		if ( ( sticky || stickyMobile ) && window.matchMedia( '( max-width: 767px )' ).matches ) {
			if ( window.scrollY < adminBarHeight ) {
				sticked.style.top = ( adminBarHeight - window.scrollY ) + 'px';
			} else {
				sticked.style.top = '0px';
			}
		} else {
			// Reset state.
			sticked.style.top = '';
		}
	} else {
		// Reset state.
		inner.classList.remove( 'active' );
		header.style.height = '';
	}

}

function woostifyBuilderFooterSticky() {
	var footer = document.querySelector( '.woostify-footer-template-builder' );
	if ( ! footer || ! footer.classList.contains( 'footer-has-sticky' ) ) {
		return;
	}

    var wpBuilderFooter = document.querySelector('body.wp-builder-footer'),
        inner = footer.querySelector( '.woostify-footer-template-builder-inner' );
	
	// All device 
    if (footer.classList.contains('footer-sticky-on-all-device')) {
        wpBuilderFooter.style.paddingBottom = inner.offsetHeight + 'px';
    }

	// Desktop
	if (footer.classList.contains('footer-sticky-on-desktop')) {
        wpBuilderFooter.style.paddingBottom = inner.offsetHeight + 'px';
    }

	// Mobile
	if (footer.classList.contains('footer-sticky-on-mobile')) {
        wpBuilderFooter.style.paddingBottom = inner.offsetHeight + 'px';
    }

}

var woostifyWooBuilderAddonFrontend = function() {

    window.addEventListener( 'load', woostifyBuilderHeaderSticky );
    window.addEventListener( 'scroll', woostifyBuilderHeaderSticky );
    window.addEventListener( 'resize', woostifyBuilderHeaderSticky );

    window.addEventListener( 'load', woostifyBuilderFooterSticky );
	window.addEventListener( 'resize', woostifyBuilderFooterSticky );

}

document.addEventListener(
	'DOMContentLoaded',
	function() {
        woostifyWooBuilderAddonFrontend();
	}
);