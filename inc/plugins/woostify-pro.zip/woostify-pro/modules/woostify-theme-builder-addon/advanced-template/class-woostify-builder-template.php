<?php
/**
 * Woostify Theme Builder Custom Template
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Builder_Template' ) ) {
	/**
	 * Class for woostify Custom Template
	 */
	class Woostify_Builder_Template {
		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		
		/**
		 * Constructor.
		 */
		public function __construct() {

			add_filter( 'body_class', array( $this, 'body_classes' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) , 999);
			add_filter( 'template_include', array( $this, 'override_template_include' ), 999 );

		}

		/**
		 * Get content action of page builder elementor
		 */
		public function get_active_page_builder( $post_id ) {

			if ( is_elementor_activated( $post_id ) ) {
				$elementor_instance = Elementor\Plugin::instance();
				echo do_shortcode($elementor_instance->frontend->get_builder_content_for_display( $post_id ));
			} else {
				$this->render_content( $post_id );
			}

		}

		/**
		 * Get content action post in editor
		 */
		public function render_content( $post_id ) {
            $output       = '';
            $current_post = get_post( $post_id, OBJECT );
            if ( has_blocks( $current_post ) ) {
                $blocks = parse_blocks( $current_post->post_content );
                foreach ( $blocks as $block ) {
                    $output .= render_block( $block );
                }
            } else {
                $output = $current_post->post_content;
            }
			ob_start();
            echo do_shortcode($output );
            echo do_shortcode( ob_get_clean() );
		}

		/**
		 * Get template exist
		 */
		public function template_exist( $template = false ) {

			$template_id = Woostify_Theme_Builder_Addons::init()->get_template_id( $template );

			$time_duration_eligibility = Woostify_Theme_Builder_Addons_Time_Duration::instance()->get_time_duration_eligibility( $template_id );

			if( ! $time_duration_eligibility ){
				return false;
            }

			if( $template_id ){
				return true;
			}

			return false;
        }

		/**
		 * Get template id
		 */
		public function get_template_id( $template = false ) {

			$template_id = Woostify_Theme_Builder_Addons::init()->get_template_id( $template );

			if( $template_id ){
				return $template_id;
			}

			return false;
        }

		/**
		 * Overriding default template by Custom Layout.
		 *
		 */
		public function render_overridden_template( $post_id ) {
			$post = get_post( $post_id );
			if ( empty( $post ) ) {
				return;
			}

			get_header();

			$this->get_content_template( $post_id );

			get_footer();
		}

		/**
		 * Overriding default template by Custom Layout.
		 *
		 */
		public function override_template_include( $template ) {
			$post_type = get_post_type();

			if (  'wp_builder_addon' !== $post_type ) {

				// 404 page
				if( is_404() && $this->template_exist('woostify_builder_404') ){
					$error_template_id = $this->get_template_id( 'woostify_builder_404' );

					return $this->render_overridden_template( $error_template_id );
				}

				// is singular
				if( is_singular() && $this->template_exist('woostify_builder_single') ){
					$single_template_id = $this->get_template_id( 'woostify_builder_single' );

					return $this->render_overridden_template( $single_template_id );
						
				}

				// is blog
				if( is_home() && !is_front_page() && $this->template_exist( 'woostify_builder_archive' ) ){
					$archive_template_id = $this->get_template_id( 'woostify_builder_archive' );

					return $this->render_overridden_template( $archive_template_id );
				}

				// is archive
				if( ( is_tax() || is_archive() ) && $this->template_exist('woostify_builder_archive') ){
					$archive_template_id = $this->get_template_id( 'woostify_builder_archive' );

					return $this->render_overridden_template( $archive_template_id );
						
				}

			}

			return $template;
		}

		/**
		 * Get content template
		 */
        public function get_content_template( $post_id ){

			$template = get_post_meta( $post_id, 'woostify_wp_builder_addon_template', true );

            $classes[] = 'woostify-builder-template';
            $classes[] = $template;

            // responsive visibility
			$desktop = get_post_meta( $post_id, 'woostify_builder_responsive_desktop', true );
			$tablet  = get_post_meta( $post_id, 'woostify_builder_responsive_tablet', true );
			$mobile  = get_post_meta( $post_id, 'woostify_builder_responsive_mobile', true );

            $classes[] = $desktop === 'desktop' ? 'wp-desktop-hidden' : '';
			$classes[] = $tablet === 'tablet' ? 'wp-tablet-hidden' : '';
			$classes[] = $mobile === 'mobile' ? 'wp-mobile-hidden' : '';

            $classes = implode( " ", $classes);

            $time_duration_eligibility = Woostify_Theme_Builder_Addons_Time_Duration::instance()->get_time_duration_eligibility( $post_id );

			if( ! $time_duration_eligibility ){
				return false;
            }

            ?>
            <div id="woostify-builder-template-<?php echo esc_attr( $post_id ); ?>" <?php post_class( $classes, $post_id ); ?>>
                <div class="woostify-builder-template-container">
                    <?php $this->get_active_page_builder( $post_id ); ?>
                </div>
            </div>
            <?php

        }

		/**
		 * body classes
		 */
		public function body_classes( $classes ){
			$template_types = array(
				'woostify_builder_404',
				'woostify_builder_single',
				'woostify_builder_archive',
			);

			foreach ($template_types as $key => $type) {
				$check_type = $this->template_exist($type);
				$template_id = $this->get_template_id( $type );

				if( $check_type && $template_id ){
					$page_layout = get_elementor_page_layout( $template_id );
					$classes[] = $page_layout;
				}

			}

			return array_filter( $classes );
		}

		/**
		 * enqueue scripts
		 */
		public function enqueue_scripts(){
			
			$template_types = array(
				'woostify_builder_404',
				'woostify_builder_single',
				'woostify_builder_archive',
			);

			foreach ($template_types as $key => $type) {
				$check_type = $this->template_exist($type);
				$template_id = $this->get_template_id( $type );
				
				if( $check_type && $template_id ){
					if( is_elementor_activated( $template_id ) ){
						if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
							$css_file = new \Elementor\Core\Files\CSS\Post( $template_id );
						} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
							$css_file = new \Elementor\Post_CSS_File( $template_id );
						}
		
						$css_file->enqueue();
					}else{
						
						if ( class_exists( 'Woostify_Builder_Gutenberg_Compatibility' ) ) {

							$woostify_gutenberg_instance = new Woostify_Builder_Gutenberg_Compatibility();
							
							if ( is_callable( array( $woostify_gutenberg_instance, 'enqueue_blocks_assets' ) ) ) {
								$woostify_gutenberg_instance->enqueue_blocks_assets( $template_id );
							}
						}

					}
				}

			}

		}

    }

	/**
	 * Initialize class object with 'get_instance()' method
	 */
	Woostify_Builder_Template::get_instance();

}