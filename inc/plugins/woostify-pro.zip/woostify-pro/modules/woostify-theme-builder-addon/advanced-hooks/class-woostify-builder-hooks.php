<?php
/**
 * Woostify theme builder addons advanced hooks
 *
 * @package Woostify Addon
 */

define( 'WOOSTIFY_PRO_BUILDER_ADDON_POST_TYPE', 'wp_builder_addon' );

if ( ! class_exists( 'Woostify_Advanced_Hooks_Builder_Addons' ) ) {

	/**
	 * Advanced Hooks Initial Setup
	 *
	 * @since 1.0.0
	 */
	
	class Woostify_Advanced_Hooks_Builder_Addons {

		/**
		 * Instance Variable
		 *
		 * @var object instance
		 */
		private static $instance;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor function that initializes required actions and hooks
		 */
		public function __construct() {

			add_action( 'wp', array( $this, 'load_advanced_hooks_template' ), 1 );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

            require_once WOOSTIFY_PRO_MODULES_PATH . 'woostify-theme-builder-addon/advanced-hooks/class-woostify-builder-hooks-meta.php';
		}

		/**
		 * Get content action of page builder elementor
		 */
		public function get_active_page_builder( $post_id ) {

			if ( is_elementor_activated( $post_id ) ) {
				$elementor_instance = Elementor\Plugin::instance();
				echo do_shortcode($elementor_instance->frontend->get_builder_content_for_display( $post_id ));
			} else {
				$this->render_content( $post_id );
			}

		}

		/**
		 * Get content action post in editor
		 */
		public function render_content( $post_id ) {
			$output       = '';
			$current_post = get_post( $post_id, OBJECT );
			if ( has_blocks( $current_post ) ) {
				$blocks = parse_blocks( $current_post->post_content );
				foreach ( $blocks as $block ) {
					$output .= render_block( $block );
				}
			} else {
				$output = $current_post->post_content;
			}
			ob_start();
			echo do_shortcode( $output );
			echo do_shortcode( ob_get_clean() );
		}

		/**
		 * Get the content of the hook
		 */
		public function get_action_content( $post_id ) {

			$time_duration_eligibility = Woostify_Theme_Builder_Addons_Time_Duration::instance()->get_time_duration_eligibility( $post_id );
		
			if( !$time_duration_eligibility ){
				return;
            }

			// responsive visibility
			$desktop = get_post_meta( $post_id, 'woostify_builder_responsive_desktop', true );
			$tablet  = get_post_meta( $post_id, 'woostify_builder_responsive_tablet', true );
			$mobile  = get_post_meta( $post_id, 'woostify_builder_responsive_mobile', true );

			$display_device_classes[] = 'woostify-advanced-hook';
			$display_device_classes[] = 'woostify-advanced-hook-' . $post_id;
			$display_device_classes[] = $desktop === 'desktop' ? 'wp-desktop-hidden' : '';
			$display_device_classes[] = $tablet === 'tablet' ? 'wp-tablet-hidden' : '';
			$display_device_classes[] = $mobile === 'mobile' ? 'wp-mobile-hidden' : '';

			$display_device_classes   = implode(' ', $display_device_classes );

			?>
			<div <?php post_class( $display_device_classes, $post_id ); ?> >
			<?php
				$this->get_active_page_builder( $post_id );
			?>
			</div>
			<?php

		}

		/**
		 * Get ids action hooks
		 */
		public function get_template_advanced_hook_ids( $type ) {

			$option = [
				'location'  => 'woostify_builder_target_include_locations',
				'exclusion' => 'woostify_builder_target_exclude_locations',
				'users'     => 'woostify_builder_target_users_rule',
			];
	
			$wp_builder_templates = Woostify_Theme_Builder_Addons_Condition::instance()->get_posts_by_conditions( 'wp_builder_addon', $option );
		
			if( $wp_builder_templates ){
				$template_ids = array();
				foreach ( $wp_builder_templates as $key => $template ) {
					if ( get_post_meta( absint( $template['id'] ), 'woostify_wp_builder_addon_template', true ) === $type ) {
						$template_ids[] = $template['id'];
						
					}
				}
				return $template_ids;
			}
			
			return '';
		}

		/**
		 * Add action hooks
		 */
		public function load_advanced_hooks_template() {

			$template_ids = $this->get_template_advanced_hook_ids( 'woostify_builder_content_hook' );
		
			if ( !empty( $template_ids ) ) {

				foreach ($template_ids as $key => $template_id) {

					$post_id = $template_id;

					$template = get_post_meta( $post_id, 'woostify_wp_builder_addon_template', true );
	
					if( $template == 'woostify_builder_content_hook' ){
						$hook_action   = get_post_meta( $post_id, 'woostify_builder_advanced_hook_action', true );
						$hook_action_custom = get_post_meta( $post_id, 'woostify_builder_advanced_hook_action_custom', true );
						$priority = get_post_meta( $post_id, 'woostify_builder_advanced_hook_action_priority', true );
	
						$action = ( $hook_action == 'wp_builder_custom_hook' )? $hook_action_custom : $hook_action;
					
						add_action(
							$action,
							function() use ( $post_id ) {
								$this->get_action_content( $post_id );
							},
							$priority
						);
	
					}
				}

			}
		}

		/**
		 * Enqueue styles and scripts.
		 */
		public function enqueue_scripts() {

			$template_ids = $this->get_template_advanced_hook_ids( 'woostify_builder_content_hook' );

			if ( '' !== $template_ids ) {
				
				foreach ($template_ids as $key => $template_id) {
					if ( class_exists( 'Elementor\Plugin' ) ) {
						if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
							$css_file = new \Elementor\Core\Files\CSS\Post( $template_id );
						} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
							$css_file = new \Elementor\Post_CSS_File( $template_id );
						}
						$css_file->enqueue();
					}
				}

			}

		}

	}

	/**
	 *  Kicking this off by calling 'get_instance()' method
	 */
	Woostify_Advanced_Hooks_Builder_Addons::get_instance();

}
