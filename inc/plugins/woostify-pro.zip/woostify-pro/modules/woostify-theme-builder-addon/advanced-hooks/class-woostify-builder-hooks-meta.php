<?php
/**
 *  Advanced Hooks Bar Post Meta Box
 *
 * @package   Woostify Pro
 */

/**
 * Hook Meta setup
 */
if ( ! class_exists( 'Woostify_Advanced_Hooks_Meta_Builder_Addons' ) ) {

	/**
	 * Hook Meta setup
	 */
	// @codingStandardsIgnoreStart
	class Woostify_Advanced_Hooks_Meta_Builder_Addons {
		// @codingStandardsIgnoreEnd

		/**
		 * Instance
		 *
		 * @var $instance
		 */
		private static $instance;

		/**
		 * Theme Action hooks.
		 *
		 * @var $hooks
		 */
		public static $hooks = array();

		/**
		 * Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			/**
			 * Filter for the 'Hooks' in Custom Layouts selection.
			 */
			$hooks = array(
				'head'    => array(
					'title' => __( 'Head', 'woostify-pro' ),
					'hooks' => array(
						'wp_head'           => array(
							'title'       => __( 'WP Head', 'woostify-pro' ),
							'description' => __( 'wp_head - Action to add custom style, script and meta at the bottom of <head> tag.', 'woostify-pro' ),
						),
					),
				),

				'header'  => array(
					'title' => __( 'Header', 'woostify-pro' ),
					'hooks' => array(
						'woostify_theme_header'         => array(
							'title'       => __( 'Theme Header', 'woostify-pro' ),
							'description' => __( 'woostify_theme_header - Placement to add your content before or after the theme <header> tag.', 'woostify-pro' ),
						),			
						'woostify_site_header'           => array(
							'title'       => __( 'Inside Header', 'woostify-pro' ),
							'description' => __( 'woostify_site_header - Placement to add your content or snippet the <header> tag.', 'woostify-pro' ),
						),				
						'woostify_after_header' => array(
							'title'       => __( 'After Header', 'woostify-pro' ),
							'description' => __( 'woostify_after_header - Placement to add your content or snippet after the closing <header> tag.', 'woostify-pro' ),
						),
						'woostify_template_part_header'         => array(
							'title'       => __( 'Template Part Header', 'woostify-pro' ),
							'description' => __( 'woostify_template_part_header - Placement to add your content template part the theme <header> tag.', 'woostify-pro' ),
						),
					),
				),

				'navigation' => array(
					'title' => __( 'Navigation', 'woostify-pro' ),
					'hooks' => array(
						'woostify_before_main_nav'             => array(
							'title'       => __( 'Before Main Navigation', 'woostify-pro' ),
							'description' => __( 'woostify_before_main_nav - Placement to add your content or snippet before main navigation.', 'woostify-pro' ),
						),
						'woostify_after_main_nav'             => array(
							'title'       => __( 'After Main Navigation', 'woostify-pro' ),
							'description' => __( 'woostify_after_main_nav - Placement to add your content or snippet after main navigation.', 'woostify-pro' ),
						),
					),
				),

				'site-tool' => array(
					'title' => __( 'Site Tool', 'woostify-pro' ),
					'hooks' => array(
						'woostify_site_tool_before_first_item'             => array(
							'title'       => __( 'Before First Item', 'woostify-pro' ),
							'description' => __( 'woostify_site_tool_before_first_item - Placement to add your content or snippet before first item.', 'woostify-pro' ),
						),
						'woostify_site_tool_before_second_item'             => array(
							'title'       => __( 'Before Second Item', 'woostify-pro' ),
							'description' => __( 'woostify_site_tool_before_second_item - Placement to add your content or snippet before second item.', 'woostify-pro' ),
						),
						'woostify_site_tool_before_third_item'             => array(
							'title'       => __( 'Before Third Item', 'woostify-pro' ),
							'description' => __( 'woostify_site_tool_before_third_item - Placement to add your content or snippet before third item.', 'woostify-pro' ),
						),
						'woostify_site_tool_before_fourth_item'             => array(
							'title'       => __( 'Before Fourth Item', 'woostify-pro' ),
							'description' => __( 'woostify_site_tool_before_fourth_item - Placement to add your content or snippet before fourth item.', 'woostify-pro' ),
						),
						'woostify_site_tool_after_last_item'             => array(
							'title'       => __( 'Before Last Item', 'woostify-pro' ),
							'description' => __( 'woostify_site_tool_after_last_item - Placement to add your content or snippet before last item.', 'woostify-pro' ),
						),
					),
				),

				'search' => array(
					'title' => __( 'Search', 'woostify-pro' ),
					'hooks' => array(
						'woostify_dialog_search_content_start'              => array(
							'title'       => __( 'Before Dialog Search', 'woostify-pro' ),
							'description' => __( 'woostify_dialog_search_content_start - Placement to add your content before the WooCommerce dialog search.', 'woostify-pro' ),
						),
						'woostify_dialog_search_content_end'           => array(
							'title'       => __( 'After Dialog Search', 'woostify-pro' ),
							'description' => __( 'woostify_dialog_search_content_end - Placement to add your content after the WooCommerce dialog search.', 'woostify-pro' ),
						),
					),
				),

				'sidebar' => array(
					'title' => __( 'Sidebar', 'woostify-pro' ),
					'hooks' => array(
						'woostify_sidebar'             => array(
							'title'       => __( 'Sidebar', 'woostify-pro' ),
							'description' => __( 'woostify_sidebar - Placement to add your content or snippet after main content.', 'woostify-pro' ),
						),
						'woostify_sidebar_account_before'             => array(
							'title'       => __( 'Before Account Sidebar Menu Bottom', 'woostify-pro' ),
							'description' => __( 'woostify_sidebar_account_before - Placement to add your content or snippet before account sidebar menu bottom.', 'woostify-pro' ),
						),
						'woostify_sidebar_account_top'             => array(
							'title'       => __( 'Top Account Sidebar Menu Bottom', 'woostify-pro' ),
							'description' => __( 'woostify_sidebar_account_top - Placement to add your content or snippet top account sidebar menu bottom.', 'woostify-pro' ),
						),
						'woostify_sidebar_account_bottom'             => array(
							'title'       => __( 'Bottom Account Sidebar Menu Bottom', 'woostify-pro' ),
							'description' => __( 'woostify_sidebar_account_bottom - Placement to add your content or snippet bottom account sidebar menu bottom.', 'woostify-pro' ),
						),
						'woostify_sidebar_account_after'             => array(
							'title'       => __( 'After Account Sidebar Menu Bottom', 'woostify-pro' ),
							'description' => __( 'woostify_sidebar_account_after - Placement to add your content or snippet after account sidebar menu bottom.', 'woostify-pro' ),
						),
					),
				),

				'posts' => array(
					'title' => __( 'Posts', 'woostify-pro' ),
					'hooks' => array(
						'woostify_loop_post'             => array(
							'title'       => __( 'Loop Post', 'woostify-pro' ),
							'description' => __( 'woostify_loop_post - Placement to add your content or snippet in loop post.', 'woostify-pro' ),
						),
						'woostify_loop_after'             => array(
							'title'       => __( 'Loop Post After', 'woostify-pro' ),
							'description' => __( 'woostify_loop_after - Placement to add your content or snippet after in loop post.', 'woostify-pro' ),
						),
						'woostify_post_content_before'             => array(
							'title'       => __( 'Loop Post Content Before', 'woostify-pro' ),
							'description' => __( 'woostify_post_content_before - Placement to add your content or snippet content before in loop post.', 'woostify-pro' ),
						),
						'woostify_post_content_after'             => array(
							'title'       => __( 'Loop Post Content After', 'woostify-pro' ),
							'description' => __( 'woostify_post_content_after - Placement to add your content or snippet content after in loop post.', 'woostify-pro' ),
						),
					),
				),

				'single-post' => array(
					'title' => __( 'Single Post', 'woostify-pro' ),
					'hooks' => array(
						'woostify_single_post'             => array(
							'title'       => __( 'Single Post', 'woostify-pro' ),
							'description' => __( 'woostify_single_post - Placement to add your content or snippet in single post.', 'woostify-pro' ),
						),
						'woostify_single_post_before'             => array(
							'title'       => __( 'Single Post Before', 'woostify-pro' ),
							'description' => __( 'woostify_single_post_before - Placement to add your content or snippet before in single post.', 'woostify-pro' ),
						),
						'woostify_single_post_after'             => array(
							'title'       => __( 'Single Post After', 'woostify-pro' ),
							'description' => __( 'woostify_single_post_after - Placement to add your content or snippet after in single post.', 'woostify-pro' ),
						),
					),
				),

				'page' => array(
					'title' => __( 'Page', 'woostify-pro' ),
					'hooks' => array(
						'woostify_page_header_start' => array(
							'title'       => __( 'Page Header Start Breadcrumb', 'woostify-pro' ),
							'description' => __( 'woostify_page_header_start - Placement to add your page header start breadcrumb.', 'woostify-pro' ),
						),
						'woostify_page_header_end' => array(
							'title'       => __( 'Page Header End Breadcrumb', 'woostify-pro' ),
							'description' => __( 'woostify_page_header_end - Placement to add your page header end breadcrumb.', 'woostify-pro' ),
						),
						'woostify_page_header_breadcrumb' => array(
							'title'       => __( 'Page Header Breadcrumb', 'woostify-pro' ),
							'description' => __( 'woostify_page_header_breadcrumb - Placement to add your page header breadcrumb.', 'woostify-pro' ),
						),
						'woostify_page'             => array(
							'title'       => __( 'Page Content', 'woostify-pro' ),
							'description' => __( 'woostify_page - Placement to add your content or snippet content in page.', 'woostify-pro' ),
						),
						'woostify_page_after'             => array(
							'title'       => __( 'Page Content After', 'woostify-pro' ),
							'description' => __( 'woostify_page_after - Placement to add your content or snippet content after in page.', 'woostify-pro' ),
						),
					),
				),

				'special-page' => array(
					'title' => __( 'Special Page', 'woostify-pro' ),
					'hooks' => array(
						'woostify_theme_404' 			=> array(
							'title' 	  => __( '404', 'woostify-pro' ),
							'description' => __( 'woostify_theme_404 Placement to add your content or snippet the page 404', 'woostify-pro' ),
						),
						'woostify_theme_archive' 			=> array(
							'title' 	  => __( 'Archive', 'woostify-pro' ),
							'description' => __( 'woostify_theme_archive Placement to add your content or snippet the page archive', 'woostify-pro' ),
						),
						'woostify_theme_single' 			=> array(
							'title' 	  => __( 'Single', 'woostify-pro' ),
							'description' => __( 'woostify_theme_single Placement to add your content or snippet the page single', 'woostify-pro' ),
						),
					),
				),

				'footer'  => array(
					'title' => __( 'Footer', 'woostify-pro' ),
					'hooks' => array(
						'woostify_theme_footer'         => array(
							'title'       => __( 'Theme Footer', 'woostify-pro' ),
							'description' => __( 'woostify_theme_footer - Placement to add your content or snippet before or after the theme footer <footer> tag.', 'woostify-pro' ),
						),
						'woostify_before_footer'         => array(
							'title'       => __( 'Before Footer', 'woostify-pro' ),
							'description' => __( 'woostify_before_footer - Placement to add your content or snippet before the opening <footer> tag.', 'woostify-pro' ),
						),
						'woostify_after_footer'          => array(
							'title'       => __( 'After Footer', 'woostify-pro' ),
							'description' => __( 'woostify_after_footer - Placement to add your content or snippet after the closing <footer> tag.', 'woostify-pro' ),
						),
						'woostify_footer_content'          => array(
							'title'       => __( 'Inside Content Footer', 'woostify-pro' ),
							'description' => __( 'woostify_footer_content - Placement to add your content or snippet the <footer> tag.', 'woostify-pro' ),
						),
						'woostify_template_part_footer'         => array(
							'title'       => __( 'Template Part Footer', 'woostify-pro' ),
							'description' => __( 'woostify_template_part_footer - Placement to add your content template part the theme <footer> tag.', 'woostify-pro' ),
						),
						'wp_footer'                   => array(
							'title'       => __( 'WP Footer', 'woostify-pro' ),
							'description' => __( 'wp_footer - Placement to add your content or snippet at end of the document.', 'woostify-pro' ),
						),
					),
				),
			);

			// Has template header
			if( self::is_wp_builder_header_active() ){
				unset ( $hooks['header']['hooks']['woostify_site_header'] );
			}

			// Has template footer
			if( self::is_wp_builder_footer_active() ){
				unset ( $hooks['footer']['hooks']['woostify_footer_content'] );
				unset ( $hooks['footer']['hooks']['woostify_before_footer'] );
				unset ( $hooks['footer']['hooks']['woostify_after_footer'] );
			}

			// If plugin - 'WooCommerce'.
			if ( class_exists( 'WooCommerce' ) ) {

				$search_product = array(
					'woostify_site_search_start'  => array(
						'title'       => __( 'Before Search', 'woostify-pro' ),
						'description' => __( 'woostify_site_search_start - Placement to add your content before the WooCommerce search.', 'woostify-pro' ),
					),
					'woostify_site_search_end'   => array(
						'title'       => __( 'After Search', 'woostify-pro' ),
						'description' => __( 'woostify_site_search_end - Placement to add your content after the WooCommerce search.', 'woostify-pro' ),
					),			
				);

				$hooks['search']['hooks'] = $hooks['search']['hooks'] + $search_product;

				$hooks['my-account'] = array(
					'title' => __( 'My Account', 'woostify-pro' ),
					'hooks' => array(
						'woostify_header_account_subbox_start'             => array(
							'title'       => __( 'Start Before My Account Box', 'woostify-pro' ),
							'description' => __( 'woostify_header_account_subbox_start - Placement to add your content or snippet before my account box.', 'woostify-pro' ),
						),
						'woostify_header_account_subbox_end'             => array(
							'title'       => __( 'Start After My Account Box', 'woostify-pro' ),
							'description' => __( 'woostify_header_account_subbox_end - Placement to add your content or snippet after my account box.', 'woostify-pro' ),
						),
						'woostify_header_account_subbox_start_default'             => array(
							'title'       => __( 'Start Before My Account Login', 'woostify-pro' ),
							'description' => __( 'woostify_header_account_subbox_start_default - Placement to add your content or snippet before my account login.', 'woostify-pro' ),
						),
						'woostify_header_account_subbox_start_logged_in'             => array(
							'title'       => __( 'Start Before My Account Logged In', 'woostify-pro' ),
							'description' => __( 'woostify_header_account_subbox_start_logged_in - Placement to add your content or snippet before my account logged in.', 'woostify-pro' ),
						),
						'woostify_header_account_subbox_before_logout'             => array(
							'title'       => __( 'Before My Account Logout', 'woostify-pro' ),
							'description' => __( 'woostify_header_account_subbox_before_logout - Placement to add your content or snippet before my account logout.', 'woostify-pro' ),
						),
					),
				);

				$hooks['woo-global'] = array(
					'title' => __( 'WooCommerce - Global', 'woostify-pro' ),
					'hooks' => array(
						'woocommerce_before_main_content'  => array(
							'title'       => __( 'Before Main Content', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before the WooCommerce main content.', 'woostify-pro' ),
						),
						'woocommerce_after_main_content'   => array(
							'title'       => __( 'After Main Content', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after the WooCommerce main content.', 'woostify-pro' ),
						),
						'woocommerce_sidebar'              => array(
							'title'       => __( 'Sidebar', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on WooCommerce sidebar action.', 'woostify-pro' ),
						),
						'woocommerce_breadcrumb'           => array(
							'title'       => __( 'Breadcrumb', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on WooCommerce breadcrumb action.', 'woostify-pro' ),
						),
						'woocommerce_before_template_part' => array(
							'title'       => __( 'Before Template Part', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce template part.', 'woostify-pro' ),
						),
						'woocommerce_after_template_part'  => array(
							'title'       => __( 'After Template Part', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce template part.', 'woostify-pro' ),
						),
					),
				);

				$hooks['woo-shop'] = array(
					'title' => __( 'WooCommerce - Shop', 'woostify-pro' ),
					'hooks' => array(
						'woostify_product_loop_item_action_item'  => array(
							'title'       => __( 'Product Loop Action', 'woostify-pro' ),
							'description' => __( 'woostify_product_loop_item_action_item - Placement to add your content on product loop action.', 'woostify-pro' ),
						),
						'woocommerce_archive_description'  => array(
							'title'       => __( 'Archive Description', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on archive_description action.', 'woostify-pro' ),
						),
						'woocommerce_before_shop_loop'     => array(
							'title'       => __( 'Before Shop Loop', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce shop loop.', 'woostify-pro' ),
						),
						'woocommerce_before_shop_loop_item_title' => array(
							'title'       => __( 'Before Shop Loop Item Title', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce shop loop item.', 'woostify-pro' ),
						),
						'woocommerce_after_shop_loop_item_title' => array(
							'title'       => __( 'After Shop Loop Item Title', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce shop loop item.', 'woostify-pro' ),
						),
						'woocommerce_after_shop_loop'      => array(
							'title'       => __( 'After Shop Loop', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce shop loop.', 'woostify-pro' ),
						),
					),
				);

				$hooks['woo-product'] = array(
					'title' => __( 'WooCommerce - Product', 'woostify-pro' ),
					'hooks' => array(
						'woostify_content_top'             => array(
							'title'       => __( 'Content Top Single Product', 'woostify-pro' ),
							'description' => __( 'woostify_content_top - Placement to add your content or snippet content top single product.', 'woostify-pro' ),
						),
						'woostify_product_images_box_end'             => array(
							'title'       => __( 'After Product Image', 'woostify-pro' ),
							'description' => __( 'woostify_product_images_box_end - Placement to add your content or snippet content after product image.', 'woostify-pro' ),
						),
						'woocommerce_product_after_tabs'             => array(
							'title'       => __( 'Custom After Product Tabs', 'woostify-pro' ),
							'description' => __( 'woocommerce_product_after_tabs - Placement to add your content or snippet content after Produc Tabs.', 'woostify-pro' ),
						),
						'woocommerce_before_single_product' => array(
							'title'       => __( 'Before Single Product', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce single product.', 'woostify-pro' ),
						),
						'woocommerce_before_single_product_summary' => array(
							'title'       => __( 'Before Single Product Summary', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce single product summary.', 'woostify-pro' ),
						),
						'woocommerce_single_product_summary' => array(
							'title'       => __( 'Single Product Summary', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on WooCommerce single product summary action.', 'woostify-pro' ),
						),
						'woocommerce_after_single_product_summary' => array(
							'title'       => __( 'After Single Product Summary', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce single product summary.', 'woostify-pro' ),
						),
						'woocommerce_simple_add_to_cart'   => array(
							'title'       => __( 'Simple Add To Cart', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on simple add to cart action.', 'woostify-pro' ),
						),
						'woocommerce_before_add_to_cart_form' => array(
							'title'       => __( 'Before Add To Cart Form', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce add to cart form.', 'woostify-pro' ),
						),
						'woocommerce_before_add_to_cart_button' => array(
							'title'       => __( 'Before Add To Cart Button', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce add to cart button.', 'woostify-pro' ),
						),
						'woocommerce_before_add_to_cart_quantity' => array(
							'title'       => __( 'Before Add To Cart Quantity', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce add to cart quantity.', 'woostify-pro' ),
						),
						'woocommerce_after_add_to_cart_quantity' => array(
							'title'       => __( 'After Add To Cart Quantity', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce add to cart quantity.', 'woostify-pro' ),
						),
						'woocommerce_after_add_to_cart_button' => array(
							'title'       => __( 'After Add To Cart Button', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce add to cart button.', 'woostify-pro' ),
						),
						'woocommerce_after_add_to_cart_form' => array(
							'title'       => __( 'After Add To Cart Form', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce add to cart form.', 'woostify-pro' ),
						),
						'woocommerce_product_meta_start'   => array(
							'title'       => __( 'Product Meta Start', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on WooCommerce product meta start action.', 'woostify-pro' ),
						),
						'woocommerce_product_meta_end'     => array(
							'title'       => __( 'Product Meta End', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on WooCommerce product meta end action.', 'woostify-pro' ),
						),
						'woocommerce_share'                => array(
							'title'       => __( 'Share', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on share action.', 'woostify-pro' ),
						),
						'woocommerce_after_single_product' => array(
							'title'       => __( 'After Single Product', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce single product.', 'woostify-pro' ),
						),
					),
				);

				$hooks['woo-cart'] = array(
					'title' => __( 'WooCommerce - Cart', 'woostify-pro' ),
					'hooks' => array(
						'woocommerce_check_cart_items'     => array(
							'title'       => __( 'Check Cart Items', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on check cart items action.', 'woostify-pro' ),
						),
						'woocommerce_cart_reset'           => array(
							'title'       => __( 'Cart Reset', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on cart reset.', 'woostify-pro' ),
						),
						'woocommerce_cart_updated'         => array(
							'title'       => __( 'Cart Updated', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on cart update.', 'woostify-pro' ),
						),
						'woocommerce_cart_is_empty'        => array(
							'title'       => __( 'Cart Is Empty', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on check cart is empty.', 'woostify-pro' ),
						),
						'woocommerce_before_calculate_totals' => array(
							'title'       => __( 'Before Calculate Totals', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce calculate totals.', 'woostify-pro' ),
						),
						'woocommerce_cart_calculate_fees'  => array(
							'title'       => __( 'Cart Calculate Fees', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on cart calculate fees.', 'woostify-pro' ),
						),
						'woocommerce_after_calculate_totals' => array(
							'title'       => __( 'After Calculate Totals', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce calculate totals.', 'woostify-pro' ),
						),
						'woocommerce_before_cart'          => array(
							'title'       => __( 'Before Cart', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce cart.', 'woostify-pro' ),
						),
						'woocommerce_before_cart_table'    => array(
							'title'       => __( 'Before Cart Table', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce cart table.', 'woostify-pro' ),
						),
						'woocommerce_before_cart_contents' => array(
							'title'       => __( 'Before Cart Contents', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce cart contents.', 'woostify-pro' ),
						),
						'woocommerce_cart_contents'        => array(
							'title'       => __( 'Cart Contents', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on cart contents.', 'woostify-pro' ),
						),
						'woocommerce_after_cart_contents'  => array(
							'title'       => __( 'After Cart Contents', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce cart contents.', 'woostify-pro' ),
						),
						'woocommerce_cart_coupon'          => array(
							'title'       => __( 'Cart Coupon', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on cart coupon.', 'woostify-pro' ),
						),
						'woocommerce_cart_actions'         => array(
							'title'       => __( 'Cart Actions', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on cart actions.', 'woostify-pro' ),
						),
						'woocommerce_after_cart_table'     => array(
							'title'       => __( 'After Cart Table', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce cart table.', 'woostify-pro' ),
						),
						'woocommerce_cart_collaterals'     => array(
							'title'       => __( 'Cart Collaterals', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on cart collaterals.', 'woostify-pro' ),
						),
						'woocommerce_before_cart_totals'   => array(
							'title'       => __( 'Before Cart Totals', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce cart totals.', 'woostify-pro' ),
						),
						'woocommerce_cart_totals_before_order_total' => array(
							'title'       => __( 'Cart Totals Before Order Total', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce order total.', 'woostify-pro' ),
						),
						'woocommerce_cart_totals_after_order_total' => array(
							'title'       => __( 'Cart Totals After Order Total', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce order total.', 'woostify-pro' ),
						),
						'woocommerce_proceed_to_checkout'  => array(
							'title'       => __( 'Proceed To Checkout', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on proceed to checkout action.', 'woostify-pro' ),
						),
						'woocommerce_after_cart_totals'    => array(
							'title'       => __( 'After Cart Totals', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce cart totals.', 'woostify-pro' ),
						),
						'woocommerce_after_cart'           => array(
							'title'       => __( 'After Cart', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce cart.', 'woostify-pro' ),
						),
					),
				);

				$hooks['woo-checkout'] = array(
					'title' => __( 'WooCommerce - Checkout', 'woostify-pro' ),
					'hooks' => array(
						'woocommerce_before_checkout_form' => array(
							'title'       => __( 'Before Checkout Form', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce checkout form.', 'woostify-pro' ),
						),
						'woocommerce_checkout_before_customer_details' => array(
							'title'       => __( 'Checkout Before Customer Details', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce customer details.', 'woostify-pro' ),
						),
						'woocommerce_checkout_after_customer_details' => array(
							'title'       => __( 'Checkout After Customer Details', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce customer details.', 'woostify-pro' ),
						),
						'woocommerce_checkout_billing'     => array(
							'title'       => __( 'Checkout Billing', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on checkout billing.', 'woostify-pro' ),
						),
						'woocommerce_before_checkout_billing_form' => array(
							'title'       => __( 'Before Checkout Billing Form', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce checkout billing form.', 'woostify-pro' ),
						),
						'woocommerce_after_checkout_billing_form' => array(
							'title'       => __( 'After Checkout Billing Form', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce checkout billing form.', 'woostify-pro' ),
						),
						'woocommerce_before_order_notes'   => array(
							'title'       => __( 'Before Order Notes', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce order notes.', 'woostify-pro' ),
						),
						'woocommerce_after_order_notes'    => array(
							'title'       => __( 'After Order Notes', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce order notes.', 'woostify-pro' ),
						),
						'woocommerce_checkout_shipping'    => array(
							'title'       => __( 'Checkout Shipping', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on checkout shipping action.', 'woostify-pro' ),
						),
						'woocommerce_checkout_before_order_review' => array(
							'title'       => __( 'Checkout Before Order Review', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce checkout order review.', 'woostify-pro' ),
						),
						'woocommerce_checkout_order_review' => array(
							'title'       => __( 'Checkout Order Review', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on checkout order review action.', 'woostify-pro' ),
						),
						'woocommerce_review_order_before_cart_contents' => array(
							'title'       => __( 'Review Order Before Cart Contents', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce review order cart contents.', 'woostify-pro' ),
						),
						'woocommerce_review_order_after_cart_contents' => array(
							'title'       => __( 'Review Order After Cart Contents', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce review order cart contents.', 'woostify-pro' ),
						),
						'woocommerce_review_order_before_order_total' => array(
							'title'       => __( 'Review Order Before Order Total', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce review order total.', 'woostify-pro' ),
						),
						'woocommerce_review_order_after_order_total' => array(
							'title'       => __( 'Review Order After Order Total', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce review order total.', 'woostify-pro' ),
						),
						'woocommerce_review_order_before_payment' => array(
							'title'       => __( 'Review Order Before Payment', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce order payment.', 'woostify-pro' ),
						),
						'woocommerce_review_order_before_submit' => array(
							'title'       => __( 'Review Order Before Submit', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce order submit.', 'woostify-pro' ),
						),
						'woocommerce_review_order_after_submit' => array(
							'title'       => __( 'Review Order After Submit', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce order submit.', 'woostify-pro' ),
						),
						'woocommerce_review_order_after_payment' => array(
							'title'       => __( 'Review Order After Payment', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce order payment.', 'woostify-pro' ),
						),
						'woocommerce_checkout_after_order_review' => array(
							'title'       => __( 'Checkout After Order Review', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce checkout order review.', 'woostify-pro' ),
						),
						'woocommerce_after_checkout_form'  => array(
							'title'       => __( 'After Checkout Form', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce checkout form.', 'woostify-pro' ),
						),
					),
				);

				$hooks['woo-account'] = array(
					'title' => __( 'WooCommerce - Account', 'woostify-pro' ),
					'hooks' => array(
						'woocommerce_before_account_navigation' => array(
							'title'       => __( 'Before Account Navigation', 'woostify-pro' ),
							'description' => __( 'Placement to add your content before WooCommerce account navigation.', 'woostify-pro' ),
						),
						'woocommerce_account_navigation' => array(
							'title'       => __( 'Account Navigation', 'woostify-pro' ),
							'description' => __( 'Placement to add your content on WooCommerce account navigation.', 'woostify-pro' ),
						),
						'woocommerce_after_account_navigation' => array(
							'title'       => __( 'After Account Navigation', 'woostify-pro' ),
							'description' => __( 'Placement to add your content after WooCommerce account navigation.', 'woostify-pro' ),
						),
					),
				);
			}

			$hooks['custom'] = array(
				'title' => __( 'Custom', 'woostify-pro' ),
				'hooks' => array(
					'wp_builder_custom_hook' => array(
						'title'       => __( 'Custom Hook', 'woostify-pro' ),
						'description' => __( 'Trigger your content or snippet on your custom action.', 'woostify-pro' ),
					),
				),
			);

			self::$hooks   = apply_filters( 'woostify_custom_layouts_hooks', $hooks );

			return self::$instance;
		}

		/**
		 * Constructor
		 */
		public function __construct() {
			add_action( 'save_post', array( $this, 'save_wp_builder_addon_advanced_hooks' ), 10, 2 );
			add_action( 'body_class', array( $this, 'body_class' ) );
		}

		public static function is_wp_builder_header_active(){

			$query_args = array(
				'post_type'  => 'wp_builder_addon',
				'posts_per_page'   => -1,
				'meta_query' => array(
					array(
						'key'   => 'woostify_wp_builder_addon_template',
						'value' => 'woostify_builder_header',
					),
				)
			);

			$posts = get_posts( $query_args );

			$status = false;

			if(!empty($posts)){
				$status = true;
			}

			return $status;
		}

		public static function is_wp_builder_footer_active(){

			$query_args = array(
				'post_type'  => 'wp_builder_addon',
				'posts_per_page'   => -1,
				'meta_query' => array(
					array(
						'key'   => 'woostify_wp_builder_addon_template',
						'value' => 'woostify_builder_footer',
					),
				)
			);

			$posts = get_posts( $query_args );

			$status = false;

			if(!empty($posts)){
				$status = true;
			}

			return $status;
		}

		/**
		 * Filter admin body class
		 *
		 * @since 1.0.0
		 *
		 * @param string $classes List of Admin Classes.
		 * @return string
		 */
		public function body_class( $classes ) {

			if ( is_woostify_builder_enabled( 'woostify_builder_content_hook' ) ) {
				$classes[] = 'woostify-builder-content-hook';
			}

			return $classes;
		}

		/**
		 * Render action hooks in editor post
		 */
        public function render_advanced_hooks( $post ) {

            $post_id = isset( $post )? $post->ID : get_the_ID();

            $action = get_post_meta( $post_id,'woostify_builder_advanced_hook_action', true );
			$action_custom = get_post_meta( $post_id,'woostify_builder_advanced_hook_action_custom', true );
			$action_priority = get_post_meta( $post_id, 'woostify_builder_advanced_hook_action_priority', true)? get_post_meta( $post_id, 'woostify_builder_advanced_hook_action_priority', true) : 10;
            $description = '';

			$action_custom_class = (!empty( $action_custom ) && $action === 'wp_builder_custom_hook' )? 'show' : '';
            ?>
			<div class="woostify-metabox-option">
				<div class="woostify-builder-advanced-hook-action">
					<p class="woostify-builder-advanced-hook-action-text"><strong><?php echo esc_html__( 'Placement', 'woostify-pro' ); ?></strong></p>	
					<select id="woostify-builder-advanced-hook-action" name="woostify_builder_advanced_hook_action" >
						<option value="0"><?php echo esc_html__( 'Select', 'woostify-pro' ); ?></option>
						<?php if ( is_array( self::$hooks ) && ! empty( self::$hooks ) ) : ?>
							<?php foreach ( self::$hooks as $hook_cat ) : ?>
							<optgroup label="<?php echo esc_attr( $hook_cat['title'] ); ?>" >
								<?php if ( is_array( $hook_cat['hooks'] ) && ! empty( $hook_cat['hooks'] ) ) : ?>
									<?php foreach ( $hook_cat['hooks'] as $key => $hook ) : ?>
										<?php
										if ( $key == $action && isset( $hook['description'] ) ) {
											$description = $hook['description'];
										}
										$hook_description = isset( $hook['description'] ) ? $hook['description'] : '';
										?>
									<option <?php selected( $key, $action ); ?> value="<?php echo esc_attr( $key ); ?>" data-desc="<?php echo esc_attr( $hook_description ); ?>"><?php echo esc_html( $hook['title'] ); ?></option>
								<?php endforeach; ?>
								<?php endif; ?>
							</optgroup>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
					<p class="description woostify-builder-advanced-hook-action-desc <?php echo ( '' == $description ) ? 'woostify-builder-action-no-desc' : ''; ?>"><?php echo esc_html( $description ); ?></p>
				</div>
			</div>
			<div class="woostify-metabox-option advanced-hook-action-custom <?php echo $action_custom_class; ?>">
				<div class="woostify-builder-advanced-hook-action-custom">
					<p class="woostify-builder-advanced-hook-action-custom-text"><strong><?php echo esc_html__( 'Custom Hook Name', 'woostify-pro' ); ?></strong></p>	
					<input id="woostify-builder-advanced-hook-action-custom" name="woostify_builder_advanced_hook_action_custom" type="text" class="woostify-builder-advanced-hook-action-custom" value="<?php echo esc_html( $action_custom ); ?>" placeholder="<?php echo __( 'Add your action','woostify-pro' ); ?>">
				</div>
			</div>
			<div class="woostify-metabox-option">
				<div class="woostify-builder-advanced-hook-action-priority">
					<p class="woostify-builder-advanced-hook-action-priority-text"><strong><?php echo esc_html__( 'Priority', 'woostify-pro' ); ?></strong></p>	
					<input id="woostify-builder-advanced-hook-action-priority" name="woostify_builder_advanced_hook_action_priority" type="number" min="1" class="woostify-builder-advanced-hook-action-priority" value="<?php echo esc_attr( $action_priority ); ?>" placeholder="Default: 10">
				</div>
			</div>
            <?php

        }

		/**
		 * save action hook settings
		 */
		public function save_wp_builder_addon_advanced_hooks( $post_id, $post ) {
			$post_type = get_post_type( $post_id );
			if ( 'wp_builder_addon' !== $post_type ) {
				return;
			}
			
			$nonce_key = 'woostify_metabox_settings_wp_builder_addon';

			// verify nonce
			if ( !isset( $_POST[$nonce_key] ) && !wp_verify_nonce( sanitize_text_field($_POST[$nonce_key]), $nonce_key ) ) {
				return 'nonce not verified';
			}

			// check permissions
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return 'cannot edit post';
			}

			$action = isset( $_POST['woostify_builder_advanced_hook_action'] ) ? $_POST['woostify_builder_advanced_hook_action'] : '';
			$action_custom = isset( $_POST['woostify_builder_advanced_hook_action_custom'] ) ? $_POST['woostify_builder_advanced_hook_action_custom'] : '';
			$action_priority = isset( $_POST['woostify_builder_advanced_hook_action_priority'] ) ? $_POST['woostify_builder_advanced_hook_action_priority'] : '';

			if( $action ){
				$action_custom = ( $action !== 'wp_builder_custom_hook')? '' : $action_custom;
				update_post_meta( $post_id, 'woostify_builder_advanced_hook_action', $action );
				update_post_meta( $post_id, 'woostify_builder_advanced_hook_action_custom', $action_custom);
			}

			if( $action_priority ){
				update_post_meta( $post_id, 'woostify_builder_advanced_hook_action_priority', $action_priority );
			}

		}

	}

	/**
	 * Kicking this off by calling 'get_instance()' method
	 */
	Woostify_Advanced_Hooks_Meta_Builder_Addons::get_instance();

}


