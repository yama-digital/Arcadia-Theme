/**
 * Remove notice
 *
 * @package woostify
 */

'use strict';

document.addEventListener(
	'DOMContentLoaded',
	function() {
		let noticeWrap = document.querySelectorAll( '.woocommerce-notices-wrapper' );
		
		if ( ! noticeWrap.length ) {
			return;
		}

		noticeWrap.forEach(
			function( notice ) {
				var elementWidget = notice.closest('.elementor-widget');
				if ( ! elementWidget ) {
					notice.remove();
				}
			}
		);
	}
);
