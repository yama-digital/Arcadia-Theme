<?php
/**
 * Thank you template
 *
 * @package Woostify Pro
 */

$wc_order = \Woostify_Woo_Builder::init()->get_wc_order();

get_header();

if ( $wc_order ) {
	if ( $wc_order->has_status( 'failed' ) ) {
		?>
		<div class="checkout-with-order-failed">
			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed">
				<?php esc_html_e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woostify-pro' ); ?>
			</p>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
				<a href="<?php echo esc_url( $wc_order->get_checkout_payment_url() ); ?>" class="button pay"><?php esc_html_e( 'Pay', 'woostify-pro' ); ?></a>

				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button pay"><?php esc_html_e( 'My account', 'woostify-pro' ); ?></a>
				<?php endif; ?>
			</p>
		</div>
		<?php
	} else {
		// Clear current cart items.
		WC()->cart->empty_cart( true );
		WC()->session->set( 'cart', array() );
		$order_key = apply_filters( 'woocommerce_thankyou_order_key', empty( $_GET['key'] ) ? '' : wc_clean( wp_unslash( $_GET['key'] ) ) );
		$verify_known_shoppers = apply_filters( 'woocommerce_order_received_verify_known_shoppers', true );
		$order_customer_id     = $wc_order->get_customer_id();
		// For non-guest orders, require the user to be logged in before showing this page.
		if ( $verify_known_shoppers && $order_customer_id && get_current_user_id() !== $order_customer_id ) {
			wc_get_template( 'checkout/order-received.php', array( 'order' => false ) );
			if ( hash_equals( $wc_order->get_order_key(), $order_key ) ) {
				wc_print_notice( esc_html__( 'Please log in to your account to view this order.', 'woostify-pro' ), 'notice' );
				woocommerce_login_form( array( 'redirect' => $wc_order->get_checkout_order_received_url() ) );
			}
		}else{
			if ( hash_equals( $wc_order->get_order_key(), $order_key ) ) {
				do_action( 'woostify_thankyou_page_content' );
			} else {
				wc_get_template( 'checkout/order-received.php', array( 'order' => false ) );
			}
		}
	}
} else {
	?>
	<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received">
		<?php esc_html_e( 'Thank you. Your order has been received.', 'woostify-pro' ); ?>
	</p>
	<?php
}

get_footer();
