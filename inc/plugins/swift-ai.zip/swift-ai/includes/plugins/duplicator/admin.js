jQuery(function($) {
    $('#dup-link-upgrade-highlight').parent().attr('target','_blank');
    $('#dup-link-upgrade-highlight').closest('li').addClass('dup-submenu-upgrade-highlight')
});