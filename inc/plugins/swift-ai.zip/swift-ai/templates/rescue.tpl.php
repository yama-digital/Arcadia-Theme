<p>
      <?php echo sprintf(esc_html__('Swift AI Code Optimizer is active. If you think this error is related to it, you can %sdisable it here%s.', 'swift3'), '<a href="' . admin_url('tools.php?page=swift3#configuration') . '" target="_blank">', '</a>');?><br>
      <?php echo sprintf(esc_html__('We also appreciate if you %ssend a bug report.%s', 'swift3'), '<a href="' . admin_url('tools.php?page=swift3#support') . '" target="_blank">', '</a>');?>
</p>