<?php
if (!defined('ABSPATH')){
      die('Keep Calm and Carry On');
}

?>

	<header class="page-header alignwide">
		<h1 class="page-title">Swift Test Page</h1>
	</header>

      <div id="swift-test-page-wrap">
            <span id="swift-connection-check">duplex</span>
            <img id="swift-image-check" src="<?php echo SWIFT3_URL?>/assets/images/wp.png">
      </div>

<?php

